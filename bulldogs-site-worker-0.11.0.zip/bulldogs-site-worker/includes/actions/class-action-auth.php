<?php
namespace Bulldogs\SiteWorker\Actions;

use Bulldogs\SiteWorker\Monitor\SiteSecret;

/**
 * Who may ask this site to do something: checks 1-4 of the actions route.
 *
 * ---------------------------------------------------------------------------
 * 🚨 WHY THE SIGNATURE IS NOT AN HMAC OF THE SITE SECRET
 * ---------------------------------------------------------------------------
 * The site secret lives in wp_options. A command keyed by it would mean anyone
 * who can READ this site's database can WRITE to it through this route - and the
 * write that hurts is a rollback to an older, vulnerable plugin, which turns a
 * read-only SQL injection into code execution. JetSmartFilters <= 3.8.3 carried
 * exactly such an injection (CVE-2026-56067) on most of the fleet a week before
 * this was designed. So commands are signed with an Ed25519 key the site does
 * NOT hold: the private half is a Vercel environment variable on the Control
 * Centre, the public half ships in this file, inside the checksummed release zip
 * the plugin's own updater verifies. A stolen site secret gives read, never write.
 *
 * The site secret is still required, as a second factor, so a leaked signing key
 * alone reaches no site whose secret it does not also hold. Decision D1, spec §4.2.
 *
 * ---------------------------------------------------------------------------
 * THE ORDER IS THE CONTRACT
 * ---------------------------------------------------------------------------
 * Checked in exactly this order, stopping at the first failure, with exactly these
 * status codes (CONTRACT.md, check order table):
 *
 *   1. x-bsw-secret          403 forbidden
 *   2. signature, RAW body   403 bad_signature
 *   3. shape                 422 invalid_request
 *      site                  403 wrong_site
 *      issued_at +-300 s     403 stale
 *   4. nonce unseen          409 replayed
 *
 * The signature is verified over the bytes WordPress received, BEFORE anything is
 * parsed. Verifying a re-encoded copy instead would make the check depend on PHP's
 * JSON encoder agreeing byte for byte with Node's, and a parser quirk would then
 * decide what was signed. Nothing in the body is looked at until the bytes are known
 * to be ours.
 *
 * The secret is checked first because it is the cheaper check and the one that
 * already answers the public internet on the findings route; an unauthenticated
 * caller gets the same 403 it gets there and learns nothing about this route.
 *
 * Steps 5-7 (action known, module on, params, rate, lock) belong to the controller,
 * because they are about what is being asked, not who is asking.
 */
class ActionAuth {
    /**
     * Ed25519 public keys, raw 32 bytes, base64. Up to two, so the signing key can
     * be rotated by a release (ship old + new, move the CC, then ship new only)
     * without a flag day on 50 sites.
     *
     * 🚨 PRODUCTION ONLY. The unit suite's key is passed to the constructor and is
     * never written here; a test key in this list would let anyone holding the
     * published test seed command every site.
     */
    public const PUBLIC_KEYS = [
        'L+P3EctL0QatbmdZAi/0J96LgXQeuVDO4FV0oLL62+k=',
    ];

    public const PROTOCOL = 1;

    /** Seconds `issued_at` may sit either side of the site clock. */
    public const WINDOW = 300;

    /** Seconds after `issued_at` a nonce is remembered for. Longer than the window on purpose; see ActionStore::claim_nonce(). */
    public const NONCE_TTL = 600;

    public const SIGNATURE_HEADER = 'x-bsw-signature';

    /** Bytes. Our largest real body is a few hundred; anything near this is not ours. */
    public const MAX_BODY = 65536;

    /** @var string[] Decoded 32-byte keys. */
    private array $keys = [];

    /**
     * @param string[]|null $public_keys Base64 keys. Null means PUBLIC_KEYS; only the
     *                                   unit suite passes anything else.
     */
    public function __construct(
        private SiteSecret $secret,
        private ActionStore $store,
        ?array $public_keys = null
    ) {
        foreach ( array_slice( $public_keys ?? self::PUBLIC_KEYS, 0, 2 ) as $b64 ) {
            $raw = is_string( $b64 ) ? base64_decode( $b64, true ) : false;
            if ( is_string( $raw ) && 32 === strlen( $raw ) ) {
                $this->keys[] = $raw;
            }
        }
    }

    /**
     * Run checks 1-4.
     *
     * @param string $home_host This site's host, already through normalise_host().
     * @return array{ok:true, request:array<string,mixed>}|array{ok:false, status:int, code:string, message:string}
     */
    public function check( string $secret, string $signature, string $raw, string $home_host ): array {
        // 1. The site secret, by the existing timing-safe check. Fails closed when
        //    no secret is stored, exactly as the findings route does.
        if ( ! $this->secret->verify( trim( $secret ) ) ) {
            return self::fail( 403, 'forbidden', 'A valid x-bsw-secret header is required.' );
        }

        // 2. The signature, over the raw bytes.
        if ( ! $this->signature_valid( trim( $signature ), $raw ) ) {
            return self::fail( 403, 'bad_signature', 'The request signature did not verify.' );
        }

        // 3. Shape, then which site, then when.
        $request = self::parse( $raw );
        if ( null === $request ) {
            return self::fail( 422, 'invalid_request', 'The request body is not a valid protocol 1 action.' );
        }

        // Exact match on the normalised host, never a suffix match: a request signed
        // for stedmansgarage.co.uk must not be accepted by stedmansgarage.co.uk.evil.com,
        // nor the other way round. An empty home host (home_url unreadable) matches
        // nothing, because normalise_host('') is '' and '' is refused by parse().
        if ( '' === $home_host || ! hash_equals( $home_host, self::normalise_host( $request['site'] ) ) ) {
            return self::fail( 403, 'wrong_site', 'This request was signed for a different site.' );
        }

        $now = $this->store->now();
        if ( abs( $now - $request['issued_at'] ) > self::WINDOW ) {
            return self::fail( 403, 'stale', 'The request is outside the accepted time window.' );
        }

        // 4. Single use. Recorded only now, after everything above has passed, so an
        //    unauthenticated caller cannot fill the nonce store.
        if ( ! $this->store->claim_nonce( $request['nonce'], $request['issued_at'] + self::NONCE_TTL ) ) {
            return self::fail( 409, 'replayed', 'This request has already been received.' );
        }

        return [ 'ok' => true, 'request' => $request ];
    }

    /**
     * The host normalisation both ends use, identical to the CC's normaliseDomain:
     * trim, lowercase, strip one leading `www.`, strip a trailing dot.
     */
    public static function normalise_host( string $host ): string {
        $host = strtolower( trim( $host ) );
        if ( str_starts_with( $host, 'www.' ) ) {
            $host = substr( $host, 4 );
        }
        return rtrim( $host, '.' );
    }

    /** This site's host from a home URL, normalised. '' when it cannot be read. */
    public static function host_of( string $home_url ): string {
        $host = parse_url( $home_url, PHP_URL_HOST );
        return is_string( $host ) ? self::normalise_host( $host ) : '';
    }

    private function signature_valid( string $signature_b64, string $raw ): bool {
        if ( [] === $this->keys || '' === $signature_b64 || '' === $raw || strlen( $raw ) > self::MAX_BODY ) {
            return false;
        }

        $signature = base64_decode( $signature_b64, true );
        if ( ! is_string( $signature ) || 64 !== strlen( $signature ) ) {
            return false;
        }

        if ( ! function_exists( 'sodium_crypto_sign_verify_detached' ) ) {
            // WordPress ships sodium_compat (5.2+) but only loads it on demand.
            // Missing both is a refusal, never a pass.
            if ( defined( 'ABSPATH' ) && defined( 'WPINC' ) && is_readable( ABSPATH . WPINC . '/sodium_compat/autoload.php' ) ) {
                require_once ABSPATH . WPINC . '/sodium_compat/autoload.php';
            }
            if ( ! function_exists( 'sodium_crypto_sign_verify_detached' ) ) {
                return false;
            }
        }

        foreach ( $this->keys as $key ) {
            try {
                if ( sodium_crypto_sign_verify_detached( $signature, $raw, $key ) ) {
                    return true;
                }
            } catch ( \Throwable $e ) {
                // A malformed input is a failed verification, not an error page.
                continue;
            }
        }
        return false;
    }

    /**
     * The body, if it is a well-formed protocol 1 action. Nothing is cast: a field
     * of the wrong type is a malformed request, not a value to be coerced.
     *
     * @return array{v:int, site:string, install:string, action:string, id:string, issued_at:int, nonce:string, params:array<string,mixed>}|null
     */
    public static function parse( string $raw ): ?array {
        if ( strlen( $raw ) > self::MAX_BODY ) {
            return null;
        }
        $body = json_decode( $raw, true, 16 );
        if ( ! is_array( $body ) || array_is_list( $body ) && [] !== $body ) {
            return null;
        }

        if ( ! isset( $body['v'] ) || 1 !== $body['v'] ) {
            return null;
        }
        foreach ( [ 'site', 'install', 'action', 'id', 'nonce' ] as $field ) {
            if ( ! isset( $body[ $field ] ) || ! is_string( $body[ $field ] ) || '' === $body[ $field ] || strlen( $body[ $field ] ) > 255 ) {
                return null;
            }
        }
        if ( ! isset( $body['issued_at'] ) || ! is_int( $body['issued_at'] ) ) {
            return null;
        }
        // The action id is echoed back and used as a record key, so it is held to a
        // plain character set: no markup, no path separators, nothing to escape.
        if ( 1 !== preg_match( '/^[A-Za-z0-9_\-]{1,100}$/', $body['id'] ) ) {
            return null;
        }
        $nonce = base64_decode( $body['nonce'], true );
        if ( ! is_string( $nonce ) || 16 !== strlen( $nonce ) ) {
            return null;
        }
        // `{}` decodes to []; anything that is not an object is malformed.
        if ( ! array_key_exists( 'params', $body ) || ! is_array( $body['params'] ) || ( [] !== $body['params'] && array_is_list( $body['params'] ) ) ) {
            return null;
        }

        return [
            'v'         => 1,
            'site'      => $body['site'],
            'install'   => $body['install'],
            'action'    => $body['action'],
            'id'        => $body['id'],
            'issued_at' => $body['issued_at'],
            'nonce'     => $body['nonce'],
            'params'    => $body['params'],
        ];
    }

    /** @return array{ok:false, status:int, code:string, message:string} */
    private static function fail( int $status, string $code, string $message ): array {
        return [ 'ok' => false, 'status' => $status, 'code' => $code, 'message' => $message ];
    }
}
