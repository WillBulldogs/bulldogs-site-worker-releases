<?php
namespace Bulldogs\SiteWorker\Actions;

/**
 * Everything the actions layer remembers between requests: seen nonces, the site
 * lock, the last `sync`, the last 20 action records and the backup index.
 *
 * ---------------------------------------------------------------------------
 * ITS OWN OPTION ROW, NOT A KEY IN Settings::OPTION
 * ---------------------------------------------------------------------------
 * Settings::OPTION is the row Modules::migrate() reads to decide whether a site
 * was running a pre-registry build, and the row every module's configuration
 * lives in. This store is written on every action and by stage 2 after the
 * response has gone, so churn here must never be able to race or corrupt the row
 * that decides whether consent is on. A separate row, not autoloaded, so a site
 * that never runs an action pays nothing on a page load either.
 *
 * ---------------------------------------------------------------------------
 * FAIL-CLOSED READING
 * ---------------------------------------------------------------------------
 * The row is restored from backups and can be hand-edited, so every section is
 * validated on the way in and anything malformed is dropped rather than cast.
 * The direction matters per section: a corrupt nonce list is read as EMPTY (a
 * replay inside the 300 s window is still stopped by the timestamp check, and the
 * site secret plus the signature still have to be valid), a corrupt lock is read
 * as FREE only once its expiry cannot be read (so a junk lock cannot wedge a site
 * forever), and a corrupt backup entry is dropped, which can only ever REFUSE a
 * rollback, never allow one.
 *
 * ---------------------------------------------------------------------------
 * ⚠️ THE LOCK IS NOT A MUTEX, AND DOES NOT NEED TO BE
 * ---------------------------------------------------------------------------
 * It is a read-modify-write of an option. WordPress has no atomic option insert
 * (add_option() is INSERT ... ON DUPLICATE KEY UPDATE), so two requests landing in
 * the same millisecond could both see it free. The only caller is the CC
 * executor, which is strictly serial across the whole fleet (spec §7.2), so the
 * lock exists to refuse a SECOND, MISTAKEN request while the first is running -
 * a double-clicked button, a retry after a timeout - not to arbitrate a race the
 * caller never creates. The nonce check has the same shape and the same caller.
 */
class ActionStore {
    public const OPTION = 'bulldogs_sw_actions';

    /** Kept records. The spec's number; enough for the CC to read stage 2 of the last run. */
    public const MAX_RECORDS = 20;

    /** Bound on stored nonces, so a flood of valid-but-refused requests cannot grow the row without limit. */
    private const MAX_NONCES = 500;

    /** @var \Closure(): int */
    private \Closure $clock;

    public function __construct( ?\Closure $clock = null ) {
        $this->clock = $clock ?? static fn (): int => time();
    }

    public function now(): int {
        return ( $this->clock )();
    }

    // -----------------------------------------------------------------------
    // Nonces
    // -----------------------------------------------------------------------

    /**
     * Record a nonce as used. False when it has been seen and has not expired.
     *
     * Kept until `issued_at + 600` (ActionAuth passes the expiry), not for the 300
     * second window alone: a nonce forgotten the moment its window closed could be
     * replayed with a request whose `issued_at` sits at the far edge of the window.
     */
    public function claim_nonce( string $nonce, int $expires ): bool {
        $now   = $this->now();
        $state = $this->state();

        $nonces = [];
        foreach ( $state['nonces'] as $seen => $until ) {
            if ( $until > $now ) {
                $nonces[ $seen ] = $until;
            }
        }

        $key = hash( 'sha256', $nonce );
        if ( isset( $nonces[ $key ] ) ) {
            return false;
        }

        $nonces[ $key ] = $expires;
        if ( count( $nonces ) > self::MAX_NONCES ) {
            asort( $nonces );
            $nonces = array_slice( $nonces, -self::MAX_NONCES, null, true );
        }

        $state['nonces'] = $nonces;
        $this->save( $state );
        return true;
    }

    // -----------------------------------------------------------------------
    // Lock
    // -----------------------------------------------------------------------

    /** Take the site lock for $ttl seconds. False when another action holds it. */
    public function acquire_lock( string $id, string $action, int $ttl ): bool {
        $now   = $this->now();
        $state = $this->state();
        $lock  = $state['lock'];

        if ( null !== $lock && $lock['expires'] > $now && $lock['id'] !== $id ) {
            return false;
        }

        $state['lock'] = [ 'id' => $id, 'action' => $action, 'expires' => $now + $ttl ];
        $this->save( $state );
        return true;
    }

    /** Move the expiry of a lock this action holds. A lock someone else holds is left alone. */
    public function extend_lock( string $id, int $ttl ): void {
        $state = $this->state();
        if ( null === $state['lock'] || $state['lock']['id'] !== $id ) {
            return;
        }
        $state['lock']['expires'] = $this->now() + $ttl;
        $this->save( $state );
    }

    public function release_lock( string $id ): void {
        $state = $this->state();
        if ( null !== $state['lock'] && $state['lock']['id'] === $id ) {
            $state['lock'] = null;
            $this->save( $state );
        }
    }

    /** @return array{id:string, action:string, expires:int}|null The live lock, or null. */
    public function lock(): ?array {
        $lock = $this->state()['lock'];
        return null !== $lock && $lock['expires'] > $this->now() ? $lock : null;
    }

    // -----------------------------------------------------------------------
    // Sync rate
    // -----------------------------------------------------------------------

    public function last_sync(): int {
        return $this->state()['last_sync'];
    }

    public function mark_sync(): void {
        $state              = $this->state();
        $state['last_sync'] = $this->now();
        $this->save( $state );
    }

    // -----------------------------------------------------------------------
    // Records
    // -----------------------------------------------------------------------

    /**
     * Open a record for an action that has just taken the lock.
     *
     * `deadline` is when stage 1 counts as dead if it has not finished - the lock
     * expiry, by construction, so "the lock expired and nobody finished" is a
     * statement about the record and not a guess.
     */
    public function start_record( string $id, string $action, int $deadline ): void {
        $this->put_record(
            $id,
            [
                'of'       => $id,
                'action'   => $action,
                'stage'    => 1,
                'started'  => $this->now(),
                'finished' => null,
                'deadline' => $deadline,
                'result'   => null,
                'stage2'   => null,
            ]
        );
    }

    /**
     * Stage 1 is done. $stage2 is `queued` or `skipped`; a queued stage 2 gets its
     * own deadline, because the stage 2 lock is the one that is now running.
     *
     * @param array<string, mixed> $result Already sanitised.
     */
    public function finish_stage1( string $id, array $result, string $stage2, int $stage2_deadline = 0 ): void {
        $record = $this->record( $id );
        if ( null === $record ) {
            return;
        }
        $now                = $this->now();
        $record['result']   = $result;
        $record['stage1_finished'] = $now;
        if ( 'queued' === $stage2 ) {
            $record['stage']    = 2;
            $record['deadline'] = $stage2_deadline;
            $record['stage2']   = self::stage2_blank( 'queued' );
        } else {
            $record['finished'] = $now;
            $record['stage2']   = self::stage2_blank( 'skipped' );
        }
        $this->put_record( $id, $record );
    }

    /** @param array<string, mixed> $fields Merged into the stage 2 sub-record. */
    public function update_stage2( string $id, array $fields, bool $finished = false ): void {
        $record = $this->record( $id );
        if ( null === $record ) {
            return;
        }
        $stage2 = is_array( $record['stage2'] ) ? $record['stage2'] : self::stage2_blank( 'running' );
        foreach ( $fields as $key => $value ) {
            $stage2[ $key ] = $value;
        }
        if ( $finished ) {
            $now                = $this->now();
            $stage2['state']    = 'done';
            $stage2['finished'] = $now;
            $record['finished'] = $now;
        }
        $record['stage2'] = $stage2;
        $this->put_record( $id, $record );
    }

    /**
     * Mark an unfinished record dead now, rather than at its deadline. For a stage
     * that threw: it did not finish, and saying so straight away is more useful than
     * reading `running` for half an hour.
     */
    public function expire( string $id ): void {
        $record = $this->record( $id );
        if ( null === $record || null !== ( $record['finished'] ?? null ) ) {
            return;
        }
        $record['deadline'] = $this->now() - 1;
        $this->put_record( $id, $record );
    }

    /** @return array<string, mixed>|null The raw stored record. */
    public function record( string $id ): ?array {
        foreach ( $this->state()['records'] as $record ) {
            if ( $record['of'] === $id ) {
                return $record;
            }
        }
        return null;
    }

    /**
     * One record as `status` reports it, with the state worked out from the clock.
     *
     * 🚨 A STAGE THAT STARTED AND NEVER FINISHED IS `died`, NEVER `done`. A host
     * that kills long requests is exactly the case where the cache cycle silently
     * did not happen, and a record still saying `queued` or `running` hours later
     * would be read as "still going" forever. Past its deadline, unfinished is dead.
     *
     * @return array<string, mixed>
     */
    public function view( string $id ): array {
        $record = $this->record( $id );
        if ( null === $record ) {
            return [ 'of' => $id, 'action' => null, 'state' => 'unknown_id', 'stage' => null, 'started' => null, 'finished' => null, 'result' => null, 'stage2' => null ];
        }
        return self::present( $record, $this->now() );
    }

    /** @return array<int, array{id:string, action:string, state:string, finished:?int}> Newest first. */
    public function recent(): array {
        $now = $this->now();
        $out = [];
        foreach ( array_reverse( $this->state()['records'] ) as $record ) {
            $view  = self::present( $record, $now );
            $out[] = [
                'id'       => $record['of'],
                'action'   => $record['action'],
                'state'    => $view['state'],
                'finished' => $view['finished'],
            ];
        }
        return $out;
    }

    /**
     * Pure: a stored record plus the time, in; the reported record, out.
     *
     * @param array<string, mixed> $record
     * @return array<string, mixed>
     */
    public static function present( array $record, int $now ): array {
        $deadline = is_int( $record['deadline'] ?? null ) ? $record['deadline'] : 0;
        $stage    = 2 === ( $record['stage'] ?? 1 ) ? 2 : 1;
        $finished = is_int( $record['finished'] ?? null ) ? $record['finished'] : null;
        $stage2   = is_array( $record['stage2'] ?? null ) ? $record['stage2'] : null;

        if ( null !== $finished ) {
            $state = 'done';
        } elseif ( $now > $deadline ) {
            $state = 'died';
            if ( null !== $stage2 && in_array( $stage2['state'] ?? '', [ 'queued', 'running' ], true ) ) {
                $stage2['state'] = 'died';
            }
        } else {
            $state = 'running';
        }

        return [
            'of'       => $record['of'],
            'action'   => $record['action'],
            'state'    => $state,
            'stage'    => $stage,
            'started'  => is_int( $record['started'] ?? null ) ? $record['started'] : null,
            'finished' => $finished,
            'result'   => is_array( $record['result'] ?? null ) ? $record['result'] : null,
            'stage2'   => $stage2,
        ];
    }

    /** @return array<string, mixed> */
    private static function stage2_blank( string $state ): array {
        return [
            'state'             => $state,
            'urls_warmed'       => 0,
            'urls_cut'          => 0,
            'min_missing'       => 0,
            'cache'             => null,
            'elementor_flushed' => false,
            'finished'          => null,
        ];
    }

    /** @param array<string, mixed> $record */
    private function put_record( string $id, array $record ): void {
        $state   = $this->state();
        $records = [];
        foreach ( $state['records'] as $existing ) {
            if ( $existing['of'] !== $id ) {
                $records[] = $existing;
            }
        }
        $records[]        = $record;
        $state['records'] = array_slice( $records, -self::MAX_RECORDS );
        $this->save( $state );
    }

    // -----------------------------------------------------------------------
    // Backup index. Backups owns what goes in it; this only keeps it.
    // -----------------------------------------------------------------------

    /** @return array<int, array<string, mixed>> */
    public function backups(): array {
        return $this->state()['backups'];
    }

    /** @param array<int, array<string, mixed>> $backups */
    public function set_backups( array $backups ): void {
        $state            = $this->state();
        $state['backups'] = array_values( $backups );
        $this->save( $state );
    }

    // -----------------------------------------------------------------------
    // The row
    // -----------------------------------------------------------------------

    /**
     * The stored row, validated section by section.
     *
     * @return array{nonces:array<string,int>, lock:?array{id:string,action:string,expires:int}, last_sync:int, records:array<int,array<string,mixed>>, backups:array<int,array<string,mixed>>}
     */
    private function state(): array {
        $raw = function_exists( 'get_option' ) ? get_option( self::OPTION, [] ) : [];
        $raw = is_array( $raw ) ? $raw : [];

        $nonces = [];
        foreach ( is_array( $raw['nonces'] ?? null ) ? $raw['nonces'] : [] as $key => $until ) {
            if ( is_string( $key ) && is_int( $until ) ) {
                $nonces[ $key ] = $until;
            }
        }

        $lock = null;
        $l    = $raw['lock'] ?? null;
        if ( is_array( $l ) && is_string( $l['id'] ?? null ) && is_string( $l['action'] ?? null ) && is_int( $l['expires'] ?? null ) ) {
            $lock = [ 'id' => $l['id'], 'action' => $l['action'], 'expires' => $l['expires'] ];
        }

        $records = [];
        foreach ( is_array( $raw['records'] ?? null ) ? $raw['records'] : [] as $record ) {
            if ( is_array( $record ) && is_string( $record['of'] ?? null ) && is_string( $record['action'] ?? null ) ) {
                $records[] = $record;
            }
        }

        $backups = [];
        foreach ( is_array( $raw['backups'] ?? null ) ? $raw['backups'] : [] as $backup ) {
            if (
                is_array( $backup )
                && is_string( $backup['id'] ?? null )
                && is_string( $backup['file'] ?? null )
                && is_string( $backup['version'] ?? null )
                && is_string( $backup['path'] ?? null )
                && is_int( $backup['created'] ?? null )
            ) {
                $backups[] = $backup;
            }
        }

        return [
            'nonces'    => $nonces,
            'lock'      => $lock,
            'last_sync' => is_int( $raw['last_sync'] ?? null ) ? $raw['last_sync'] : 0,
            'records'   => $records,
            'backups'   => $backups,
        ];
    }

    /** @param array<string, mixed> $state */
    private function save( array $state ): void {
        if ( function_exists( 'update_option' ) ) {
            // Not autoloaded: nothing on a page load reads this.
            update_option( self::OPTION, $state, false );
        }
    }
}
