<?php
namespace Bulldogs\SiteWorker\Actions;

/**
 * Asks Crocoblock what is current for the installed Jet plugins, outside wp-admin.
 *
 * ---------------------------------------------------------------------------
 * WHY AN ADAPTER AT ALL
 * ---------------------------------------------------------------------------
 * The Jet Dashboard hooks its update check in wp-admin only, so wp-cli, WP-Cron
 * and this REST route never see a Jet update. On 22 Oct 2026 `wp plugin list
 * --update=available` said `none` on all 21 sites carrying Jet plugins, every one
 * of them behind, and the vendor download had to be rebuilt by hand. This class is
 * that hand-built step, read off the working sweep scripts (`jet-probe.php`,
 * `jet-update.php`) and nothing else.
 *
 * It does what the dashboard would have done had it loaded: during WordPress's own
 * update check it writes a `response` entry, with the vendor's package, for each
 * installed Jet plugin behind the vendor's version - into the SAME transient, so the
 * Plugins screen, the core upgrader and UpdateReport all see it. It never writes
 * `no_update`; an up-to-date Jet plugin reads `current` through UpdaterWitness,
 * which recognises this class's `inject` callback (see UpdaterWitness::owners()).
 *
 * ---------------------------------------------------------------------------
 * 🚨 THE PACKAGE URL IS THE LICENCE KEY
 * ---------------------------------------------------------------------------
 * `Utils::package_url()` puts `license=<key>` in the query string. It goes into the
 * transient because that is where WordPress keeps packages, and nowhere else. This
 * class never returns it to the action layer except through package(), whose only
 * callers hand it straight to PackageCheck or the upgrader, and every string the
 * action layer emits passes OutputSanitiser.
 *
 * And it is PINNED: a package is used only when its host is the host of
 * `Utils::get_api_url()`. A package URL on any other host is treated as no package
 * at all, so a tampered option or a vendor bug cannot point the upgrader somewhere
 * else.
 */
class CrocoblockAdapter {
    public const STATUS_RAN    = 'ran';
    public const STATUS_ABSENT = 'absent';
    public const STATUS_ERROR  = 'error';

    /** The dashboard's own copy ships inside each Jet plugin; any one will do. */
    private const UTILS_GLOB = '/jet-*/framework/jet-dashboard/inc/utils.php';

    private const UTILS_CLASS = 'Jet_Dashboard\\Utils';

    /** Bytes read from the vendor API at most. Its real answer is a few tens of KB. */
    public const MAX_API_BYTES = 1048576;

    /** @var array<string, string>|null Plugin file => vendor's latest version. Null until probed or on failure. */
    private ?array $vendor = null;

    private bool $probed = false;

    private string $status = self::STATUS_ABSENT;

    /** @var array<string, true> Plugin directories the vendor answered for, in the last probe. */
    private array $answered = [];

    /**
     * @param object|null $utils Anything with get_api_url() and package_url( $file, $version ).
     *                           Null means the real \Jet_Dashboard\Utils, loaded on demand.
     */
    public function __construct( private Environment $env, private ?object $utils = null ) {}

    /** Is there a Jet Dashboard on this site we can talk through? */
    public function available(): bool {
        return null !== $this->utils();
    }

    /** `ran`, `absent` or `error`, for the last probe. */
    public function status(): string {
        return $this->status;
    }

    /** Forget the last answer, so the next check asks the vendor again. */
    public function reset(): void {
        $this->vendor   = null;
        $this->probed   = false;
        $this->answered = [];
        $this->status   = self::STATUS_ABSENT;
    }

    /** The host packages must come from. '' when the API URL cannot be read, which pins to nothing. */
    public function pinned_host(): string {
        $utils = $this->utils();
        if ( null === $utils ) {
            return '';
        }
        try {
            $api = $utils->get_api_url();
        } catch ( \Throwable $e ) {
            return '';
        }
        if ( ! is_string( $api ) || ! self::is_https( $api ) ) {
            // Pins to nothing, so no package is ever accepted.
            return '';
        }
        $host = parse_url( $api, PHP_URL_HOST );
        return is_string( $host ) ? strtolower( $host ) : '';
    }

    /**
     * The vendor's latest version for each Jet plugin it knows, asked once per check.
     *
     * @return array<string, string>|null Null when the vendor could not be asked.
     */
    public function probe(): ?array {
        if ( $this->probed ) {
            return $this->vendor;
        }
        $this->probed = true;

        $utils = $this->utils();
        if ( null === $utils ) {
            $this->status = self::STATUS_ABSENT;
            return null;
        }

        try {
            $api = $utils->get_api_url();
        } catch ( \Throwable $e ) {
            $api = null;
        }
        // HTTPS only. The answer decides what gets offered as an update, and over
        // plain HTTP anyone on the path could rewrite it.
        if ( ! is_string( $api ) || ! self::is_https( $api ) || ! function_exists( 'wp_remote_get' ) ) {
            $this->status = self::STATUS_ERROR;
            return null;
        }

        $url      = function_exists( 'add_query_arg' )
            ? add_query_arg( [ 'action' => 'get_plugins_data' ], $api )
            : $api . ( str_contains( $api, '?' ) ? '&' : '?' ) . 'action=get_plugins_data';
        $response = wp_remote_get( $url, [ 'timeout' => 30, 'limit_response_size' => self::MAX_API_BYTES ] );

        if ( function_exists( 'is_wp_error' ) && is_wp_error( $response ) ) {
            $this->status = self::STATUS_ERROR;
            return null;
        }
        $code = function_exists( 'wp_remote_retrieve_response_code' ) ? wp_remote_retrieve_response_code( $response ) : 0;
        $body = function_exists( 'wp_remote_retrieve_body' ) ? wp_remote_retrieve_body( $response ) : '';
        if ( 200 !== ( is_scalar( $code ) ? (int) $code : 0 ) || ! is_string( $body ) ) {
            $this->status = self::STATUS_ERROR;
            return null;
        }

        $decoded = json_decode( $body, true );
        $data    = is_array( $decoded ) && isset( $decoded['data'] ) && is_array( $decoded['data'] ) ? $decoded['data'] : null;
        if ( null === $data ) {
            $this->status = self::STATUS_ERROR;
            return null;
        }

        // `slug` in this API is the plugin FILE (jet-engine/jet-engine.php), not the
        // directory. Read off jet-probe.php's output on 22 Oct.
        $vendor = [];
        foreach ( $data as $row ) {
            if ( ! is_array( $row ) ) {
                continue;
            }
            $file    = $row['slug'] ?? null;
            $version = $row['version'] ?? null;
            if ( is_string( $file ) && is_string( $version ) && '' !== $version && 1 === preg_match( '#^[a-z0-9\-_]+/[a-z0-9\-_.]+\.php$#i', $file ) ) {
                $vendor[ $file ] = $version;
            }
        }

        $this->vendor = $vendor;
        $this->status = self::STATUS_RAN;

        foreach ( $this->env->installed_plugins() as $file => $meta ) {
            if ( isset( $vendor[ $file ] ) ) {
                $this->answered[ dirname( $file ) ] = true;
            }
        }

        return $vendor;
    }

    /** Is this installed plugin one the vendor answers for? Probes if it has not yet. */
    public function covers( string $file ): bool {
        $vendor = $this->probe();
        return null !== $vendor && isset( $vendor[ $file ] );
    }

    /** The vendor's latest for one plugin, or null. */
    public function latest( string $file ): ?string {
        $vendor = $this->probe();
        return null !== $vendor ? ( $vendor[ $file ] ?? null ) : null;
    }

    /**
     * Plugin directories the vendor answered for in the last probe. What
     * UpdaterWitness records as this updater's owners, so an up-to-date Jet plugin
     * reads `current`. Empty when the probe failed, which leaves them unchecked.
     *
     * @return array<int, string>
     */
    public function answered_dirs(): array {
        $out = array_keys( $this->answered );
        sort( $out );
        return $out;
    }

    /**
     * The vendor's package for one plugin: the latest when $version is false, an
     * exact version otherwise.
     *
     * @return array{url:?string, reason:?string} `url` null with a reason: `none`
     *         (empty answer, i.e. no licence key on this site) or `host_mismatch`.
     */
    public function package( string $file, string|false $version = false ): array {
        $utils = $this->utils();
        if ( null === $utils ) {
            return [ 'url' => null, 'reason' => 'none' ];
        }
        try {
            $url = $utils->package_url( $file, $version );
        } catch ( \Throwable $e ) {
            return [ 'url' => null, 'reason' => 'none' ];
        }
        if ( ! is_string( $url ) || '' === $url ) {
            return [ 'url' => null, 'reason' => 'none' ];
        }

        $pinned = $this->pinned_host();
        $host   = parse_url( $url, PHP_URL_HOST );
        // 🚨 HTTPS ONLY. A plain-HTTP package is a code-injection route for anyone on
        // the path, and the URL carries the licence key in clear text.
        if ( '' === $pinned || ! is_string( $host ) || strtolower( $host ) !== $pinned || ! self::is_https( $url ) ) {
            return [ 'url' => null, 'reason' => 'host_mismatch' ];
        }
        return [ 'url' => $url, 'reason' => null ];
    }

    /**
     * Filter on `pre_set_site_transient_update_plugins`: add a `response` entry for
     * each installed Jet plugin behind the vendor. The value passes through
     * untouched for anything else, and on any failure.
     *
     * @param mixed $value
     * @return mixed
     */
    public function inject( $value ) {
        try {
            if ( ! is_object( $value ) ) {
                return $value;
            }
            $vendor = $this->probe();
            if ( null === $vendor ) {
                return $value;
            }
            $response  = isset( $value->response ) && is_array( $value->response ) ? $value->response : [];
            $installed = $this->env->installed_plugins();

            foreach ( $vendor as $file => $latest ) {
                $have = $installed[ $file ]['version'] ?? null;
                if ( ! isset( $installed[ $file ] ) || null === $have || ! version_compare( $latest, $have, '>' ) ) {
                    continue;
                }
                $package           = $this->package( $file, false );
                $response[ $file ] = (object) [
                    'id'          => 'crocoblock/' . dirname( $file ),
                    'slug'        => dirname( $file ),
                    'plugin'      => $file,
                    'new_version' => $latest,
                    'package'     => $package['url'] ?? '',
                    'url'         => '',
                ];
                if ( isset( $value->no_update ) && is_array( $value->no_update ) ) {
                    unset( $value->no_update[ $file ] );
                }
            }
            $value->response = $response;
        } catch ( \Throwable $e ) {
            OutputSanitiser::log( 'crocoblock adapter failed: ' . $e->getMessage() );
        }
        return $value;
    }

    public static function is_https( string $url ): bool {
        $scheme = parse_url( $url, PHP_URL_SCHEME );
        $host   = parse_url( $url, PHP_URL_HOST );
        return is_string( $scheme ) && 'https' === strtolower( $scheme ) && is_string( $host ) && '' !== $host;
    }

    /** Attach for the duration of one update check. */
    public function attach(): void {
        if ( function_exists( 'add_filter' ) ) {
            // Before UpdaterWitness (PHP_INT_MAX), so the witness sees this callback.
            add_filter( 'pre_set_site_transient_update_plugins', [ $this, 'inject' ], 20 );
        }
    }

    public function detach(): void {
        if ( function_exists( 'remove_filter' ) ) {
            remove_filter( 'pre_set_site_transient_update_plugins', [ $this, 'inject' ], 20 );
        }
    }

    /**
     * The injected utils, or the real Jet Dashboard Utils loaded the way the sweep
     * scripts loaded it: the first copy found, once.
     */
    private function utils(): ?object {
        if ( null !== $this->utils ) {
            return $this->utils;
        }
        if ( ! class_exists( self::UTILS_CLASS ) ) {
            $dir = $this->env->plugins_dir();
            if ( '' === $dir ) {
                return null;
            }
            foreach ( glob( $dir . self::UTILS_GLOB ) ?: [] as $file ) {
                try {
                    require_once $file;
                } catch ( \Throwable $e ) {
                    OutputSanitiser::log( 'could not load the Jet Dashboard utilities: ' . $e->getMessage() );
                }
                break;
            }
            if ( ! class_exists( self::UTILS_CLASS ) ) {
                return null;
            }
        }
        $this->utils = new class() {
            public function get_api_url() {
                return \Jet_Dashboard\Utils::get_api_url();
            }
            public function package_url( string $file, $version ) {
                return \Jet_Dashboard\Utils::package_url( $file, $version );
            }
        };
        return $this->utils;
    }
}
