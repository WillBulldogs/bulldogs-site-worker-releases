<?php
namespace Bulldogs\SiteWorker\Actions;

/**
 * The WordPress calls the actions layer makes that change or read the install:
 * the upgrader, the update check, plugin headers, activation.
 *
 * ---------------------------------------------------------------------------
 * WHY THESE ARE GATHERED INTO ONE CLASS
 * ---------------------------------------------------------------------------
 * Every decision about an update - policy, ordering, the version assertion, when
 * to roll back - is made by UpdateRunner, and those decisions are the part that
 * must be tested. The calls below cannot run without a real WordPress, so they
 * live here, each one small enough to read, and the suite stands in a subclass
 * that records what was asked. Nothing in this class decides anything.
 *
 * ⚠️ NONE OF THIS IS LOADED ON A REST REQUEST BY DEFAULT. The upgrader, get_plugins()
 * and wp_clean_plugins_cache() live in wp-admin/includes, which WordPress only
 * loads in wp-admin. load_admin() requires the files the 22 Oct sweep scripts
 * needed under `wp eval`, which is the same situation.
 */
class Environment {
    public function load_admin(): void {
        if ( ! defined( 'ABSPATH' ) ) {
            return;
        }
        foreach ( [ 'plugin.php', 'file.php', 'misc.php', 'class-wp-upgrader.php', 'update.php' ] as $file ) {
            $path = ABSPATH . 'wp-admin/includes/' . $file;
            if ( is_readable( $path ) ) {
                require_once $path;
            }
        }
        // wp_update_plugins() lives in wp-includes/update.php. Required only when
        // missing, so a site that already loaded it is not asked to again.
        if ( ! function_exists( 'wp_update_plugins' ) && defined( 'WPINC' ) && is_readable( ABSPATH . WPINC . '/update.php' ) ) {
            require_once ABSPATH . WPINC . '/update.php';
        }
    }

    /** @return array<string, array{name:?string, version:?string}> Plugin file => headers. */
    public function installed_plugins(): array {
        $this->load_admin();
        $out = [];
        if ( ! function_exists( 'get_plugins' ) ) {
            return $out;
        }
        foreach ( (array) get_plugins() as $file => $headers ) {
            if ( ! is_string( $file ) || ! is_array( $headers ) ) {
                continue;
            }
            $out[ $file ] = [
                'name'    => isset( $headers['Name'] ) && is_string( $headers['Name'] ) ? $headers['Name'] : null,
                'version' => isset( $headers['Version'] ) && is_string( $headers['Version'] ) && '' !== $headers['Version'] ? $headers['Version'] : null,
            ];
        }
        return $out;
    }

    public function is_active( string $file ): bool {
        return function_exists( 'is_plugin_active' ) && is_plugin_active( $file );
    }

    /** True when the plugin is active afterwards. activate_plugin() returns null on success. */
    public function activate( string $file ): bool {
        if ( function_exists( 'activate_plugin' ) ) {
            activate_plugin( $file, '', false, true );
        }
        return $this->is_active( $file );
    }

    public function is_multisite(): bool {
        return function_exists( 'is_multisite' ) && is_multisite();
    }

    public function home_url( string $path = '/' ): string {
        $url = function_exists( 'home_url' ) ? home_url( $path ) : '';
        return is_string( $url ) ? $url : '';
    }

    /** The REST URL for a route, honouring plain permalinks (?rest_route=). */
    public function rest_url( string $route ): string {
        $url = function_exists( 'rest_url' ) ? rest_url( $route ) : $this->home_url( '/wp-json/' . ltrim( $route, '/' ) );
        return is_string( $url ) ? $url : '';
    }

    /**
     * Throw away WordPress's update cache and ask again, now.
     *
     * Deleting the transient is what makes wp_update_plugins() actually call out:
     * with a fresh `last_checked` it returns early and nothing is asked. That early
     * return is half of the Elementor -> Elementor Pro trap in wordpress-updates §2.
     */
    public function refresh_update_check(): void {
        $this->load_admin();
        if ( function_exists( 'delete_site_transient' ) ) {
            delete_site_transient( 'update_plugins' );
            delete_site_transient( 'update_themes' );
        }
        if ( function_exists( 'wp_clean_plugins_cache' ) ) {
            wp_clean_plugins_cache( false );
        }
        if ( function_exists( 'wp_update_plugins' ) ) {
            wp_update_plugins();
        }
        if ( function_exists( 'wp_update_themes' ) ) {
            wp_update_themes();
        }
    }

    public function plugins_transient(): mixed {
        return function_exists( 'get_site_transient' ) ? get_site_transient( 'update_plugins' ) : false;
    }

    /**
     * Install $package over $file through the core upgrader, the path
     * `wp plugin update` takes and the one the 22 Oct jet-update.php used.
     *
     * The skin is Automatic_Upgrader_Skin because it captures feedback instead of
     * printing it. That matters beyond tidiness: the upgrader's own feedback
     * includes "Downloading update from <package>", which for a Jet plugin is the
     * licence key. It is captured, and never read back out of the skin.
     *
     * `temp_backup` asks core (6.3+) to keep its own copy in upgrade-temp-backup
     * and put it back if the INSTALL fails - the same hook_extra
     * Plugin_Upgrader::upgrade() passes. It covers "the zip was bad", not "the new
     * version broke the site"; that is what Backups is for.
     *
     * @return true|string True, or a short failure code (never the upgrader's message).
     */
    public function upgrade( string $file, string $package ): bool|string {
        $this->load_admin();
        if ( ! class_exists( 'Plugin_Upgrader' ) || ! class_exists( 'Automatic_Upgrader_Skin' ) || ! defined( 'WP_PLUGIN_DIR' ) ) {
            return 'upgrader_unavailable';
        }

        $dir      = dirname( $file );
        $upgrader = new \Plugin_Upgrader( new \Automatic_Upgrader_Skin() );
        $result   = $upgrader->run(
            [
                'package'           => $package,
                'destination'       => WP_PLUGIN_DIR,
                'clear_destination' => true,
                'clear_working'     => true,
                'hook_extra'        => [
                    'plugin'      => $file,
                    'type'        => 'plugin',
                    'action'      => 'update',
                    'temp_backup' => [ 'slug' => '.' === $dir ? basename( $file, '.php' ) : $dir, 'src' => WP_PLUGIN_DIR, 'dir' => 'plugins' ],
                ],
            ]
        );

        $this->clean_plugins_cache();

        if ( function_exists( 'is_wp_error' ) && is_wp_error( $result ) ) {
            $code = $result->get_error_code();
            return is_string( $code ) && '' !== $code ? 'upgrade_failed:' . preg_replace( '/[^a-z0-9_\-]/i', '', $code ) : 'upgrade_failed';
        }
        if ( false === $result || null === $result ) {
            return 'upgrade_failed';
        }
        return true;
    }

    public function clean_plugins_cache(): void {
        if ( function_exists( 'wp_clean_plugins_cache' ) ) {
            wp_clean_plugins_cache( true );
        }
        if ( function_exists( 'clearstatcache' ) ) {
            clearstatcache();
        }
    }

    /**
     * The version in the plugin FILE's header, read from disk now.
     *
     * Never the upgrader's return value: wordpress-updates §2 has `wp plugin update
     * elementor-pro` reporting success on 21 sites that had not moved. The state
     * afterwards is the acceptance test.
     */
    public function read_version( string $file ): ?string {
        $this->load_admin();
        $this->clean_plugins_cache();
        if ( ! defined( 'WP_PLUGIN_DIR' ) || ! function_exists( 'get_file_data' ) ) {
            return null;
        }
        $path = WP_PLUGIN_DIR . '/' . $file;
        if ( ! is_readable( $path ) ) {
            return null;
        }
        $data = get_file_data( $path, [ 'Version' => 'Version' ] );
        $v    = is_array( $data ) ? ( $data['Version'] ?? null ) : null;
        return is_string( $v ) && '' !== $v ? $v : null;
    }

    public function plugins_dir(): string {
        return defined( 'WP_PLUGIN_DIR' ) ? (string) WP_PLUGIN_DIR : '';
    }

    public function abspath(): string {
        return defined( 'ABSPATH' ) ? (string) ABSPATH : '';
    }

    /** The web server's document root for this request, or '' when it is not known. */
    public function doc_root(): string {
        $root = $_SERVER['DOCUMENT_ROOT'] ?? '';
        return is_string( $root ) ? $root : '';
    }
}
