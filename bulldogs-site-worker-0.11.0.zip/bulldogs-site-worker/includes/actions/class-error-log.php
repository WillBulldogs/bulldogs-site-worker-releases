<?php
namespace Bulldogs\SiteWorker\Actions;

/**
 * New PHP fatals since a baseline, read from the site's own error log.
 *
 * ---------------------------------------------------------------------------
 * 🚨 UNREADABLE IS "unknown", NEVER []
 * ---------------------------------------------------------------------------
 * An empty list says "we looked and the update caused no fatal". A log we could
 * not find or open says nothing at all, and reporting it as [] would turn "could
 * not read" into "clean" - the one mistake this whole system exists to refuse.
 * So since() returns the string `unknown` whenever there is no baseline to read
 * from or the file cannot be read now.
 *
 * ---------------------------------------------------------------------------
 * ROTATION
 * ---------------------------------------------------------------------------
 * Brixly clears its logs nightly around 02:00 (gotchas §2), and cPanel rotates
 * them. A log that is now SMALLER than the baseline offset, or is a different file
 * (inode changed), has been rotated: everything in it is new, so it is read from
 * the start and `log_rotated` says so. Reading from the old offset would skip the
 * very fatal we are looking for, or read nothing and report clean.
 *
 * Where the log lives, in the order the spec gives: `ini_get('error_log')`, then
 * `ABSPATH/error_log`, then the newest `*error*log*` file in `../logs/`.
 */
class ErrorLog {
    /** Bytes read past the baseline, at most. */
    public const MAX_READ = 262144;

    /** Lines returned, at most. */
    public const MAX_LINES = 20;

    /** @param string[]|null $candidates Explicit paths to try; null means the real lookup. */
    public function __construct( private Environment $env, private ?array $candidates = null ) {}

    /**
     * Where the log is now and how big it is, or null when there is no readable log.
     *
     * @return array{path:string, size:int, inode:int}|null
     */
    public function baseline(): ?array {
        foreach ( $this->candidates() as $path ) {
            clearstatcache( true, $path );
            if ( ! is_file( $path ) || ! is_readable( $path ) ) {
                continue;
            }
            $stat = @stat( $path );
            if ( ! is_array( $stat ) ) {
                continue;
            }
            return [ 'path' => $path, 'size' => (int) $stat['size'], 'inode' => (int) $stat['ino'] ];
        }
        return null;
    }

    /**
     * Fatal and parse error lines written since the baseline.
     *
     * @param array{path:string, size:int, inode:int}|null $baseline
     * @return array{new_fatals:array<int,string>|string, log_rotated:bool}
     */
    public function since( ?array $baseline ): array {
        if ( null === $baseline ) {
            return [ 'new_fatals' => 'unknown', 'log_rotated' => false ];
        }
        $path = $baseline['path'];
        clearstatcache( true, $path );
        if ( ! is_file( $path ) || ! is_readable( $path ) ) {
            return [ 'new_fatals' => 'unknown', 'log_rotated' => false ];
        }
        $stat = @stat( $path );
        if ( ! is_array( $stat ) ) {
            return [ 'new_fatals' => 'unknown', 'log_rotated' => false ];
        }

        $size    = (int) $stat['size'];
        $rotated = $size < $baseline['size'] || (int) $stat['ino'] !== $baseline['inode'];
        $offset  = $rotated ? 0 : $baseline['size'];

        $handle = @fopen( $path, 'rb' );
        if ( false === $handle ) {
            return [ 'new_fatals' => 'unknown', 'log_rotated' => $rotated ];
        }
        $chunk = '';
        if ( $size > $offset && 0 === fseek( $handle, $offset ) ) {
            $read  = fread( $handle, min( self::MAX_READ, $size - $offset ) );
            $chunk = is_string( $read ) ? $read : '';
        }
        fclose( $handle );

        return [ 'new_fatals' => self::fatal_lines( $chunk ), 'log_rotated' => $rotated ];
    }

    /**
     * Pure: a chunk of log, in; the fatal and parse error lines, URLs stripped, out.
     * File paths are kept - they are what says which plugin broke.
     *
     * @return array<int, string>
     */
    public static function fatal_lines( string $chunk ): array {
        $out = [];
        foreach ( preg_split( '/\r\n|\r|\n/', $chunk ) ?: [] as $line ) {
            if ( str_contains( $line, 'PHP Fatal error' ) || str_contains( $line, 'PHP Parse error' ) ) {
                $out[] = substr( OutputSanitiser::string( trim( $line ) ), 0, 500 );
                if ( count( $out ) >= self::MAX_LINES ) {
                    break;
                }
            }
        }
        return $out;
    }

    /** @return string[] */
    private function candidates(): array {
        if ( null !== $this->candidates ) {
            return $this->candidates;
        }
        $out = [];
        $ini = ini_get( 'error_log' );
        if ( is_string( $ini ) && '' !== $ini && 'syslog' !== $ini ) {
            $out[] = $ini;
        }
        $abs = $this->env->abspath();
        if ( '' !== $abs ) {
            $out[] = rtrim( $abs, '/' ) . '/error_log';
            $logs  = dirname( rtrim( $abs, '/' ) ) . '/logs';
            $found = glob( $logs . '/*error*log*' ) ?: [];
            usort( $found, static fn ( string $a, string $b ): int => (int) @filemtime( $b ) <=> (int) @filemtime( $a ) );
            foreach ( $found as $file ) {
                $out[] = $file;
            }
        }
        return $out;
    }
}
