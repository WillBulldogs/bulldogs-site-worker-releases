<?php
namespace Bulldogs\SiteWorker\Actions;

use Bulldogs\SiteWorker\Modules;
use Bulldogs\SiteWorker\Monitor\SiteSecret;

/**
 * Is the site still up after a change, judged from inside it?
 *
 * ---------------------------------------------------------------------------
 * CACHE-BUSTED, OR IT PROVES NOTHING
 * ---------------------------------------------------------------------------
 * A bare-URL 200 from a site behind WP Rocket is the page cache answering, and it
 * says nothing about whether PHP still renders the page (WP Rocket SOP §5b). Every
 * fetch here carries `?bsw=<random>` and no-cache headers. This is the opposite of
 * the consent scanner, which deliberately reads what visitors get, cache and all.
 *
 * ---------------------------------------------------------------------------
 * THE REST PROBE
 * ---------------------------------------------------------------------------
 * The findings route with `?probe=1` and the site's own secret: a 200 proves
 * WordPress and the plugin stack boot under REST after the update, which is the
 * closest an HTTP check gets to "wp-cli still boots". When the monitor module is
 * off that route does not exist, so the probe falls back to the REST index, which
 * proves REST boots without proving our route does.
 *
 * The probe is baselined like everything else. UpdateRunner refuses to start on a
 * site whose probe already fails, because a health check that cannot pass before
 * the update would auto-roll-back every update after it.
 *
 * These loopback requests come from the server's own IP, not ours, so they do not
 * count against the Brixly ban envelope.
 */
class HealthCheck {
    public const TIMEOUT = 30;

    /** "More than 20% smaller" (decision D3): report, never roll back. */
    public const DEGRADED_RATIO = 0.8;

    public const OK       = 'ok';
    public const BROKEN   = 'broken';
    public const DEGRADED = 'degraded';

    public function __construct(
        private Environment $env,
        private SiteSecret $secret,
        private ?Modules $modules = null
    ) {}

    /**
     * Home and each key path, cache-busted.
     *
     * @param string[] $key_paths Already validated: each starts with '/'.
     * @return array{home:array{0:int,1:int}, key_paths:array<string,array{0:int,1:int}>}
     */
    public function snapshot( array $key_paths ): array {
        $out = [ 'home' => $this->fetch( '/' ), 'key_paths' => [] ];
        foreach ( $key_paths as $path ) {
            $out['key_paths'][ $path ] = $this->fetch( $path );
        }
        return $out;
    }

    /** @return array{0:int, 1:int} Status (0 when there was no answer) and body bytes. */
    public function fetch( string $path ): array {
        if ( ! function_exists( 'wp_remote_get' ) ) {
            return [ 0, 0 ];
        }
        $url = self::bust( $this->env->home_url( $path ) );
        if ( '' === $url ) {
            return [ 0, 0 ];
        }
        $response = wp_remote_get(
            $url,
            [
                'timeout'     => self::TIMEOUT,
                'redirection' => 3,
                'sslverify'   => false,
                'headers'     => [
                    'Cache-Control'          => 'no-cache',
                    'Pragma'                 => 'no-cache',
                    'X-Bulldogs-SW-Health'   => '1',
                ],
            ]
        );
        if ( function_exists( 'is_wp_error' ) && is_wp_error( $response ) ) {
            return [ 0, 0 ];
        }
        $code = function_exists( 'wp_remote_retrieve_response_code' ) ? wp_remote_retrieve_response_code( $response ) : 0;
        $body = function_exists( 'wp_remote_retrieve_body' ) ? wp_remote_retrieve_body( $response ) : '';
        return [ is_scalar( $code ) ? (int) $code : 0, is_string( $body ) ? strlen( $body ) : 0 ];
    }

    /** `ok` or `failed`. */
    public function rest_probe(): string {
        if ( ! function_exists( 'wp_remote_get' ) ) {
            return 'failed';
        }
        $monitor = null === $this->modules || $this->modules->is_enabled( Modules::MONITOR );
        $secret  = $this->secret->get();

        if ( $monitor && null !== $secret ) {
            $url     = $this->env->rest_url( 'bulldogs-sw/v1/findings' );
            $url    .= ( str_contains( $url, '?' ) ? '&' : '?' ) . 'probe=1';
            $headers = [ 'x-bsw-secret' => $secret ];
        } else {
            $url     = $this->env->rest_url( '' );
            $headers = [];
        }
        if ( '' === $url ) {
            return 'failed';
        }

        $response = wp_remote_get(
            self::bust( $url ),
            [
                'timeout'     => self::TIMEOUT,
                'redirection' => 0,
                'sslverify'   => false,
                'headers'     => $headers + [ 'Cache-Control' => 'no-cache', 'Pragma' => 'no-cache' ],
            ]
        );
        if ( function_exists( 'is_wp_error' ) && is_wp_error( $response ) ) {
            return 'failed';
        }
        $code = function_exists( 'wp_remote_retrieve_response_code' ) ? wp_remote_retrieve_response_code( $response ) : 0;
        $body = function_exists( 'wp_remote_retrieve_body' ) ? wp_remote_retrieve_body( $response ) : '';
        if ( 200 !== ( is_scalar( $code ) ? (int) $code : 0 ) || ! is_string( $body ) || ! is_array( json_decode( $body, true ) ) ) {
            return 'failed';
        }
        return 'ok';
    }

    /**
     * Can this site be measured at all? A baseline home with no answer or a 5xx, or a
     * failing probe, means the health check could never pass - so nothing is changed.
     *
     * @param array{home:array{0:int,1:int}, key_paths:array<string,array{0:int,1:int}>} $before
     */
    public static function measurable( array $before, string $probe ): bool {
        $home = $before['home'][0];
        return 'ok' === $probe && $home > 0 && $home < 500;
    }

    /**
     * Pure: the before and after snapshots and the probe after, in; the verdict, out.
     *
     * `broken` (auto-rollback): a path that was 200 at baseline is now 5xx or did not
     * answer, or the REST probe fails. `degraded` (report only): 200 both times but
     * more than 20% smaller. Otherwise `ok`.
     *
     * @param array{home:array{0:int,1:int}, key_paths:array<string,array{0:int,1:int}>} $before
     * @param array{home:array{0:int,1:int}, key_paths:array<string,array{0:int,1:int}>} $after
     */
    public static function verdict( array $before, array $after, string $probe_after ): string {
        $pairs = [ [ $before['home'], $after['home'] ] ];
        foreach ( $before['key_paths'] as $path => $b ) {
            $pairs[] = [ $b, $after['key_paths'][ $path ] ?? [ 0, 0 ] ];
        }

        if ( 'ok' !== $probe_after ) {
            return self::BROKEN;
        }

        $degraded = false;
        foreach ( $pairs as [ $b, $a ] ) {
            if ( 200 === $b[0] && ( $a[0] >= 500 || 0 === $a[0] ) ) {
                return self::BROKEN;
            }
            if ( 200 === $b[0] && 200 === $a[0] && $b[1] > 0 && $a[1] < $b[1] * self::DEGRADED_RATIO ) {
                $degraded = true;
            }
        }
        return $degraded ? self::DEGRADED : self::OK;
    }

    /**
     * The health block of a result, in the contract's shape.
     *
     * @param array{home:array{0:int,1:int}, key_paths:array<string,array{0:int,1:int}>} $before
     * @param array{home:array{0:int,1:int}, key_paths:array<string,array{0:int,1:int}>} $after
     * @param array{new_fatals:array<int,string>|string, log_rotated:bool} $log
     * @return array<string, mixed>
     */
    public static function report( array $before, array $after, string $probe, array $log ): array {
        $paths = [];
        foreach ( $before['key_paths'] as $path => $b ) {
            $paths[ $path ] = [ 'before' => $b, 'after' => $after['key_paths'][ $path ] ?? [ 0, 0 ] ];
        }
        return [
            'home'        => [ 'before' => $before['home'], 'after' => $after['home'] ],
            'key_paths'   => $paths,
            'rest_probe'  => 'ok' === $probe ? 'ok' : 'failed',
            'new_fatals'  => $log['new_fatals'],
            'log_rotated' => $log['log_rotated'],
        ];
    }

    private static function bust( string $url ): string {
        if ( '' === $url ) {
            return '';
        }
        return $url . ( str_contains( $url, '?' ) ? '&' : '?' ) . 'bsw=' . bin2hex( random_bytes( 6 ) );
    }
}
