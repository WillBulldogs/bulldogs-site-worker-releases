<?php
namespace Bulldogs\SiteWorker\Actions;

/**
 * The one filter every string the actions layer emits passes through.
 *
 * ---------------------------------------------------------------------------
 * 🚨 WHY: THE CROCOBLOCK PACKAGE URL CARRIES THE LICENCE KEY
 * ---------------------------------------------------------------------------
 * `\Jet_Dashboard\Utils::package_url()` returns a download link with `license=<key>`
 * in the query string (wordpress-updates §2b). That URL has to exist on the site -
 * WordPress keeps packages in the `update_plugins` transient and the upgrader
 * downloads from it - but it must NEVER leave the site: not in a response, not in
 * an action record (which `status` and the findings `capabilities` serve back),
 * not in an error message, not in a log line. A key that reaches the CC's audit
 * log reaches Supabase, Slack and every agent that reads either.
 *
 * Rather than trusting every call site to remember, the response builder, the
 * record store's writers and the action layer's error_log() all go through here.
 * It removes every URL, outright, and redacts any `license=` style value that
 * survives without a scheme. Responses carry `package: true/false` and a HOST
 * NAME, which is what the CC needs, and a host name is not a URL.
 *
 * Deliberately blunt. A filter that tried to recognise "only the dangerous URLs"
 * would be one vendor's new URL shape away from leaking; this one has nothing to
 * recognise. The cost is that a Wordfence issue message quoting a URL loses it in
 * the `sync` copy of the security section, which is a fair trade.
 */
class OutputSanitiser {
    public const URL_MARK = '[url]';

    /** Query parameters whose VALUE is a credential, wherever they turn up. */
    private const SECRET_PARAMS = 'license|licence|license_key|licence_key|api_key|apikey|token|secret|password|pass|key_hash';

    /** Deeper than any response we build; past it, values are dropped rather than walked. */
    private const MAX_DEPTH = 12;

    /**
     * Clean a value of any shape. Arrays are walked (keys included), strings are
     * filtered, scalars pass through, and anything else - objects, resources - is
     * replaced, because an object's string form is not ours to vouch for.
     */
    public static function clean( mixed $value, int $depth = 0 ): mixed {
        if ( is_string( $value ) ) {
            return self::string( $value );
        }
        if ( is_int( $value ) || is_float( $value ) || is_bool( $value ) || null === $value ) {
            return $value;
        }
        if ( is_array( $value ) ) {
            if ( $depth >= self::MAX_DEPTH ) {
                return null;
            }
            $out = [];
            foreach ( $value as $key => $item ) {
                $out[ is_string( $key ) ? self::string( $key ) : $key ] = self::clean( $item, $depth + 1 );
            }
            return $out;
        }
        return null;
    }

    public static function string( string $text ): string {
        // 1. Anything with a scheme: https://, http://, ftp://, s3:// ...
        $text = preg_replace( '~\b[a-z][a-z0-9+.\-]{1,15}://[^\s"\'<>]*~i', self::URL_MARK, $text ) ?? '';
        // 2. Protocol-relative: //host.tld/...
        $text = preg_replace( '~(?<![a-z0-9:/])//[a-z0-9\-]+(?:\.[a-z0-9\-]+)+(?::\d+)?(?:[/?#][^\s"\'<>]*)?~i', self::URL_MARK, $text ) ?? '';
        // 3. A bare host carrying a query string: api.example.com/?x=1. Only with a
        //    query, so a file path through a dotted directory (the LDN1 mockup sites
        //    live under /home/bulldog1/<name>.bulldogs.digital/) keeps its path.
        $text = preg_replace( '~\b[a-z0-9\-]+(?:\.[a-z0-9\-]+)*\.[a-z]{2,}(?::\d+)?(?:/[^\s"\'<>?]*)?\?[^\s"\'<>]*~i', self::URL_MARK, $text ) ?? '';
        // 4. Whatever is left: a credential-shaped parameter on its own.
        $text = preg_replace( '~\b(' . self::SECRET_PARAMS . ')=[^&\s"\'<>]*~i', '$1=[redacted]', $text ) ?? '';
        return $text;
    }

    /** error_log(), sanitised. The only way the actions layer writes to the log. */
    public static function log( string $message ): void {
        if ( function_exists( 'error_log' ) ) {
            error_log( 'bulldogs-site-worker: ' . self::string( $message ) );
        }
    }
}
