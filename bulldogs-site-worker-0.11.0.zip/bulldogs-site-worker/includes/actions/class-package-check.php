<?php
namespace Bulldogs\SiteWorker\Actions;

/**
 * Will the vendor actually hand over this package? Asked without downloading it.
 *
 * ---------------------------------------------------------------------------
 * THE COTTIER ALERT
 * ---------------------------------------------------------------------------
 * On 22 Oct 2026 Cottier's `jet-license-data` option said `active`, and Crocoblock
 * refused the download with `license_not_active`: the licence had been removed
 * from the Crocoblock account. Nothing on the site knew. Only asking the vendor for
 * the package found it, so that is what this does - a GET with `Range: bytes=0-3`,
 * reading the status, the content type and the first bytes.
 *
 *   a zip (PK\x03\x04)              -> ok
 *   a JSON or other error body      -> refused, with the vendor's own code if it sent one
 *   no package in the transient     -> none
 *   no answer (network, 5xx)        -> unknown. NEVER ok.
 *
 * A 5xx is `unknown`, not `refused`: a vendor outage is not a licence problem, and
 * reporting it as one would put a Slack alert on every Covered site at once.
 *
 * A vendor that ignores Range sends the whole zip; `limit_response_size` stops the
 * read at 64 KB, which is plenty for an error body and a magic number.
 *
 * Runs in `sync` and before each `update`, never on the 6-hourly findings poll.
 */
class PackageCheck {
    public const OK      = 'ok';
    public const REFUSED = 'refused';
    public const NONE    = 'none';
    public const UNKNOWN = 'unknown';

    private const ZIP_MAGIC = "PK\x03\x04";

    /**
     * @return array{state:string, host:?string, vendor_code?:string}
     */
    public function check( ?string $package ): array {
        if ( null === $package || '' === trim( $package ) ) {
            return [ 'state' => self::NONE, 'host' => null ];
        }

        $host = parse_url( $package, PHP_URL_HOST );
        $host = is_string( $host ) ? strtolower( $host ) : null;

        if ( null === $host || ! function_exists( 'wp_remote_get' ) ) {
            return [ 'state' => self::UNKNOWN, 'host' => $host ];
        }

        $response = wp_remote_get(
            $package,
            [
                'timeout'             => 20,
                'redirection'         => 3,
                'headers'             => [ 'Range' => 'bytes=0-3' ],
                'limit_response_size' => 65536,
            ]
        );

        if ( function_exists( 'is_wp_error' ) && is_wp_error( $response ) ) {
            return [ 'state' => self::UNKNOWN, 'host' => $host ];
        }

        $code = function_exists( 'wp_remote_retrieve_response_code' ) ? wp_remote_retrieve_response_code( $response ) : 0;
        $code = is_scalar( $code ) ? (int) $code : 0;
        $body = function_exists( 'wp_remote_retrieve_body' ) ? wp_remote_retrieve_body( $response ) : '';
        $body = is_string( $body ) ? $body : '';

        return self::interpret( $code, $body, $host );
    }

    /**
     * Pure: what the vendor sent, in; the verdict, out.
     *
     * @return array{state:string, host:?string, vendor_code?:string}
     */
    public static function interpret( int $code, string $body, ?string $host ): array {
        if ( ( 200 === $code || 206 === $code ) && str_starts_with( $body, self::ZIP_MAGIC ) ) {
            return [ 'state' => self::OK, 'host' => $host ];
        }
        if ( 0 === $code || $code >= 500 ) {
            return [ 'state' => self::UNKNOWN, 'host' => $host ];
        }

        $out    = [ 'state' => self::REFUSED, 'host' => $host ];
        $vendor = self::vendor_code( $body );
        if ( null !== $vendor ) {
            $out['vendor_code'] = $vendor;
        }
        return $out;
    }

    /**
     * The vendor's own reason, if the body is JSON carrying one. Held to a plain
     * identifier, because it is echoed to the CC and into Slack.
     */
    private static function vendor_code( string $body ): ?string {
        $json = json_decode( $body, true );
        if ( ! is_array( $json ) ) {
            return null;
        }
        $candidates = [
            $json['code'] ?? null,
            $json['error_code'] ?? null,
            $json['error'] ?? null,
            is_array( $json['data'] ?? null ) ? ( $json['data']['code'] ?? null ) : null,
            is_array( $json['data'] ?? null ) ? ( $json['data']['error'] ?? null ) : null,
            $json['status'] ?? null,
        ];
        foreach ( $candidates as $c ) {
            if ( is_string( $c ) && 1 === preg_match( '/^[A-Za-z0-9_\-]{1,64}$/', $c ) ) {
                return strtolower( $c );
            }
        }
        return null;
    }
}
