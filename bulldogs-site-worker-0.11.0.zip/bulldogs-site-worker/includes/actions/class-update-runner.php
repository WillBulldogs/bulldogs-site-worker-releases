<?php
namespace Bulldogs\SiteWorker\Actions;

use Bulldogs\SiteWorker\Settings;

/**
 * `update` and `rollback`, stage 1: one plugin at a time, through WordPress's own
 * upgrader, from the plugin's own update source only.
 *
 * ---------------------------------------------------------------------------
 * THE PLUGIN ENFORCES POLICY. THE CC ONLY ASKS.
 * ---------------------------------------------------------------------------
 * Every rule below is checked HERE, on the site, so a wrong or forged request from
 * the CC side meets a refusal rather than an update (spec §3, §6):
 *
 *   - No parameter takes a URL, a path or a package. Plugins are named by their
 *     installed `file`; packages come from the transient or the Crocoblock adapter,
 *     whose host is pinned.
 *   - Installed plugins only. Nothing is installed or deleted. Plugins only.
 *   - Never `bulldogs-site-worker` itself: it has its own checksummed channel, and a
 *     plugin replacing itself mid-request is a separate problem.
 *   - Never `clsop` (AccelerateWP, deployed from a CloudLinux package with its own
 *     revert vector). Never `wp-rocket` unless this site holds the local
 *     `allow_wp_rocket_update` flag, literally true, set by WP-CLI: our licence
 *     lapsed in Feb 2026 and most copies carry the hand patch, which any reinstall
 *     reverts and takes the site down on the next request.
 *   - Not on multisite in v1.
 *   - The version is an ASSERTION: `latest`, or exactly what the source offers. A
 *     vendor shipping something newer between the CC deciding and the site acting
 *     produces a refusal, not a surprise. Only the Crocoblock adapter may name an
 *     older-than-latest version (its vendor serves versioned packages), and never
 *     one older than what is installed. Downgrades are refused everywhere.
 *
 * ---------------------------------------------------------------------------
 * ORDER, AND A FRESH CHECK BETWEEN EVERY TWO PLUGINS
 * ---------------------------------------------------------------------------
 * Updating `elementor` invalidates the transient, so an `elementor-pro` update
 * straight after it silently does nothing and reports success - 21 of 22 sites on
 * 8 Sep 2026 (wordpress-updates §2). So the update cache is rebuilt before EVERY
 * plugin, and known dependency pairs are put in order on the site: `elementor`
 * before `elementor-pro`, `jet-engine` before any other Jet plugin (JetSmartFilters'
 * newer releases need JetEngine >= 3.8.15.4). The order applied is reported.
 *
 * The run stops at the first plugin that is not `updated`; the rest come back
 * `not_attempted`. The same rule as scripts/bsw-rollout.sh.
 *
 * ---------------------------------------------------------------------------
 * PER PLUGIN (spec §5.4)
 * ---------------------------------------------------------------------------
 *   1. Policy, then the version plan, then the package check must be `ok`.
 *   2. Baseline: cache-busted home + key paths, the REST probe, the error log offset.
 *      A site that cannot be measured before is not changed.
 *   3. Backup outside the web root, or refuse.
 *   4. Upgrade. Reactivate if it was active and now is not.
 *   5. Read the version back FROM THE FILE.
 *   6. Health. 5xx where there was a 200, or a failed REST probe, with auto_rollback
 *      on: restore the backup IN THIS REQUEST (decision D3: a broken site may not
 *      boot far enough to receive a second command). Smaller by more than 20%:
 *      `degraded`, reported, not rolled back.
 */
class UpdateRunner {
    public const OUTCOME_UPDATED       = 'updated';
    public const OUTCOME_REFUSED       = 'refused';
    public const OUTCOME_FAILED        = 'failed';
    public const OUTCOME_ROLLED_BACK   = 'rolled_back';
    public const OUTCOME_DEGRADED      = 'degraded';
    public const OUTCOME_NOT_ATTEMPTED = 'not_attempted';

    /** Settings key, honoured only when LITERALLY true. Set by `wp bulldogs actions allow-wp-rocket`. */
    public const KEY_ALLOW_WP_ROCKET = 'allow_wp_rocket_update';

    /** Directories that go first, in this order, when present in a request. */
    private const FIRST = [ 'elementor', 'jet-engine' ];

    /** @var \Closure(): void */
    private \Closure $heartbeat;

    public function __construct(
        private Environment $env,
        private CrocoblockAdapter $crocoblock,
        private SyncRunner $sync,
        private PackageCheck $packages,
        private HealthCheck $health,
        private ErrorLog $log,
        private Backups $backups,
        private Settings $settings,
        ?\Closure $heartbeat = null
    ) {
        $this->heartbeat = $heartbeat ?? static function (): void {};
    }

    /** The controller extends the site lock through this between long steps. */
    public function set_heartbeat( \Closure $heartbeat ): void {
        $this->heartbeat = $heartbeat;
    }

    /**
     * @param array<int, array{file:string, version:string}> $plugins Validated by the controller.
     * @param string[] $key_paths Validated by the controller.
     * @return array{results:array<int,array<string,mixed>>, order_applied:string[], changed:bool}
     */
    public function update( array $plugins, array $key_paths, bool $auto_rollback ): array {
        $ordered = self::order( $plugins );
        $order   = array_map( static fn ( array $p ): string => $p['file'], $ordered );

        if ( $this->env->is_multisite() ) {
            $results = [];
            foreach ( $ordered as $p ) {
                $results[] = self::result( $p['file'], null, null, self::OUTCOME_REFUSED, 'multisite' );
            }
            return [ 'results' => $results, 'order_applied' => $order, 'changed' => false ];
        }

        $results = [];
        $changed = false;
        $stop    = false;

        foreach ( $ordered as $p ) {
            if ( $stop ) {
                $results[] = self::result( $p['file'], null, null, self::OUTCOME_NOT_ATTEMPTED, null );
                continue;
            }
            ( $this->heartbeat )();

            // Before EVERY plugin, the first included: the asserted version is judged
            // against what the source offers now, not at the last cron check.
            $this->sync->refresh();

            [ $result, $touched ] = $this->update_one( $p['file'], $p['version'], $key_paths, $auto_rollback );
            $results[] = $result;
            $changed   = $changed || $touched;
            if ( self::OUTCOME_UPDATED !== $result['outcome'] ) {
                $stop = true;
            }
        }

        return [ 'results' => $results, 'order_applied' => $order, 'changed' => $changed ];
    }

    /**
     * Restore a backup this plugin made, by id.
     *
     * Same baseline, health and auto-rollback as an update. The current version is
     * backed up first, so a rollback that breaks the site can itself be undone in
     * the same request - and the CC gets a backup id to undo a rollback that
     * worked but was the wrong call.
     *
     * The outcomes mean what they mean for `update`, so the CC reads one vocabulary:
     * success is `updated` (the requested change was applied and health passed), and
     * `rolled_back` only ever means "the change was undone because health failed" -
     * here, the pre-rollback version put back by auto_rollback. A broken site with
     * auto_rollback off is `failed`, reason `health_failed`.
     *
     * @param string[] $key_paths
     * @return array{results:array<int,array<string,mixed>>, order_applied:string[], changed:bool}
     */
    public function rollback( string $backup_id, array $key_paths, bool $auto_rollback ): array {
        $entry = $this->backups->find( $backup_id );
        $file  = null !== $entry ? $entry['file'] : '';
        $wrap  = static fn ( array $r, bool $changed ): array => [ 'results' => [ $r ], 'order_applied' => '' !== $r['file'] ? [ $r['file'] ] : [], 'changed' => $changed ];

        if ( $this->env->is_multisite() ) {
            return $wrap( self::result( $file, null, null, self::OUTCOME_REFUSED, 'multisite' ), false );
        }
        if ( null === $entry ) {
            return $wrap( self::result( '', null, null, self::OUTCOME_REFUSED, 'backup_not_found' ), false );
        }
        if ( ! $this->backups->within_window( $entry ) || ! is_file( $entry['path'] ) ) {
            return $wrap( self::result( $file, null, $entry['version'], self::OUTCOME_REFUSED, 'backup_expired' ), false );
        }

        $installed = $this->env->installed_plugins();
        if ( ! isset( $installed[ $file ] ) ) {
            return $wrap( self::result( $file, null, $entry['version'], self::OUTCOME_REFUSED, 'not_installed' ), false );
        }
        $refusal = $this->policy( $file );
        if ( null !== $refusal ) {
            return $wrap( self::result( $file, $installed[ $file ]['version'], $entry['version'], self::OUTCOME_REFUSED, $refusal ), false );
        }

        $from   = $installed[ $file ]['version'] ?? 'unknown';
        $result = self::result( $file, $from, $entry['version'], self::OUTCOME_FAILED, null );

        [ $before, $probe_before ] = $this->baseline( $key_paths );
        if ( ! HealthCheck::measurable( $before, $probe_before ) ) {
            $result['outcome'] = self::OUTCOME_REFUSED;
            $result['reason']  = 'site_unhealthy';
            return $wrap( $result, false );
        }
        $log_base = $this->log->baseline();

        $safety = $this->backups->create( $file, $from );
        if ( true !== $safety['ok'] ) {
            $result['outcome'] = self::OUTCOME_REFUSED;
            $result['reason']  = $safety['reason'];
            return $wrap( $result, false );
        }
        $result['backup'] = $safety['backup'];

        $was_active = $this->env->is_active( $file );
        ( $this->heartbeat )();
        $restored = $this->backups->restore( $entry );
        $this->reactivate( $file, $was_active );
        $result['read_back'] = $this->env->read_version( $file );

        $after  = $this->health->snapshot( $key_paths );
        $probe  = $this->health->rest_probe();
        $result['health'] = HealthCheck::report( $before, $after, $probe, $this->log->since( $log_base ) );

        if ( ! $restored ) {
            $result['reason'] = 'restore_failed';
            return $wrap( $result, true );
        }

        $verdict = HealthCheck::verdict( $before, $after, $probe );
        if ( HealthCheck::BROKEN === $verdict ) {
            if ( $auto_rollback ) {
                $undo = $this->backups->find( $safety['backup']['id'] );
                $ok   = null !== $undo && $this->backups->restore( $undo );
                $this->reactivate( $file, $was_active );
                $result['read_back']       = $this->env->read_version( $file );
                $result['outcome']         = $ok ? self::OUTCOME_ROLLED_BACK : self::OUTCOME_FAILED;
                $result['reason']          = $ok ? 'health_failed' : 'rollback_failed';
                $result['rollback_health'] = $this->recheck( $before, $key_paths );
            } else {
                $result['reason'] = 'health_failed';
            }
            return $wrap( $result, true );
        }

        if ( $result['read_back'] !== $entry['version'] ) {
            $result['reason'] = 'read_back_mismatch';
            return $wrap( $result, true );
        }

        if ( HealthCheck::DEGRADED === $verdict ) {
            $result['outcome'] = self::OUTCOME_DEGRADED;
            $result['reason']  = 'page_smaller';
            return $wrap( $result, true );
        }

        $result['outcome'] = self::OUTCOME_UPDATED;
        return $wrap( $result, true );
    }

    /**
     * One plugin, steps 1-6.
     *
     * @param string[] $key_paths
     * @return array{0:array<string,mixed>, 1:bool} The result, and whether anything on disk was changed.
     */
    private function update_one( string $file, string $version, array $key_paths, bool $auto_rollback ): array {
        $installed = $this->env->installed_plugins();
        if ( ! isset( $installed[ $file ] ) ) {
            return [ self::result( $file, null, null, self::OUTCOME_REFUSED, 'not_installed' ), false ];
        }
        $from = $installed[ $file ]['version'];

        $refusal = $this->policy( $file );
        if ( null !== $refusal ) {
            return [ self::result( $file, $from, null, self::OUTCOME_REFUSED, $refusal ), false ];
        }
        if ( null === $from ) {
            return [ self::result( $file, null, null, self::OUTCOME_REFUSED, 'version_mismatch' ), false ];
        }

        // 1. The version plan and the package.
        $plan = $this->plan( $file, $version, $from );
        if ( isset( $plan['reason'] ) ) {
            return [ self::result( $file, $from, $plan['to'] ?? null, self::OUTCOME_REFUSED, $plan['reason'] ), false ];
        }
        $to     = $plan['to'];
        $result = self::result( $file, $from, $to, self::OUTCOME_FAILED, null );

        $check = $this->packages->check( $plan['package'] );
        if ( PackageCheck::OK !== $check['state'] ) {
            $result['outcome'] = self::OUTCOME_REFUSED;
            $result['reason']  = PackageCheck::REFUSED === $check['state'] ? 'package_refused' : 'package_unavailable';
            if ( isset( $check['vendor_code'] ) ) {
                $result['vendor_code'] = $check['vendor_code'];
            }
            return [ $result, false ];
        }

        // 2. Baseline.
        [ $before, $probe_before ] = $this->baseline( $key_paths );
        if ( ! HealthCheck::measurable( $before, $probe_before ) ) {
            $result['outcome'] = self::OUTCOME_REFUSED;
            $result['reason']  = 'site_unhealthy';
            return [ $result, false ];
        }
        $log_base = $this->log->baseline();

        // 3. Backup, or nothing happens.
        $backup = $this->backups->create( $file, $from );
        if ( true !== $backup['ok'] ) {
            $result['outcome'] = self::OUTCOME_REFUSED;
            $result['reason']  = $backup['reason'];
            return [ $result, false ];
        }
        $result['backup'] = $backup['backup'];

        // 4. Upgrade.
        $was_active = $this->env->is_active( $file );
        ( $this->heartbeat )();
        $upgraded = $this->env->upgrade( $file, $plan['package'] );
        $this->reactivate( $file, $was_active );

        // 5. Read back, from the file.
        $result['read_back'] = $this->env->read_version( $file );

        // 6. Health.
        $after            = $this->health->snapshot( $key_paths );
        $probe            = $this->health->rest_probe();
        $result['health'] = HealthCheck::report( $before, $after, $probe, $this->log->since( $log_base ) );
        $verdict          = HealthCheck::verdict( $before, $after, $probe );

        if ( HealthCheck::BROKEN === $verdict ) {
            if ( $auto_rollback ) {
                $entry = $this->backups->find( $backup['backup']['id'] );
                $ok    = null !== $entry && $this->backups->restore( $entry );
                $this->reactivate( $file, $was_active );
                $result['read_back']       = $this->env->read_version( $file );
                $result['outcome']         = $ok ? self::OUTCOME_ROLLED_BACK : self::OUTCOME_FAILED;
                $result['reason']          = $ok ? 'health_failed' : 'rollback_failed';
                $result['rollback_health'] = $this->recheck( $before, $key_paths );
            } else {
                $result['reason'] = 'health_failed';
            }
            return [ $result, true ];
        }

        if ( true !== $upgraded ) {
            $result['reason'] = 'upgrade_failed';
            return [ $result, true ];
        }
        if ( $result['read_back'] !== $to ) {
            $result['reason'] = 'read_back_mismatch';
            return [ $result, true ];
        }
        if ( HealthCheck::DEGRADED === $verdict ) {
            $result['outcome'] = self::OUTCOME_DEGRADED;
            $result['reason']  = 'page_smaller';
            return [ $result, true ];
        }

        $result['outcome'] = self::OUTCOME_UPDATED;
        return [ $result, true ];
    }

    /**
     * Why this plugin may never be updated by this route, or null.
     */
    public function policy( string $file ): ?string {
        $dir = dirname( $file );
        $dir = '.' === $dir ? basename( $file, '.php' ) : explode( '/', $dir )[0];

        $self = defined( 'BULLDOGS_SW_FILE' ) && function_exists( 'plugin_basename' ) ? plugin_basename( BULLDOGS_SW_FILE ) : null;
        if ( 'bulldogs-site-worker' === $dir || ( null !== $self && $self === $file ) ) {
            return 'self_update_refused';
        }
        if ( 'clsop' === $dir ) {
            return 'clsop_managed';
        }
        if ( 'wp-rocket' === $dir && true !== $this->settings->get( self::KEY_ALLOW_WP_ROCKET, false ) ) {
            return 'wp_rocket_unlicensed';
        }
        return null;
    }

    /**
     * Which version to install and from where, or why not.
     *
     * @return array{to:string, package:string}|array{reason:string, to?:?string}
     */
    public function plan( string $file, string $requested, string $installed ): array {
        $latest_wanted = 'latest' === $requested;

        if ( ! $latest_wanted && version_compare( $requested, $installed, '<' ) ) {
            return [ 'reason' => 'downgrade_refused', 'to' => $requested ];
        }

        if ( $this->crocoblock->available() && $this->crocoblock->covers( $file ) ) {
            $latest = $this->crocoblock->latest( $file );
            if ( null === $latest ) {
                return [ 'reason' => 'version_mismatch' ];
            }
            $target = $latest_wanted ? $latest : $requested;
            if ( version_compare( $target, $installed, '<' ) ) {
                return [ 'reason' => 'downgrade_refused', 'to' => $target ];
            }
            if ( version_compare( $target, $installed, '==' ) || version_compare( $target, $latest, '>' ) ) {
                return [ 'reason' => 'version_mismatch', 'to' => $target ];
            }
            $package = $this->crocoblock->package( $file, $latest_wanted ? false : $target );
            if ( null === $package['url'] ) {
                return [ 'reason' => 'package_unavailable', 'to' => $target ];
            }
            return [ 'to' => $target, 'package' => $package['url'] ];
        }

        $transient = $this->env->plugins_transient();
        $entry     = is_object( $transient ) && isset( $transient->response ) && is_array( $transient->response ) ? ( $transient->response[ $file ] ?? null ) : null;
        $offered   = is_object( $entry ) && isset( $entry->new_version ) && is_scalar( $entry->new_version ) ? trim( (string) $entry->new_version ) : '';

        if ( '' === $offered ) {
            // Nothing on offer from this plugin's own source.
            return [ 'reason' => 'version_mismatch' ];
        }
        if ( version_compare( $offered, $installed, '<' ) ) {
            return [ 'reason' => 'downgrade_refused', 'to' => $offered ];
        }
        if ( version_compare( $offered, $installed, '==' ) ) {
            return [ 'reason' => 'version_mismatch', 'to' => $offered ];
        }
        if ( ! $latest_wanted && ! version_compare( $requested, $offered, '==' ) ) {
            // Versioned packages are the Crocoblock adapter's alone in v1.
            return [ 'reason' => 'version_mismatch', 'to' => $offered ];
        }
        $package = SyncRunner::package_of( $entry );
        if ( null === $package ) {
            return [ 'reason' => 'package_unavailable', 'to' => $offered ];
        }
        return [ 'to' => $offered, 'package' => $package ];
    }

    /**
     * Known pairs first, everything else in the order asked. Stable, so a request
     * that is already in a safe order comes back unchanged.
     *
     * @param array<int, array{file:string, version:string}> $plugins
     * @return array<int, array{file:string, version:string}>
     */
    public static function order( array $plugins ): array {
        $rank = static function ( string $file ): int {
            $dir = explode( '/', $file )[0];
            $at  = array_search( $dir, self::FIRST, true );
            return false === $at ? count( self::FIRST ) : (int) $at;
        };
        $indexed = [];
        foreach ( array_values( $plugins ) as $i => $p ) {
            $indexed[] = [ $rank( $p['file'] ), $i, $p ];
        }
        usort( $indexed, static fn ( array $a, array $b ): int => [ $a[0], $a[1] ] <=> [ $b[0], $b[1] ] );
        return array_map( static fn ( array $row ): array => $row[2], $indexed );
    }

    /**
     * @param string[] $key_paths
     * @return array{0:array, 1:string}
     */
    private function baseline( array $key_paths ): array {
        return [ $this->health->snapshot( $key_paths ), $this->health->rest_probe() ];
    }

    /** Health after an automatic rollback, so the CC can see the site came back. */
    private function recheck( array $before, array $key_paths ): array {
        $after = $this->health->snapshot( $key_paths );
        $probe = $this->health->rest_probe();
        return [
            'home'       => [ 'before' => $before['home'], 'after' => $after['home'] ],
            'rest_probe' => 'ok' === $probe ? 'ok' : 'failed',
            'verdict'    => HealthCheck::verdict( $before, $after, $probe ),
        ];
    }

    private function reactivate( string $file, bool $was_active ): void {
        if ( $was_active && ! $this->env->is_active( $file ) ) {
            $this->env->activate( $file );
        }
    }

    /** @return array<string, mixed> One result in the contract's shape. */
    private static function result( string $file, ?string $from, ?string $to, string $outcome, ?string $reason ): array {
        return [
            'file'      => $file,
            'from'      => $from,
            'to'        => $to,
            'read_back' => null,
            'outcome'   => $outcome,
            'reason'    => $reason,
            'health'    => null,
            'backup'    => null,
        ];
    }
}
