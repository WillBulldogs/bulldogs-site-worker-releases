<?php
namespace Bulldogs\SiteWorker\CLI;

use Bulldogs\SiteWorker\Actions\ActionStore;
use Bulldogs\SiteWorker\Actions\ActionAuth;
use Bulldogs\SiteWorker\Actions\Backups;
use Bulldogs\SiteWorker\Actions\Environment;
use Bulldogs\SiteWorker\Actions\UpdateRunner;
use Bulldogs\SiteWorker\Settings;
use WP_CLI;

/**
 * `wp bulldogs actions ...` - what the on-demand actions have done here, and the
 * one site-local switch the policy reads.
 *
 * Registered whether or not the `sync` / `actions` modules are on, for the reason
 * the module commands are: the command an operator reaches for to see why an
 * action was refused has to exist on the site that refused it.
 *
 * ---------------------------------------------------------------------------
 * THE WP ROCKET FLAG IS LOCAL, ON PURPOSE
 * ---------------------------------------------------------------------------
 * `allow-wp-rocket` is the only way the actions route will update WP Rocket on
 * this site (decision D5). It is set here, over SSH or a one-shot on Brixly, and
 * never by any remote request: our WP Rocket licence lapsed in Feb 2026 and most
 * copies carry a hand patch that a reinstall reverts, taking the site down on the
 * next request. The two Beau sites run a live client licence and are the expected
 * users. The two nulled copies (hhtyfcco, phxgymco) are never flagged.
 */
class ActionsCommands {
    /**
     * Recent actions, their stage 2 results, and the rollback backups held here.
     *
     * ## OPTIONS
     *
     * [--format=<format>]
     * : Render output in a particular format.
     * ---
     * default: table
     * options:
     *   - table
     *   - json
     *   - yaml
     * ---
     *
     * ## EXAMPLES
     *
     *     wp bulldogs actions status
     *
     * @param array $args  Unused.
     * @param array $assoc Associative arguments.
     */
    public function status( $args, $assoc ): void {
        $format   = isset( $assoc['format'] ) && is_string( $assoc['format'] ) ? $assoc['format'] : 'table';
        $store    = new ActionStore();
        $env      = new Environment();
        $backups  = new Backups( $env, $store, ActionAuth::host_of( $env->home_url( '/' ) ) );
        $settings = new Settings();

        $rows = self::action_rows( $store );
        $kept = self::backup_rows( $backups->listing(), $store->now() );
        $lock = $store->lock();

        if ( 'table' !== $format ) {
            WP_CLI::print_value(
                [
                    'lock'           => $lock,
                    'actions'        => $rows,
                    'backups'        => $kept,
                    'wp_rocket_flag' => true === $settings->get( UpdateRunner::KEY_ALLOW_WP_ROCKET, false ),
                    'backup_dir_ok'  => null !== $backups->dir(),
                ],
                [ 'format' => $format ]
            );
            return;
        }

        WP_CLI::log( null === $lock ? 'Lock: free' : sprintf( 'Lock: held by %s (%s) for %ds more', $lock['id'], $lock['action'], $lock['expires'] - $store->now() ) );
        WP_CLI::log( 'WP Rocket updates: ' . ( true === $settings->get( UpdateRunner::KEY_ALLOW_WP_ROCKET, false ) ? 'ALLOWED on this site' : 'refused (no local flag)' ) );
        WP_CLI::log( 'Backup folder: ' . ( null !== $backups->dir() ? 'usable, outside the web root' : 'NOT usable - updates will be refused (no_safe_backup_dir)' ) );
        WP_CLI::log( '' );

        if ( [] === $rows ) {
            WP_CLI::log( 'No actions recorded here.' );
        } else {
            \WP_CLI\Utils\format_items( 'table', $rows, [ 'id', 'action', 'state', 'stage', 'started', 'finished', 'outcomes', 'stage2' ] );
        }
        WP_CLI::log( '' );
        if ( [] === $kept ) {
            WP_CLI::log( 'No rollback backups held here.' );
        } else {
            \WP_CLI\Utils\format_items( 'table', $kept, [ 'id', 'file', 'version', 'created', 'rollback', 'bytes' ] );
        }
    }

    /**
     * Allow the actions route to update WP Rocket on THIS site.
     *
     * Only for a site with a live WP Rocket licence and an unpatched copy. Read the
     * WP Rocket SOP before using it.
     *
     * ## OPTIONS
     *
     * [--yes]
     * : Confirm. Required.
     *
     * ## EXAMPLES
     *
     *     wp bulldogs actions allow-wp-rocket --yes
     *
     * @subcommand allow-wp-rocket
     *
     * @param array $args  Unused.
     * @param array $assoc Associative arguments.
     */
    public function allow_wp_rocket( $args, $assoc ): void {
        if ( empty( $assoc['yes'] ) ) {
            WP_CLI::log( '  - Our WP Rocket licence lapsed in Feb 2026 and most fleet copies carry a hand patch. A reinstall reverts the patch and takes the site down on the next request.' );
            WP_CLI::log( '  - Only flag a site with its own live licence (the two Beau sites). Never hhtyfcco or phxgymco.' );
            WP_CLI::error( 'refusing without --yes.' );
            return;
        }
        ( new Settings() )->set( UpdateRunner::KEY_ALLOW_WP_ROCKET, true );
        WP_CLI::success( 'WP Rocket updates are now allowed through the actions route on this site.' );
    }

    /**
     * Refuse WP Rocket updates through the actions route on this site again (the default).
     *
     * ## EXAMPLES
     *
     *     wp bulldogs actions deny-wp-rocket
     *
     * @subcommand deny-wp-rocket
     *
     * @param array $args  Unused.
     * @param array $assoc Unused.
     */
    public function deny_wp_rocket( $args, $assoc ): void {
        ( new Settings() )->set( UpdateRunner::KEY_ALLOW_WP_ROCKET, false );
        WP_CLI::success( 'WP Rocket updates through the actions route are refused on this site.' );
    }

    /**
     * Pure: the record store as table rows.
     *
     * @return array<int, array<string, mixed>>
     */
    public static function action_rows( ActionStore $store ): array {
        $rows = [];
        foreach ( $store->recent() as $summary ) {
            $view     = $store->view( $summary['id'] );
            $outcomes = [];
            foreach ( is_array( $view['result']['results'] ?? null ) ? $view['result']['results'] : [] as $r ) {
                if ( is_array( $r ) ) {
                    $outcomes[] = ( $r['file'] ?? '?' ) . ': ' . ( $r['outcome'] ?? '?' ) . ( isset( $r['reason'] ) && is_string( $r['reason'] ) ? ' (' . $r['reason'] . ')' : '' );
                }
            }
            $stage2 = is_array( $view['stage2'] ) ? (string) ( $view['stage2']['state'] ?? '' ) : '';
            if ( is_array( $view['stage2'] ) && 'done' === $stage2 ) {
                $stage2 .= sprintf( ' (%d warmed, %d cut, %d [MIN])', (int) ( $view['stage2']['urls_warmed'] ?? 0 ), (int) ( $view['stage2']['urls_cut'] ?? 0 ), (int) ( $view['stage2']['min_missing'] ?? 0 ) );
            }
            $rows[] = [
                'id'       => $summary['id'],
                'action'   => $summary['action'],
                'state'    => $view['state'],
                'stage'    => (string) $view['stage'],
                'started'  => is_int( $view['started'] ) ? gmdate( 'Y-m-d H:i', $view['started'] ) : '',
                'finished' => is_int( $view['finished'] ) ? gmdate( 'Y-m-d H:i', $view['finished'] ) : '',
                'outcomes' => implode( '; ', $outcomes ),
                'stage2'   => $stage2,
            ];
        }
        return $rows;
    }

    /**
     * @param array<int, array<string, mixed>> $listing Backups::listing().
     * @return array<int, array<string, mixed>>
     */
    public static function backup_rows( array $listing, int $now ): array {
        $rows = [];
        foreach ( $listing as $b ) {
            $rows[] = [
                'id'       => $b['id'],
                'file'     => $b['file'],
                'version'  => $b['version'],
                'created'  => gmdate( 'Y-m-d H:i', (int) $b['created'] ),
                'rollback' => $now <= (int) $b['rollback_until'] ? 'until ' . gmdate( 'Y-m-d', (int) $b['rollback_until'] ) : 'expired',
                'bytes'    => (string) $b['bytes'],
            ];
        }
        return $rows;
    }
}
