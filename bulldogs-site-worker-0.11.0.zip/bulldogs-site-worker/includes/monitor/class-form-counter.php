<?php
namespace Bulldogs\SiteWorker\Monitor;

/**
 * Counts Divi contact form submissions, per month, per form. Counts only.
 *
 * ---------------------------------------------------------------------------
 * WHY THIS EXISTS
 * ---------------------------------------------------------------------------
 * Divi's Contact Form module emails the message and keeps nothing. There is no
 * submissions table, so a site built on it cannot answer "how many enquiries
 * came through the website this month" from anything we can read. GA4 cannot
 * either: since the consent rollout it only sees visitors who accepted analytics,
 * and only on forms that redirect to a page it can count. Measured on Beau
 * Property Staging, 12 Oct 2026: six Divi forms, one redirect, so five of the
 * six left no trace anywhere. The monthly client report leads with enquiries,
 * so that was a hole in the one number it exists to give.
 *
 * Divi fires `et_pb_contact_form_submit` after every submit (ContactForm.php,
 * since Divi 4.13.1), with a flag saying whether the submit failed - captcha,
 * reCAPTCHA spam check, a missing required field, a bad nonce. Only a submit
 * with that flag clear is counted: that is the same condition under which Divi
 * sends the email, so the count is "messages the client was sent".
 *
 * ---------------------------------------------------------------------------
 * 🚨 NO PERSONAL DATA, BY CONSTRUCTION
 * ---------------------------------------------------------------------------
 * The submitted fields are the hook's first argument and are never read. What is
 * stored is the month, the page it was sent from, Divi's id for the form, and a
 * number. That is what a report needs, and it keeps this plugin out of holding
 * enquirers' names and emails on every site in the fleet - which would make it
 * a new store of personal data needing its own retention and access story.
 *
 * ---------------------------------------------------------------------------
 * ZERO IS ONLY A ZERO AFTER `counting_since`
 * ---------------------------------------------------------------------------
 * The first boot stamps when counting began. A month before that stamp has no
 * data, not no enquiries, and the report carries the stamp so a reader can tell
 * the two apart. The same goes for a site with no Divi: `divi: false` means the
 * section does not apply, not that nobody wrote in.
 */
class FormCounter {
    public const OPTION = 'bulldogs_sw_form_counts';

    /** Months kept. Two years covers a year-on-year comparison with room spare. */
    public const KEEP_MONTHS = 24;

    public const SOURCE_DIVI = 'divi';

    /** One count per request. See on_divi_submit(). */
    private static bool $counted_this_request = false;

    public function register(): void {
        $this->ensure_started();
        add_action( 'et_pb_contact_form_submit', [ $this, 'on_divi_submit' ], 10, 3 );
    }

    /**
     * Hooked to `et_pb_contact_form_submit`.
     *
     * ⚠️ ONCE PER REQUEST. Divi renders the form module wherever its shortcode is
     * expanded, and the hook fires from inside that render. An SEO plugin building
     * a meta description from the content, or a theme builder layout rendering the
     * same page twice, expands it again in the same request and fires the hook
     * again for the same POST. One POST is one submission, so the first counts and
     * the rest are ignored.
     *
     * @param mixed $fields Submitted values. Deliberately unused - see the class note.
     * @param mixed $error  True when Divi rejected the submit.
     * @param mixed $info   contact_form_id, post_id, ...
     */
    public function on_divi_submit( $fields, $error, $info ): void {
        try {
            if ( false !== $error || self::$counted_this_request ) {
                return;
            }
            self::$counted_this_request = true;

            $info    = is_array( $info ) ? $info : [];
            $post_id = isset( $info['post_id'] ) && is_numeric( $info['post_id'] ) ? (int) $info['post_id'] : 0;
            $form_id = isset( $info['contact_form_id'] ) && is_string( $info['contact_form_id'] ) ? $info['contact_form_id'] : '';
            $path    = self::path_of( isset( $_SERVER['REQUEST_URI'] ) ? (string) $_SERVER['REQUEST_URI'] : '' );

            $stored = get_option( self::OPTION );
            $stored = self::record(
                is_array( $stored ) ? $stored : [],
                (string) wp_date( 'Y-m' ),
                self::SOURCE_DIVI,
                $post_id,
                $form_id,
                $path,
                time()
            );
            // Autoloaded, matching ensure_started(): the row is a few hundred bytes,
            // and leaving it out of the cache would cost a query on every page load.
            update_option( self::OPTION, $stored, true );
        } catch ( \Throwable $e ) {
            // Counting is a convenience. It must never break a client's contact form.
            if ( function_exists( 'error_log' ) ) {
                error_log( 'bulldogs-site-worker: form counter failed: ' . $e->getMessage() );
            }
        }
    }

    /**
     * Add one submission to the store. Pure, so the suite can drive it.
     *
     * @param array<string, mixed> $store
     * @return array<string, mixed>
     */
    public static function record( array $store, string $month, string $source, int $post_id, string $form_id, string $path, int $now ): array {
        if ( ! preg_match( '/^\d{4}-\d{2}$/', $month ) ) {
            return $store;
        }
        $store  = self::normalise( $store, $now );
        $key    = $source . ':' . $post_id . ':' . $form_id;
        $months = $store['months'];

        $row = isset( $months[ $month ][ $key ] ) && is_array( $months[ $month ][ $key ] ) ? $months[ $month ][ $key ] : [];
        $months[ $month ][ $key ] = [
            'source'  => $source,
            'post_id' => $post_id,
            'form_id' => $form_id,
            'path'    => '' !== $path ? $path : ( isset( $row['path'] ) && is_string( $row['path'] ) ? $row['path'] : '' ),
            'count'   => ( isset( $row['count'] ) && is_int( $row['count'] ) ? $row['count'] : 0 ) + 1,
        ];

        // Keep the newest KEEP_MONTHS. "YYYY-MM" sorts as text in date order.
        ksort( $months );
        $store['months'] = array_slice( $months, -self::KEEP_MONTHS, null, true );
        return $store;
    }

    /**
     * The `forms` section of the findings response.
     *
     * @return array{divi: bool, counting_since: int|null, months: array<string, array<int, array<string, mixed>>>}
     */
    public function gather(): array {
        $stored = function_exists( 'get_option' ) ? get_option( self::OPTION ) : false;
        return self::shape( is_array( $stored ) ? $stored : [], self::divi_present() );
    }

    /**
     * @param array<string, mixed> $stored
     * @return array{divi: bool, counting_since: int|null, months: array<string, array<int, array<string, mixed>>>}
     */
    public static function shape( array $stored, bool $divi ): array {
        $months = [];
        foreach ( isset( $stored['months'] ) && is_array( $stored['months'] ) ? $stored['months'] : [] as $month => $rows ) {
            if ( ! is_string( $month ) || ! is_array( $rows ) ) {
                continue;
            }
            $months[ $month ] = array_values( array_filter( $rows, 'is_array' ) );
        }
        ksort( $months );

        return [
            'divi'           => $divi,
            'counting_since' => isset( $stored['since'] ) && is_int( $stored['since'] ) ? $stored['since'] : null,
            'months'         => $months,
        ];
    }

    /** The path a form was sent from, without the query string (which can carry anything). */
    public static function path_of( string $uri ): string {
        $path = strtok( $uri, '?#' );
        return is_string( $path ) ? substr( $path, 0, 200 ) : '';
    }

    /**
     * Stamp when counting began, once. Autoloaded, so checking it on a normal page
     * load reads WordPress's option cache rather than the database.
     */
    private function ensure_started(): void {
        $stored = get_option( self::OPTION );
        if ( is_array( $stored ) && isset( $stored['since'] ) ) {
            return;
        }
        update_option( self::OPTION, self::normalise( is_array( $stored ) ? $stored : [], time() ), true );
    }

    /**
     * @param array<string, mixed> $store
     * @return array{since:int, months:array<string, mixed>}
     */
    private static function normalise( array $store, int $now ): array {
        return [
            'since'  => isset( $store['since'] ) && is_int( $store['since'] ) ? $store['since'] : $now,
            'months' => isset( $store['months'] ) && is_array( $store['months'] ) ? $store['months'] : [],
        ];
    }

    /** Divi as the theme (or parent theme), Extra, or the Divi Builder plugin. */
    private static function divi_present(): bool {
        if ( function_exists( 'get_template' ) && in_array( get_template(), [ 'Divi', 'Extra' ], true ) ) {
            return true;
        }
        $active = function_exists( 'get_option' ) ? get_option( 'active_plugins' ) : [];
        return is_array( $active ) && in_array( 'divi-builder/divi-builder.php', $active, true );
    }
}
