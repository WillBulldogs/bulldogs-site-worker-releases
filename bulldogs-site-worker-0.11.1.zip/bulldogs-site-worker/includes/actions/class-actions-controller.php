<?php
namespace Bulldogs\SiteWorker\Actions;

use Bulldogs\SiteWorker\Modules;
use Bulldogs\SiteWorker\Monitor\SecurityReport;
use Bulldogs\SiteWorker\Monitor\SiteSecret;
use Bulldogs\SiteWorker\Monitor\UpdateReport;
use Bulldogs\SiteWorker\Settings;

/**
 * `POST /wp-json/bulldogs-sw/v1/actions` - signed, on-demand `sync`, `update`,
 * `rollback` and `status`, called by the Control Centre's executor and nothing else.
 *
 * ---------------------------------------------------------------------------
 * 🚨 DORMANT UNLESS SWITCHED ON, AND ONLY BY HAND
 * ---------------------------------------------------------------------------
 * The route is registered only when module `sync` or module `actions` is on. Both
 * default OFF, and neither can be switched on by any remote request - only by
 * `wp bulldogs module enable` (LDN1) or a one-shot over the reseller API (Brixly).
 * If a remote command could switch them on, the switch would mean nothing. With
 * both off the route does not exist, the caller gets WordPress's own 404
 * `rest_no_route`, and a site on this version is byte-identical to one on 0.10.x.
 *
 * ---------------------------------------------------------------------------
 * WHY THE PERMISSION CALLBACK IS __return_true
 * ---------------------------------------------------------------------------
 * Not because the route is open: dispatch() refuses everything before ActionAuth
 * has passed, and does nothing else first. The checks live in the handler because
 * (a) the signature has to be verified over the RAW body, and (b) every refusal
 * must come back in the contract's body shape, `{"ok":false,"code","message"}`,
 * with the contract's status codes - a permission callback can only answer with a
 * WP_Error, which WordPress renders in its own shape.
 *
 * ---------------------------------------------------------------------------
 * THE CHECK ORDER (CONTRACT.md)
 * ---------------------------------------------------------------------------
 *   1-4  ActionAuth: secret, signature, shape/site/time, nonce
 *   5    action known (422 unknown_action); its module on (422 module_disabled)
 *   6    params valid (422 invalid_params / invalid_key_path); sync rate (429)
 *   7    the site lock (409 busy). `status` never locks.
 *
 * ---------------------------------------------------------------------------
 * LONG REQUESTS
 * ---------------------------------------------------------------------------
 * Stage 1 runs inside the request with ignore_user_abort(true), so if the CC's
 * connection drops the site still finishes and records the result against the
 * action id.
 *
 * 🚨 STAGE 2 RUNS IN ITS OWN REQUEST, FROM WP-CRON - NEVER INSIDE THIS ONE.
 * 0.11.0 ran it on `shutdown` after fastcgi_finish_request(). The first real
 * update (template, 23 Oct 2026) proved that wrong: template is one of the four
 * LDN1 vhosts that run PHP as plain CGI (/cgi-sys/ea-php82, not an FPM pool), where
 * fastcgi_finish_request() does not exist, so stage 2 ran inline and Apache held
 * the CC's connection for the whole 265 s cache cycle; the CC's 240 s timeout
 * fired inside it. Whether a response can be released early depends on the SAPI,
 * and the fleet has three (FPM, CGI, LiteSpeed). So stage 2 is scheduled as a
 * single WP-Cron event keyed by the action id and kicked with a non-blocking
 * loopback, and the stage 1 response returns the moment stage 1 is done, on any
 * SAPI. The site lock is held across the gap. The record says how stage 2 ran:
 * `mode` is `cron`, or `deferred` / `inline` on the shutdown fallback used only
 * when the event cannot be scheduled. A stage 2 that is queued or started and
 * never finishes still reads `died` once its deadline passes.
 */
class ActionsController {
    public const ROUTE = '/actions';

    /** Seconds. Stage 1 lock (spec §5.5). */
    public const STAGE1_TTL = 900;

    /** Seconds. Stage 2 lock. */
    public const STAGE2_TTL = 1800;

    public const ACTIONS = [ 'sync', 'update', 'rollback', 'status' ];

    /**
     * A plugin file as get_plugins() keys it: one optional directory, a file name
     * ending .php, each segment starting with a letter or digit (so no `.`, `..` or
     * dot-file segment). Whether it is INSTALLED is checked against the exact keys of
     * get_plugins() by UpdateRunner (`not_installed`).
     */
    public const FILE_PATTERN = '/^(?:[A-Za-z0-9][A-Za-z0-9._-]*\/)?[A-Za-z0-9][A-Za-z0-9._-]*\.php$/';

    /** An id Backups minted. Only ever looked up in the index, never turned into a path. */
    public const BACKUP_PATTERN = '/^bk_[A-Za-z0-9]{16,64}$/';

    private const MAX_PLUGINS   = 10;
    private const MAX_KEY_PATHS = 10;

    private static bool $booted = false;

    /** @var \Closure(\Closure): void */
    private \Closure $defer;

    /** The WP-Cron hook stage 2 runs on. One event per action id. */
    public const STAGE2_HOOK = 'bulldogs_sw_actions_stage2';

    private string $current = '';

    /**
     * @param \Closure(string, string[]): void|null $defer How stage 2 is handed off, given the
     *        action id and key paths. Null means schedule(): a WP-Cron event plus a
     *        non-blocking loopback. The suite captures it and runs stage 2 itself.
     */
    public function __construct(
        private Modules $modules,
        private ActionAuth $auth,
        private ActionStore $store,
        private Environment $env,
        private SyncRunner $sync,
        private UpdateRunner $updates,
        private CacheCycle $cache,
        private UpdateReport $update_report,
        ?\Closure $defer = null
    ) {
        $this->defer = $defer ?? fn ( string $id, array $key_paths ) => $this->schedule( $id, $key_paths );
        $this->updates->set_heartbeat( fn () => $this->store->extend_lock( $this->current, self::STAGE1_TTL ) );
    }

    /**
     * Called from the `sync` and `actions` module boot callbacks. Either one being on
     * mounts the route; both on mounts it once.
     */
    public static function boot(): void {
        if ( self::$booted || ! function_exists( 'add_action' ) ) {
            return;
        }
        self::$booted = true;
        add_action(
            'rest_api_init',
            static function (): void {
                self::build()->register_routes();
            }
        );
        // Registered on every request the module boots on, because WP-Cron runs
        // the event in a request of its own (wp-cron.php), not this one.
        add_action( self::STAGE2_HOOK, [ self::class, 'run_scheduled' ], 10, 1 );
    }

    /** WP-Cron callback. Never throws into WP-Cron. */
    public static function run_scheduled( mixed $id = null ): void {
        try {
            if ( ! is_string( $id ) || 1 !== preg_match( '/^[A-Za-z0-9_\-]{1,100}$/', $id ) ) {
                return;
            }
            self::build()->run_stage2_from_cron( $id );
        } catch ( \Throwable $e ) {
            OutputSanitiser::log( 'scheduled stage 2 failed (' . get_class( $e ) . ')' );
        }
    }

    /**
     * Run a queued stage 2, once. Only for a record that is in stage 2, unfinished,
     * still `queued` (so a duplicate event or a second cron runner does nothing), and
     * whose lock this action still holds. The key paths come from the record, never
     * from the event's arguments.
     */
    public function run_stage2_from_cron( string $id ): bool {
        $record = $this->store->record( $id );
        $lock   = $this->store->lock();
        if (
            null === $record
            || 2 !== ( $record['stage'] ?? null )
            || null !== ( $record['finished'] ?? null )
            || 'queued' !== ( $record['stage2']['state'] ?? null )
            || null === $lock
            || $lock['id'] !== $id
        ) {
            return false;
        }
        $paths = [];
        foreach ( is_array( $record['key_paths'] ?? null ) ? $record['key_paths'] : [] as $path ) {
            if ( self::valid_path( $path ) ) {
                $paths[] = $path;
            }
        }
        $this->stage2( $id, $paths, 'cron' );
        return true;
    }

    /** The real wiring. */
    public static function build(): self {
        $settings = new Settings();
        $modules  = new Modules( $settings );
        $secret   = new SiteSecret( $settings );
        $store    = new ActionStore();
        $env      = new Environment();
        $host     = ActionAuth::host_of( $env->home_url( '/' ) );
        $croc     = new CrocoblockAdapter( $env );
        $packages = new PackageCheck();
        $report   = new UpdateReport();
        $sync     = new SyncRunner(
            $env,
            $croc,
            $packages,
            $report,
            new SecurityReport(),
            null,
            class_exists( \Bulldogs\SiteWorker\Vendors\VendorVersions::class )
                ? new \Bulldogs\SiteWorker\Vendors\VendorVersions( $env, new \Bulldogs\SiteWorker\Vendors\VendorStore() )
                : null
        );
        $updates  = new UpdateRunner(
            $env,
            $croc,
            $sync,
            $packages,
            new HealthCheck( $env, $secret, $modules ),
            new ErrorLog( $env ),
            new Backups( $env, $store, $host ),
            $settings
        );

        return new self( $modules, new ActionAuth( $secret, $store ), $store, $env, $sync, $updates, new CacheCycle( $env ), $report );
    }

    public function register_routes(): void {
        if ( ! function_exists( 'register_rest_route' ) ) {
            return;
        }
        register_rest_route(
            \Bulldogs\SiteWorker\Monitor\RestController::REST_NAMESPACE,
            self::ROUTE,
            [
                [
                    'methods'             => 'POST',
                    'callback'            => [ $this, 'handle' ],
                    // See the class docblock: authentication is the first thing
                    // handle() does, and it needs the raw body.
                    'permission_callback' => '__return_true',
                    'show_in_index'       => false,
                ],
            ]
        );
    }

    /**
     * @param mixed $request WP_REST_Request in production.
     * @return mixed WP_REST_Response when WordPress is present, the body otherwise.
     */
    public function handle( $request ) {
        $secret = self::header( $request, 'x-bsw-secret' );
        $sig    = self::header( $request, ActionAuth::SIGNATURE_HEADER );
        $raw    = is_object( $request ) && method_exists( $request, 'get_body' ) ? $request->get_body() : '';

        $out = $this->dispatch( $secret, $sig, is_string( $raw ) ? $raw : '' );

        if ( class_exists( 'WP_REST_Response' ) ) {
            $response = new \WP_REST_Response( $out['body'], $out['status'] );
            $response->header( 'Cache-Control', 'no-store, no-cache, must-revalidate, max-age=0' );
            return $response;
        }
        return $out['body'];
    }

    /**
     * Everything, without WordPress's request and response objects.
     *
     * @return array{status:int, body:array<string,mixed>}
     */
    public function dispatch( string $secret, string $signature, string $raw ): array {
        try {
            return $this->sanitised( $this->route( $secret, $signature, $raw ) );
        } catch ( \Throwable $e ) {
            OutputSanitiser::log( 'actions route failed: ' . $e->getMessage() );
            if ( '' !== $this->current ) {
                $this->store->release_lock( $this->current );
            }
            return $this->sanitised( self::error( 500, 'internal_error', 'The action failed on the site. See the PHP error log.' ) );
        }
    }

    /** @return array{status:int, body:array<string,mixed>} */
    private function route( string $secret, string $signature, string $raw ): array {
        $home = ActionAuth::host_of( $this->env->home_url( '/' ) );

        // 1-4.
        $auth = $this->auth->check( $secret, $signature, $raw, $home );
        if ( true !== $auth['ok'] ) {
            return self::error( $auth['status'], $auth['code'], $auth['message'] );
        }
        $req = $auth['request'];

        // 5.
        if ( ! in_array( $req['action'], self::ACTIONS, true ) ) {
            return self::error( 422, 'unknown_action', 'Unknown action.' );
        }
        if ( ! $this->module_allows( $req['action'] ) ) {
            return self::error( 422, 'module_disabled', 'That action is switched off on this site.' );
        }

        // 6.
        $params = $this->params( $req['action'], $req['params'], $home );
        if ( isset( $params['error'] ) ) {
            return $params['error'];
        }
        if ( 'sync' === $req['action'] ) {
            $elapsed = $this->store->now() - $this->store->last_sync();
            if ( $elapsed < SyncRunner::MIN_INTERVAL ) {
                $err                        = self::error( 429, 'rate_limited', 'A sync ran here recently.' );
                $err['body']['retry_after'] = SyncRunner::MIN_INTERVAL - $elapsed;
                return $err;
            }
        }

        if ( 'status' === $req['action'] ) {
            return self::ok( $req, [ 'record' => $this->store->view( $params['of'] ) ] );
        }

        // 7.
        if ( ! $this->store->acquire_lock( $req['id'], $req['action'], self::STAGE1_TTL ) ) {
            return self::error( 409, 'busy', 'Another action is running on this site.' );
        }
        $this->current = $req['id'];
        $this->long_request( self::STAGE1_TTL );
        $this->store->start_record( $req['id'], $req['action'], $this->store->now() + self::STAGE1_TTL );

        if ( 'sync' === $req['action'] ) {
            $this->store->mark_sync();
            $body = $this->sync->run();
            $this->store->finish_stage1( $req['id'], OutputSanitiser::clean( [ 'ok' => true, 'duration_ms' => $body['duration_ms'], 'adapters' => $body['adapters'] ] ), 'skipped' );
            $this->store->release_lock( $req['id'] );
            $this->current = '';
            return self::ok( $req, $body );
        }

        $run = 'update' === $req['action']
            ? $this->updates->update( $params['plugins'], $params['key_paths'], $params['auto_rollback'] )
            : $this->updates->rollback( $params['backup'], $params['key_paths'], $params['auto_rollback'] );

        // A fresh report after the run, so the CC's view moves with the site.
        $this->sync->refresh();
        $stage2 = $run['changed'] ? 'queued' : 'skipped';
        $body   = [
            'results'       => $run['results'],
            'order_applied' => $run['order_applied'],
            'stage2'        => $stage2,
            'updates'       => SyncRunner::section( $this->update_report ),
        ];

        $this->store->finish_stage1(
            $req['id'],
            OutputSanitiser::clean( [ 'results' => $run['results'], 'order_applied' => $run['order_applied'] ] ),
            $stage2,
            $this->store->now() + self::STAGE2_TTL
        );

        if ( 'queued' === $stage2 ) {
            $this->store->extend_lock( $req['id'], self::STAGE2_TTL );
            $this->store->annotate( $req['id'], [ 'key_paths' => $params['key_paths'] ] );
            ( $this->defer )( $req['id'], $params['key_paths'] );
        } else {
            $this->store->release_lock( $req['id'] );
        }
        $this->current = '';

        return self::ok( $req, $body );
    }

    /**
     * The cache cycle, recorded as it goes so a stage that is killed half way still
     * says how far it got - and reads `died` once its deadline passes.
     *
     * `mode` is how it ran: `cron` (its own request), `deferred` (shutdown, after the
     * response was released) or `inline` (shutdown, holding the connection).
     * `flushed` is kept for 0.11.0 readers: true unless the run was inline.
     *
     * @param string[] $key_paths
     */
    public function stage2( string $id, array $key_paths, string $mode ): void {
        $this->long_request( self::STAGE2_TTL );
        $this->store->extend_lock( $id, self::STAGE2_TTL );
        $this->store->update_stage2( $id, [ 'state' => 'running', 'mode' => $mode, 'flushed' => 'inline' !== $mode, 'started' => $this->store->now() ] );
        try {
            $data = $this->cache->run(
                $key_paths,
                function ( array $partial ) use ( $id ): void {
                    $this->store->extend_lock( $id, self::STAGE2_TTL );
                    $this->store->update_stage2( $id, $partial );
                }
            );
            $this->store->update_stage2( $id, $data, true );
        } catch ( \Throwable $e ) {
            OutputSanitiser::log( 'stage 2 failed: ' . $e->getMessage() );
            $this->store->update_stage2( $id, [ 'state' => 'died', 'error' => OutputSanitiser::string( substr( $e->getMessage(), 0, 200 ) ) ] );
            $this->store->expire( $id );
        } finally {
            $this->store->release_lock( $id );
        }
    }

    private function module_allows( string $action ): bool {
        $actions = $this->modules->is_enabled( Modules::ACTIONS );
        if ( 'update' === $action || 'rollback' === $action ) {
            return $actions;
        }
        return $actions || $this->modules->is_enabled( Modules::SYNC );
    }

    /**
     * Per-action params, validated and normalised, or the error to return.
     *
     * @param array<string, mixed> $p
     * @return array<string, mixed>
     */
    private function params( string $action, array $p, string $home ): array {
        $bad = static fn ( string $why ): array => [ 'error' => self::error( 422, 'invalid_params', $why ) ];

        if ( 'sync' === $action ) {
            return [];
        }
        if ( 'status' === $action ) {
            $of = $p['of'] ?? null;
            if ( ! is_string( $of ) || 1 !== preg_match( '/^[A-Za-z0-9_\-]{1,100}$/', $of ) ) {
                return $bad( '`of` must be an action id.' );
            }
            return [ 'of' => $of ];
        }

        $auto = $p['auto_rollback'] ?? ( 'update' === $action );
        if ( ! is_bool( $auto ) ) {
            return $bad( '`auto_rollback` must be a boolean.' );
        }

        $paths = $p['key_paths'] ?? [];
        if ( ! is_array( $paths ) || ! array_is_list( $paths ) || count( $paths ) > self::MAX_KEY_PATHS ) {
            return $bad( '`key_paths` must be a list of at most 10 paths.' );
        }
        $key_paths = [];
        foreach ( $paths as $path ) {
            if ( ! self::valid_path( $path ) || ActionAuth::host_of( $this->env->home_url( $path ) ) !== $home ) {
                return [ 'error' => self::error( 422, 'invalid_key_path', 'A key path must be a path on this site, starting with a single /.' ) ];
            }
            $key_paths[] = $path;
        }
        $key_paths = array_values( array_unique( $key_paths ) );

        if ( 'rollback' === $action ) {
            $backup = $p['backup'] ?? null;
            if ( ! is_string( $backup ) || 1 !== preg_match( self::BACKUP_PATTERN, $backup ) ) {
                return $bad( '`backup` must be a backup id.' );
            }
            return [ 'backup' => $backup, 'key_paths' => $key_paths, 'auto_rollback' => $auto ];
        }

        $list = $p['plugins'] ?? null;
        if ( ! is_array( $list ) || ! array_is_list( $list ) || [] === $list || count( $list ) > self::MAX_PLUGINS ) {
            return $bad( '`plugins` must be a list of 1 to 10 plugins.' );
        }
        $plugins = [];
        $seen    = [];
        foreach ( $list as $item ) {
            $file    = is_array( $item ) ? ( $item['file'] ?? null ) : null;
            $version = is_array( $item ) ? ( $item['version'] ?? null ) : null;
            if ( ! is_string( $file ) || 1 !== preg_match( self::FILE_PATTERN, $file ) || str_contains( $file, '..' ) ) {
                return $bad( 'Each plugin needs an installed plugin file.' );
            }
            if ( ! is_string( $version ) || ( 'latest' !== $version && 1 !== preg_match( '/^[0-9][0-9A-Za-z.\-+_]{0,39}$/', $version ) ) ) {
                return $bad( 'Each plugin needs a version: "latest" or an exact version.' );
            }
            if ( isset( $seen[ $file ] ) ) {
                return $bad( 'A plugin is named twice.' );
            }
            $seen[ $file ] = true;
            $plugins[]     = [ 'file' => $file, 'version' => $version ];
        }
        return [ 'plugins' => $plugins, 'key_paths' => $key_paths, 'auto_rollback' => $auto ];
    }

    /** A path on this site: one leading slash, no scheme, no host, nothing to escape. */
    public static function valid_path( mixed $path ): bool {
        return is_string( $path )
            && '' !== $path
            && strlen( $path ) <= 200
            && str_starts_with( $path, '/' )
            && ! str_starts_with( $path, '//' )
            && 1 !== preg_match( '/[\x00-\x20\x7f\\\\#@]/', $path )
            && ! str_contains( $path, '://' )
            && ! str_contains( $path, '..' );
    }

    /**
     * Stage 1 must finish even if the CC hangs up, and must be allowed the time.
     * set_time_limit() is disabled on some hosts, which is why it is checked first.
     */
    private function long_request( int $seconds ): void {
        if ( function_exists( 'ignore_user_abort' ) ) {
            ignore_user_abort( true );
        }
        if ( function_exists( 'set_time_limit' ) ) {
            @set_time_limit( $seconds );
        }
    }

    /**
     * Hand stage 2 to WP-Cron and kick it. Returns at once; nothing here waits on
     * the cache cycle.
     *
     * The kick is spawn_cron(): a loopback POST to wp-cron.php with `blocking`
     * false, the same request WordPress itself makes, so it respects the host's
     * `cron_request` filter. It works with DISABLE_WP_CRON (that only stops the
     * page-load trigger; wp-cron.php still runs when asked). Under
     * ALTERNATE_WP_CRON spawn_cron() would REDIRECT this very request, which would
     * break the JSON response, so there the loopback is posted directly instead.
     * If the kick is lost (another cron run holding WordPress's 60 s lock), the event
     * still runs on the next cron trigger; if none comes before the deadline the
     * record reads `died`, which is the honest answer.
     *
     * Falls back to the shutdown hook only if the event cannot be scheduled.
     *
     * @param string[] $key_paths
     */
    public function schedule( string $id, array $key_paths ): void {
        $scheduled = function_exists( 'wp_schedule_single_event' )
            && true === wp_schedule_single_event( time(), self::STAGE2_HOOK, [ $id ], true );

        if ( $scheduled ) {
            // Written BEFORE the kick. Once the loopback is out, the cron request may
            // already be writing this record, and a write from here (from this
            // process's cached copy of the row) could put `queued` back over its
            // `running`. Only a failed kick, which started nothing, writes after.
            $this->store->update_stage2( $id, [ 'mode' => 'cron', 'spawned' => true ] );
            if ( ! self::kick_cron() ) {
                $this->store->update_stage2( $id, [ 'spawned' => false ] );
            }
            return;
        }

        $this->store->update_stage2( $id, [ 'mode' => 'shutdown' ] );
        ( self::after_response() )( fn ( bool $flushed ) => $this->stage2( $id, $key_paths, $flushed ? 'deferred' : 'inline' ) );
    }

    /** A non-blocking loopback to wp-cron.php. True when one was sent. */
    private static function kick_cron(): bool {
        if ( defined( 'ALTERNATE_WP_CRON' ) && ALTERNATE_WP_CRON ) {
            if ( ! function_exists( 'wp_remote_post' ) || ! function_exists( 'site_url' ) ) {
                return false;
            }
            wp_remote_post( site_url( 'wp-cron.php' ), [ 'timeout' => 0.01, 'blocking' => false, 'sslverify' => false ] );
            return true;
        }
        if ( ! function_exists( 'spawn_cron' ) ) {
            return false;
        }
        return false !== spawn_cron();
    }

    /**
     * The fallback stage 2 runner: on `shutdown`, after the response has been
     * flushed and the connection closed where the SAPI allows it. Only when the
     * WP-Cron event could not be scheduled (see schedule()).
     *
     * @return \Closure(\Closure(bool): void): void
     */
    private static function after_response(): \Closure {
        return static function ( \Closure $job ): void {
            if ( ! function_exists( 'add_action' ) ) {
                $job( false );
                return;
            }
            add_action(
                'shutdown',
                static function () use ( $job ): void {
                    $flushed = false;
                    if ( function_exists( 'fastcgi_finish_request' ) || function_exists( 'litespeed_finish_request' ) ) {
                        while ( ob_get_level() > 0 ) {
                            @ob_end_flush();
                        }
                        $flushed = function_exists( 'fastcgi_finish_request' ) ? fastcgi_finish_request() : litespeed_finish_request();
                    }
                    $job( (bool) $flushed );
                },
                PHP_INT_MAX
            );
        };
    }

    /**
     * @param array<string, mixed> $req
     * @param array<string, mixed> $extra
     * @return array{status:int, body:array<string,mixed>}
     */
    private static function ok( array $req, array $extra ): array {
        return [
            'status' => 200,
            'body'   => [
                'ok'       => true,
                'id'       => $req['id'],
                'install'  => $req['install'],
                'action'   => $req['action'],
                'protocol' => ActionAuth::PROTOCOL,
                'version'  => defined( 'BULLDOGS_SW_VERSION' ) ? BULLDOGS_SW_VERSION : 'unknown',
            ] + $extra,
        ];
    }

    /** @return array{status:int, body:array<string,mixed>} */
    private static function error( int $status, string $code, string $message ): array {
        return [ 'status' => $status, 'body' => [ 'ok' => false, 'code' => $code, 'message' => $message ] ];
    }

    /**
     * @param array{status:int, body:array<string,mixed>} $out
     * @return array{status:int, body:array<string,mixed>}
     */
    private function sanitised( array $out ): array {
        return [ 'status' => $out['status'], 'body' => OutputSanitiser::clean( $out['body'] ) ];
    }

    private static function header( mixed $request, string $name ): string {
        if ( ! is_object( $request ) || ! method_exists( $request, 'get_header' ) ) {
            return '';
        }
        $value = $request->get_header( $name );
        return is_string( $value ) ? $value : '';
    }
}
