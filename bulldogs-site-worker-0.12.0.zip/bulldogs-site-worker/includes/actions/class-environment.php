<?php
namespace Bulldogs\SiteWorker\Actions;

/**
 * The WordPress calls the actions layer makes that change or read the install:
 * the upgrader, the update check, plugin headers, activation.
 *
 * ---------------------------------------------------------------------------
 * WHY THESE ARE GATHERED INTO ONE CLASS
 * ---------------------------------------------------------------------------
 * Every decision about an update - policy, ordering, the version assertion, when
 * to roll back - is made by UpdateRunner, and those decisions are the part that
 * must be tested. The calls below cannot run without a real WordPress, so they
 * live here, each one small enough to read, and the suite stands in a subclass
 * that records what was asked. Nothing in this class decides anything.
 *
 * ⚠️ NONE OF THIS IS LOADED ON A REST REQUEST BY DEFAULT. The upgrader, get_plugins()
 * and wp_clean_plugins_cache() live in wp-admin/includes, which WordPress only
 * loads in wp-admin. load_admin() requires the files the 22 Oct sweep scripts
 * needed under `wp eval`, which is the same situation.
 */
class Environment {
    public function load_admin(): void {
        if ( ! defined( 'ABSPATH' ) ) {
            return;
        }
        foreach ( [ 'plugin.php', 'theme.php', 'file.php', 'misc.php', 'class-wp-upgrader.php', 'update.php', 'translation-install.php' ] as $file ) {
            $path = ABSPATH . 'wp-admin/includes/' . $file;
            if ( is_readable( $path ) ) {
                require_once $path;
            }
        }
        // wp_update_plugins() lives in wp-includes/update.php. Required only when
        // missing, so a site that already loaded it is not asked to again.
        if ( ! function_exists( 'wp_update_plugins' ) && defined( 'WPINC' ) && is_readable( ABSPATH . WPINC . '/update.php' ) ) {
            require_once ABSPATH . WPINC . '/update.php';
        }
    }

    /** @return array<string, array{name:?string, version:?string}> Plugin file => headers. */
    public function installed_plugins(): array {
        $this->load_admin();
        $out = [];
        if ( ! function_exists( 'get_plugins' ) ) {
            return $out;
        }
        foreach ( (array) get_plugins() as $file => $headers ) {
            if ( ! is_string( $file ) || ! is_array( $headers ) ) {
                continue;
            }
            $out[ $file ] = [
                'name'    => isset( $headers['Name'] ) && is_string( $headers['Name'] ) ? $headers['Name'] : null,
                'version' => isset( $headers['Version'] ) && is_string( $headers['Version'] ) && '' !== $headers['Version'] ? $headers['Version'] : null,
            ];
        }
        return $out;
    }

    public function is_active( string $file ): bool {
        return function_exists( 'is_plugin_active' ) && is_plugin_active( $file );
    }

    /** True when the plugin is active afterwards. activate_plugin() returns null on success. */
    public function activate( string $file ): bool {
        if ( function_exists( 'activate_plugin' ) ) {
            activate_plugin( $file, '', false, true );
        }
        return $this->is_active( $file );
    }

    public function is_multisite(): bool {
        return function_exists( 'is_multisite' ) && is_multisite();
    }

    public function home_url( string $path = '/' ): string {
        $url = function_exists( 'home_url' ) ? home_url( $path ) : '';
        return is_string( $url ) ? $url : '';
    }

    /** The REST URL for a route, honouring plain permalinks (?rest_route=). */
    public function rest_url( string $route ): string {
        $url = function_exists( 'rest_url' ) ? rest_url( $route ) : $this->home_url( '/wp-json/' . ltrim( $route, '/' ) );
        return is_string( $url ) ? $url : '';
    }

    /**
     * Throw away WordPress's update cache and ask again, now.
     *
     * Deleting the transient is what makes wp_update_plugins() actually call out:
     * with a fresh `last_checked` it returns early and nothing is asked. That early
     * return is half of the Elementor -> Elementor Pro trap in wordpress-updates §2.
     */
    public function refresh_update_check(): void {
        $this->load_admin();
        if ( function_exists( 'delete_site_transient' ) ) {
            delete_site_transient( 'update_plugins' );
            delete_site_transient( 'update_themes' );
        }
        if ( function_exists( 'wp_clean_plugins_cache' ) ) {
            wp_clean_plugins_cache( false );
        }
        if ( function_exists( 'wp_update_plugins' ) ) {
            wp_update_plugins();
        }
        if ( function_exists( 'wp_update_themes' ) ) {
            wp_update_themes();
        }
    }

    public function plugins_transient(): mixed {
        return function_exists( 'get_site_transient' ) ? get_site_transient( 'update_plugins' ) : false;
    }

    /**
     * Install $package over $file through the core upgrader, the path
     * `wp plugin update` takes and the one the 22 Oct jet-update.php used.
     *
     * The skin is Automatic_Upgrader_Skin because it captures feedback instead of
     * printing it. That matters beyond tidiness: the upgrader's own feedback
     * includes "Downloading update from <package>", which for a Jet plugin is the
     * licence key. It is captured, and never read back out of the skin.
     *
     * `temp_backup` asks core (6.3+) to keep its own copy in upgrade-temp-backup
     * and put it back if the INSTALL fails - the same hook_extra
     * Plugin_Upgrader::upgrade() passes. It covers "the zip was bad", not "the new
     * version broke the site"; that is what Backups is for.
     *
     * @return true|string True, or a short failure code (never the upgrader's message).
     */
    public function upgrade( string $file, string $package ): bool|string {
        $this->load_admin();
        if ( ! class_exists( 'Plugin_Upgrader' ) || ! class_exists( 'Automatic_Upgrader_Skin' ) || ! defined( 'WP_PLUGIN_DIR' ) ) {
            return 'upgrader_unavailable';
        }

        $dir      = dirname( $file );
        $upgrader = new \Plugin_Upgrader( new \Automatic_Upgrader_Skin() );
        $result   = $upgrader->run(
            [
                'package'           => $package,
                'destination'       => WP_PLUGIN_DIR,
                'clear_destination' => true,
                'clear_working'     => true,
                'hook_extra'        => [
                    'plugin'      => $file,
                    'type'        => 'plugin',
                    'action'      => 'update',
                    'temp_backup' => [ 'slug' => '.' === $dir ? basename( $file, '.php' ) : $dir, 'src' => WP_PLUGIN_DIR, 'dir' => 'plugins' ],
                ],
            ]
        );

        $this->clean_plugins_cache();

        if ( function_exists( 'is_wp_error' ) && is_wp_error( $result ) ) {
            $code = $result->get_error_code();
            return is_string( $code ) && '' !== $code ? 'upgrade_failed:' . preg_replace( '/[^a-z0-9_\-]/i', '', $code ) : 'upgrade_failed';
        }
        if ( false === $result || null === $result ) {
            return 'upgrade_failed';
        }
        return true;
    }

    public function clean_plugins_cache(): void {
        if ( function_exists( 'wp_clean_plugins_cache' ) ) {
            wp_clean_plugins_cache( true );
        }
        if ( function_exists( 'clearstatcache' ) ) {
            clearstatcache();
        }
    }

    /**
     * The version in the plugin FILE's header, read from disk now.
     *
     * Never the upgrader's return value: wordpress-updates §2 has `wp plugin update
     * elementor-pro` reporting success on 21 sites that had not moved. The state
     * afterwards is the acceptance test.
     */
    public function read_version( string $file ): ?string {
        $this->load_admin();
        $this->clean_plugins_cache();
        if ( ! defined( 'WP_PLUGIN_DIR' ) || ! function_exists( 'get_file_data' ) ) {
            return null;
        }
        $path = WP_PLUGIN_DIR . '/' . $file;
        if ( ! is_readable( $path ) ) {
            return null;
        }
        $data = get_file_data( $path, [ 'Version' => 'Version' ] );
        $v    = is_array( $data ) ? ( $data['Version'] ?? null ) : null;
        return is_string( $v ) && '' !== $v ? $v : null;
    }

    // -----------------------------------------------------------------------
    // Themes (0.12.0)
    // -----------------------------------------------------------------------

    /** @return array<string, array{name:?string, version:?string, template:?string}> Stylesheet => headers. */
    public function installed_themes(): array {
        $out = [];
        if ( ! function_exists( 'wp_get_themes' ) ) {
            return $out;
        }
        foreach ( (array) wp_get_themes() as $stylesheet => $theme ) {
            if ( ! is_string( $stylesheet ) || ! is_object( $theme ) || ! method_exists( $theme, 'get' ) ) {
                continue;
            }
            $v        = $theme->get( 'Version' );
            $n        = $theme->get( 'Name' );
            $template = method_exists( $theme, 'get_template' ) ? $theme->get_template() : null;
            $out[ $stylesheet ] = [
                'name'     => is_string( $n ) && '' !== $n ? $n : null,
                'version'  => is_string( $v ) && '' !== $v ? $v : null,
                'template' => is_string( $template ) && '' !== $template ? $template : null,
            ];
        }
        return $out;
    }

    public function themes_transient(): mixed {
        return function_exists( 'get_site_transient' ) ? get_site_transient( 'update_themes' ) : false;
    }

    public function theme_root(): string {
        $root = function_exists( 'get_theme_root' ) ? get_theme_root() : '';
        return is_string( $root ) ? $root : '';
    }

    /**
     * Install $package over a theme through Theme_Upgrader::run(), the same shape as
     * upgrade() for plugins (Automatic_Upgrader_Skin captures the feedback, which can
     * carry a licensed package URL; `temp_backup` asks core to restore on a bad zip).
     *
     * @return true|string
     */
    public function upgrade_theme( string $stylesheet, string $package ): bool|string {
        $this->load_admin();
        if ( ! class_exists( 'Theme_Upgrader' ) || ! class_exists( 'Automatic_Upgrader_Skin' ) ) {
            return 'upgrader_unavailable';
        }
        $root     = $this->theme_root();
        $upgrader = new \Theme_Upgrader( new \Automatic_Upgrader_Skin() );
        $result   = $upgrader->run(
            [
                'package'           => $package,
                'destination'       => $root,
                'clear_destination' => true,
                'clear_working'     => true,
                'hook_extra'        => [
                    'theme'       => $stylesheet,
                    'type'        => 'theme',
                    'action'      => 'update',
                    'temp_backup' => [ 'slug' => $stylesheet, 'src' => $root, 'dir' => 'themes' ],
                ],
            ]
        );
        if ( function_exists( 'wp_clean_themes_cache' ) ) {
            wp_clean_themes_cache( true );
        }
        if ( function_exists( 'is_wp_error' ) && is_wp_error( $result ) ) {
            $code = $result->get_error_code();
            return is_string( $code ) && '' !== $code ? 'upgrade_failed:' . preg_replace( '/[^a-z0-9_\-]/i', '', $code ) : 'upgrade_failed';
        }
        return false === $result || null === $result ? 'upgrade_failed' : true;
    }

    /** The Version header in the theme's style.css, read from disk now. */
    public function read_theme_version( string $stylesheet ): ?string {
        $path = $this->theme_root() . '/' . $stylesheet . '/style.css';
        clearstatcache();
        if ( ! is_readable( $path ) || ! function_exists( 'get_file_data' ) ) {
            return null;
        }
        $data = get_file_data( $path, [ 'Version' => 'Version' ] );
        $v    = is_array( $data ) ? ( $data['Version'] ?? null ) : null;
        return is_string( $v ) && '' !== $v ? $v : null;
    }

    // -----------------------------------------------------------------------
    // Memory and translations (0.12.0)
    // -----------------------------------------------------------------------

    public function memory_limit(): string {
        $v = ini_get( 'memory_limit' );
        return is_string( $v ) ? $v : '';
    }

    /** What wp-admin's updater raises to: WP_MAX_MEMORY_LIMIT (256M by default). */
    public function raise_memory(): void {
        if ( function_exists( 'wp_raise_memory_limit' ) ) {
            wp_raise_memory_limit( 'admin' );
        }
    }

    public function memory_limit_admin(): string {
        return defined( 'WP_MAX_MEMORY_LIMIT' ) ? (string) WP_MAX_MEMORY_LIMIT : '256M';
    }

    /**
     * Language packs for what was just updated, as wp-admin does after an update.
     * Never fails anything: the caller only reports the counts.
     *
     * @param array<int, array{type:string, slug:string}> $items `plugin`/`theme`/`core` and slug.
     * @return array{updated:int, failed:int}
     */
    public function update_translations( array $items ): array {
        $this->load_admin();
        if ( [] === $items || ! function_exists( 'wp_get_translation_updates' ) || ! class_exists( 'Language_Pack_Upgrader' ) ) {
            return [ 'updated' => 0, 'failed' => 0 ];
        }
        $wanted = [];
        foreach ( $items as $item ) {
            $wanted[ $item['type'] . ':' . $item['slug'] ] = true;
        }
        $packs = [];
        foreach ( (array) wp_get_translation_updates() as $pack ) {
            if ( is_object( $pack ) && isset( $pack->type, $pack->slug ) && isset( $wanted[ $pack->type . ':' . $pack->slug ] ) ) {
                $packs[] = $pack;
            }
        }
        if ( [] === $packs ) {
            return [ 'updated' => 0, 'failed' => 0 ];
        }
        $upgrader = new \Language_Pack_Upgrader( new \Automatic_Upgrader_Skin() );
        $results  = $upgrader->bulk_upgrade( $packs, [ 'clear_update_cache' => false ] );
        $ok       = 0;
        foreach ( is_array( $results ) ? $results : [] as $r ) {
            if ( true === $r || ( is_array( $r ) && [] !== $r ) ) {
                ++$ok;
            }
        }
        return [ 'updated' => $ok, 'failed' => count( $packs ) - $ok ];
    }

    // -----------------------------------------------------------------------
    // Core (0.12.0)
    // -----------------------------------------------------------------------

    /**
     * What wp-includes/version.php says NOW, on disk. Parsed, not included: the
     * running request loaded the old file at boot, and including the new one would
     * redefine globals mid-request.
     *
     * @return array{wp_version:?string, wp_db_version:?int, required_php:?string, required_mysql:?string}
     */
    public function core_version_on_disk(): array {
        $path = rtrim( $this->abspath(), '/' ) . '/' . ( defined( 'WPINC' ) ? WPINC : 'wp-includes' ) . '/version.php';
        clearstatcache( true, $path );
        $src = is_readable( $path ) ? (string) file_get_contents( $path ) : '';
        $get = static function ( string $var ) use ( $src ): ?string {
            return 1 === preg_match( '/\$' . $var . '\s*=\s*[\'"]?([^\'";]+)[\'"]?\s*;/', $src, $m ) ? trim( $m[1] ) : null;
        };
        $db = $get( 'wp_db_version' );
        return [
            'wp_version'     => $get( 'wp_version' ),
            'wp_db_version'  => null !== $db && ctype_digit( $db ) ? (int) $db : null,
            'required_php'   => $get( 'required_php_version' ),
            'required_mysql' => $get( 'required_mysql_version' ),
        ];
    }

    /**
     * Core update offers, after a FRESH check (delete `update_core`, then
     * wp_version_check()) so the asserted version is judged against what
     * WordPress.org offers now.
     *
     * @return array<int, object>
     */
    public function core_offers(): array {
        $this->load_admin();
        if ( function_exists( 'delete_site_transient' ) ) {
            delete_site_transient( 'update_core' );
        }
        if ( function_exists( 'wp_version_check' ) ) {
            wp_version_check( [], true );
        }
        $offers = function_exists( 'get_core_updates' ) ? get_core_updates( [ 'dismissed' => true ] ) : [];
        return array_values( array_filter( is_array( $offers ) ? $offers : [], 'is_object' ) );
    }

    /**
     * Core_Upgrader with this offer: the path wp-admin's Updates screen takes. It
     * sets and clears `.maintenance` itself and loopback-POSTs upgrade.php for the
     * database (update_core()). The caller clears `.maintenance` again whatever
     * happens, because a fatal inside the upgrader leaves it behind.
     *
     * @return true|string
     */
    public function core_upgrade( object $offer, ?Timings $timings = null ): bool|string {
        $this->load_admin();
        if ( ! class_exists( 'Core_Upgrader' ) || ! class_exists( 'Automatic_Upgrader_Skin' ) ) {
            return 'upgrader_unavailable';
        }
        // A skin that timestamps WordPress's own feedback lines ("Downloading",
        // "Unpacking", "Copying the required files", "Upgrading database"...), so the
        // record shows where inside the upgrader the time went. Declared here, not at
        // file scope: Automatic_Upgrader_Skin only exists once wp-admin is loaded.
        $skin = new class( $timings ) extends \Automatic_Upgrader_Skin {
            private ?Timings $bsw_timings;
            public function __construct( ?Timings $t ) {
                $this->bsw_timings = $t;
                parent::__construct();
            }
            public function feedback( $feedback, ...$args ) {
                if ( null !== $this->bsw_timings && is_string( $feedback ) && '' !== $feedback ) {
                    $text = isset( $this->upgrader->strings[ $feedback ] ) ? $feedback : OutputSanitiser::string( strip_tags( $feedback ) );
                    $this->bsw_timings->mark( 'wp: ' . substr( $text, 0, 60 ) );
                }
                parent::feedback( $feedback, ...$args );
            }
        };
        $upgrader = new \Core_Upgrader( $skin );
        // No core "attempt_rollback": the rollback here is our own, files AND database.
        $result = $upgrader->upgrade( $offer, [ 'attempt_rollback' => false, 'do_rollback' => false ] );
        if ( function_exists( 'is_wp_error' ) && is_wp_error( $result ) ) {
            $code = $result->get_error_code();
            return is_string( $code ) && '' !== $code ? 'upgrade_failed:' . preg_replace( '/[^a-z0-9_\-]/i', '', $code ) : 'upgrade_failed';
        }
        return is_string( $result ) && '' !== $result ? true : 'upgrade_failed';
    }

    /**
     * Run the database upgrade in a FRESH request, as update_core() itself does: a
     * loopback POST to upgrade.php?step=upgrade_db. Not wp_upgrade() in this
     * process: this request booted with the OLD wp-includes, so running the new
     * upgrade routines here would mix new code with old globals ($wp_db_version).
     */
    public function core_db_upgrade(): void {
        if ( ! function_exists( 'wp_remote_post' ) || ! function_exists( 'admin_url' ) ) {
            return;
        }
        wp_remote_post( admin_url( 'upgrade.php?step=upgrade_db' ), [ 'timeout' => 60, 'sslverify' => false ] );
    }

    /**
     * WordPress.org's md5 of every file in a release, path => md5, as the core
     * upgrader itself fetches them (get_core_checksums(), the same locale it uses).
     * Null when they cannot be had: the caller then takes a full backup.
     *
     * @return array<string, string>|null
     */
    public function core_checksums( string $version ): ?array {
        $this->load_admin();
        if ( ! function_exists( 'get_core_checksums' ) ) {
            return null;
        }
        $locale = isset( $GLOBALS['wp_local_package'] ) && is_string( $GLOBALS['wp_local_package'] ) ? $GLOBALS['wp_local_package'] : 'en_US';
        $sums   = get_core_checksums( $version, $locale );
        if ( ! is_array( $sums ) || [] === $sums ) {
            return null;
        }
        $out = [];
        foreach ( $sums as $file => $md5 ) {
            if ( is_string( $file ) && is_string( $md5 ) && 1 === preg_match( '/^[a-f0-9]{32}$/', $md5 ) ) {
                $out[ $file ] = $md5;
            }
        }
        return [] === $out ? null : $out;
    }

    public function maintenance_file(): string {
        return rtrim( $this->abspath(), '/' ) . '/.maintenance';
    }

    public function set_maintenance(): void {
        @file_put_contents( $this->maintenance_file(), '<?php $upgrading = ' . time() . '; ?>' );
    }

    /** True when the site is NOT in maintenance mode afterwards. */
    public function clear_maintenance(): bool {
        $f = $this->maintenance_file();
        if ( file_exists( $f ) ) {
            @unlink( $f );
        }
        clearstatcache( true, $f );
        return ! file_exists( $f );
    }

    /**
     * What a core backup holds: wp-admin, wp-includes and the root *.php files,
     * never wp-config.php (the site's credentials, and core never replaces it).
     *
     * @return string[]
     */
    public function core_paths(): array {
        $abs = rtrim( $this->abspath(), '/' );
        if ( '' === $abs ) {
            return [];
        }
        $out = [];
        foreach ( [ 'wp-admin', 'wp-includes' ] as $dir ) {
            if ( is_dir( $abs . '/' . $dir ) ) {
                $out[] = $abs . '/' . $dir;
            }
        }
        foreach ( glob( $abs . '/*.php' ) ?: [] as $file ) {
            if ( 'wp-config.php' !== basename( $file ) ) {
                $out[] = $file;
            }
        }
        return $out;
    }

    public function php_version(): string {
        return PHP_VERSION;
    }

    public function plugins_dir(): string {
        return defined( 'WP_PLUGIN_DIR' ) ? (string) WP_PLUGIN_DIR : '';
    }

    public function abspath(): string {
        return defined( 'ABSPATH' ) ? (string) ABSPATH : '';
    }

    /** The web server's document root for this request, or '' when it is not known. */
    public function doc_root(): string {
        $root = $_SERVER['DOCUMENT_ROOT'] ?? '';
        return is_string( $root ) ? $root : '';
    }
}
