<?php
namespace Bulldogs\SiteWorker\Actions;

use Bulldogs\SiteWorker\Settings;

/**
 * `update` and `rollback`, stage 1, for plugins and themes: one component at a
 * time, through WordPress's own upgrader, from the component's own update source.
 * Core has its own runner (CoreRunner); this one never touches it.
 *
 * ---------------------------------------------------------------------------
 * THE PLUGIN ENFORCES POLICY. THE CC ONLY ASKS.
 * ---------------------------------------------------------------------------
 * Every rule below is checked HERE, on the site, so a wrong or forged request from
 * the CC side meets a refusal rather than an update (spec §3, §6):
 *
 *   - No parameter takes a URL, a path or a package. Plugins are named by their
 *     installed `file`, themes by their `stylesheet`; packages come from the
 *     update transient or the Crocoblock adapter, whose host is pinned.
 *   - Installed components only. Nothing is installed or deleted.
 *   - Never `bulldogs-site-worker` itself, never `clsop`, never `wp-rocket` without
 *     the local `allow_wp_rocket_update` flag (literally true), never the 0.11.1
 *     report-only vendors, and never Divi or Extra unless Elegant Themes' own
 *     updater put a package in the transient during this request's fresh check.
 *   - Not on multisite.
 *   - The version is an ASSERTION: `latest`, or exactly what the source offers.
 *     Only the Crocoblock adapter may name an older-than-latest version, and never
 *     one older than what is installed. Downgrades are refused everywhere.
 *
 * ---------------------------------------------------------------------------
 * ORDER, AND A FRESH CHECK BEFORE EVERY COMPONENT
 * ---------------------------------------------------------------------------
 * Updating `elementor` invalidates the transient, so an `elementor-pro` update
 * straight after it silently does nothing and reports success (wordpress-updates
 * §2). So the update cache is rebuilt before EVERY component, and known
 * dependency pairs go first: `elementor` before `elementor-pro`, `jet-engine`
 * before other Jet plugins, and a parent theme before its child. The run stops at
 * the first component that is not `updated`; the rest come back `not_attempted`.
 *
 * ---------------------------------------------------------------------------
 * 0.12.0: WHAT bandcservices TAUGHT US (23 Oct 2026, Brixly/LiteSpeed, 128M)
 * ---------------------------------------------------------------------------
 *   - PROGRESS IS PERSISTED AFTER EVERY STEP (set_progress()). Update #2 there was
 *     killed mid-run and left `result: null`; nobody could say which plugins had
 *     changed. Every step now reaches the record before the next one starts.
 *   - HEALTH IS RETRIED BEFORE A VERDICT (settle()). After the rollback there, the
 *     health check read 500 / 0 bytes while a check a minute later read 200 at
 *     exactly the baseline: a PHP worker being recycled after a memory event. A
 *     failed reading is re-taken at 10 s and 25 s before it is believed. The
 *     rollback still happens if all three fail: retries decide the verdict, they
 *     never skip the safety net.
 *   - LOW MEMORY IS FLAGGED (set_low_memory()), never refused.
 */
class UpdateRunner {
    public const OUTCOME_UPDATED       = 'updated';
    public const OUTCOME_REFUSED       = 'refused';
    public const OUTCOME_FAILED        = 'failed';
    public const OUTCOME_ROLLED_BACK   = 'rolled_back';
    public const OUTCOME_DEGRADED      = 'degraded';
    public const OUTCOME_NOT_ATTEMPTED = 'not_attempted';

    public const KIND_PLUGIN = 'plugin';
    public const KIND_THEME  = 'theme';

    /** Settings key, honoured only when LITERALLY true. Set by `wp bulldogs actions allow-wp-rocket`. */
    public const KEY_ALLOW_WP_ROCKET = 'allow_wp_rocket_update';

    /**
     * Report-only in 0.11.1: their vendors are asked for versions (Vendors\*), but
     * nothing here can install from them yet.
     */
    public const REPORT_ONLY = [ 'revslider', 'duplicator-pro', 'divi-builder' ];

    /** Elegant Themes' themes: updatable only through ET's own channel (see policy_theme()). */
    public const ET_THEMES = [ 'Divi', 'Extra' ];


    /** Directories that go first, in this order, when present in a request. */
    private const FIRST = [ 'elementor', 'jet-engine' ];

    /** @var \Closure(): void */
    private \Closure $heartbeat;

    /** @var \Closure(int, array<string,mixed>): void Called with each result as each step completes. */
    private \Closure $progress;

    /** @var \Closure(int): void */
    private \Closure $sleep;

    private bool $low_memory = false;

    private ?Timings $timings = null;

    public function __construct(
        private Environment $env,
        private CrocoblockAdapter $crocoblock,
        private SyncRunner $sync,
        private PackageCheck $packages,
        private HealthCheck $health,
        private ErrorLog $log,
        private Backups $backups,
        private Settings $settings,
        ?\Closure $heartbeat = null,
        ?\Closure $sleep = null
    ) {
        $this->heartbeat = $heartbeat ?? static function (): void {};
        $this->progress  = static function ( int $i, array $r ): void {};
        $this->sleep     = $sleep ?? static function ( int $seconds ): void {
            sleep( $seconds );
        };
    }

    /** The controller extends the site lock through this between long steps. */
    public function set_heartbeat( \Closure $heartbeat ): void {
        $this->heartbeat = $heartbeat;
    }

    /** The controller writes each step to the record through this. */
    public function set_progress( \Closure $progress ): void {
        $this->progress = $progress;
    }

    public function set_timings( Timings $t ): void {
        $this->timings = $t;
    }

    /** Time one step, if timings are on. */
    private function tm( string $step, \Closure $fn ): mixed {
        return null === $this->timings ? $fn() : $this->timings->measure( $step, $fn );
    }

    /** Stamp `low_memory` on every result of this run (0.12.0, A5). */
    public function set_low_memory( bool $low ): void {
        $this->low_memory = $low;
    }

    /**
     * Plugins only, as 0.11 callers ask.
     *
     * @param array<int, array{file:string, version:string}> $plugins
     * @param string[] $key_paths
     * @return array{results:array<int,array<string,mixed>>, order_applied:string[], changed:bool}
     */
    public function update( array $plugins, array $key_paths, bool $auto_rollback, array $themes = [] ): array {
        $components = [];
        foreach ( self::order( $plugins ) as $p ) {
            $components[] = [ 'kind' => self::KIND_PLUGIN, 'key' => $p['file'], 'version' => $p['version'] ];
        }
        foreach ( self::order_themes( $themes, $this->env->installed_themes() ) as $t ) {
            $components[] = [ 'kind' => self::KIND_THEME, 'key' => $t['stylesheet'], 'version' => $t['version'] ];
        }
        $order = array_map( static fn ( array $c ): string => $c['key'], $components );

        $results = [];
        if ( $this->env->is_multisite() ) {
            foreach ( $components as $c ) {
                $results[] = $this->result( $c['kind'], $c['key'], null, null, self::OUTCOME_REFUSED, 'multisite' );
            }
            return [ 'results' => $results, 'order_applied' => $order, 'changed' => false ];
        }

        $changed = false;
        $stop    = false;
        foreach ( $components as $i => $c ) {
            if ( $stop ) {
                $results[ $i ] = $this->result( $c['kind'], $c['key'], null, null, self::OUTCOME_NOT_ATTEMPTED, null );
                continue;
            }
            ( $this->heartbeat )();

            // Before EVERY component, the first included: the asserted version is
            // judged against what the source offers now, not at the last cron check.
            $this->tm( 'fresh_update_check', fn () => $this->sync->refresh( false ) );

            [ $result, $touched ] = $this->update_one( $i, $c['kind'], $c['key'], $c['version'], $key_paths, $auto_rollback );
            $results[ $i ] = $result;
            $changed       = $changed || $touched;
            if ( self::OUTCOME_UPDATED !== $result['outcome'] ) {
                $stop = true;
            }
        }

        return [ 'results' => array_values( $results ), 'order_applied' => $order, 'changed' => $changed ];
    }

    /**
     * Restore a backup this plugin made, by id, for a plugin or a theme.
     *
     * Same baseline, health and auto-rollback as an update. The current version is
     * backed up first, so a rollback that breaks the site can itself be undone in
     * the same request. Outcomes mean what they mean for `update`: success is
     * `updated`; `rolled_back` only ever means "undone because health failed".
     *
     * @param string[] $key_paths
     * @return array{results:array<int,array<string,mixed>>, order_applied:string[], changed:bool}
     */
    public function rollback( string $backup_id, array $key_paths, bool $auto_rollback ): array {
        $entry = $this->backups->find( $backup_id );
        $kind  = null !== $entry ? ( $entry['kind'] ?? self::KIND_PLUGIN ) : self::KIND_PLUGIN;
        $key   = null !== $entry ? $entry['file'] : '';
        $wrap  = static fn ( array $r, bool $changed ): array => [ 'results' => [ $r ], 'order_applied' => '' !== $r['component'] ? [ $r['component'] ] : [], 'changed' => $changed ];

        if ( $this->env->is_multisite() ) {
            return $wrap( $this->result( $kind, $key, null, null, self::OUTCOME_REFUSED, 'multisite' ), false );
        }
        if ( null === $entry || ! in_array( $kind, [ self::KIND_PLUGIN, self::KIND_THEME ], true ) ) {
            return $wrap( $this->result( $kind, $key, null, null, self::OUTCOME_REFUSED, 'backup_not_found' ), false );
        }
        if ( ! $this->backups->within_window( $entry ) || ! is_file( $entry['path'] ) ) {
            return $wrap( $this->result( $kind, $key, null, $entry['version'], self::OUTCOME_REFUSED, 'backup_expired' ), false );
        }

        $installed = $this->installed( $kind );
        if ( ! isset( $installed[ $key ] ) ) {
            return $wrap( $this->result( $kind, $key, null, $entry['version'], self::OUTCOME_REFUSED, 'not_installed' ), false );
        }
        $refusal = self::KIND_PLUGIN === $kind ? $this->policy( $key ) : null;
        if ( null !== $refusal ) {
            return $wrap( $this->result( $kind, $key, $installed[ $key ]['version'], $entry['version'], self::OUTCOME_REFUSED, $refusal ), false );
        }

        $from   = $installed[ $key ]['version'] ?? 'unknown';
        $result = $this->result( $kind, $key, $from, $entry['version'], self::OUTCOME_FAILED, null );
        $this->step( 0, $result, 'started' );

        [ $before, $probe_before ] = $this->baseline( $key_paths );
        if ( ! HealthCheck::measurable( $before, $probe_before ) ) {
            $result['outcome'] = self::OUTCOME_REFUSED;
            $result['reason']  = 'site_unhealthy';
            return $wrap( $this->step( 0, $result, 'done' ), false );
        }
        $log_base = $this->log->baseline();

        $safety = $this->backups->create( $key, $from, $kind );
        if ( true !== $safety['ok'] ) {
            $result['outcome'] = self::OUTCOME_REFUSED;
            $result['reason']  = $safety['reason'];
            return $wrap( $this->step( 0, $result, 'done' ), false );
        }
        $result['backup'] = $safety['backup'];
        $this->step( 0, $result, 'backed_up' );

        $was_active = self::KIND_PLUGIN === $kind && $this->env->is_active( $key );
        ( $this->heartbeat )();
        $restored = $this->backups->restore( $entry );
        $this->reactivate( $kind, $key, $was_active );
        $result['read_back'] = $this->read_version( $kind, $key );
        $this->step( 0, $result, 'upgraded' );

        [ $after, $probe, $verdict, $attempts ] = $this->settle( $before, $key_paths );
        $result['health']             = HealthCheck::report( $before, $after, $probe, $this->log->since( $log_base ) );
        $result['health']['attempts'] = $attempts;
        $this->step( 0, $result, 'health_checked' );

        if ( ! $restored ) {
            $result['reason'] = 'restore_failed';
            return $wrap( $this->step( 0, $result, 'done' ), true );
        }

        if ( HealthCheck::BROKEN === $verdict ) {
            if ( $auto_rollback ) {
                $undo = $this->backups->find( $safety['backup']['id'] );
                $ok   = null !== $undo && $this->backups->restore( $undo );
                $this->reactivate( $kind, $key, $was_active );
                $result['read_back']       = $this->read_version( $kind, $key );
                $result['outcome']         = $ok ? self::OUTCOME_ROLLED_BACK : self::OUTCOME_FAILED;
                $result['reason']          = $ok ? 'health_failed' : 'rollback_failed';
                $this->step( 0, $result, 'rolled_back' );
                $result['rollback_health'] = $this->recheck( $before, $key_paths );
            } else {
                $result['reason'] = 'health_failed';
            }
            return $wrap( $this->step( 0, $result, 'done' ), true );
        }

        if ( $result['read_back'] !== $entry['version'] ) {
            $result['reason'] = 'read_back_mismatch';
            return $wrap( $this->step( 0, $result, 'done' ), true );
        }
        if ( HealthCheck::DEGRADED === $verdict ) {
            $result['outcome'] = self::OUTCOME_DEGRADED;
            $result['reason']  = 'page_smaller';
            return $wrap( $this->step( 0, $result, 'done' ), true );
        }

        $result['outcome'] = self::OUTCOME_UPDATED;
        return $wrap( $this->step( 0, $result, 'done' ), true );
    }

    /**
     * One component, every step persisted as it completes.
     *
     * @param string[] $key_paths
     * @return array{0:array<string,mixed>, 1:bool} The result, and whether anything on disk was changed.
     */
    private function update_one( int $i, string $kind, string $key, string $version, array $key_paths, bool $auto_rollback ): array {
        $installed = $this->installed( $kind );
        if ( ! isset( $installed[ $key ] ) ) {
            return [ $this->step( $i, $this->result( $kind, $key, null, null, self::OUTCOME_REFUSED, 'not_installed' ), 'done' ), false ];
        }
        $from = $installed[ $key ]['version'];

        $refusal = self::KIND_PLUGIN === $kind ? $this->policy( $key ) : $this->policy_theme( $key );
        if ( null !== $refusal ) {
            return [ $this->step( $i, $this->result( $kind, $key, $from, null, self::OUTCOME_REFUSED, $refusal ), 'done' ), false ];
        }
        if ( null === $from ) {
            return [ $this->step( $i, $this->result( $kind, $key, null, null, self::OUTCOME_REFUSED, 'version_mismatch' ), 'done' ), false ];
        }

        // 1. The version plan and the package.
        $plan = self::KIND_PLUGIN === $kind ? $this->plan( $key, $version, $from ) : $this->plan_theme( $key, $version, $from );
        if ( isset( $plan['reason'] ) ) {
            return [ $this->step( $i, $this->result( $kind, $key, $from, $plan['to'] ?? null, self::OUTCOME_REFUSED, $plan['reason'] ), 'done' ), false ];
        }
        $to     = $plan['to'];
        $result = $this->result( $kind, $key, $from, $to, self::OUTCOME_FAILED, null );

        $check = $this->tm( 'package_check', fn () => $this->packages->check( $plan['package'] ) );
        if ( PackageCheck::OK !== $check['state'] ) {
            $result['outcome'] = self::OUTCOME_REFUSED;
            $result['reason']  = PackageCheck::REFUSED === $check['state'] ? 'package_refused' : 'package_unavailable';
            if ( isset( $check['vendor_code'] ) ) {
                $result['vendor_code'] = $check['vendor_code'];
            }
            return [ $this->step( $i, $result, 'done' ), false ];
        }
        $this->step( $i, $result, 'started' );

        // 2. Baseline.
        [ $before, $probe_before ] = $this->baseline( $key_paths );
        if ( ! HealthCheck::measurable( $before, $probe_before ) ) {
            $result['outcome'] = self::OUTCOME_REFUSED;
            $result['reason']  = 'site_unhealthy';
            return [ $this->step( $i, $result, 'done' ), false ];
        }
        $log_base = $this->log->baseline();

        // 3. Backup, or nothing happens.
        $backup = $this->tm( 'backup', fn () => $this->backups->create( $key, $from, $kind ) );
        if ( true !== $backup['ok'] ) {
            $result['outcome'] = self::OUTCOME_REFUSED;
            $result['reason']  = $backup['reason'];
            return [ $this->step( $i, $result, 'done' ), false ];
        }
        $result['backup'] = $backup['backup'];
        $this->step( $i, $result, 'backed_up' );

        // 4. Upgrade.
        $was_active = self::KIND_PLUGIN === $kind && $this->env->is_active( $key );
        ( $this->heartbeat )();
        $upgraded = $this->tm( 'upgrade', fn () => self::KIND_PLUGIN === $kind ? $this->env->upgrade( $key, $plan['package'] ) : $this->env->upgrade_theme( $key, $plan['package'] ) );
        $this->reactivate( $kind, $key, $was_active );

        // 5. Read back, from the file.
        $result['read_back'] = $this->read_version( $kind, $key );
        $this->step( $i, $result, 'upgraded' );

        // 6. Health, retried before it is believed.
        [ $after, $probe, $verdict, $attempts ] = $this->settle( $before, $key_paths );
        $result['health']             = HealthCheck::report( $before, $after, $probe, $this->log->since( $log_base ) );
        $result['health']['attempts'] = $attempts;
        $this->step( $i, $result, 'health_checked' );

        if ( HealthCheck::BROKEN === $verdict ) {
            if ( $auto_rollback ) {
                $entry = $this->backups->find( $backup['backup']['id'] );
                $ok    = null !== $entry && $this->tm( 'rollback_restore', fn () => $this->backups->restore( $entry ) );
                $this->reactivate( $kind, $key, $was_active );
                $result['read_back'] = $this->read_version( $kind, $key );
                $result['outcome']   = $ok ? self::OUTCOME_ROLLED_BACK : self::OUTCOME_FAILED;
                $result['reason']    = $ok ? 'health_failed' : 'rollback_failed';
                $this->step( $i, $result, 'rolled_back' );
                $result['rollback_health'] = $this->recheck( $before, $key_paths );
            } else {
                $result['reason'] = 'health_failed';
            }
            return [ $this->step( $i, $result, 'done' ), true ];
        }

        if ( true !== $upgraded ) {
            $result['reason'] = 'upgrade_failed';
            return [ $this->step( $i, $result, 'done' ), true ];
        }
        if ( $result['read_back'] !== $to ) {
            $result['reason'] = 'read_back_mismatch';
            return [ $this->step( $i, $result, 'done' ), true ];
        }
        if ( HealthCheck::DEGRADED === $verdict ) {
            $result['outcome'] = self::OUTCOME_DEGRADED;
            $result['reason']  = 'page_smaller';
            return [ $this->step( $i, $result, 'done' ), true ];
        }

        $result['outcome'] = self::OUTCOME_UPDATED;
        return [ $this->step( $i, $result, 'done' ), true ];
    }

    /**
     * Why this plugin may never be updated by this route, or null.
     */
    public function policy( string $file ): ?string {
        $dir = dirname( $file );
        $dir = '.' === $dir ? basename( $file, '.php' ) : explode( '/', $dir )[0];

        $self = defined( 'BULLDOGS_SW_FILE' ) && function_exists( 'plugin_basename' ) ? plugin_basename( BULLDOGS_SW_FILE ) : null;
        if ( 'bulldogs-site-worker' === $dir || ( null !== $self && $self === $file ) ) {
            return 'self_update_refused';
        }
        if ( 'clsop' === $dir ) {
            return 'clsop_managed';
        }
        if ( in_array( $dir, self::REPORT_ONLY, true ) ) {
            return 'update_source_not_supported';
        }
        if ( 'wp-rocket' === $dir && true !== $this->settings->get( self::KEY_ALLOW_WP_ROCKET, false ) ) {
            return 'wp_rocket_unlicensed';
        }
        return null;
    }

    /**
     * Why this theme may not be updated by this route, or null.
     *
     * Divi and Extra update through Elegant Themes' own updater, which registers
     * only in wp-admin and WP-Cron. If it put a package into the transient during
     * this request's fresh check, that IS ET's channel and the update may go; if
     * not, there is nothing honest to install from (`update_source_not_supported`).
     */
    public function policy_theme( string $stylesheet ): ?string {
        if ( in_array( $stylesheet, self::ET_THEMES, true ) ) {
            $entry = $this->theme_offer( $stylesheet );
            return null !== $entry && null !== SyncRunner::package_of( $entry ) ? null : 'update_source_not_supported';
        }
        return null;
    }

    /**
     * Which version to install and from where, or why not.
     *
     * @return array{to:string, package:string}|array{reason:string, to?:?string}
     */
    public function plan( string $file, string $requested, string $installed ): array {
        $latest_wanted = 'latest' === $requested;

        if ( ! $latest_wanted && version_compare( $requested, $installed, '<' ) ) {
            return [ 'reason' => 'downgrade_refused', 'to' => $requested ];
        }

        if ( $this->crocoblock->available() && $this->crocoblock->covers( $file ) ) {
            $latest = $this->crocoblock->latest( $file );
            if ( null === $latest ) {
                return [ 'reason' => 'version_mismatch' ];
            }
            $target = $latest_wanted ? $latest : $requested;
            if ( version_compare( $target, $installed, '<' ) ) {
                return [ 'reason' => 'downgrade_refused', 'to' => $target ];
            }
            if ( version_compare( $target, $installed, '==' ) || version_compare( $target, $latest, '>' ) ) {
                return [ 'reason' => 'version_mismatch', 'to' => $target ];
            }
            $package = $this->crocoblock->package( $file, $latest_wanted ? false : $target );
            if ( null === $package['url'] ) {
                return [ 'reason' => 'package_unavailable', 'to' => $target ];
            }
            return [ 'to' => $target, 'package' => $package['url'] ];
        }

        $transient = $this->env->plugins_transient();
        $entry     = is_object( $transient ) && isset( $transient->response ) && is_array( $transient->response ) ? ( $transient->response[ $file ] ?? null ) : null;
        return self::plan_from_offer( $entry, $requested, $installed );
    }

    /**
     * The same plan for a theme, from `update_themes` only. No versioned packages.
     *
     * @return array{to:string, package:string}|array{reason:string, to?:?string}
     */
    public function plan_theme( string $stylesheet, string $requested, string $installed ): array {
        if ( 'latest' !== $requested && version_compare( $requested, $installed, '<' ) ) {
            return [ 'reason' => 'downgrade_refused', 'to' => $requested ];
        }
        return self::plan_from_offer( $this->theme_offer( $stylesheet ), $requested, $installed );
    }

    /**
     * Pure: a transient offer (object for plugins, array for themes), in; the plan, out.
     *
     * @return array{to:string, package:string}|array{reason:string, to?:?string}
     */
    public static function plan_from_offer( mixed $entry, string $requested, string $installed ): array {
        $raw     = is_object( $entry ) ? ( $entry->new_version ?? null ) : ( is_array( $entry ) ? ( $entry['new_version'] ?? null ) : null );
        $offered = is_scalar( $raw ) ? trim( (string) $raw ) : '';

        if ( '' === $offered ) {
            // Nothing on offer from this component's own source.
            return [ 'reason' => 'version_mismatch' ];
        }
        if ( version_compare( $offered, $installed, '<' ) ) {
            return [ 'reason' => 'downgrade_refused', 'to' => $offered ];
        }
        if ( version_compare( $offered, $installed, '==' ) ) {
            return [ 'reason' => 'version_mismatch', 'to' => $offered ];
        }
        if ( 'latest' !== $requested && ! version_compare( $requested, $offered, '==' ) ) {
            // Versioned packages are the Crocoblock adapter's alone.
            return [ 'reason' => 'version_mismatch', 'to' => $offered ];
        }
        $package = SyncRunner::package_of( $entry );
        if ( null === $package ) {
            return [ 'reason' => 'package_unavailable', 'to' => $offered ];
        }
        return [ 'to' => $offered, 'package' => $package ];
    }

    /**
     * Known plugin pairs first, everything else in the order asked. Stable.
     *
     * @param array<int, array{file:string, version:string}> $plugins
     * @return array<int, array{file:string, version:string}>
     */
    public static function order( array $plugins ): array {
        $rank = static function ( string $file ): int {
            $dir = explode( '/', $file )[0];
            $at  = array_search( $dir, self::FIRST, true );
            return false === $at ? count( self::FIRST ) : (int) $at;
        };
        $indexed = [];
        foreach ( array_values( $plugins ) as $i => $p ) {
            $indexed[] = [ $rank( $p['file'] ), $i, $p ];
        }
        usort( $indexed, static fn ( array $a, array $b ): int => [ $a[0], $a[1] ] <=> [ $b[0], $b[1] ] );
        return array_map( static fn ( array $row ): array => $row[2], $indexed );
    }

    /**
     * A parent theme before any child of it named in the same request. Stable.
     *
     * @param array<int, array{stylesheet:string, version:string}> $themes
     * @param array<string, array{name:?string, version:?string, template?:?string}> $installed
     * @return array<int, array{stylesheet:string, version:string}>
     */
    public static function order_themes( array $themes, array $installed ): array {
        $named   = array_column( $themes, 'stylesheet' );
        $indexed = [];
        foreach ( array_values( $themes ) as $i => $t ) {
            $parent    = $installed[ $t['stylesheet'] ]['template'] ?? null;
            $is_child  = is_string( $parent ) && $parent !== $t['stylesheet'] && in_array( $parent, $named, true );
            $indexed[] = [ $is_child ? 1 : 0, $i, $t ];
        }
        usort( $indexed, static fn ( array $a, array $b ): int => [ $a[0], $a[1] ] <=> [ $b[0], $b[1] ] );
        return array_map( static fn ( array $row ): array => $row[2], $indexed );
    }

    /** @param string[] $key_paths */
    private function settle( array $before, array $key_paths ): array {
        return $this->health->settle( $before, $key_paths, $this->sleep, $this->heartbeat, $this->timings );
    }

    /**
     * @param string[] $key_paths
     * @return array{0:array, 1:string}
     */
    private function baseline( array $key_paths ): array {
        return $this->tm( 'baseline', fn () => [ $this->health->snapshot( $key_paths ), $this->health->rest_probe() ] );
    }

    /** Health after an automatic rollback, with the same retries, so a recycled worker does not read as broken. */
    private function recheck( array $before, array $key_paths ): array {
        [ $after, $probe, $verdict, $attempts ] = $this->settle( $before, $key_paths );
        return [
            'home'       => [ 'before' => $before['home'], 'after' => $after['home'] ],
            'rest_probe' => 'ok' === $probe ? 'ok' : 'failed',
            'verdict'    => $verdict,
            'attempts'   => $attempts,
        ];
    }

    /** @return array<string, array{name:?string, version:?string}> */
    private function installed( string $kind ): array {
        return self::KIND_THEME === $kind ? $this->env->installed_themes() : $this->env->installed_plugins();
    }

    private function read_version( string $kind, string $key ): ?string {
        return self::KIND_THEME === $kind ? $this->env->read_theme_version( $key ) : $this->env->read_version( $key );
    }

    private function theme_offer( string $stylesheet ): mixed {
        $t = $this->env->themes_transient();
        return is_object( $t ) && isset( $t->response ) && is_array( $t->response ) ? ( $t->response[ $stylesheet ] ?? null ) : null;
    }

    private function reactivate( string $kind, string $key, bool $was_active ): void {
        if ( self::KIND_PLUGIN === $kind && $was_active && ! $this->env->is_active( $key ) ) {
            $this->env->activate( $key );
        }
    }

    /**
     * Write this step to the record, then hand the result back.
     *
     * @param array<string, mixed> $result
     * @return array<string, mixed>
     */
    private function step( int $i, array $result, string $step ): array {
        $row = [ 'step' => $step ] + $result;
        if ( null !== $this->timings ) {
            $row['timings'] = $this->timings->report();
        }
        ( $this->progress )( $i, $row );
        return $result;
    }

    /** @return array<string, mixed> One result in the contract's shape. */
    private function result( string $kind, string $key, ?string $from, ?string $to, string $outcome, ?string $reason ): array {
        $r = self::KIND_THEME === $kind ? [ 'stylesheet' => $key ] : [ 'file' => $key ];
        $r += [
            'kind'      => $kind,
            'component' => $key,
            'from'      => $from,
            'to'        => $to,
            'read_back' => null,
            'outcome'   => $outcome,
            'reason'    => $reason,
            'health'    => null,
            'backup'    => null,
        ];
        if ( $this->low_memory ) {
            $r['low_memory'] = true;
        }
        return $r;
    }
}
