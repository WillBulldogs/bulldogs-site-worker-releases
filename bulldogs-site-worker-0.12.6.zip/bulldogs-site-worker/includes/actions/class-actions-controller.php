<?php
namespace Bulldogs\SiteWorker\Actions;

use Bulldogs\SiteWorker\Modules;
use Bulldogs\SiteWorker\Monitor\SecurityReport;
use Bulldogs\SiteWorker\Monitor\SiteSecret;
use Bulldogs\SiteWorker\Monitor\UpdateReport;
use Bulldogs\SiteWorker\Settings;

/**
 * `POST /wp-json/bulldogs-sw/v1/actions` - signed, on-demand `sync`, `update`,
 * `rollback`, `status` and (0.12.2) `cache_cycle`, called by the Control Centre's executor and nothing else.
 *
 * ---------------------------------------------------------------------------
 * 🚨 DORMANT UNLESS SWITCHED ON, AND ONLY BY HAND
 * ---------------------------------------------------------------------------
 * The route is registered only when module `sync` or module `actions` is on. Both
 * default OFF, and neither can be switched on by any remote request - only by
 * `wp bulldogs module enable` (LDN1) or a one-shot over the reseller API (Brixly).
 * If a remote command could switch them on, the switch would mean nothing. With
 * both off the route does not exist, the caller gets WordPress's own 404
 * `rest_no_route`, and a site on this version is byte-identical to one on 0.10.x.
 *
 * ---------------------------------------------------------------------------
 * WHY THE PERMISSION CALLBACK IS __return_true
 * ---------------------------------------------------------------------------
 * Not because the route is open: dispatch() refuses everything before ActionAuth
 * has passed, and does nothing else first. The checks live in the handler because
 * (a) the signature has to be verified over the RAW body, and (b) every refusal
 * must come back in the contract's body shape, `{"ok":false,"code","message"}`,
 * with the contract's status codes - a permission callback can only answer with a
 * WP_Error, which WordPress renders in its own shape.
 *
 * ---------------------------------------------------------------------------
 * THE CHECK ORDER (CONTRACT.md)
 * ---------------------------------------------------------------------------
 *   1-4  ActionAuth: secret, signature, shape/site/time, nonce
 *   5    action known (422 unknown_action); its module on (422 module_disabled)
 *   6    params valid (422 invalid_params / invalid_key_path); sync rate (429)
 *   7    the site lock (409 busy). `status` never locks.
 *
 * ---------------------------------------------------------------------------
 * LONG REQUESTS
 * ---------------------------------------------------------------------------
 * Stage 1 runs inside the request with ignore_user_abort(true), so if the CC's
 * connection drops the site still finishes and records the result against the
 * action id.
 *
 * 🚨 STAGE 2 RUNS IN ITS OWN REQUEST, FROM WP-CRON - NEVER INSIDE THIS ONE.
 * 0.11.0 ran it on `shutdown` after fastcgi_finish_request(). The first real
 * update (template, 23 Oct 2026) proved that wrong: template is one of the four
 * LDN1 vhosts that run PHP as plain CGI (/cgi-sys/ea-php82, not an FPM pool), where
 * fastcgi_finish_request() does not exist, so stage 2 ran inline and Apache held
 * the CC's connection for the whole 265 s cache cycle; the CC's 240 s timeout
 * fired inside it. Whether a response can be released early depends on the SAPI,
 * and the fleet has three (FPM, CGI, LiteSpeed). So stage 2 is scheduled as a
 * single WP-Cron event keyed by the action id and kicked with a non-blocking
 * loopback, and the stage 1 response returns the moment stage 1 is done, on any
 * SAPI. The site lock is held across the gap. The record says how stage 2 ran:
 * `mode` is `cron`, or `deferred` / `inline` on the shutdown fallback used only
 * when the event cannot be scheduled. A stage 2 that is queued or started and
 * never finishes still reads `died` once its deadline passes.
 */
class ActionsController {
    public const ROUTE = '/actions';

    /** Seconds. Stage 1 lock (spec §5.5). */
    public const STAGE1_TTL = 900;

    /** Seconds. Stage 2 lock. */
    public const STAGE2_TTL = 1800;

    public const ACTIONS = [ 'sync', 'update', 'rollback', 'status', 'cache_cycle' ];

    /**
     * A plugin file as get_plugins() keys it: one optional directory, a file name
     * ending .php, each segment starting with a letter or digit (so no `.`, `..` or
     * dot-file segment). Whether it is INSTALLED is checked against the exact keys of
     * get_plugins() by UpdateRunner (`not_installed`).
     */
    public const FILE_PATTERN = '/^(?:[A-Za-z0-9][A-Za-z0-9._-]*\/)?[A-Za-z0-9][A-Za-z0-9._-]*\.php$/';

    /** An id Backups minted. Only ever looked up in the index, never turned into a path. */
    /** A theme directory name, as wp_get_themes() keys it. No slashes. */
    public const STYLESHEET_PATTERN = '/^[A-Za-z0-9][A-Za-z0-9._-]{0,99}$/';

    public const BACKUP_PATTERN = '/^bk_[A-Za-z0-9]{16,64}$/';

    private const MAX_PLUGINS   = 10;
    private const MAX_KEY_PATHS = 10;

    private static bool $booted = false;

    /** @var \Closure(\Closure): void */
    private \Closure $defer;

    /** The WP-Cron hook stage 2 runs on. One event per action id. */
    public const STAGE2_HOOK = 'bulldogs_sw_actions_stage2';

    /** Seconds a queued stage 2 may sit with its event missing before it is put back (0.12.3). */
    public const RESCUE_AFTER = 60;

    /** Times one stage 2 is put back before it is left to read `died` at its deadline (0.12.3). */
    public const RESCUE_MAX = 10;

    private string $current = '';

    /**
     * @param \Closure(string, string[]): void|null $defer How stage 2 is handed off, given the
     *        action id and key paths. Null means schedule(): a WP-Cron event plus a
     *        non-blocking loopback. The suite captures it and runs stage 2 itself.
     */
    public function __construct(
        private Modules $modules,
        private ActionAuth $auth,
        private ActionStore $store,
        private Environment $env,
        private SyncRunner $sync,
        private UpdateRunner $updates,
        private CacheCycle $cache,
        private UpdateReport $update_report,
        ?\Closure $defer = null,
        private ?CoreRunner $core = null,
        private ?Backups $backups = null
    ) {
        $this->defer = $defer ?? fn ( string $id, array $key_paths ) => $this->schedule( $id, $key_paths );
        $tick        = fn () => $this->store->extend_lock( $this->current, self::STAGE1_TTL );
        // Every step of every component reaches the record as it completes (A2).
        $progress = fn ( int $i, array $row ) => $this->store->progress( $this->current, $i, OutputSanitiser::clean( $row ) );
        $this->updates->set_heartbeat( $tick );
        $this->updates->set_progress( $progress );
        if ( null !== $this->core ) {
            $this->core->set_heartbeat( $tick );
            $this->core->set_progress( $progress );
        }
    }

    /**
     * Called from the `sync` and `actions` module boot callbacks. Either one being on
     * mounts the route; both on mounts it once.
     */
    public static function boot(): void {
        if ( self::$booted || ! function_exists( 'add_action' ) ) {
            return;
        }
        self::$booted = true;
        add_action(
            'rest_api_init',
            static function (): void {
                self::build()->register_routes();
            }
        );
        // Registered on every request the module boots on, because WP-Cron runs
        // the event in a request of its own (wp-cron.php), not this one.
        add_action( self::STAGE2_HOOK, [ self::class, 'run_scheduled' ], 10, 1 );
        // On `init`, which wp-cron.php reaches BEFORE it reads the ready events, so an
        // event put back here is run by this same cron request (0.12.3).
        add_action( 'init', [ self::class, 'rescue_on_cron' ], 20, 0 );
        // WP Rocket and AccelerateWP read every option through this filter first; preload
        // reads as off while a run holds the lock (0.12.4, see ActionStore::pause_preload()).
        add_filter( 'pre_get_rocket_option_manual_preload', [ self::class, 'filter_manual_preload' ], 10, 1 );
        // 0.12.6: and the preload jobs already queued are stopped at the HTTP call.
        add_filter( 'pre_http_request', [ self::class, 'filter_preload_request' ], 10, 3 );
    }

    /** User agents WP Rocket (desktop and mobile) and AccelerateWP preload with. */
    public const PRELOAD_AGENTS = [ 'WP Rocket/Preload', 'AccelerateWP/Preload' ];

    /**
     * `pre_http_request`: while preload is paused, a WP Rocket / AccelerateWP preload
     * fetch is answered with a WP_Error instead of being sent (0.12.6).
     *
     * ⚠️ WHY. The setting filter stops WP Rocket dispatching new batches, but jobs it
     * had already queued in Action Scheduler run whenever the queue runner next fires
     * (often kicked by our own update's requests) and never re-check the setting. On
     * Harlow, 25 Oct 2026, one of five queued jobs fetched `/author/bronwyn/` during
     * the Elementor Pro swap and got a 500; the same class caused the swap-window
     * fatals on allroundglazing, Apex and Gadsden. Stopping the fetch itself works for
     * queued and in-flight batches alike. Stage 2 warms every page at the end, so
     * nothing is left uncached. Our own warm uses WordPress's default user agent.
     *
     * @param mixed                $pre  false, or an earlier filter's answer.
     * @param array<string, mixed> $args
     */
    public static function filter_preload_request( mixed $pre = false, mixed $args = [], mixed $url = '' ): mixed {
        if ( false !== $pre || ! is_array( $args ) ) {
            return $pre;
        }
        $agent = $args['user-agent'] ?? '';
        if ( ! is_string( $agent ) || '' === $agent ) {
            return $pre;
        }
        foreach ( self::PRELOAD_AGENTS as $prefix ) {
            if ( str_starts_with( $agent, $prefix ) ) {
                if ( ! ActionStore::preload_paused() ) {
                    return $pre;
                }
                return class_exists( '\WP_Error' )
                    ? new \WP_Error( 'bulldogs_sw_preload_paused', 'Preload is paused while an update runs.' )
                    : $pre;
            }
        }
        return $pre;
    }

    /**
     * `pre_get_rocket_option_manual_preload`: 0 while paused, otherwise the value passed
     * in (null, which tells WP Rocket to read its own setting). One autoloaded option
     * read, no query.
     */
    public static function filter_manual_preload( mixed $value = null ): mixed {
        return ActionStore::preload_paused() ? 0 : $value;
    }

    /**
     * `init` callback: in a WP-Cron request only, put back a stage 2 whose event was
     * lost (see rescue_stage2()). One read of a non-autoloaded option on a cron
     * request, nothing at all on a page load. Never throws into WordPress.
     */
    public static function rescue_on_cron(): void {
        try {
            if ( ! function_exists( 'wp_doing_cron' ) || ! wp_doing_cron() ) {
                return;
            }
            if ( null === ( new ActionStore() )->lock() ) {
                return;
            }
            self::build()->rescue_stage2();
        } catch ( \Throwable $e ) {
            OutputSanitiser::log( 'stage 2 rescue failed (' . get_class( $e ) . ')' );
        }
    }

    /**
     * Put back a stage 2 whose WP-Cron event vanished without running (0.12.3).
     *
     * ⚠️ WHY AN EVENT CAN VANISH. WordPress keeps the whole cron schedule in ONE
     * option, and each request caches it. wp-cron.php reads it once, then writes the
     * whole array back on every reschedule or unschedule as it works through its
     * list. A cron request that was already running when stage 2 was scheduled - WP
     * Rocket's preload, every minute, often for longer than a minute - writes back a
     * schedule without our event. Measured on hitnlift 24 Oct 2026 (0.12.2): stage 2
     * sat `queued, spawned: false`, the event was gone, and nothing had run it. It
     * never showed on template, which has no WP Rocket.
     *
     * Only for the action that holds the site lock, still in stage 2, unfinished,
     * `queued` by cron, with no event left, and quiet for RESCUE_AFTER seconds since
     * it was queued or last put back. A put-back event that turns out to be a
     * duplicate is harmless: run_stage2_from_cron() runs a record only while it is
     * still `queued`. Bounded by RESCUE_MAX; past the deadline it reads `died` as
     * before. True when the event was put back.
     *
     * ⚠️ This writes the records row from a request that is not the lock holder. If
     * the event fires in the instant between the read and that write, the write can
     * put `queued` back over a stage 2 just started; the runner's own later writes
     * restore it, and at worst the cycle is put back and runs once more. The window
     * needs an event that has been missing for a minute to run at that exact moment.
     */
    public function rescue_stage2(): bool {
        if ( ! function_exists( 'wp_next_scheduled' ) || ! function_exists( 'wp_schedule_single_event' ) ) {
            return false;
        }
        $lock = $this->store->lock();
        if ( null === $lock ) {
            return false;
        }
        $id     = $lock['id'];
        $record = $this->store->record( $id );
        if ( null === $record || 2 !== ( $record['stage'] ?? null ) || null !== ( $record['finished'] ?? null ) ) {
            return false;
        }
        $s2 = is_array( $record['stage2'] ?? null ) ? $record['stage2'] : [];
        if ( 'queued' !== ( $s2['state'] ?? null ) || 'cron' !== ( $s2['mode'] ?? null ) ) {
            return false;
        }
        if ( false !== wp_next_scheduled( self::STAGE2_HOOK, [ $id ] ) ) {
            return false;
        }
        $now   = $this->store->now();
        $since = max( is_int( $s2['queued_at'] ?? null ) ? $s2['queued_at'] : 0, is_int( $s2['rescued_at'] ?? null ) ? $s2['rescued_at'] : 0 );
        if ( $since > 0 && $now - $since < self::RESCUE_AFTER ) {
            return false;
        }
        $count = is_int( $s2['rescued'] ?? null ) ? $s2['rescued'] : 0;
        if ( $count >= self::RESCUE_MAX ) {
            return false;
        }
        if ( true !== wp_schedule_single_event( $now, self::STAGE2_HOOK, [ $id ], true ) ) {
            return false;
        }
        $this->store->update_stage2( $id, [ 'rescued' => $count + 1, 'rescued_at' => $now ] );
        return true;
    }

    /** WP-Cron callback. Never throws into WP-Cron. */
    public static function run_scheduled( mixed $id = null ): void {
        try {
            if ( ! is_string( $id ) || 1 !== preg_match( '/^[A-Za-z0-9_\-]{1,100}$/', $id ) ) {
                return;
            }
            self::build()->run_stage2_from_cron( $id );
        } catch ( \Throwable $e ) {
            OutputSanitiser::log( 'scheduled stage 2 failed (' . get_class( $e ) . ')' );
        }
    }

    /**
     * Run a queued stage 2, once. Only for a record that is in stage 2, unfinished,
     * still `queued` (so a duplicate event or a second cron runner does nothing), and
     * whose lock this action still holds. The key paths come from the record, never
     * from the event's arguments.
     */
    public function run_stage2_from_cron( string $id ): bool {
        $record = $this->store->record( $id );
        $lock   = $this->store->lock();
        if (
            null === $record
            || 2 !== ( $record['stage'] ?? null )
            || null !== ( $record['finished'] ?? null )
            || 'queued' !== ( $record['stage2']['state'] ?? null )
            || null === $lock
            || $lock['id'] !== $id
        ) {
            return false;
        }
        $paths = [];
        foreach ( is_array( $record['key_paths'] ?? null ) ? $record['key_paths'] : [] as $path ) {
            if ( self::valid_path( $path ) ) {
                $paths[] = $path;
            }
        }
        $this->stage2( $id, $paths, 'cron' );
        return true;
    }

    /** The real wiring. */
    public static function build(): self {
        $settings = new Settings();
        $modules  = new Modules( $settings );
        $secret   = new SiteSecret( $settings );
        $store    = new ActionStore();
        $env      = new Environment();
        $host     = ActionAuth::host_of( $env->home_url( '/' ) );
        $croc     = new CrocoblockAdapter( $env );
        $packages = new PackageCheck();
        $report   = new UpdateReport();
        $sync     = new SyncRunner(
            $env,
            $croc,
            $packages,
            $report,
            new SecurityReport(),
            null,
            class_exists( \Bulldogs\SiteWorker\Vendors\VendorVersions::class )
                ? new \Bulldogs\SiteWorker\Vendors\VendorVersions( $env, new \Bulldogs\SiteWorker\Vendors\VendorStore() )
                : null
        );
        $health   = new HealthCheck( $env, $secret, $modules );
        $log      = new ErrorLog( $env );
        $backups  = new Backups( $env, $store, $host );
        $updates  = new UpdateRunner( $env, $croc, $sync, $packages, $health, $log, $backups, $settings );
        $database = new Database();
        $dumps    = new DbBackup( $database );
        $core     = new CoreRunner( $env, $database, $dumps, new CoreBackup( $env, $backups, $dumps, $store ), $backups, $health, $log, $settings );

        // The report returned at the END of an update reads every version from disk:
        // this request booted with the old ones in memory (0.12.1).
        return new self( $modules, new ActionAuth( $secret, $store ), $store, $env, $sync, $updates, new CacheCycle( $env ), new UpdateReport( true ), null, $core, $backups );
    }

    public function register_routes(): void {
        if ( ! function_exists( 'register_rest_route' ) ) {
            return;
        }
        register_rest_route(
            \Bulldogs\SiteWorker\Monitor\RestController::REST_NAMESPACE,
            self::ROUTE,
            [
                [
                    'methods'             => 'POST',
                    'callback'            => [ $this, 'handle' ],
                    // See the class docblock: authentication is the first thing
                    // handle() does, and it needs the raw body.
                    'permission_callback' => '__return_true',
                    'show_in_index'       => false,
                ],
            ]
        );
    }

    /**
     * @param mixed $request WP_REST_Request in production.
     * @return mixed WP_REST_Response when WordPress is present, the body otherwise.
     */
    public function handle( $request ) {
        $secret = self::header( $request, 'x-bsw-secret' );
        $sig    = self::header( $request, ActionAuth::SIGNATURE_HEADER );
        $raw    = is_object( $request ) && method_exists( $request, 'get_body' ) ? $request->get_body() : '';

        $out = $this->dispatch( $secret, $sig, is_string( $raw ) ? $raw : '' );

        if ( class_exists( 'WP_REST_Response' ) ) {
            $response = new \WP_REST_Response( $out['body'], $out['status'] );
            $response->header( 'Cache-Control', 'no-store, no-cache, must-revalidate, max-age=0' );
            return $response;
        }
        return $out['body'];
    }

    /**
     * Everything, without WordPress's request and response objects.
     *
     * @return array{status:int, body:array<string,mixed>}
     */
    public function dispatch( string $secret, string $signature, string $raw ): array {
        try {
            return $this->sanitised( $this->route( $secret, $signature, $raw ) );
        } catch ( \Throwable $e ) {
            OutputSanitiser::log( 'actions route failed: ' . $e->getMessage() );
            if ( '' !== $this->current ) {
                $this->store->release_lock( $this->current );
            }
            return $this->sanitised( self::error( 500, 'internal_error', 'The action failed on the site. See the PHP error log.' ) );
        }
    }

    /** @return array{status:int, body:array<string,mixed>} */
    private function route( string $secret, string $signature, string $raw ): array {
        $home = ActionAuth::host_of( $this->env->home_url( '/' ) );

        // 1-4.
        $auth = $this->auth->check( $secret, $signature, $raw, $home );
        if ( true !== $auth['ok'] ) {
            return self::error( $auth['status'], $auth['code'], $auth['message'] );
        }
        $req = $auth['request'];

        // 5.
        if ( ! in_array( $req['action'], self::ACTIONS, true ) ) {
            return self::error( 422, 'unknown_action', 'Unknown action.' );
        }
        if ( ! $this->module_allows( $req['action'] ) ) {
            return self::error( 422, 'module_disabled', 'That action is switched off on this site.' );
        }

        // 6.
        $params = $this->params( $req['action'], $req['params'], $home );
        if ( isset( $params['error'] ) ) {
            return $params['error'];
        }
        if ( 'sync' === $req['action'] ) {
            $elapsed = $this->store->now() - $this->store->last_sync();
            if ( $elapsed < SyncRunner::MIN_INTERVAL ) {
                $err                        = self::error( 429, 'rate_limited', 'A sync ran here recently.' );
                $err['body']['retry_after'] = SyncRunner::MIN_INTERVAL - $elapsed;
                return $err;
            }
        }

        if ( 'status' === $req['action'] ) {
            // The CC's poll doubles as a check for a lost stage 2 event (0.12.3). This
            // request's own cron spawn has already gone out (WordPress spawns on
            // `init`), so a put-back event gets a kick of its own.
            if ( $this->rescue_stage2() ) {
                self::kick_cron();
            }
            $record = $this->store->view( $params['of'] );
            // A CC that lost the stage 1 response (a timeout: on the pilot, every core
            // update) still needs the fresh report it carried. Regathered here, from
            // disk, rather than stored in all 20 records: it reflects the site NOW,
            // costs no network, and keeps the option row small. Only once stage 1 has
            // a result; a request still in stage 1 has nothing settled to report.
            if ( in_array( $record['action'], [ 'update', 'rollback' ], true ) && is_array( $record['result'] ) ) {
                $record['result']['updates']        = SyncRunner::section( $this->update_report );
                $record['result']['updates_source'] = 'status';
            }
            return self::ok( $req, [ 'record' => $record ] );
        }

        // 7.
        if ( ! $this->store->acquire_lock( $req['id'], $req['action'], self::STAGE1_TTL ) ) {
            return self::error( 409, 'busy', 'Another action is running on this site.' );
        }
        $this->current = $req['id'];
        $this->long_request( self::STAGE1_TTL );
        $this->store->start_record( $req['id'], $req['action'], $this->store->now() + self::STAGE1_TTL );

        if ( 'sync' === $req['action'] ) {
            $this->store->mark_sync();
            $body = $this->sync->run();
            $this->store->finish_stage1( $req['id'], OutputSanitiser::clean( [ 'ok' => true, 'duration_ms' => $body['duration_ms'], 'adapters' => $body['adapters'] ] ), 'skipped' );
            $this->store->release_lock( $req['id'] );
            $this->current = '';
            return self::ok( $req, $body );
        }

        // 0.12.2: the cache cycle alone, as the last thing in a queue of updates.
        // Same lock, same record, same WP-Cron stage 2 as an update's, so `status`
        // reads it exactly the same way. Stage 1 does no work: it answers at once.
        if ( 'cache_cycle' === $req['action'] ) {
            return $this->cache_cycle_stage1( $req, $params['key_paths'] );
        }

        // A1: what wp-admin's updater does first. A5: flag, never refuse, a low limit.
        // Where the time goes, step by step (0.12.0, after the pilot).
        $timings = new Timings();
        $this->updates->set_timings( $timings );
        $this->core?->set_timings( $timings );

        $memory = $this->raise_memory();
        $this->updates->set_low_memory( $memory['low'] );
        if ( null !== $this->core ) {
            $this->core->set_low_memory( $memory['low'] );
        }

        $run = $this->run( $req['action'], $params );

        // A fresh report after the run, so the CC's view moves with the site.
        $timings->measure( 'fresh_update_check', fn () => $this->sync->refresh( false ) );
        $stage2        = $run['changed'] ? 'queued' : 'skipped';
        $stage2_reason = null;
        // `cache_cycle: false` skips stage 2 - EXCEPT after an automatic rollback in
        // this request: the site must never be left serving a cache built for the
        // version that was just taken away.
        if ( 'queued' === $stage2 && false === $params['cache_cycle'] && ! self::rolled_back( $run['results'] ) ) {
            $stage2        = 'skipped';
            $stage2_reason = 'deferred_to_last';
        }
        $body   = [
            'results'       => $run['results'],
            'order_applied' => $run['order_applied'],
            'stage2'        => $stage2,
            'updates'       => $timings->measure( 'updates_report', fn () => SyncRunner::section( $this->update_report ) ),
            'memory'        => $memory,
            'translations'  => $timings->measure( 'translations', fn () => $this->translations( $run['results'] ) ),
        ];
        $body['timings'] = $timings->report();
        if ( null !== $stage2_reason ) {
            $body['stage2_reason'] = $stage2_reason;
        }

        $this->store->finish_stage1(
            $req['id'],
            OutputSanitiser::clean( [ 'results' => $run['results'], 'order_applied' => $run['order_applied'], 'timings' => $body['timings'] ] ),
            $stage2,
            $this->store->now() + self::STAGE2_TTL,
            $stage2_reason
        );

        if ( 'queued' === $stage2 ) {
            $this->store->extend_lock( $req['id'], self::STAGE2_TTL );
            $this->store->annotate( $req['id'], [ 'key_paths' => $params['key_paths'] ] );
            ( $this->defer )( $req['id'], $params['key_paths'] );
        } else {
            $this->store->release_lock( $req['id'] );
        }
        $this->current = '';

        return self::ok( $req, $body );
    }

    /**
     * Stage 1 of a `cache_cycle` action. The lock is already held and the record
     * started. `queued` hands stage 2 to WP-Cron; `skipped` (reason `no_page_cache`)
     * means there is nothing for a cycle to do here - no page cache we recognise and
     * no Elementor - so the lock is released straight away.
     *
     * @param array<string, mixed> $req
     * @param string[]             $key_paths
     * @return array{status:int, body:array<string,mixed>}
     */
    private function cache_cycle_stage1( array $req, array $key_paths ): array {
        $cache  = $this->cache->cache_kind();
        $stage2 = $this->cache->has_work() ? 'queued' : 'skipped';
        $reason = 'skipped' === $stage2 ? CacheCycle::WARM_SKIPPED_NO_PAGE_CACHE : null;

        $this->store->finish_stage1( $req['id'], [ 'results' => [], 'order_applied' => [], 'cache' => $cache ], $stage2, $this->store->now() + self::STAGE2_TTL, $reason );
        if ( 'queued' === $stage2 ) {
            $this->store->extend_lock( $req['id'], self::STAGE2_TTL );
            $this->store->annotate( $req['id'], [ 'key_paths' => $key_paths ] );
            ( $this->defer )( $req['id'], $key_paths );
        } else {
            $this->store->release_lock( $req['id'] );
        }
        $this->current = '';

        $body = [ 'results' => [], 'order_applied' => [], 'stage2' => $stage2, 'cache' => $cache ];
        if ( null !== $reason ) {
            $body['stage2_reason'] = $reason;
        }
        return self::ok( $req, $body );
    }

    /**
     * The cache cycle, recorded as it goes so a stage that is killed half way still
     * says how far it got - and reads `died` once its deadline passes.
     *
     * `mode` is how it ran: `cron` (its own request), `deferred` (shutdown, after the
     * response was released) or `inline` (shutdown, holding the connection).
     * `flushed` is kept for 0.11.0 readers: true unless the run was inline.
     *
     * @param string[] $key_paths
     */
    public function stage2( string $id, array $key_paths, string $mode ): void {
        $this->long_request( self::STAGE2_TTL );
        $this->store->extend_lock( $id, self::STAGE2_TTL );
        $this->store->update_stage2( $id, [ 'state' => 'running', 'mode' => $mode, 'flushed' => 'inline' !== $mode, 'started' => $this->store->now() ] );
        try {
            $data = $this->cache->run(
                $key_paths,
                function ( array $partial ) use ( $id ): void {
                    $this->store->extend_lock( $id, self::STAGE2_TTL );
                    $this->store->update_stage2( $id, $partial );
                }
            );
            $this->store->update_stage2( $id, $data, true );
        } catch ( \Throwable $e ) {
            OutputSanitiser::log( 'stage 2 failed: ' . $e->getMessage() );
            $this->store->update_stage2( $id, [ 'state' => 'died', 'error' => OutputSanitiser::string( substr( $e->getMessage(), 0, 200 ) ) ] );
            $this->store->expire( $id );
        } finally {
            $this->store->release_lock( $id );
        }
    }

    /**
     * Dispatch an update or rollback to the runner that owns it: core to CoreRunner,
     * plugins and themes to UpdateRunner. A rollback goes by the backup's own kind.
     *
     * @param array<string, mixed> $params
     * @return array{results:array<int,array<string,mixed>>, order_applied:string[], changed:bool}
     */
    private function run( string $action, array $params ): array {
        if ( 'update' === $action ) {
            if ( null !== $params['core'] ) {
                if ( null === $this->core ) {
                    throw new \RuntimeException( 'core updates are not wired' );
                }
                return $this->core->update( $params['core'], $params['key_paths'], $params['auto_rollback'] );
            }
            return $this->updates->update( $params['plugins'], $params['key_paths'], $params['auto_rollback'], $params['themes'] );
        }
        $entry = null !== $this->backups ? $this->backups->find( $params['backup'] ) : null;
        if ( null !== $entry && 'core' === ( $entry['kind'] ?? null ) && null !== $this->core ) {
            return $this->core->rollback( $entry, $params['key_paths'], $params['auto_rollback'] );
        }
        return $this->updates->rollback( $params['backup'], $params['key_paths'], $params['auto_rollback'] );
    }

    /** Did any component roll back automatically in this request? */
    private static function rolled_back( array $results ): bool {
        foreach ( $results as $r ) {
            if ( UpdateRunner::OUTCOME_ROLLED_BACK === ( $r['outcome'] ?? null ) || is_array( $r['rollback_health'] ?? null ) ) {
                return true;
            }
        }
        return false;
    }

    /**
     * @return array{before:string, after:string, low:bool}
     */
    private function raise_memory(): array {
        $before = $this->env->memory_limit();
        $this->env->raise_memory();
        $after = $this->env->memory_limit();
        return [ 'before' => $before, 'after' => $after, 'low' => self::below( $after, 256 * 1048576 ) ];
    }

    /** Is this php.ini size below $bytes? -1 (no limit) never is. */
    public static function below( string $limit, int $bytes ): bool {
        $l = trim( $limit );
        if ( '' === $l || '-1' === $l ) {
            return false;
        }
        if ( 1 !== preg_match( '/^(\d+)\s*([kmg]?)$/i', $l, $m ) ) {
            return false;
        }
        $n = (int) $m[1] * [ '' => 1, 'k' => 1024, 'm' => 1048576, 'g' => 1073741824 ][ strtolower( $m[2] ) ];
        return $n < $bytes;
    }

    /**
     * D: language packs for what changed, as wp-admin does. Never fails anything.
     *
     * @param array<int, array<string, mixed>> $results
     * @return array{updated:int, failed:int}
     */
    private function translations( array $results ): array {
        $items = [];
        foreach ( $results as $r ) {
            if ( ! in_array( $r['outcome'] ?? null, [ UpdateRunner::OUTCOME_UPDATED, UpdateRunner::OUTCOME_DEGRADED ], true ) ) {
                continue;
            }
            $kind = $r['kind'] ?? 'plugin';
            if ( 'core' === $kind ) {
                $items[] = [ 'type' => 'core', 'slug' => 'default' ];
            } elseif ( 'theme' === $kind ) {
                $items[] = [ 'type' => 'theme', 'slug' => (string) $r['component'] ];
            } else {
                $items[] = [ 'type' => 'plugin', 'slug' => UpdateReport::plugin_slug( (string) $r['component'] ) ];
            }
        }
        try {
            return $this->env->update_translations( $items );
        } catch ( \Throwable $e ) {
            OutputSanitiser::log( 'translation update failed (' . get_class( $e ) . ')' );
            return [ 'updated' => 0, 'failed' => count( $items ) ];
        }
    }

    private function module_allows( string $action ): bool {
        $actions = $this->modules->is_enabled( Modules::ACTIONS );
        if ( 'update' === $action || 'rollback' === $action || 'cache_cycle' === $action ) {
            return $actions;
        }
        return $actions || $this->modules->is_enabled( Modules::SYNC );
    }

    /**
     * Per-action params, validated and normalised, or the error to return.
     *
     * @param array<string, mixed> $p
     * @return array<string, mixed>
     */
    private function params( string $action, array $p, string $home ): array {
        $bad = static fn ( string $why ): array => [ 'error' => self::error( 422, 'invalid_params', $why ) ];

        if ( 'sync' === $action ) {
            return [];
        }
        if ( 'status' === $action ) {
            $of = $p['of'] ?? null;
            if ( ! is_string( $of ) || 1 !== preg_match( '/^[A-Za-z0-9_\-]{1,100}$/', $of ) ) {
                return $bad( '`of` must be an action id.' );
            }
            return [ 'of' => $of ];
        }

        // 0.12.2: a cache cycle on its own, after the last update in a queue. Key
        // paths only, validated exactly as an update's are; anything else is refused
        // rather than ignored, so a caller that thinks it is sending an update finds out.
        if ( 'cache_cycle' === $action ) {
            if ( [] !== array_diff( array_keys( $p ), [ 'key_paths' ] ) ) {
                return $bad( 'A cache_cycle takes `key_paths` only.' );
            }
            $key_paths = $this->key_paths( $p, $home );
            return isset( $key_paths['error'] ) ? $key_paths : [ 'key_paths' => $key_paths ];
        }

        $auto = $p['auto_rollback'] ?? ( 'update' === $action );
        if ( ! is_bool( $auto ) ) {
            return $bad( '`auto_rollback` must be a boolean.' );
        }
        // 0.12.0: the CC runs one component per request and sends false on every
        // component of a run but each install's last, so a nine-plugin update runs
        // one cache cycle, not nine. Default true, so an older caller is unchanged.
        $cycle = $p['cache_cycle'] ?? true;
        if ( ! is_bool( $cycle ) ) {
            return $bad( '`cache_cycle` must be a boolean.' );
        }

        $key_paths = $this->key_paths( $p, $home );
        if ( isset( $key_paths['error'] ) ) {
            return $key_paths;
        }

        if ( 'rollback' === $action ) {
            $backup = $p['backup'] ?? null;
            if ( ! is_string( $backup ) || 1 !== preg_match( self::BACKUP_PATTERN, $backup ) ) {
                return $bad( '`backup` must be a backup id.' );
            }
            return [ 'backup' => $backup, 'key_paths' => $key_paths, 'auto_rollback' => $auto, 'cache_cycle' => $cycle ];
        }

        // Core runs alone (0.12.0, C): never batched with plugins or themes.
        if ( array_key_exists( 'core', $p ) ) {
            if ( array_key_exists( 'plugins', $p ) || array_key_exists( 'themes', $p ) ) {
                return $bad( 'A core update runs alone: no plugins or themes in the same request.' );
            }
            $core    = $p['core'];
            $version = is_array( $core ) ? ( $core['version'] ?? null ) : null;
            if ( ! is_string( $version ) || ( ! in_array( $version, [ 'latest', 'latest-minor' ], true ) && 1 !== preg_match( '/^\d+\.\d+(\.\d+)?$/', $version ) ) ) {
                return $bad( '`core.version` must be "latest-minor", "latest" or an exact x.y[.z].' );
            }
            return [ 'core' => $version, 'plugins' => [], 'themes' => [], 'key_paths' => $key_paths, 'auto_rollback' => $auto, 'cache_cycle' => $cycle ];
        }

        $themes = [];
        if ( array_key_exists( 'themes', $p ) ) {
            $tlist = $p['themes'];
            if ( ! is_array( $tlist ) || ! array_is_list( $tlist ) || [] === $tlist || count( $tlist ) > self::MAX_PLUGINS ) {
                return $bad( '`themes` must be a list of 1 to 10 themes.' );
            }
            $seen_t = [];
            foreach ( $tlist as $item ) {
                $sheet   = is_array( $item ) ? ( $item['stylesheet'] ?? null ) : null;
                $version = is_array( $item ) ? ( $item['version'] ?? null ) : null;
                if ( ! is_string( $sheet ) || 1 !== preg_match( self::STYLESHEET_PATTERN, $sheet ) || str_contains( $sheet, '..' ) ) {
                    return $bad( 'Each theme needs an installed theme stylesheet.' );
                }
                if ( ! is_string( $version ) || ( 'latest' !== $version && 1 !== preg_match( '/^[0-9][0-9A-Za-z.\-+_]{0,39}$/', $version ) ) ) {
                    return $bad( 'Each theme needs a version: "latest" or an exact version.' );
                }
                if ( isset( $seen_t[ $sheet ] ) ) {
                    return $bad( 'A theme is named twice.' );
                }
                $seen_t[ $sheet ] = true;
                $themes[]         = [ 'stylesheet' => $sheet, 'version' => $version ];
            }
        }

        $list = $p['plugins'] ?? ( [] !== $themes ? [] : null );
        if ( ! is_array( $list ) || ! array_is_list( $list ) || ( [] === $list && [] === $themes ) || count( $list ) > self::MAX_PLUGINS ) {
            return $bad( '`plugins` must be a list of 1 to 10 plugins.' );
        }
        $plugins = [];
        $seen    = [];
        foreach ( $list as $item ) {
            $file    = is_array( $item ) ? ( $item['file'] ?? null ) : null;
            $version = is_array( $item ) ? ( $item['version'] ?? null ) : null;
            if ( ! is_string( $file ) || 1 !== preg_match( self::FILE_PATTERN, $file ) || str_contains( $file, '..' ) ) {
                return $bad( 'Each plugin needs an installed plugin file.' );
            }
            if ( ! is_string( $version ) || ( 'latest' !== $version && 1 !== preg_match( '/^[0-9][0-9A-Za-z.\-+_]{0,39}$/', $version ) ) ) {
                return $bad( 'Each plugin needs a version: "latest" or an exact version.' );
            }
            if ( isset( $seen[ $file ] ) ) {
                return $bad( 'A plugin is named twice.' );
            }
            $seen[ $file ] = true;
            $plugins[]     = [ 'file' => $file, 'version' => $version ];
        }
        return [ 'plugins' => $plugins, 'themes' => $themes, 'core' => null, 'key_paths' => $key_paths, 'auto_rollback' => $auto, 'cache_cycle' => $cycle ];
    }

    /**
     * `key_paths`, validated: a list of at most 10 paths on this site. Shared by
     * update, rollback and cache_cycle.
     *
     * @param array<string, mixed> $p
     * @return array<int|string, mixed> The paths, or [ 'error' => ... ].
     */
    private function key_paths( array $p, string $home ): array {
        $paths = $p['key_paths'] ?? [];
        if ( ! is_array( $paths ) || ! array_is_list( $paths ) || count( $paths ) > self::MAX_KEY_PATHS ) {
            return [ 'error' => self::error( 422, 'invalid_params', '`key_paths` must be a list of at most 10 paths.' ) ];
        }
        $key_paths = [];
        foreach ( $paths as $path ) {
            if ( ! self::valid_path( $path ) || ActionAuth::host_of( $this->env->home_url( $path ) ) !== $home ) {
                return [ 'error' => self::error( 422, 'invalid_key_path', 'A key path must be a path on this site, starting with a single /.' ) ];
            }
            $key_paths[] = $path;
        }
        return array_values( array_unique( $key_paths ) );
    }

    /** A path on this site: one leading slash, no scheme, no host, nothing to escape. */
    public static function valid_path( mixed $path ): bool {
        return is_string( $path )
            && '' !== $path
            && strlen( $path ) <= 200
            && str_starts_with( $path, '/' )
            && ! str_starts_with( $path, '//' )
            && 1 !== preg_match( '/[\x00-\x20\x7f\\\\#@]/', $path )
            && ! str_contains( $path, '://' )
            && ! str_contains( $path, '..' );
    }

    /**
     * Stage 1 must finish even if the CC hangs up, and must be allowed the time.
     * set_time_limit() is disabled on some hosts, which is why it is checked first.
     */
    private function long_request( int $seconds ): void {
        if ( function_exists( 'ignore_user_abort' ) ) {
            ignore_user_abort( true );
        }
        if ( function_exists( 'set_time_limit' ) ) {
            @set_time_limit( $seconds );
        }
    }

    /**
     * Hand stage 2 to WP-Cron and kick it. Returns at once; nothing here waits on
     * the cache cycle.
     *
     * The kick is spawn_cron(): a loopback POST to wp-cron.php with `blocking`
     * false, the same request WordPress itself makes, so it respects the host's
     * `cron_request` filter. It works with DISABLE_WP_CRON (that only stops the
     * page-load trigger; wp-cron.php still runs when asked). Under
     * ALTERNATE_WP_CRON spawn_cron() would REDIRECT this very request, which would
     * break the JSON response, so there the loopback is posted directly instead.
     * If the kick is lost (another cron run holding WordPress's 60 s lock), the event
     * still runs on the next cron trigger; if none comes before the deadline the
     * record reads `died`, which is the honest answer.
     *
     * Falls back to the shutdown hook only if the event cannot be scheduled.
     *
     * @param string[] $key_paths
     */
    public function schedule( string $id, array $key_paths ): void {
        $scheduled = function_exists( 'wp_schedule_single_event' )
            && true === wp_schedule_single_event( time(), self::STAGE2_HOOK, [ $id ], true );

        if ( $scheduled ) {
            // Written BEFORE the kick. Once the loopback is out, the cron request may
            // already be writing this record, and a write from here (from this
            // process's cached copy of the row) could put `queued` back over its
            // `running`. Only a failed kick, which started nothing, writes after.
            $this->store->update_stage2( $id, [ 'mode' => 'cron', 'spawned' => true, 'queued_at' => $this->store->now() ] );
            if ( ! self::kick_cron() ) {
                $this->store->update_stage2( $id, [ 'spawned' => false ] );
            }
            return;
        }

        $this->store->update_stage2( $id, [ 'mode' => 'shutdown' ] );
        ( self::after_response() )( fn ( bool $flushed ) => $this->stage2( $id, $key_paths, $flushed ? 'deferred' : 'inline' ) );
    }

    /** A non-blocking loopback to wp-cron.php. True when one was sent. */
    private static function kick_cron(): bool {
        if ( defined( 'ALTERNATE_WP_CRON' ) && ALTERNATE_WP_CRON ) {
            if ( ! function_exists( 'wp_remote_post' ) || ! function_exists( 'site_url' ) ) {
                return false;
            }
            wp_remote_post( site_url( 'wp-cron.php' ), [ 'timeout' => 0.01, 'blocking' => false, 'sslverify' => false ] );
            return true;
        }
        if ( ! function_exists( 'spawn_cron' ) ) {
            return false;
        }
        return false !== spawn_cron();
    }

    /**
     * The fallback stage 2 runner: on `shutdown`, after the response has been
     * flushed and the connection closed where the SAPI allows it. Only when the
     * WP-Cron event could not be scheduled (see schedule()).
     *
     * @return \Closure(\Closure(bool): void): void
     */
    private static function after_response(): \Closure {
        return static function ( \Closure $job ): void {
            if ( ! function_exists( 'add_action' ) ) {
                $job( false );
                return;
            }
            add_action(
                'shutdown',
                static function () use ( $job ): void {
                    $flushed = false;
                    if ( function_exists( 'fastcgi_finish_request' ) || function_exists( 'litespeed_finish_request' ) ) {
                        while ( ob_get_level() > 0 ) {
                            @ob_end_flush();
                        }
                        $flushed = function_exists( 'fastcgi_finish_request' ) ? fastcgi_finish_request() : litespeed_finish_request();
                    }
                    $job( (bool) $flushed );
                },
                PHP_INT_MAX
            );
        };
    }

    /**
     * @param array<string, mixed> $req
     * @param array<string, mixed> $extra
     * @return array{status:int, body:array<string,mixed>}
     */
    private static function ok( array $req, array $extra ): array {
        return [
            'status' => 200,
            'body'   => [
                'ok'       => true,
                'id'       => $req['id'],
                'install'  => $req['install'],
                'action'   => $req['action'],
                'protocol' => ActionAuth::PROTOCOL,
                'version'  => defined( 'BULLDOGS_SW_VERSION' ) ? BULLDOGS_SW_VERSION : 'unknown',
            ] + $extra,
        ];
    }

    /** @return array{status:int, body:array<string,mixed>} */
    private static function error( int $status, string $code, string $message ): array {
        return [ 'status' => $status, 'body' => [ 'ok' => false, 'code' => $code, 'message' => $message ] ];
    }

    /**
     * @param array{status:int, body:array<string,mixed>} $out
     * @return array{status:int, body:array<string,mixed>}
     */
    private function sanitised( array $out ): array {
        return [ 'status' => $out['status'], 'body' => OutputSanitiser::clean( $out['body'] ) ];
    }

    private static function header( mixed $request, string $name ): string {
        if ( ! is_object( $request ) || ! method_exists( $request, 'get_header' ) ) {
            return '';
        }
        $value = $request->get_header( $name );
        return is_string( $value ) ? $value : '';
    }
}
