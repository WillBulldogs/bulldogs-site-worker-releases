<?php
namespace Bulldogs\SiteWorker\Actions;

/**
 * Zips of plugin folders taken just before an update, and putting them back.
 *
 * ---------------------------------------------------------------------------
 * 🚨 OUTSIDE THE WEB ROOT, OR NOT AT ALL
 * ---------------------------------------------------------------------------
 * A web-servable zip of a premium plugin is a licence leak and a code leak, on a
 * client's public site. So backups go to `<account home>/.bsw-backups/<host>/`,
 * the account home being the parent of ABSPATH (`/home/<acct>` on LDN1 and
 * Brixly). The LDN1 mockup sites live side by side under `/home/bulldog1/`, which
 * is why there is a host folder.
 *
 * The folder is checked with realpath() against BOTH ABSPATH and the request's
 * DOCUMENT_ROOT. ABSPATH alone is not enough: a WordPress installed in a
 * subdirectory (`public_html/wp/`) has a parent that IS the document root. If the
 * folder resolves under either, or cannot be created and written, the update is
 * REFUSED (`no_safe_backup_dir`). There is no fallback to somewhere servable.
 *
 * ---------------------------------------------------------------------------
 * THE INDEX IS THE ONLY WAY BACK IN
 * ---------------------------------------------------------------------------
 * `rollback` takes an opaque id and looks it up in this plugin's own index. It never
 * takes a path, a file name or a version, so it can only ever restore a zip this
 * plugin made, on this site, recently - not "roll JetEngine back to 3.8.13", which
 * is inside the RCE range. Another site's id is simply not in this site's index.
 *
 * Retention: three per plugin, nothing older than 30 days. A rollback is accepted
 * for 14 days after the backup was taken (ROLLBACK_WINDOW); after that the CC must
 * ask for a normal update.
 *
 * ⚠️ PILOT RISK, from the spec: PHP writing a zip of PHP files into the account home
 * may trip Imunify360 (LDN1) or cPGuard (Brixly). Measure on a demo site first.
 */
class Backups {
    public const DIR_NAME = '.bsw-backups';

    public const KEEP_PER_PLUGIN = 3;
    public const RETENTION       = 30 * 86400;
    public const ROLLBACK_WINDOW = 14 * 86400;

    /** Room to leave free on top of the backup's own size, in bytes. */
    private const DISK_MARGIN = 52428800;

    public function __construct(
        private Environment $env,
        private ActionStore $store,
        private string $host
    ) {}

    /**
     * The backup folder for this site, created if needed, or null when there is no
     * folder that is both writable and outside every web root we can see.
     */
    public function dir(): ?string {
        $abs = rtrim( $this->env->abspath(), '/' );
        if ( '' === $abs || '' === $this->host || 1 !== preg_match( '/^[a-z0-9.\-]+$/', $this->host ) ) {
            return null;
        }
        $base = dirname( $abs ) . '/' . self::DIR_NAME;
        $dir  = $base . '/' . $this->host;

        if ( ! is_dir( $dir ) && ! @mkdir( $dir, 0700, true ) && ! is_dir( $dir ) ) {
            return null;
        }
        $real = realpath( $dir );
        if ( false === $real || ! is_writable( $real ) ) {
            return null;
        }
        foreach ( [ $abs, $this->env->doc_root() ] as $root ) {
            if ( '' === $root ) {
                continue;
            }
            $real_root = realpath( $root );
            if ( false !== $real_root && self::is_within( $real, $real_root ) ) {
                return null;
            }
        }
        @chmod( $real, 0700 );
        // Belt and braces for a host that maps the account home somewhere servable
        // after all. Harmless where it is not.
        $deny = dirname( $real ) . '/.htaccess';
        if ( ! file_exists( $deny ) ) {
            @file_put_contents( $deny, "Require all denied\nDeny from all\n" );
        }
        return $real;
    }

    public static function is_within( string $path, string $root ): bool {
        $path = rtrim( $path, '/' );
        $root = rtrim( $root, '/' );
        return $path === $root || str_starts_with( $path . '/', $root . '/' );
    }

    /**
     * Zip one plugin's folder (or file) before it is replaced.
     *
     * @return array{ok:true, backup:array<string,mixed>}|array{ok:false, reason:string}
     */
    public function create( string $file, string $version, string $kind = 'plugin' ): array {
        $dir = $this->dir();
        if ( null === $dir ) {
            return [ 'ok' => false, 'reason' => 'no_safe_backup_dir' ];
        }
        $source = $this->source( $file, $kind );
        if ( null === $source ) {
            return [ 'ok' => false, 'reason' => 'not_installed' ];
        }

        $size = self::size_of( $source );
        $free = function_exists( 'disk_free_space' ) ? @disk_free_space( $dir ) : false;
        if ( is_float( $free ) && $free < $size + self::DISK_MARGIN ) {
            return [ 'ok' => false, 'reason' => 'backup_no_space' ];
        }

        $id   = 'bk_' . bin2hex( random_bytes( 12 ) );
        $slug = ( 'theme' === $kind ? 'theme-' : '' ) . ( preg_replace( '/[^a-z0-9\-_.]/i', '', 'theme' === $kind ? $file : self::slug( $file ) ) ?: 'plugin' );
        $ver  = preg_replace( '/[^a-z0-9\-_.]/i', '', $version ) ?: 'unknown';
        $now  = $this->store->now();
        $path = $dir . '/' . $slug . '-' . $ver . '-' . $now . '-' . substr( $id, 3, 6 ) . '.zip';

        if ( ! $this->zip( $source, $path ) ) {
            @unlink( $path );
            return [ 'ok' => false, 'reason' => 'backup_failed' ];
        }
        @chmod( $path, 0600 );

        $entry = [
            'id'      => $id,
            'kind'    => $kind,
            'file'    => $file,
            'version' => $version,
            'path'    => $path,
            'created' => $now,
            'bytes'   => (int) @filesize( $path ),
        ];
        return [ 'ok' => true, 'backup' => $this->register( $entry ) ];
    }

    /**
     * Add a finished backup to the index and prune. Public for CoreBackup, which
     * makes its own files (core zip + database dump) and registers one entry for both.
     *
     * @param array<string, mixed> $entry
     * @return array<string, mixed> The entry as it leaves the site.
     */
    public function register( array $entry ): array {
        $index   = $this->store->backups();
        $index[] = $entry;
        $this->store->set_backups( $index );
        $this->prune();
        return self::present( $entry );
    }

    /** One index entry by id, or null. */
    public function find( string $id ): ?array {
        foreach ( $this->store->backups() as $entry ) {
            if ( hash_equals( $entry['id'], $id ) ) {
                return $entry;
            }
        }
        return null;
    }

    /** Can this backup still be rolled back to? */
    public function within_window( array $entry ): bool {
        return $this->store->now() - $entry['created'] <= self::ROLLBACK_WINDOW;
    }

    /**
     * Put a backup back in place of whatever is installed now.
     *
     * Extracted to a staging folder inside the backup area first, then swapped in by
     * rename, so the window in which the plugin folder is missing or half-written is
     * two renames long rather than an extraction long. If the swap fails part way,
     * the displaced copy is moved back.
     */
    public function restore( array $entry ): bool {
        $dir = $this->dir();
        if ( null === $dir || ! is_file( $entry['path'] ) ) {
            return false;
        }
        $kind = is_string( $entry['kind'] ?? null ) ? $entry['kind'] : 'plugin';
        $root = $this->root_for( $kind );
        if ( '' === $root || 'core' === $kind ) {
            // Core is restored by CoreBackup, never by swapping one folder.
            return false;
        }
        $name   = 'theme' === $kind ? $entry['file'] : self::top_level( $entry['file'] );
        $target = $root . '/' . $name;
        $stage  = $dir . '/restore-' . bin2hex( random_bytes( 6 ) );
        $aside  = $dir . '/displaced-' . bin2hex( random_bytes( 6 ) );

        if ( ! @mkdir( $stage, 0700 ) || ! $this->unzip( $entry['path'], $stage ) || ! file_exists( $stage . '/' . $name ) ) {
            self::remove_tree( $stage );
            return false;
        }

        $moved_aside = false;
        if ( file_exists( $target ) ) {
            if ( ! @rename( $target, $aside ) ) {
                self::remove_tree( $stage );
                return false;
            }
            $moved_aside = true;
        }

        if ( ! @rename( $stage . '/' . $name, $target ) ) {
            if ( $moved_aside ) {
                @rename( $aside, $target );
            }
            self::remove_tree( $stage );
            return false;
        }

        self::remove_tree( $stage );
        if ( $moved_aside ) {
            self::remove_tree( $aside );
        }
        $this->env->clean_plugins_cache();
        if ( function_exists( 'wp_clean_themes_cache' ) ) {
            wp_clean_themes_cache( true );
        }
        return true;
    }

    /**
     * Delete what retention says to: more than three per plugin, or older than 30
     * days. Files and index entries go together; an index entry whose file has
     * vanished goes too, because it can never be restored.
     */
    public function prune(): void {
        $now      = $this->store->now();
        $by_file  = [];
        $keep     = [];
        $entries  = $this->store->backups();
        usort( $entries, static fn ( array $a, array $b ): int => $b['created'] <=> $a['created'] );

        foreach ( $entries as $entry ) {
            $group = ( $entry['kind'] ?? 'plugin' ) . ':' . $entry['file'];
            $count = $by_file[ $group ] ?? 0;
            $stale = $now - $entry['created'] > self::RETENTION || $count >= self::KEEP_PER_PLUGIN || ! is_file( $entry['path'] );
            if ( $stale ) {
                foreach ( [ $entry['path'], $entry['db_path'] ?? null ] as $f ) {
                    if ( is_string( $f ) && is_file( $f ) && $this->is_ours( $f ) ) {
                        @unlink( $f );
                    }
                }
                continue;
            }
            $by_file[ $group ] = $count + 1;
            $keep[]                    = $entry;
        }
        $this->store->set_backups( array_reverse( $keep ) );
    }

    /**
     * The index as the findings `capabilities` lists it. Read-only: a GET must not
     * delete files, so expired entries are filtered here and pruned on the next write.
     *
     * @return array<int, array<string, mixed>>
     */
    public function listing(): array {
        $now = $this->store->now();
        $out = [];
        foreach ( $this->store->backups() as $entry ) {
            if ( $now - $entry['created'] <= self::RETENTION ) {
                $out[] = self::present( $entry );
            }
        }
        return $out;
    }

    /**
     * What leaves the site about a backup. Never the path: it names the account.
     *
     * `expires` is when the zip is deleted (30 days, the spec's example). The rollback
     * window is shorter, so it is given separately as `rollback_until`.
     *
     * @return array<string, mixed>
     */
    public static function present( array $entry ): array {
        $kind = is_string( $entry['kind'] ?? null ) ? $entry['kind'] : 'plugin';
        return [
            'id'             => $entry['id'],
            'kind'           => $kind,
            'component'      => $entry['file'],
            'file'           => $entry['file'],
            'version'        => $entry['version'],
            'created'        => $entry['created'],
            'expires'        => $entry['created'] + self::RETENTION,
            'rollback_until' => $entry['created'] + self::ROLLBACK_WINDOW,
            'bytes'          => is_int( $entry['bytes'] ?? null ) ? $entry['bytes'] : 0,
        ];
    }

    /** The plugin's folder (or single file), or the theme's folder. */
    private function source( string $file, string $kind = 'plugin' ): ?string {
        $root = $this->root_for( $kind );
        if ( '' === $root || 'core' === $kind || str_contains( $file, '..' ) || str_contains( $file, '/' ) && 'theme' === $kind ) {
            return null;
        }
        $path = $root . '/' . ( 'theme' === $kind ? $file : self::top_level( $file ) );
        return file_exists( $path ) ? $path : null;
    }

    private function root_for( string $kind ): string {
        return rtrim( 'theme' === $kind ? $this->env->theme_root() : $this->env->plugins_dir(), '/' );
    }

    /** `jet-engine/jet-engine.php` -> `jet-engine`; `hello.php` -> `hello.php`. */
    private static function top_level( string $file ): string {
        $dir = dirname( $file );
        return '.' === $dir || '' === $dir ? basename( $file ) : explode( '/', $dir )[0];
    }

    private static function slug( string $file ): string {
        $dir = dirname( $file );
        return '.' === $dir || '' === $dir ? basename( $file, '.php' ) : explode( '/', $dir )[0];
    }

    public function is_ours( string $path ): bool {
        $dir = $this->dir();
        return null !== $dir && self::is_within( (string) realpath( $path ), $dir );
    }

    /** ZipArchive, else WordPress's bundled PclZip. Entries are relative to the plugins folder. */
    private function zip( string $source, string $dest ): bool {
        return $this->zip_paths( [ $source ], dirname( $source ), $dest );
    }

    /**
     * Zip several paths (folders or files), each stored relative to $base. Public for
     * CoreBackup (wp-admin, wp-includes and the root *.php files under ABSPATH).
     *
     * @param string[] $sources
     * @param array<string, string> $extra Extra entries, name => content (CoreBackup's manifest).
     */
    public function zip_paths( array $sources, string $base, string $dest, array $extra = [] ): bool {
        $base = rtrim( $base, '/' );
        if ( class_exists( 'ZipArchive' ) ) {
            $zip = new \ZipArchive();
            if ( true !== $zip->open( $dest, \ZipArchive::CREATE | \ZipArchive::OVERWRITE ) ) {
                return false;
            }
            $ok = true;
            foreach ( $sources as $source ) {
                foreach ( self::walk( $source ) as $path ) {
                    $local = ltrim( substr( $path, strlen( $base ) ), '/' );
                    $ok    = ( is_dir( $path ) ? $zip->addEmptyDir( $local ) : $zip->addFile( $path, $local ) ) && $ok;
                }
            }
            foreach ( $extra as $name => $content ) {
                $ok = $zip->addFromString( $name, $content ) && $ok;
            }
            return $zip->close() && $ok;
        }
        $source = count( $sources ) === 1 ? $sources[0] : $sources;

        if ( ! class_exists( 'PclZip' ) && defined( 'ABSPATH' ) && is_readable( ABSPATH . 'wp-admin/includes/class-pclzip.php' ) ) {
            require_once ABSPATH . 'wp-admin/includes/class-pclzip.php';
        }
        if ( ! class_exists( 'PclZip' ) ) {
            return false;
        }
        $zip    = new \PclZip( $dest );
        $strings = [];
        foreach ( $extra as $name => $content ) {
            $strings[] = [ PCLZIP_ATT_FILE_NAME => $name, PCLZIP_ATT_FILE_CONTENT => $content ];
        }
        if ( [] === $sources ) {
            return [] !== $strings && 0 !== $zip->create( $strings );
        }
        if ( 0 === $zip->create( $source, PCLZIP_OPT_REMOVE_PATH, $base ) ) {
            return false;
        }
        return [] === $strings || 0 !== $zip->add( $strings );
    }

    public function unzip( string $zip_path, string $dest ): bool {
        if ( class_exists( 'ZipArchive' ) ) {
            $zip = new \ZipArchive();
            if ( true !== $zip->open( $zip_path ) ) {
                return false;
            }
            // Refuse any entry that would land outside the staging folder.
            for ( $i = 0; $i < $zip->numFiles; $i++ ) {
                $name = (string) $zip->getNameIndex( $i );
                if ( str_starts_with( $name, '/' ) || str_contains( $name, '..' ) ) {
                    $zip->close();
                    return false;
                }
            }
            $ok = $zip->extractTo( $dest );
            $zip->close();
            return $ok;
        }

        if ( ! class_exists( 'PclZip' ) && defined( 'ABSPATH' ) && is_readable( ABSPATH . 'wp-admin/includes/class-pclzip.php' ) ) {
            require_once ABSPATH . 'wp-admin/includes/class-pclzip.php';
        }
        if ( ! class_exists( 'PclZip' ) ) {
            return false;
        }
        $zip = new \PclZip( $zip_path );
        return 0 !== $zip->extract( PCLZIP_OPT_PATH, $dest );
    }

    /** @return string[] Every path under $source, itself included, without following links. */
    private static function walk( string $source ): array {
        if ( ! is_dir( $source ) ) {
            return [ $source ];
        }
        $out  = [ $source ];
        $iter = new \RecursiveIteratorIterator(
            new \RecursiveDirectoryIterator( $source, \FilesystemIterator::SKIP_DOTS ),
            \RecursiveIteratorIterator::SELF_FIRST
        );
        foreach ( $iter as $item ) {
            if ( $item->isLink() ) {
                continue;
            }
            $out[] = $item->getPathname();
        }
        return $out;
    }

    public static function size_of( string $source ): int {
        $total = 0;
        foreach ( self::walk( $source ) as $path ) {
            if ( is_file( $path ) ) {
                $total += (int) @filesize( $path );
            }
        }
        return $total;
    }

    /** Recursive delete that never follows a symlink out of the tree. */
    public static function remove_tree( string $path ): void {
        if ( is_link( $path ) || is_file( $path ) ) {
            @unlink( $path );
            return;
        }
        if ( ! is_dir( $path ) ) {
            return;
        }
        foreach ( scandir( $path ) ?: [] as $item ) {
            if ( '.' === $item || '..' === $item ) {
                continue;
            }
            self::remove_tree( $path . '/' . $item );
        }
        @rmdir( $path );
    }
}
