<?php
namespace Bulldogs\SiteWorker\Actions;

/**
 * Stage 2: rebuild the caches after an update, in SOP order.
 *
 * ---------------------------------------------------------------------------
 * THE ORDER IS THE WHOLE POINT
 * ---------------------------------------------------------------------------
 * wordpress-updates §3-§4, done with PHP calls instead of wp-cli, and decision D6:
 *
 *   1. Builder CSS: Elementor's files_manager->clear_cache() (what `wp elementor
 *      flush-css` calls). It DELETES every post-<id>.css and rebuilds nothing, so
 *      stopping here is the race that broke career-tests on 7 Aug. Never stop here.
 *   2. Purge minify + page cache. WP Rocket and clsop: rocket_clean_minify() then
 *      rocket_clean_domain(). LiteSpeed: do_action('litespeed_purge_all') - the
 *      CLI form returned `Got 400` on Cottier. Anything else: not purged, said so.
 *      Minify goes BEFORE the first warm: purged after it, it deletes the assets
 *      that warm just wrote.
 *   3. Warm 1, which writes the regenerated assets.
 *   4. Purge the page cache only, leaving those assets.
 *   5. Warm 2, so the cached HTML references assets that exist.
 *   6. [MIN] check: every /wp-content/cache/min/ reference in the warm-2 HTML must
 *      exist on disk. One failure re-runs 4-6 once, then reports.
 *
 * `[CSS]` is NOT checked. It false-positives on beaupro3 and apexlof1 and the SOP
 * forbids "fixing" it - the fix (flush-css) arms the very race above.
 *
 * ---------------------------------------------------------------------------
 * WARMING: SERIAL, SLOW, COMPLETE, AND HONEST ABOUT WHAT IT CUT
 * ---------------------------------------------------------------------------
 * Serial with 0.4 s between requests, 45 s timeout: parallel warming on 7 Aug hit
 * the 1 GB LVE cap and 503'd real visitors. Never AccelerateWP's preload, which is
 * too aggressive for that cage. The list is every published page, post and public
 * custom post type, home, every public post type archive and the key paths -
 * missing the archives produced a real [MIN] on randrbr1. Capped at 600 URLs, and
 * anything cut is COUNTED in the record, never silently dropped.
 *
 * The [MIN] check reads the HTML warm 2 was served, which is the HTML the page
 * cache just stored, so it costs no extra request.
 */
class CacheCycle {
    public const MAX_URLS  = 600;
    public const TIMEOUT   = 45;
    public const GAP_US    = 400000;

    public const CACHE_ROCKET       = 'wp-rocket';
    public const CACHE_LITESPEED    = 'litespeed';
    public const CACHE_UNRECOGNISED = 'unrecognised';

    /** stage2.warm_skipped when there is no page cache to warm (0.12.2). */
    public const WARM_SKIPPED_NO_PAGE_CACHE = 'no_page_cache';

    /** @var \Closure(int): void */
    private \Closure $sleep;

    /** @var string[] Steps taken, in order. Read by the suite to pin the order. */
    public array $steps = [];

    /** @var (\Closure(): string)|null Tests pin the cache kind here (0.12.2). */
    private ?\Closure $kind;

    public function __construct( private Environment $env, ?\Closure $sleep = null, ?\Closure $kind = null ) {
        $this->kind  = $kind;
        $this->sleep = $sleep ?? static function ( int $us ): void {
            usleep( $us );
        };
    }

    /**
     * Run the cycle. $progress is called with partial stage 2 fields as it goes, so a
     * record of a stage that was killed half way still says how far it got.
     *
     * @param string[] $key_paths
     * @param \Closure(array<string,mixed>): void $progress
     * @return array{urls_warmed:int, urls_cut:int, min_missing:int, cache:string, elementor_flushed:bool, min_rerun:bool, warm_skipped?:string}
     */
    public function run( array $key_paths, \Closure $progress ): array {
        $cache = $this->cache_kind();

        // 1. Builder CSS.
        $elementor = $this->flush_elementor();
        $progress( [ 'cache' => $cache, 'elementor_flushed' => $elementor ] );

        // 0.12.2 (Will, 24 Oct 2026: "only if the site has a cache"): with no page
        // cache we recognise, there is no cached HTML to rebuild and nothing for a
        // warm to write, so both purges, both warms and the [MIN] check are skipped.
        // Measured on template (cache "unrecognised"): the two warms took 5 min quiet
        // and 29 min under load and bought nothing, while the site lock was held.
        // The Elementor flush above still runs: Elementor rebuilds its CSS on the next
        // view, and with no page cache no stale HTML can point at the old files.
        if ( self::CACHE_UNRECOGNISED === $cache ) {
            return [
                'urls_warmed'       => 0,
                'urls_cut'          => 0,
                'min_missing'       => 0,
                'cache'             => $cache,
                'elementor_flushed' => $elementor,
                'min_rerun'         => false,
                'warm_skipped'      => self::WARM_SKIPPED_NO_PAGE_CACHE,
            ];
        }

        // 2. Minify + page.
        $this->purge( $cache, true );

        [ $urls, $cut ] = $this->urls( $key_paths );
        $progress( [ 'urls_cut' => $cut ] );

        // 3. Warm 1.
        $this->warm( $urls, false );
        $progress( [ 'urls_warmed' => count( $urls ) ] );

        // 4-6, and once more on a [MIN] failure.
        $missing = $this->purge_warm_check( $cache, $urls );
        $rerun   = false;
        if ( $missing > 0 ) {
            $rerun   = true;
            $missing = $this->purge_warm_check( $cache, $urls );
        }

        return [
            'urls_warmed'       => count( $urls ),
            'urls_cut'          => $cut,
            'min_missing'       => $missing,
            'cache'             => $cache,
            'elementor_flushed' => $elementor,
            'min_rerun'         => $rerun,
        ];
    }

    /** Steps 4-6. @param string[] $urls */
    private function purge_warm_check( string $cache, array $urls ): int {
        $this->purge( $cache, false );
        $bodies = $this->warm( $urls, true );
        $this->steps[] = 'min_check';
        $missing = 0;
        foreach ( $bodies as $html ) {
            $missing += count( self::missing_min( $html, $this->min_dir() ) );
        }
        return $missing;
    }

    /**
     * Would a cycle do anything here? A recognised page cache, or Elementor (whose
     * CSS flush runs even without one). False means a `cache_cycle` action can be
     * answered `skipped` at once instead of queued.
     */
    public function has_work(): bool {
        return self::CACHE_UNRECOGNISED !== $this->cache_kind() || self::elementor_present();
    }

    public function cache_kind(): string {
        if ( null !== $this->kind ) {
            return (string) ( $this->kind )();
        }
        if ( function_exists( 'rocket_clean_domain' ) ) {
            // WP Rocket, and AccelerateWP (clsop), which ships the same functions.
            return self::CACHE_ROCKET;
        }
        if ( defined( 'LSCWP_V' ) || ( function_exists( 'has_action' ) && has_action( 'litespeed_purge_all' ) ) ) {
            return self::CACHE_LITESPEED;
        }
        return self::CACHE_UNRECOGNISED;
    }

    private static function elementor_present(): bool {
        return class_exists( '\Elementor\Plugin' ) && isset( \Elementor\Plugin::$instance ) && is_object( \Elementor\Plugin::$instance );
    }

    private function flush_elementor(): bool {
        $this->steps[] = 'elementor';
        try {
            if ( self::elementor_present() ) {
                $files = \Elementor\Plugin::$instance->files_manager ?? null;
                if ( is_object( $files ) && method_exists( $files, 'clear_cache' ) ) {
                    $files->clear_cache();
                    return true;
                }
            }
        } catch ( \Throwable $e ) {
            OutputSanitiser::log( 'elementor css flush failed: ' . $e->getMessage() );
        }
        return false;
    }

    private function purge( string $cache, bool $with_minify ): void {
        $this->steps[] = $with_minify ? 'purge_minify_and_page' : 'purge_page';
        try {
            if ( self::CACHE_ROCKET === $cache ) {
                if ( $with_minify && function_exists( 'rocket_clean_minify' ) ) {
                    rocket_clean_minify();
                }
                rocket_clean_domain();
            } elseif ( self::CACHE_LITESPEED === $cache && function_exists( 'do_action' ) ) {
                do_action( 'litespeed_purge_all' );
            }
        } catch ( \Throwable $e ) {
            OutputSanitiser::log( 'cache purge failed: ' . $e->getMessage() );
        }
    }

    /**
     * Fetch each URL, serially. Returns the bodies only when asked, for the [MIN]
     * check, and then only the bodies - not kept beyond this call.
     *
     * @param string[] $urls
     * @return string[]
     */
    private function warm( array $urls, bool $keep ): array {
        $this->steps[] = $keep ? 'warm2' : 'warm1';
        $bodies = [];
        $first  = true;
        foreach ( $urls as $url ) {
            if ( ! $first ) {
                ( $this->sleep )( self::GAP_US );
            }
            $first = false;
            if ( ! function_exists( 'wp_remote_get' ) ) {
                continue;
            }
            $response = wp_remote_get( $url, [ 'timeout' => self::TIMEOUT, 'redirection' => 3, 'sslverify' => false, 'headers' => [ 'X-Bulldogs-SW-Warm' => '1' ] ] );
            if ( $keep && ! ( function_exists( 'is_wp_error' ) && is_wp_error( $response ) ) ) {
                $body = function_exists( 'wp_remote_retrieve_body' ) ? wp_remote_retrieve_body( $response ) : '';
                if ( is_string( $body ) && '' !== $body ) {
                    $bodies[] = $body;
                }
            }
        }
        return $bodies;
    }

    /**
     * The warm list and how many were cut by the cap.
     *
     * @param string[] $key_paths
     * @return array{0:string[], 1:int}
     */
    public function urls( array $key_paths ): array {
        $urls = [];
        $home = $this->env->home_url( '/' );
        if ( '' !== $home ) {
            $urls[] = $home;
        }
        foreach ( $key_paths as $path ) {
            $url = $this->env->home_url( $path );
            if ( '' !== $url ) {
                $urls[] = $url;
            }
        }

        $types = [ 'page', 'post' ];
        if ( function_exists( 'get_post_types' ) ) {
            $public = get_post_types( [ 'public' => true ], 'names' );
            foreach ( is_array( $public ) ? $public : [] as $type ) {
                if ( is_string( $type ) && 'attachment' !== $type ) {
                    $types[] = $type;
                }
            }
        }
        $types = array_values( array_unique( $types ) );

        foreach ( $types as $type ) {
            if ( function_exists( 'get_post_type_archive_link' ) ) {
                $archive = get_post_type_archive_link( $type );
                if ( is_string( $archive ) && '' !== $archive ) {
                    $urls[] = $archive;
                }
            }
        }

        $fixed = count( array_unique( $urls ) );
        if ( function_exists( 'get_posts' ) && function_exists( 'get_permalink' ) ) {
            $ids = get_posts(
                [
                    'post_type'        => $types,
                    'post_status'      => 'publish',
                    // Never more than the cap can use: a 5,000-post site must not
                    // load 5,000 permalinks to warm 600 of them.
                    'numberposts'      => self::MAX_URLS,
                    'fields'           => 'ids',
                    'orderby'          => 'date',
                    'order'            => 'DESC',
                    'no_found_rows'    => true,
                    'suppress_filters' => false,
                ]
            );
            foreach ( is_array( $ids ) ? $ids : [] as $id ) {
                $link = get_permalink( $id );
                if ( is_string( $link ) && '' !== $link ) {
                    $urls[] = $link;
                }
            }
        }

        $urls = array_values( array_unique( $urls ) );
        $cut  = max( 0, count( $urls ) - self::MAX_URLS );

        // The query stopped at the cap, so what it did not load is counted from the
        // published totals: home, archives and key paths, plus every published post.
        if ( function_exists( 'wp_count_posts' ) ) {
            $published = 0;
            foreach ( $types as $type ) {
                $counts     = wp_count_posts( $type );
                $published += is_object( $counts ) && isset( $counts->publish ) && is_numeric( $counts->publish ) ? (int) $counts->publish : 0;
            }
            $cut = max( $cut, $fixed + $published - self::MAX_URLS );
        }
        return [ array_slice( $urls, 0, self::MAX_URLS ), $cut ];
    }

    private function min_dir(): string {
        return ( defined( 'WP_CONTENT_DIR' ) ? (string) WP_CONTENT_DIR : rtrim( $this->env->abspath(), '/' ) . '/wp-content' ) . '/cache/min/';
    }

    /**
     * Pure: every /wp-content/cache/min/ reference in $html that is not on disk.
     *
     * @return string[]
     */
    public static function missing_min( string $html, string $min_dir ): array {
        if ( ! preg_match_all( '~/wp-content/cache/min/([^"\'\s?#>)]+)~', $html, $m ) ) {
            return [];
        }
        $missing = [];
        foreach ( array_unique( $m[1] ) as $relative ) {
            if ( str_contains( $relative, '..' ) ) {
                continue;
            }
            if ( ! is_file( rtrim( $min_dir, '/' ) . '/' . $relative ) ) {
                $missing[] = $relative;
            }
        }
        return $missing;
    }
}
