<?php
namespace Bulldogs\SiteWorker\Actions;

use Bulldogs\SiteWorker\Modules;

/**
 * The `capabilities` key of the findings response.
 *
 * ---------------------------------------------------------------------------
 * WHY THE CC NEEDS THIS
 * ---------------------------------------------------------------------------
 * With both action modules off, the actions route is not registered, so a call to
 * it is WordPress's own 404 `rest_no_route` - the same answer a site still running
 * 0.10.x gives. "Switched off here" and "plugin too old" must not be told apart by
 * guessing, and "plugin gone" is a third thing again. The findings route, which the
 * CC already polls, therefore says which action modules are on, plus the backups a
 * rollback could use and the last actions' states, so the CC can show a Roll back
 * button and a stage 2 result without an extra request.
 *
 * Read-only, like everything on that route: listing backups filters expired ones
 * rather than deleting them, and no record is changed by being read.
 */
class Capabilities {
    /**
     * @param Backups|null $backups Null means build one when asked. The monitor module
     *                             constructs this on every request it boots on, so the
     *                             constructor must not read anything - home_url()
     *                             included - until a findings pull actually calls gather().
     */
    public function __construct(
        private Modules $modules,
        private ActionStore $store,
        private ?Backups $backups = null
    ) {}

    private function backups(): Backups {
        if ( null === $this->backups ) {
            $env           = new Environment();
            $this->backups = new Backups( $env, $this->store, ActionAuth::host_of( $env->home_url( '/' ) ) );
        }
        return $this->backups;
    }

    /** @return array<string, mixed> */
    public function gather(): array {
        return OutputSanitiser::clean(
            [
                'protocol'       => ActionAuth::PROTOCOL,
                'sync'           => $this->modules->is_enabled( Modules::SYNC ),
                'actions'        => $this->modules->is_enabled( Modules::ACTIONS ),
                'backups'        => $this->backups()->listing(),
                'recent_actions' => $this->store->recent(),
                // 0.12.0, A1: so the CC can show a low limit before anyone updates.
                'memory_limit'       => ( new Environment() )->memory_limit(),
                'memory_limit_admin' => ( new Environment() )->memory_limit_admin(),
            ]
        );
    }
}
