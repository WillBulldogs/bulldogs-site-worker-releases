<?php
namespace Bulldogs\SiteWorker\Actions;

/**
 * The backup a core update takes before it touches anything: WordPress's own
 * files AND the database, as ONE index entry (kind `core`), so a rollback by id
 * restores both or neither is offered.
 *
 * ---------------------------------------------------------------------------
 * 🚨 BYTES ARE TIME: EVERY LDN1 ACCOUNT IS CAPPED AT 1 MB/s OF DISK I/O
 * ---------------------------------------------------------------------------
 * CloudLinux LVE, `IO 1024` on the default and on bulldog1 (lvectl, 24 Oct 2026),
 * with I/O faults the moment real files are read. On the 0.12.0 pilot a core
 * update's stage 1 took ~295 s while its database dump took 5.7 s: the time was
 * bytes. So this class moves as few as it can:
 *
 *   - DELTA BACKUP. With the TARGET release's checksums from WordPress.org (one
 *     API call), only the files the update will change or delete are zipped -
 *     the core upgrader itself skips every file that is already identical, so
 *     nothing else can change. A minor update backs up a handful of files instead
 *     of the 23 MB a full core zip writes. Files the release will ADD are listed
 *     (`absent_before`), so a rollback can remove them. Without checksums (an API
 *     failure, a locale WordPress.org does not publish) the backup is the whole of
 *     wp-admin, wp-includes and the root *.php, as in 0.12.0 before the pilot.
 *   - TWO-PHASE RESTORE. prepare_restore() extracts only the files that differ
 *     from the backup, into a staging folder, BEFORE maintenance mode goes on;
 *     apply_restore(), under `.maintenance`, only renames them into place and
 *     removes what the failed release added. The 503 window becomes renames plus
 *     the database restore, not a 100 MB unzip (the pilot's failed major sat behind
 *     `.maintenance` for 4-5 minutes).
 *
 * wp-config.php is never backed up, compared, restored or deleted.
 */
class CoreBackup {
    public const MANIFEST = 'bsw-core-manifest.json';

    public function __construct(
        private Environment $env,
        private Backups $backups,
        private DbBackup $db,
        private ActionStore $store
    ) {}

    /**
     * @param \Closure(string, int): void|null $progress Per table, while the database is dumped.
     * @param array<string, string>|null $target_checksums The TARGET release's md5s, path => md5 (get_core_checksums()). Null means a full backup.
     * @return array<string, mixed> `ok` with `backup` (as it leaves the site), `db` (dump stats) and `files` (mode, count, bytes), or `ok` false with `reason`/`detail`.
     */
    public function create( string $version, ?int $db_version, string $prefix, ?\Closure $progress = null, ?Timings $timings = null, ?array $target_checksums = null ): array {
        $dir = $this->backups->dir();
        if ( null === $dir ) {
            return [ 'ok' => false, 'reason' => 'no_safe_backup_dir', 'detail' => '' ];
        }
        $abs = rtrim( $this->env->abspath(), '/' );

        $timings?->start( 'files_select' );
        $plan = null !== $target_checksums && [] !== $target_checksums ? $this->delta( $abs, $target_checksums ) : null;
        $timings?->stop( 'files_select' );
        $paths    = null !== $plan ? $plan['files'] : $this->env->core_paths();
        $manifest = null !== $plan
            ? [ 'mode' => 'delta', 'version' => $version, 'absent_before' => $plan['absent_before'] ]
            : [ 'mode' => 'full', 'version' => $version, 'absent_before' => [] ];
        if ( null === $plan && [] === $paths ) {
            return [ 'ok' => false, 'reason' => 'backup_failed', 'detail' => 'no core files found' ];
        }

        $id   = 'bk_' . bin2hex( random_bytes( 12 ) );
        $ver  = preg_replace( '/[^a-z0-9\-_.]/i', '', $version ) ?: 'unknown';
        $now  = $this->store->now();
        $base = $dir . '/core-' . $ver . '-' . $now . '-' . substr( $id, 3, 6 );

        $timings?->start( 'files_backup' );
        $zipped = $this->backups->zip_paths( $paths, $abs, $base . '.zip', [ self::MANIFEST => (string) json_encode( $manifest, JSON_UNESCAPED_SLASHES ) ] );
        $timings?->stop( 'files_backup' );
        if ( ! $zipped ) {
            @unlink( $base . '.zip' );
            return [ 'ok' => false, 'reason' => 'backup_failed', 'detail' => 'could not zip the core files' ];
        }
        @chmod( $base . '.zip', 0600 );

        $timings?->start( 'db_backup' );
        $dump = $this->db->dump( $prefix, $base . '.sql.gz', $progress );
        $timings?->stop( 'db_backup' );
        if ( true !== $dump['ok'] ) {
            @unlink( $base . '.zip' );
            return [ 'ok' => false, 'reason' => $dump['reason'], 'detail' => $dump['detail'] ];
        }
        @chmod( $base . '.sql.gz', 0600 );

        $entry = [
            'id'         => $id,
            'kind'       => 'core',
            'file'       => 'core',
            'version'    => $version,
            'db_version' => $db_version,
            'prefix'     => $prefix,
            'path'       => $base . '.zip',
            'db_path'    => $base . '.sql.gz',
            'created'    => $now,
            'bytes'      => (int) @filesize( $base . '.zip' ) + (int) @filesize( $base . '.sql.gz' ),
        ];
        return [
            'ok'     => true,
            'backup' => $this->backups->register( $entry ),
            'db'     => $dump,
            'files'  => [ 'mode' => $manifest['mode'], 'count' => count( $paths ), 'bytes' => (int) @filesize( $base . '.zip' ) ],
        ];
    }

    /**
     * Which current core files the update can touch: every core file whose md5
     * differs from the target's (it will be overwritten), or that the target does
     * not have (it may be deleted). And which target files do not exist yet (the
     * update will add them; a rollback removes them).
     *
     * @param array<string, string> $target
     * @return array{files:string[], absent_before:string[]}
     */
    private function delta( string $abs, array $target ): array {
        $files = [];
        foreach ( $this->current_core_files( $abs ) as $rel ) {
            $want = $target[ $rel ] ?? null;
            if ( null === $want || ! hash_equals( (string) $want, (string) @md5_file( $abs . '/' . $rel ) ) ) {
                $files[] = $abs . '/' . $rel;
            }
        }
        $absent = [];
        foreach ( array_keys( $target ) as $rel ) {
            if ( self::is_core_path( (string) $rel ) && ! file_exists( $abs . '/' . $rel ) ) {
                $absent[] = (string) $rel;
            }
        }
        sort( $absent );
        return [ 'files' => $files, 'absent_before' => $absent ];
    }

    /**
     * Phase 1 of a restore, OUTSIDE maintenance mode: extract only the files that
     * differ from the backup into a staging folder, and list what to delete.
     *
     * @return array{stage:string, moves:array<string,string>, deletes:string[], mode:string}|null Null when the backup cannot be read.
     */
    public function prepare_restore( array $entry ): ?array {
        $dir = $this->backups->dir();
        $abs = rtrim( $this->env->abspath(), '/' );
        $zip_path = (string) ( $entry['path'] ?? '' );
        if ( null === $dir || '' === $abs || ! is_file( $zip_path ) || ! class_exists( 'ZipArchive' ) ) {
            return null;
        }
        $zip = new \ZipArchive();
        if ( true !== $zip->open( $zip_path ) ) {
            return null;
        }
        $raw      = $zip->getFromName( self::MANIFEST );
        $manifest = is_string( $raw ) ? json_decode( $raw, true ) : null;
        // A backup from before the manifest existed is a full one.
        $mode = is_array( $manifest ) && 'delta' === ( $manifest['mode'] ?? null ) ? 'delta' : 'full';

        $stage = $dir . '/restore-' . bin2hex( random_bytes( 6 ) );
        if ( ! @mkdir( $stage, 0700 ) ) {
            $zip->close();
            return null;
        }
        $moves   = [];
        $in_zip  = [];
        $extract = [];
        for ( $i = 0; $i < $zip->numFiles; $i++ ) {
            $st   = $zip->statIndex( $i );
            $name = is_array( $st ) ? (string) $st['name'] : '';
            if ( '' === $name || str_ends_with( $name, '/' ) || self::MANIFEST === $name ) {
                continue;
            }
            if ( str_starts_with( $name, '/' ) || str_contains( $name, '..' ) || ! self::is_core_path( $name ) ) {
                $zip->close();
                Backups::remove_tree( $stage );
                return null;
            }
            $in_zip[ $name ] = true;
            $live            = $abs . '/' . $name;
            // Unchanged since the backup: nothing to write. CRC32 is what the zip
            // already stores, so this costs a read of the live file and no write.
            if ( is_file( $live ) && sprintf( '%08x', $st['crc'] & 0xFFFFFFFF ) === hash_file( 'crc32b', $live ) ) {
                continue;
            }
            $extract[]       = $name;
            $moves[ $name ]  = $stage . '/' . $name;
        }
        $ok = [] === $extract || $zip->extractTo( $stage, $extract );
        $zip->close();
        if ( ! $ok ) {
            Backups::remove_tree( $stage );
            return null;
        }

        $deletes = [];
        if ( 'delta' === $mode ) {
            foreach ( (array) ( $manifest['absent_before'] ?? [] ) as $rel ) {
                if ( is_string( $rel ) && self::is_core_path( $rel ) && ! isset( $in_zip[ $rel ] ) && file_exists( $abs . '/' . $rel ) ) {
                    $deletes[] = $rel;
                }
            }
        } else {
            foreach ( $this->current_core_files( $abs ) as $rel ) {
                if ( ! isset( $in_zip[ $rel ] ) ) {
                    $deletes[] = $rel;
                }
            }
        }
        return [ 'stage' => $stage, 'moves' => $moves, 'deletes' => $deletes, 'mode' => $mode ];
    }

    /**
     * Phase 2, UNDER maintenance mode: rename the staged files into place and
     * remove what the failed release added. Renames on one filesystem; a copy where
     * a rename is refused.
     */
    public function apply_restore( array $plan ): bool {
        $abs = rtrim( $this->env->abspath(), '/' );
        $ok  = true;
        foreach ( $plan['moves'] as $rel => $staged ) {
            $live = $abs . '/' . $rel;
            if ( ! is_dir( dirname( $live ) ) ) {
                @mkdir( dirname( $live ), 0755, true );
            }
            if ( ! @rename( $staged, $live ) && ! @copy( $staged, $live ) ) {
                $ok = false;
            }
        }
        foreach ( $plan['deletes'] as $rel ) {
            if ( 'wp-config.php' !== $rel ) {
                @unlink( $abs . '/' . $rel );
            }
        }
        Backups::remove_tree( $plan['stage'] );
        if ( function_exists( 'opcache_reset' ) ) {
            @opcache_reset();
        }
        return $ok;
    }

    public function discard_restore( array $plan ): void {
        Backups::remove_tree( $plan['stage'] );
    }

    /** Both phases at once, for callers that do not hold maintenance mode themselves. */
    public function restore_files( array $entry ): bool {
        $plan = $this->prepare_restore( $entry );
        return null !== $plan && $this->apply_restore( $plan );
    }

    /**
     * Put the database back from this entry's dump.
     *
     * @param \Closure(string): void|null $progress
     * @return array<string, mixed>
     */
    public function restore_db( array $entry, ?\Closure $progress = null ): array {
        $path   = (string) ( $entry['db_path'] ?? '' );
        $prefix = (string) ( $entry['prefix'] ?? '' );
        if ( '' === $path || ! is_file( $path ) || ! $this->backups->is_ours( $path ) ) {
            return [ 'ok' => false, 'reason' => 'db_restore_failed', 'detail' => 'the dump is missing' ];
        }
        return $this->db->restore( $path, $prefix, $progress );
    }

    /** wp-admin/..., wp-includes/..., or a root *.php - never wp-config.php. */
    public static function is_core_path( string $rel ): bool {
        if ( 'wp-config.php' === $rel || str_contains( $rel, '..' ) || str_starts_with( $rel, '/' ) ) {
            return false;
        }
        return str_starts_with( $rel, 'wp-admin/' ) || str_starts_with( $rel, 'wp-includes/' ) || 1 === preg_match( '#^[^/]+\.php$#', $rel );
    }

    /** @return string[] Paths relative to ABSPATH. */
    private function current_core_files( string $abs ): array {
        $out = [];
        foreach ( $this->env->core_paths() as $path ) {
            if ( is_file( $path ) ) {
                $out[] = ltrim( substr( $path, strlen( $abs ) ), '/' );
                continue;
            }
            $iter = new \RecursiveIteratorIterator( new \RecursiveDirectoryIterator( $path, \FilesystemIterator::SKIP_DOTS ) );
            foreach ( $iter as $f ) {
                if ( $f->isFile() && ! $f->isLink() ) {
                    $out[] = ltrim( substr( $f->getPathname(), strlen( $abs ) ), '/' );
                }
            }
        }
        sort( $out );
        return $out;
    }
}
