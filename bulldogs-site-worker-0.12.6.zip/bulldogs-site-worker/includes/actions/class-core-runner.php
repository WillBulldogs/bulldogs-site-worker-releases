<?php
namespace Bulldogs\SiteWorker\Actions;

use Bulldogs\SiteWorker\Settings;

/**
 * WordPress core updates and rollbacks (0.12.0, work order section C).
 *
 * ---------------------------------------------------------------------------
 * ALONE, BACKED UP TWICE, AND PERSISTED AT EVERY STEP
 * ---------------------------------------------------------------------------
 * Core runs in a request of its own, never batched with plugins or themes (the
 * controller refuses the mix). Before anything changes, the core files AND every
 * table with the site's prefix are backed up and the dump is verified
 * (CoreBackup, DbBackup). Every step reaches the action record before the next
 * starts: a core update is the case where a killed request matters most, and the
 * record must say whether the files moved, whether the database moved, and where
 * both backups are.
 *
 * ---------------------------------------------------------------------------
 * WHAT IS REFUSED, EACH WITH ITS OWN REASON
 * ---------------------------------------------------------------------------
 *   multisite                - not in v1
 *   version_mismatch         - nothing on offer matching the request
 *   downgrade_refused        - the target is older than what is installed
 *   core_major_not_allowed   - a major update (7.0.x -> 7.1.x, which runs database
 *                              changes) without this site allowing majors. The site
 *                              flag `allow_core_major` decides when it is set
 *                              (literally true or false); unset, MAJOR_DEFAULT does.
 *                              MAJOR_DEFAULT is TRUE since the template pilot proved
 *                              a major update and a forced rollback with a database
 *                              restore (24 Oct 2026).
 *   php_too_old              - PHP below the offer's php_version
 *   db_too_old               - MySQL/MariaDB below the offer's mysql_version
 *   wp_rocket_wp71_fatal     - a target >= 7.1 while any copy of WP Rocket's
 *                              Cloudflare.php (wp-rocket, clsop, or a white label:
 *                              found by FILE, never by plugin name) still calls
 *                              substr() on an unchecked $key. 14 sites went 500 on
 *                              20 Aug 2026 that way (wp-rocket-wp71-substr-fatal.md)
 *   package_unavailable      - the offer's package is not an https download from
 *                              downloads.wordpress.org
 *   insufficient_disk        - free space under twice (core files + database)
 *   site_unhealthy           - the site cannot be measured before the change
 *   db_backup_unsupported / db_backup_failed / no_safe_backup_dir / backup_failed
 *
 * ---------------------------------------------------------------------------
 * THE UPGRADE, AND THE WAY BACK
 * ---------------------------------------------------------------------------
 * Core_Upgrader with the offer (the wp-admin path), then the database upgrade in a
 * fresh request (upgrade.php, as update_core() does), then the version read back
 * from wp-includes/version.php ON DISK and `db_version` read from the database.
 * Health is settled with the same retries as plugins. Broken, with auto_rollback:
 * the files are restored, and the database too when its version changed - inside
 * this request. `.maintenance` is removed on every exit path.
 */
class CoreRunner {
    /** Settings key. Literally true allows majors here; literally false refuses them; unset means MAJOR_DEFAULT. */
    public const KEY_ALLOW_MAJOR = 'allow_core_major';

    /**
     * ON since the template pilot passed (24 Oct 2026): a major 7.0.7 -> 7.1.3 with
     * a forced breaker rolled back files AND database (62 tables, 39,136 rows) to
     * exactly the baseline page, and a clean major updated with home 200 throughout.
     * A site can still refuse majors with `wp bulldogs actions deny-core-major`.
     */
    public const MAJOR_DEFAULT = true;

    public const PACKAGE_HOST = 'downloads.wordpress.org';

    /** @var \Closure(): void */
    private \Closure $heartbeat;
    /** @var \Closure(int, array<string,mixed>): void */
    private \Closure $progress;
    /** @var \Closure(int): void */
    private \Closure $sleep;

    private bool $low_memory = false;

    private ?Timings $timings = null;

    public function __construct(
        private Environment $env,
        private Database $db,
        private DbBackup $dumps,
        private CoreBackup $core_backup,
        private Backups $backups,
        private HealthCheck $health,
        private ErrorLog $log,
        private Settings $settings,
        ?\Closure $sleep = null
    ) {
        $this->heartbeat = static function (): void {};
        $this->progress  = static function ( int $i, array $r ): void {};
        $this->sleep     = $sleep ?? static function ( int $s ): void {
            sleep( $s );
        };
    }

    public function set_heartbeat( \Closure $h ): void {
        $this->heartbeat = $h;
    }

    public function set_progress( \Closure $p ): void {
        $this->progress = $p;
    }

    public function set_low_memory( bool $low ): void {
        $this->low_memory = $low;
    }

    public function set_timings( Timings $t ): void {
        $this->timings = $t;
    }

    /** Time one step, if timings are on. */
    private function tm( string $step, \Closure $fn ): mixed {
        return null === $this->timings ? $fn() : $this->timings->measure( $step, $fn );
    }

    /**
     * @param string[] $key_paths
     * @return array{results:array<int,array<string,mixed>>, order_applied:string[], changed:bool}
     */
    public function update( string $requested, array $key_paths, bool $auto_rollback ): array {
        $disk   = $this->env->core_version_on_disk();
        $from   = $disk['wp_version'];
        $result = $this->result( $from, null );
        $wrap   = static fn ( array $r, bool $changed ): array => [ 'results' => [ $r ], 'order_applied' => [ 'core' ], 'changed' => $changed ];
        $refuse = function ( string $reason, array $extra = [] ) use ( &$result, $wrap ): array {
            $result = array_merge( $result, [ 'outcome' => UpdateRunner::OUTCOME_REFUSED, 'reason' => $reason ], $extra );
            return $wrap( $this->step( $result, 'done' ), false );
        };

        if ( $this->env->is_multisite() ) {
            return $refuse( 'multisite' );
        }
        if ( null === $from ) {
            return $refuse( 'version_mismatch' );
        }

        // 1. What is on offer, freshly.
        $offer = self::pick( $this->tm( 'core_offers', fn () => $this->env->core_offers() ), $requested, $from );
        if ( isset( $offer['reason'] ) ) {
            return $refuse( $offer['reason'], [ 'to' => $offer['to'] ?? null ] );
        }
        $to            = $offer['version'];
        $result['to']  = $to;
        $major         = self::branch( $to ) !== self::branch( $from );
        $result['major'] = $major;

        // 2. Policy.
        $refusal = $this->tm( 'preflight', fn () => $this->preflight( $offer['offer'], $to, $from, $major ) );
        if ( null !== $refusal ) {
            return $refuse( $refusal );
        }

        $prefix = $this->db->prefix();
        $need   = $this->tm( 'disk_estimate', fn () => 2 * ( $this->files_size() + $this->dumps->size( $prefix ) ) );
        $dir    = $this->backups->dir();
        if ( null === $dir ) {
            return $refuse( 'no_safe_backup_dir' );
        }
        $free = function_exists( 'disk_free_space' ) ? @disk_free_space( $dir ) : false;
        if ( is_float( $free ) && $free < $need ) {
            return $refuse( 'insufficient_disk' );
        }
        $this->step( $result, 'started' );

        // 3. Baseline.
        [ $before, $probe0 ] = $this->tm( 'baseline', fn () => [ $this->health->snapshot( $key_paths ), $this->health->rest_probe() ] );
        if ( ! HealthCheck::measurable( $before, $probe0 ) ) {
            return $refuse( 'site_unhealthy' );
        }
        $log_base = $this->log->baseline();

        // 4. Backup: files and database, the dump verified. Only the files this
        // release will touch, judged by its own checksums (see CoreBackup).
        $db_before = $this->db_version();
        $target    = $this->tm( 'target_checksums', fn () => $this->env->core_checksums( $to ) );
        ( $this->heartbeat )();
        $backup = $this->core_backup->create(
            $from,
            $db_before,
            $prefix,
            function ( string $table, int $rows ) use ( &$result ): void {
                ( $this->heartbeat )();
                $result['db_backup_progress'] = [ 'table' => $table, 'rows' => $rows ];
                $this->step( $result, 'backing_up' );
            },
            $this->timings,
            $target
        );
        unset( $result['db_backup_progress'] );
        if ( true !== $backup['ok'] ) {
            return $refuse( $backup['reason'], [ 'detail' => $backup['detail'] ] );
        }
        $result['backup']    = $backup['backup'];
        $result['db_backup'] = array_intersect_key( $backup['db'], array_flip( [ 'tables', 'rows', 'bytes', 'duration_ms', 'verified', 'engines' ] ) );
        $result['files_backup'] = $backup['files'] ?? null;
        $result['db_version'] = [ 'before' => $db_before, 'after' => null ];
        $this->step( $result, 'backed_up' );

        // 5. Upgrade, then the database in a fresh request.
        $upgraded = 'upgrade_failed';
        try {
            ( $this->heartbeat )();
            $upgraded = $this->tm( 'core_upgrade', fn () => $this->env->core_upgrade( $offer['offer'], $this->timings ) );
            $this->step( $result + [ 'files_changed' => true ], 'upgraded' );
            $want = $this->env->core_version_on_disk()['wp_db_version'];
            if ( null !== $want && $this->db_version() !== $want ) {
                $this->tm( 'upgrade_db_loopback_1', fn () => $this->env->core_db_upgrade() );
                if ( $this->db_version() !== $want ) {
                    $this->tm( 'upgrade_db_loopback_2', fn () => $this->env->core_db_upgrade() );
                }
            }
        } catch ( \Throwable $e ) {
            // A throw from inside the upgrader can leave core half-copied. Carry on
            // to the health check, so the rollback below still runs, rather than
            // letting the request die with the files in an unknown state.
            OutputSanitiser::log( 'core upgrade threw (' . get_class( $e ) . ')' );
            $upgraded = 'upgrade_failed';
        } finally {
            $result['maintenance_cleared'] = $this->env->clear_maintenance();
        }

        // 6. Read back, from disk and from the database.
        $result['read_back']           = $this->env->core_version_on_disk()['wp_version'];
        $result['db_version']['after'] = $this->db_version();
        $want                          = $this->env->core_version_on_disk()['wp_db_version'];
        $db_pending                    = null !== $want && $result['db_version']['after'] !== $want;
        $this->step( $result, 'read_back' );

        // 7. Health, retried before it is believed.
        [ $after, $probe, $verdict, $attempts ] = $this->health->settle( $before, $key_paths, $this->sleep, $this->heartbeat, $this->timings );
        $result['health']             = HealthCheck::report( $before, $after, $probe, $this->log->since( $log_base ) );
        $result['health']['attempts'] = $attempts;
        $this->step( $result, 'health_checked' );

        // A failed upgrade that nonetheless moved the files is treated as broken: a
        // half-copied core passing a health check is luck, not a state to leave.
        $half   = true !== $upgraded && $result['read_back'] !== $from;
        $broken = HealthCheck::BROKEN === $verdict || $db_pending || $half;
        if ( $broken ) {
            $result['reason'] = HealthCheck::BROKEN === $verdict ? 'health_failed' : ( $db_pending ? 'core_db_upgrade_pending' : 'upgrade_failed' );
            if ( $auto_rollback ) {
                $entry = $this->backups->find( $backup['backup']['id'] );
                $back  = null !== $entry ? $this->restore( $entry, $result ) : [ 'ok' => false ];
                $result['outcome']  = $back['ok'] ? UpdateRunner::OUTCOME_ROLLED_BACK : UpdateRunner::OUTCOME_FAILED;
                if ( ! $back['ok'] ) {
                    $result['reason'] = $back['reason'] ?? 'rollback_failed';
                }
                $result['read_back'] = $this->env->core_version_on_disk()['wp_version'];
                $this->step( $result, 'rolled_back' );
                $this->timings?->mark( 'rollback_health' );
                [ $a2, $p2, $v2, $att2 ] = $this->health->settle( $before, $key_paths, $this->sleep, $this->heartbeat, $this->timings );
                $result['rollback_health'] = [ 'home' => [ 'before' => $before['home'], 'after' => $a2['home'] ], 'rest_probe' => 'ok' === $p2 ? 'ok' : 'failed', 'verdict' => $v2, 'attempts' => $att2 ];
            } else {
                $result['outcome'] = UpdateRunner::OUTCOME_FAILED;
            }
            return $wrap( $this->step( $result, 'done' ), true );
        }

        if ( true !== $upgraded ) {
            $result['outcome'] = UpdateRunner::OUTCOME_FAILED;
            $result['reason']  = 'upgrade_failed';
            return $wrap( $this->step( $result, 'done' ), true );
        }
        if ( $result['read_back'] !== $to ) {
            $result['outcome'] = UpdateRunner::OUTCOME_FAILED;
            $result['reason']  = 'read_back_mismatch';
            return $wrap( $this->step( $result, 'done' ), true );
        }
        if ( HealthCheck::DEGRADED === $verdict ) {
            $result['outcome'] = UpdateRunner::OUTCOME_DEGRADED;
            $result['reason']  = 'page_smaller';
            return $wrap( $this->step( $result, 'done' ), true );
        }
        $result['outcome'] = UpdateRunner::OUTCOME_UPDATED;
        return $wrap( $this->step( $result, 'done' ), true );
    }

    /**
     * Roll core back to a backup this plugin made (by id, within 14 days): files,
     * and the database when its version differs from the backup's.
     *
     * @param string[] $key_paths
     * @return array{results:array<int,array<string,mixed>>, order_applied:string[], changed:bool}
     */
    public function rollback( array $entry, array $key_paths, bool $auto_rollback ): array {
        $from   = $this->env->core_version_on_disk()['wp_version'];
        $result = $this->result( $from, $entry['version'] );
        $wrap   = static fn ( array $r, bool $changed ): array => [ 'results' => [ $r ], 'order_applied' => [ 'core' ], 'changed' => $changed ];

        if ( $this->env->is_multisite() ) {
            $result['outcome'] = UpdateRunner::OUTCOME_REFUSED;
            $result['reason']  = 'multisite';
            return $wrap( $this->step( $result, 'done' ), false );
        }
        if ( ! $this->backups->within_window( $entry ) || ! is_file( $entry['path'] ) ) {
            $result['outcome'] = UpdateRunner::OUTCOME_REFUSED;
            $result['reason']  = 'backup_expired';
            return $wrap( $this->step( $result, 'done' ), false );
        }
        $this->step( $result, 'started' );

        $before = $this->health->snapshot( $key_paths );
        if ( ! HealthCheck::measurable( $before, $this->health->rest_probe() ) ) {
            // A site broken by a core update is exactly when a rollback is asked
            // for, so an unmeasurable baseline does not refuse it: health is read
            // afterwards and reported, nothing is auto-reverted.
            $before = null;
        }

        $back                = $this->restore( $entry, $result );
        $result['read_back'] = $this->env->core_version_on_disk()['wp_version'];
        $result['backup']    = Backups::present( $entry );
        $this->step( $result, 'rolled_back' );
        if ( ! $back['ok'] ) {
            $result['outcome'] = UpdateRunner::OUTCOME_FAILED;
            $result['reason']  = $back['reason'] ?? 'restore_failed';
            return $wrap( $this->step( $result, 'done' ), true );
        }

        $base = $before ?? [ 'home' => [ 200, 0 ], 'key_paths' => [] ];
        [ $after, $probe, $verdict, $attempts ] = $this->health->settle( $base, $key_paths, $this->sleep, $this->heartbeat );
        $result['health']             = HealthCheck::report( $base, $after, $probe, [ 'new_fatals' => 'unknown', 'log_rotated' => false ] );
        $result['health']['attempts'] = $attempts;

        if ( HealthCheck::BROKEN === $verdict ) {
            $result['outcome'] = UpdateRunner::OUTCOME_FAILED;
            $result['reason']  = 'health_failed';
        } elseif ( $result['read_back'] !== $entry['version'] ) {
            $result['outcome'] = UpdateRunner::OUTCOME_FAILED;
            $result['reason']  = 'read_back_mismatch';
        } else {
            $result['outcome'] = UpdateRunner::OUTCOME_UPDATED;
        }
        return $wrap( $this->step( $result, 'done' ), true );
    }

    /**
     * Files, then the database if its version moved, under `.maintenance`, which is
     * removed whatever happens.
     *
     * @return array{ok:bool, reason?:string}
     */
    private function restore( array $entry, array &$result ): array {
        // Phase 1 OUTSIDE maintenance: stage only the files that differ. The site is
        // already broken (that is why this runs), but a 503 for the length of an
        // unzip is a cost the staging moves out of the window.
        ( $this->heartbeat )();
        $plan = $this->tm( 'restore_stage', fn () => $this->core_backup->prepare_restore( $entry ) );
        if ( null === $plan ) {
            return [ 'ok' => false, 'reason' => 'restore_failed' ];
        }
        $result['files_restore'] = [ 'files' => count( $plan['moves'] ), 'removed' => count( $plan['deletes'] ), 'mode' => $plan['mode'] ];

        $this->env->set_maintenance();
        $this->timings?->start( 'maintenance_on' );
        try {
            if ( ! $this->tm( 'restore_files', fn () => $this->core_backup->apply_restore( $plan ) ) ) {
                return [ 'ok' => false, 'reason' => 'restore_failed' ];
            }
            $result['files_restored'] = true;
            $this->step( $result, 'files_restored' );

            $now  = $this->db_version();
            $then = is_int( $entry['db_version'] ?? null ) ? $entry['db_version'] : null;
            if ( null === $then || $now !== $then ) {
                $result['db_restore'] = [ 'started' => true, 'table' => null ];
                $this->step( $result, 'db_restore_started' );
                $this->timings?->start( 'db_restore' );
                $db = $this->core_backup->restore_db(
                    $entry,
                    function ( string $table ) use ( &$result ): void {
                        ( $this->heartbeat )();
                        $result['db_restore']['table'] = $table;
                        $this->step( $result, 'db_restoring' );
                    }
                );
                $this->timings?->stop( 'db_restore' );
                $result['db_restore'] = [ 'ok' => $db['ok'], 'tables' => $db['tables'] ?? null, 'rows' => $db['rows'] ?? null ] + ( $db['ok'] ? [] : [ 'detail' => $db['detail'] ?? '' ] );
                $this->step( $result, 'db_restored' );
                if ( ! $db['ok'] ) {
                    return [ 'ok' => false, 'reason' => 'db_restore_failed' ];
                }
            }
            return [ 'ok' => true ];
        } finally {
            $result['maintenance_cleared'] = $this->env->clear_maintenance();
            $this->timings?->stop( 'maintenance_on' );
        }
    }

    /**
     * Why this core update may not run here, or null.
     */
    public function preflight( object $offer, string $to, string $from, bool $major ): ?string {
        if ( version_compare( $to, $from, '<' ) ) {
            return 'downgrade_refused';
        }
        if ( $major ) {
            $flag = $this->settings->get( self::KEY_ALLOW_MAJOR, null );
            $allowed = true === $flag ? true : ( false === $flag ? false : self::MAJOR_DEFAULT );
            if ( ! $allowed ) {
                return 'core_major_not_allowed';
            }
        }
        $php = is_string( $offer->php_version ?? null ) ? $offer->php_version : '';
        if ( '' !== $php && version_compare( $this->env->php_version(), $php, '<' ) ) {
            return 'php_too_old';
        }
        $mysql  = is_string( $offer->mysql_version ?? null ) ? $offer->mysql_version : '';
        $server = preg_replace( '/^(\d+(\.\d+)*).*$/', '$1', $this->db->server_version() ) ?? '';
        if ( '' !== $mysql && '' !== $server && version_compare( $server, $mysql, '<' ) ) {
            return 'db_too_old';
        }
        if ( version_compare( $to, '7.1', '>=' ) && version_compare( $from, '7.1', '<' ) && [] !== self::unpatched_rocket_copies( $this->env->plugins_dir() ) ) {
            return 'wp_rocket_wp71_fatal';
        }
        if ( ! self::package_ok( $offer ) ) {
            return 'package_unavailable';
        }
        return null;
    }

    /**
     * Every copy of WP Rocket's Cloudflare.php that would fatal on WordPress 7.1:
     * found by FILE across every plugin folder (wp-rocket, clsop, any white label),
     * patched only if it already casts the key: substr( (string) $key, ... ). The
     * vendor fix in 3.23.2.2 is character-for-character that cast.
     *
     * @return string[] Plugin directory names.
     */
    public static function unpatched_rocket_copies( string $plugins_dir ): array {
        $out = [];
        if ( '' === $plugins_dir ) {
            return $out;
        }
        foreach ( glob( rtrim( $plugins_dir, '/' ) . '/*/inc/ThirdParty/Plugins/CDN/Cloudflare.php' ) ?: [] as $file ) {
            $src = (string) @file_get_contents( $file );
            if ( 1 === preg_match( '/substr\(\s*\$key\s*,/', $src ) ) {
                $out[] = basename( dirname( $file, 5 ) );
            }
        }
        return $out;
    }

    /**
     * Pure: the offers, in; the one asked for, out.
     *
     * `latest-minor`: the newest offer on the installed major.minor branch.
     * `latest`: the newest offer. An exact version: that offer, or nothing.
     *
     * @param array<int, object> $offers
     * @return array{version:string, offer:object}|array{reason:string, to?:string}
     */
    public static function pick( array $offers, string $requested, string $from ): array {
        $best = null;
        foreach ( $offers as $o ) {
            $v = is_string( $o->current ?? null ) ? $o->current : ( is_string( $o->version ?? null ) ? $o->version : '' );
            if ( '' === $v || 1 !== preg_match( '/^\d+\.\d+(\.\d+)?$/', $v ) ) {
                continue;
            }
            if ( 'latest-minor' === $requested && self::branch( $v ) !== self::branch( $from ) ) {
                continue;
            }
            if ( ! in_array( $requested, [ 'latest', 'latest-minor' ], true ) && ! version_compare( $v, $requested, '==' ) ) {
                continue;
            }
            if ( null === $best || version_compare( $v, $best['version'], '>' ) ) {
                $best = [ 'version' => $v, 'offer' => $o ];
            }
        }
        if ( null === $best ) {
            return [ 'reason' => 'version_mismatch' ];
        }
        if ( version_compare( $best['version'], $from, '<' ) ) {
            return [ 'reason' => 'downgrade_refused', 'to' => $best['version'] ];
        }
        if ( version_compare( $best['version'], $from, '==' ) ) {
            return [ 'reason' => 'version_mismatch', 'to' => $best['version'] ];
        }
        return $best;
    }

    /** `7.0.7` -> `7.0`; `7.1` -> `7.1`. */
    public static function branch( string $v ): string {
        $parts = explode( '.', $v );
        return ( $parts[0] ?? '0' ) . '.' . ( $parts[1] ?? '0' );
    }

    /** Only an https package from downloads.wordpress.org (the rule lives in UpdateReport, which also reports it). */
    public static function package_ok( object $offer ): bool {
        return \Bulldogs\SiteWorker\Monitor\UpdateReport::core_package_ok( $offer );
    }

    private function db_version(): ?int {
        $v = $this->db->value( 'SELECT option_value FROM ' . Database::quote( $this->db->prefix() . 'options' ) . " WHERE option_name = 'db_version'" );
        return is_numeric( $v ) ? (int) $v : null;
    }

    private function files_size(): int {
        $n = 0;
        foreach ( $this->env->core_paths() as $p ) {
            $n += Backups::size_of( $p );
        }
        return $n;
    }

    /** @return array<string, mixed> */
    private function result( ?string $from, ?string $to ): array {
        $r = [
            'kind'      => 'core',
            'component' => 'core',
            'from'      => $from,
            'to'        => $to,
            'read_back' => null,
            'outcome'   => UpdateRunner::OUTCOME_FAILED,
            'reason'    => null,
            'health'    => null,
            'backup'    => null,
        ];
        if ( $this->low_memory ) {
            $r['low_memory'] = true;
        }
        return $r;
    }

    /** @return array<string, mixed> */
    private function step( array $result, string $step ): array {
        $row = [ 'step' => $step ] + $result;
        if ( null !== $this->timings ) {
            $row['timings'] = $this->timings->report();
        }
        ( $this->progress )( 0, $row );
        return $result;
    }
}
