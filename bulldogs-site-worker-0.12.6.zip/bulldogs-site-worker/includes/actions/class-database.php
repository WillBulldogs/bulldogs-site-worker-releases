<?php
namespace Bulldogs\SiteWorker\Actions;

/**
 * The few database calls DbBackup makes, on WordPress's own connection ($wpdb).
 *
 * Kept apart from DbBackup for the same reason Environment is kept apart from
 * UpdateRunner: the dump and restore logic is the part that must be tested hard,
 * and the suite runs it against a real MariaDB through a stand-in that speaks the
 * same small vocabulary (tests/php/support/mysqli-database.php). Nothing here
 * decides anything.
 *
 * Every identifier passed in comes from SHOW TABLES / SHOW COLUMNS on this same
 * connection, never from a request, and is still backtick-quoted with backticks
 * doubled (quote()).
 */
class Database {
    public function prefix(): string {
        global $wpdb;
        return is_object( $wpdb ) && isset( $wpdb->prefix ) && is_string( $wpdb->prefix ) ? $wpdb->prefix : '';
    }

    /** The connection charset WordPress set with SET NAMES (utf8mb4 on every current install). */
    public function charset(): string {
        global $wpdb;
        $c = is_object( $wpdb ) && isset( $wpdb->charset ) && is_string( $wpdb->charset ) && '' !== $wpdb->charset ? $wpdb->charset : 'utf8mb4';
        return 1 === preg_match( '/^[a-z0-9_]+$/', $c ) ? $c : 'utf8mb4';
    }

    public function server_version(): string {
        $v = $this->value( 'SELECT VERSION()' );
        return is_string( $v ) ? $v : '';
    }

    /**
     * @return array<int, array{0:mixed, 1:mixed}> Rows as numeric arrays, or [] on error.
     */
    public function rows( string $sql ): array {
        global $wpdb;
        if ( ! is_object( $wpdb ) ) {
            return [];
        }
        $r = $wpdb->get_results( $sql, 'ARRAY_N' );
        return is_array( $r ) ? $r : [];
    }

    public function value( string $sql ): mixed {
        global $wpdb;
        return is_object( $wpdb ) ? $wpdb->get_var( $sql ) : null;
    }

    /** Run one statement. False on error; the error is in last_error(). */
    public function exec( string $sql ): bool {
        global $wpdb;
        if ( ! is_object( $wpdb ) ) {
            return false;
        }
        // wpdb re-scans any non-ASCII query for "invalid text" against every column's
        // charset and refuses it if anything would change. Our INSERTs are pure ASCII
        // (hex literals), but a CREATE TABLE can carry a non-ASCII COMMENT or DEFAULT
        // that SHOW CREATE TABLE gave us verbatim, and refusing to recreate a table
        // in the middle of a restore is the worst moment for it. The flag is per
        // query; wpdb resets it.
        $wpdb->check_current_query = false;
        // query() returns false on error and an int / true otherwise.
        return false !== $wpdb->query( $sql );
    }

    public function last_error(): string {
        global $wpdb;
        return is_object( $wpdb ) && is_string( $wpdb->last_error ) ? $wpdb->last_error : '';
    }

    /** A LIKE pattern matching the literal prefix. */
    public function like_prefix( string $prefix ): string {
        return addcslashes( $prefix, '\\%_' ) . '%';
    }

    /** A string literal for this connection. Only ever used on our own identifiers. */
    public function literal( string $s ): string {
        return "'" . addcslashes( $s, "\\'\0\n\r\x1a" ) . "'";
    }

    public static function quote( string $identifier ): string {
        return '`' . str_replace( '`', '``', $identifier ) . '`';
    }
}
