<?php
namespace Bulldogs\SiteWorker\Actions;

/**
 * A dump of every table carrying this site's prefix, written in PHP, and putting
 * it back. For a core update, which can change the database (upgrade.php).
 *
 * ---------------------------------------------------------------------------
 * WHY PHP AND NOT mysqldump
 * ---------------------------------------------------------------------------
 * Brixly has no shell. So the dump is made through WordPress's own connection,
 * as SQL, in batches. Everything below exists because that is harder than it
 * looks, and every rule is one a naive dumper gets wrong:
 *
 *   - A CONSISTENT SNAPSHOT. The site is live while it is dumped. The whole dump,
 *     row counts included, runs inside one REPEATABLE READ transaction started WITH
 *     CONSISTENT SNAPSHOT (what `mysqldump --single-transaction` does), so the
 *     tables agree with each other and the counts in the header are exact. InnoDB
 *     only: a MyISAM table is read as it is at the time (reported, see `engines`).
 *   - VALUES ARE HEX, AND TYPED. A quoted string is one escaping bug away from a
 *     broken restore, so non-NULL values are hex literals. But a hex literal is a
 *     NUMBER in numeric context (INSERT INTO t (id) VALUES (0x3132) stores 12594,
 *     not 12), so numeric columns are written as their digits, text columns as
 *     CONVERT(0x... USING <connection charset>) - the bytes $wpdb hands us are in
 *     the CONNECTION charset, so a latin1 column would otherwise get UTF-8 bytes
 *     stored raw - JSON the same way (MySQL refuses a binary string for JSON), and
 *     binary/blob columns as plain 0x... BIT is numeric: mysqlnd (and so $wpdb)
 *     returns a BIT(8) 0xAA as the DIGITS "170" - measured against MariaDB, where
 *     hexing those digits stored 0xFF - so digits are written as digits, and only
 *     a driver that hands back raw bytes falls through to 0x... Generated columns
 *     are left out of the
 *     INSERT: the server computes them.
 *   - BATCHED BOTH WAYS. 1000 rows per SELECT (by primary key where there is a
 *     single numeric one, so a million-row postmeta is not an O(n^2) OFFSET scan),
 *     and an INSERT is cut at 1000 rows or 1 MB, well under max_allowed_packet.
 *   - A ROW TOO BIG TO RESTORE IS REFUSED AT DUMP TIME. If one row alone would make
 *     a statement larger than the server's max_allowed_packet, the restore could
 *     never run it. Better to refuse the update (`db_backup_unsupported`) than to
 *     hold a backup that cannot be restored.
 *   - SPATIAL COLUMNS ARE REFUSED (`db_backup_unsupported`). $wpdb returns them in
 *     MySQL's internal format; writing that back is server-version-dependent and
 *     nothing on the fleet is known to use them. Refusing is honest; guessing is not.
 *
 * ---------------------------------------------------------------------------
 * THE FILE, AND WHY IT IS NOT "SPLIT ON SEMICOLONS"
 * ---------------------------------------------------------------------------
 * gzip. First line `-- bsw-dump <json header>` (prefix, charset, server, and per
 * table its row count). Then every statement framed by its byte length:
 * `-- bsw-stmt <bytes> <table> <rows>\n<statement>\n`, and a last line
 * `-- bsw-end <statements>`. CREATE TABLE statements contain newlines and can
 * contain semicolons in COMMENTs; a length frame has nothing to mis-split, and a
 * truncated file is detected exactly (a short read, a missing end line).
 *
 * VERIFY re-reads the whole file: every frame, the end line, and for every table
 * in the header a CREATE statement and an exact row total. The restore runs the
 * same check BEFORE it drops anything.
 *
 * RESTORE drops only BASE TABLEs with this prefix - including ones the failed
 * upgrade created that the dump does not know - recreates each from the dump, and
 * finishes with a row count per table against the header.
 */
class DbBackup {
    public const FORMAT      = 1;
    public const BATCH_ROWS  = 1000;
    public const BATCH_BYTES = 1048576;

    private const SPATIAL = [ 'geometry', 'point', 'linestring', 'polygon', 'multipoint', 'multilinestring', 'multipolygon', 'geometrycollection', 'geomcollection' ];
    private const NUMERIC = [ 'tinyint', 'smallint', 'mediumint', 'int', 'integer', 'bigint', 'decimal', 'dec', 'numeric', 'fixed', 'float', 'double', 'real', 'year', 'bit' ];

    /** @var \Closure(): float */
    private \Closure $timer;

    /**
     * @param object $db Database, or the suite's stand-in with the same methods.
     */
    public function __construct( private object $db, ?\Closure $timer = null ) {
        $this->timer = $timer ?? static fn (): float => microtime( true );
    }

    /**
     * This prefix's base tables and views.
     *
     * @return array{tables:string[], views:string[]}
     */
    public function inventory( string $prefix ): array {
        $tables = [];
        $views  = [];
        if ( '' === $prefix ) {
            return [ 'tables' => [], 'views' => [] ];
        }
        foreach ( $this->db->rows( 'SHOW FULL TABLES LIKE ' . $this->db->literal( $this->db->like_prefix( $prefix ) ) ) as $row ) {
            $name = isset( $row[0] ) && is_string( $row[0] ) ? $row[0] : '';
            if ( '' === $name || ! str_starts_with( $name, $prefix ) ) {
                continue;
            }
            if ( 'VIEW' === strtoupper( (string) ( $row[1] ?? '' ) ) ) {
                $views[] = $name;
            } else {
                $tables[] = $name;
            }
        }
        sort( $tables );
        sort( $views );
        return [ 'tables' => $tables, 'views' => $views ];
    }

    /** Bytes the prefix's tables occupy, for the disk check. 0 when unknown. */
    public function size( string $prefix ): int {
        $v = $this->db->value(
            'SELECT COALESCE(SUM(data_length + index_length), 0) FROM information_schema.TABLES WHERE table_schema = DATABASE() AND table_name LIKE '
            . $this->db->literal( $this->db->like_prefix( $prefix ) )
        );
        return is_numeric( $v ) ? (int) $v : 0;
    }

    /**
     * Dump every prefixed table to $path (gzip), then verify it.
     *
     * @param \Closure(string, int): void|null $progress Called after each table with its rows written.
     * @return array<string, mixed> `ok` true with tables/rows/bytes/duration_ms/engines, or false with `reason` and `detail`.
     */
    public function dump( string $prefix, string $path, ?\Closure $progress = null ): array {
        $start = ( $this->timer )();
        $inv   = $this->inventory( $prefix );
        if ( [] === $inv['tables'] ) {
            return self::fail( 'db_backup_failed', 'no tables with this prefix' );
        }

        $meta = [];
        foreach ( $inv['tables'] as $table ) {
            if ( 1 === preg_match( '/\s/', $table ) ) {
                // The frame line carries the table name; whitespace would break it.
                return self::fail( 'db_backup_unsupported', 'a table name containing whitespace' );
            }
            $cols = $this->columns( $table );
            if ( [] === $cols ) {
                return self::fail( 'db_backup_failed', 'could not read the columns of ' . $table );
            }
            foreach ( $cols as $c ) {
                if ( in_array( $c['base'], self::SPATIAL, true ) ) {
                    return self::fail( 'db_backup_unsupported', 'spatial column ' . $table . '.' . $c['name'] );
                }
            }
            $meta[ $table ] = $cols;
        }

        $packet = $this->db->value( 'SELECT @@max_allowed_packet' );
        $packet = is_numeric( $packet ) ? (int) $packet : 4194304;

        if ( ! $this->db->exec( 'SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ' ) || ! $this->db->exec( 'START TRANSACTION WITH CONSISTENT SNAPSHOT' ) ) {
            return self::fail( 'db_backup_failed', 'could not open a consistent snapshot: ' . $this->db->last_error() );
        }

        $gz = @gzopen( $path, 'wb6' );
        if ( false === $gz ) {
            $this->db->exec( 'COMMIT' );
            return self::fail( 'db_backup_failed', 'could not write the dump file' );
        }

        $statements = 0;
        $total_rows = 0;
        $engines    = [];
        try {
            $header = [
                'format'  => self::FORMAT,
                'prefix'  => $prefix,
                'charset' => $this->db->charset(),
                'server'  => $this->db->server_version(),
                'tables'  => [],
                'views'   => $inv['views'],
            ];
            foreach ( $inv['tables'] as $table ) {
                $count = $this->db->value( 'SELECT COUNT(*) FROM ' . Database::quote( $table ) );
                if ( ! is_numeric( $count ) ) {
                    return $this->abort( $gz, $path, 'db_backup_failed', 'could not count ' . $table );
                }
                $header['tables'][ $table ] = [ 'rows' => (int) $count, 'columns' => array_column( $meta[ $table ], 'name' ) ];
            }
            gzwrite( $gz, '-- bsw-dump ' . json_encode( $header, JSON_UNESCAPED_SLASHES ) . "\n" );

            foreach ( $inv['tables'] as $table ) {
                $create = $this->db->rows( 'SHOW CREATE TABLE ' . Database::quote( $table ) );
                $sql    = isset( $create[0][1] ) && is_string( $create[0][1] ) ? $create[0][1] : '';
                if ( '' === $sql ) {
                    return $this->abort( $gz, $path, 'db_backup_failed', 'could not read the structure of ' . $table );
                }
                if ( 1 === preg_match( '/\bENGINE=(\w+)/i', $sql, $m ) ) {
                    $engines[ strtolower( $m[1] ) ] = true;
                }
                self::frame( $gz, 'DROP TABLE IF EXISTS ' . Database::quote( $table ), $table, 0 );
                self::frame( $gz, $sql, $table, 0 );
                $statements += 2;

                [ $written, $frames, $error ] = $this->dump_rows( $gz, $table, $meta[ $table ], $packet );
                if ( null !== $error ) {
                    return $this->abort( $gz, $path, $error[0], $error[1] );
                }
                if ( $written !== $header['tables'][ $table ]['rows'] ) {
                    return $this->abort( $gz, $path, 'db_backup_failed', sprintf( '%s: counted %d rows, wrote %d', $table, $header['tables'][ $table ]['rows'], $written ) );
                }
                $statements += $frames;
                $total_rows += $written;
                if ( null !== $progress ) {
                    $progress( $table, $written );
                }
            }
            gzwrite( $gz, '-- bsw-end ' . $statements . "\n" );
        } finally {
            if ( is_resource( $gz ) ) {
                gzclose( $gz );
            }
            $this->db->exec( 'COMMIT' );
        }

        $check = $this->verify( $path, $inv['tables'] );
        if ( true !== $check['ok'] ) {
            @unlink( $path );
            return self::fail( 'db_backup_failed', 'the dump did not verify: ' . $check['detail'] );
        }

        return [
            'ok'          => true,
            'tables'      => count( $inv['tables'] ),
            'rows'        => $total_rows,
            'bytes'       => (int) @filesize( $path ),
            'duration_ms' => (int) round( ( ( $this->timer )() - $start ) * 1000 ),
            'engines'     => array_keys( $engines ),
            'verified'    => true,
        ];
    }

    /**
     * Read the whole file back and check it against its own header (and, given the
     * live table list, that it holds exactly those tables).
     *
     * @param string[]|null $live_tables
     * @return array{ok:bool, detail:string, header?:array<string,mixed>, statements?:int}
     */
    public function verify( string $path, ?array $live_tables = null ): array {
        $gz = @gzopen( $path, 'rb' );
        if ( false === $gz ) {
            return [ 'ok' => false, 'detail' => 'cannot open the dump' ];
        }
        try {
            $header = self::read_header( $gz );
            if ( null === $header ) {
                return [ 'ok' => false, 'detail' => 'no header' ];
            }
            $rows    = [];
            $created = [];
            $count   = 0;
            $ended   = false;
            while ( true ) {
                $frame = self::next_frame( $gz );
                if ( 'end' === $frame['type'] ) {
                    $ended = $frame['count'] === $count;
                    break;
                }
                if ( 'stmt' !== $frame['type'] ) {
                    return [ 'ok' => false, 'detail' => 'damaged at statement ' . ( $count + 1 ) ];
                }
                ++$count;
                $rows[ $frame['table'] ] = ( $rows[ $frame['table'] ] ?? 0 ) + $frame['rows'];
                if ( 0 === $frame['rows'] && 1 === preg_match( '/^CREATE\s+TABLE\b/i', $frame['sql'] ) ) {
                    $created[ $frame['table'] ] = true;
                }
            }
            if ( ! $ended ) {
                return [ 'ok' => false, 'detail' => 'the end line is missing or wrong (truncated?)' ];
            }
            foreach ( $header['tables'] as $table => $t ) {
                if ( ! isset( $created[ $table ] ) ) {
                    return [ 'ok' => false, 'detail' => 'no CREATE for ' . $table ];
                }
                if ( ( $rows[ $table ] ?? 0 ) !== $t['rows'] ) {
                    return [ 'ok' => false, 'detail' => sprintf( '%s: header %d rows, file %d', $table, $t['rows'], $rows[ $table ] ?? 0 ) ];
                }
            }
            if ( null !== $live_tables ) {
                $in_file = array_keys( $header['tables'] );
                sort( $in_file );
                $live = $live_tables;
                sort( $live );
                if ( $in_file !== $live ) {
                    return [ 'ok' => false, 'detail' => 'the table list does not match the database' ];
                }
            }
            return [ 'ok' => true, 'detail' => '', 'header' => $header, 'statements' => $count ];
        } finally {
            gzclose( $gz );
        }
    }

    /**
     * Put the dump back: verify first, then drop this prefix's base tables and
     * recreate them, then count every table against the header.
     *
     * @param \Closure(string): void|null $progress Called as each table starts, so a killed restore says where it stopped.
     * @return array<string, mixed>
     */
    public function restore( string $path, string $prefix, ?\Closure $progress = null ): array {
        $check = $this->verify( $path );
        if ( true !== $check['ok'] ) {
            return self::fail( 'db_restore_failed', 'refused before touching the database: ' . $check['detail'] );
        }
        $header = $check['header'];
        if ( ( $header['prefix'] ?? null ) !== $prefix || '' === $prefix ) {
            return self::fail( 'db_restore_failed', 'the dump is for another table prefix' );
        }
        $charset = is_string( $header['charset'] ?? null ) && 1 === preg_match( '/^[a-z0-9_]+$/', $header['charset'] ) ? $header['charset'] : 'utf8mb4';

        foreach ( [ 'SET FOREIGN_KEY_CHECKS = 0', "SET SESSION sql_mode = 'NO_AUTO_VALUE_ON_ZERO'", 'SET NAMES ' . $charset ] as $sql ) {
            if ( ! $this->db->exec( $sql ) ) {
                return self::fail( 'db_restore_failed', 'could not prepare the session: ' . $this->db->last_error() );
            }
        }

        try {
            // Tables the failed upgrade created, which the dump does not know.
            foreach ( $this->inventory( $prefix )['tables'] as $table ) {
                if ( ! isset( $header['tables'][ $table ] ) && ! $this->db->exec( 'DROP TABLE IF EXISTS ' . Database::quote( $table ) ) ) {
                    return self::fail( 'db_restore_failed', 'could not drop ' . $table . ': ' . $this->db->last_error() );
                }
            }

            $gz = @gzopen( $path, 'rb' );
            if ( false === $gz ) {
                return self::fail( 'db_restore_failed', 'cannot open the dump' );
            }
            try {
                self::read_header( $gz );
                $current = '';
                while ( true ) {
                    $frame = self::next_frame( $gz );
                    if ( 'stmt' !== $frame['type'] ) {
                        break;
                    }
                    if ( $frame['table'] !== $current ) {
                        $current = $frame['table'];
                        if ( null !== $progress ) {
                            $progress( $current );
                        }
                    }
                    if ( ! $this->db->exec( $frame['sql'] ) ) {
                        return self::fail( 'db_restore_failed', $current . ': ' . $this->db->last_error() );
                    }
                }
            } finally {
                gzclose( $gz );
            }

            $rows = 0;
            foreach ( $header['tables'] as $table => $t ) {
                $n = $this->db->value( 'SELECT COUNT(*) FROM ' . Database::quote( $table ) );
                if ( ! is_numeric( $n ) || (int) $n !== $t['rows'] ) {
                    return self::fail( 'db_restore_failed', sprintf( '%s: expected %d rows after restore, found %s', $table, $t['rows'], is_numeric( $n ) ? (string) $n : 'none' ) );
                }
                $rows += $t['rows'];
            }
            return [ 'ok' => true, 'tables' => count( $header['tables'] ), 'rows' => $rows ];
        } finally {
            $this->db->exec( 'SET FOREIGN_KEY_CHECKS = 1' );
        }
    }

    // -----------------------------------------------------------------------

    /**
     * @param array<int, array<string, mixed>> $cols
     * @return array{0:int, 1:int, 2:?array{0:string,1:string}} Rows written, frames written, error.
     */
    private function dump_rows( $gz, string $table, array $cols, int $packet ): array {
        $insertable = array_values( array_filter( $cols, static fn ( array $c ): bool => ! $c['generated'] ) );
        $names      = array_map( static fn ( array $c ): string => Database::quote( $c['name'] ), $insertable );
        $prefix_sql = 'INSERT INTO ' . Database::quote( $table ) . ' (' . implode( ',', $names ) . ') VALUES ';
        $select     = 'SELECT ' . implode( ',', $names ) . ' FROM ' . Database::quote( $table );

        $pk      = $this->primary_key( $table );
        $keyset  = null;
        if ( 1 === count( $pk ) ) {
            foreach ( $insertable as $i => $c ) {
                if ( $c['name'] === $pk[0] && in_array( $c['base'], self::NUMERIC, true ) && 'year' !== $c['base'] ) {
                    $keyset = $i;
                }
            }
        }
        $order = [] !== $pk ? ' ORDER BY ' . implode( ',', array_map( [ Database::class, 'quote' ], $pk ) ) : '';

        $written = 0;
        $frames  = 0;
        $tuples  = [];
        $bytes   = 0;
        $offset  = 0;
        $last    = null;

        $flush = function () use ( $gz, $prefix_sql, &$tuples, &$bytes, &$frames, $table ): void {
            if ( [] === $tuples ) {
                return;
            }
            self::frame( $gz, $prefix_sql . implode( ',', $tuples ), $table, count( $tuples ) );
            ++$frames;
            $tuples = [];
            $bytes  = 0;
        };

        while ( true ) {
            if ( null !== $keyset ) {
                $where = null === $last ? '' : ' WHERE ' . Database::quote( $pk[0] ) . ' > ' . $last;
                $batch = $this->db->rows( $select . $where . ' ORDER BY ' . Database::quote( $pk[0] ) . ' LIMIT ' . self::BATCH_ROWS );
            } else {
                $batch = $this->db->rows( $select . $order . ' LIMIT ' . self::BATCH_ROWS . ' OFFSET ' . $offset );
            }

            foreach ( $batch as $row ) {
                $values = [];
                foreach ( $insertable as $i => $c ) {
                    $values[] = $this->encode( $row[ $i ] ?? null, $c );
                }
                $tuple = '(' . implode( ',', $values ) . ')';
                if ( strlen( $prefix_sql ) + strlen( $tuple ) + 1024 > $packet ) {
                    return [ $written, $frames, [ 'db_backup_unsupported', sprintf( '%s: a row of %d bytes is larger than max_allowed_packet (%d), so it could never be restored', $table, strlen( $tuple ), $packet ) ] ];
                }
                if ( [] !== $tuples && ( count( $tuples ) >= self::BATCH_ROWS || $bytes + strlen( $tuple ) > self::BATCH_BYTES ) ) {
                    $flush();
                }
                $tuples[] = $tuple;
                $bytes   += strlen( $tuple ) + 1;
                ++$written;
                if ( null !== $keyset ) {
                    $last = is_numeric( $row[ $keyset ] ?? null ) ? (string) $row[ $keyset ] : null;
                    if ( null === $last ) {
                        return [ $written, $frames, [ 'db_backup_failed', $table . ': a non-numeric primary key value' ] ];
                    }
                }
            }
            $flush();
            if ( count( $batch ) < self::BATCH_ROWS ) {
                break;
            }
            $offset += self::BATCH_ROWS;
        }
        return [ $written, $frames, null ];
    }

    /** One value, as SQL. See the class docblock for why each type is written as it is. */
    private function encode( mixed $value, array $col ): string {
        if ( null === $value ) {
            return 'NULL';
        }
        $s = is_scalar( $value ) ? (string) $value : '';
        if ( in_array( $col['base'], self::NUMERIC, true ) && 1 === preg_match( '/^-?(\d+(\.\d*)?|\.\d+)([eE][-+]?\d+)?$/', $s ) ) {
            return $s;
        }
        if ( '' === $s ) {
            return "''";
        }
        if ( $col['text'] || 'json' === $col['base'] ) {
            return 'CONVERT(0x' . bin2hex( $s ) . ' USING ' . $this->db->charset() . ')';
        }
        return '0x' . bin2hex( $s );
    }

    /**
     * @return array<int, array{name:string, base:string, text:bool, generated:bool}>
     */
    private function columns( string $table ): array {
        $out = [];
        foreach ( $this->db->rows( 'SHOW FULL COLUMNS FROM ' . Database::quote( $table ) ) as $row ) {
            // Field, Type, Collation, Null, Key, Default, Extra, Privileges, Comment
            $name = is_string( $row[0] ?? null ) ? $row[0] : '';
            $type = strtolower( is_string( $row[1] ?? null ) ? $row[1] : '' );
            if ( '' === $name || '' === $type ) {
                return [];
            }
            $base  = preg_match( '/^[a-z]+/', $type, $m ) ? $m[0] : $type;
            $extra = strtolower( is_string( $row[6] ?? null ) ? $row[6] : '' );
            $out[] = [
                'name'      => $name,
                'base'      => $base,
                // A collation means a character column: text, char, enum, set.
                'text'      => is_string( $row[2] ?? null ) && '' !== $row[2],
                // MySQL: "VIRTUAL GENERATED" / "STORED GENERATED"; MariaDB: "VIRTUAL GENERATED" / "STORED GENERATED" or "PERSISTENT GENERATED".
                'generated' => str_contains( $extra, 'generated' ),
            ];
        }
        return $out;
    }

    /** @return string[] Primary key columns in order. */
    private function primary_key( string $table ): array {
        $keys = [];
        foreach ( $this->db->rows( 'SHOW KEYS FROM ' . Database::quote( $table ) . " WHERE Key_name = 'PRIMARY'" ) as $row ) {
            // Table, Non_unique, Key_name, Seq_in_index, Column_name
            if ( is_string( $row[4] ?? null ) && is_numeric( $row[3] ?? null ) ) {
                $keys[ (int) $row[3] ] = $row[4];
            }
        }
        ksort( $keys );
        return array_values( $keys );
    }

    /** @param resource $gz */
    private static function frame( $gz, string $sql, string $table, int $rows ): void {
        gzwrite( $gz, '-- bsw-stmt ' . strlen( $sql ) . ' ' . $table . ' ' . $rows . "\n" . $sql . "\n" );
    }

    /** @param resource $gz */
    private static function read_header( $gz ): ?array {
        $line = gzgets( $gz );
        if ( ! is_string( $line ) || ! str_starts_with( $line, '-- bsw-dump ' ) ) {
            return null;
        }
        $h = json_decode( substr( rtrim( $line, "\n" ), 12 ), true );
        if ( ! is_array( $h ) || self::FORMAT !== ( $h['format'] ?? null ) || ! is_array( $h['tables'] ?? null ) ) {
            return null;
        }
        foreach ( $h['tables'] as $table => $t ) {
            if ( ! is_string( $table ) || ! is_array( $t ) || ! is_int( $t['rows'] ?? null ) ) {
                return null;
            }
        }
        return $h;
    }

    /**
     * @param resource $gz
     * @return array{type:string, sql?:string, table?:string, rows?:int, count?:int}
     */
    private static function next_frame( $gz ): array {
        $line = gzgets( $gz );
        if ( ! is_string( $line ) ) {
            return [ 'type' => 'eof' ];
        }
        if ( 1 === preg_match( '/^-- bsw-end (\d+)\n?$/', $line, $m ) ) {
            return [ 'type' => 'end', 'count' => (int) $m[1] ];
        }
        if ( 1 !== preg_match( '/^-- bsw-stmt (\d+) (\S+) (\d+)\n$/', $line, $m ) ) {
            return [ 'type' => 'bad' ];
        }
        $want = (int) $m[1];
        $sql  = '';
        while ( strlen( $sql ) < $want ) {
            $chunk = gzread( $gz, min( 1048576, $want - strlen( $sql ) ) );
            if ( ! is_string( $chunk ) || '' === $chunk ) {
                return [ 'type' => 'bad' ];
            }
            $sql .= $chunk;
        }
        if ( "\n" !== gzread( $gz, 1 ) ) {
            return [ 'type' => 'bad' ];
        }
        return [ 'type' => 'stmt', 'sql' => $sql, 'table' => $m[2], 'rows' => (int) $m[3] ];
    }

    /** @param resource $gz */
    private function abort( $gz, string $path, string $reason, string $detail ): array {
        if ( is_resource( $gz ) ) {
            gzclose( $gz );
        }
        @unlink( $path );
        return self::fail( $reason, $detail );
    }

    /** @return array{ok:false, reason:string, detail:string} */
    private static function fail( string $reason, string $detail ): array {
        return [ 'ok' => false, 'reason' => $reason, 'detail' => OutputSanitiser::string( substr( $detail, 0, 300 ) ) ];
    }
}
