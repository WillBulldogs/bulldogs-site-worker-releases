<?php
namespace Bulldogs\SiteWorker\Actions;

use Bulldogs\SiteWorker\Monitor\SecurityReport;
use Bulldogs\SiteWorker\Monitor\UpdateReport;
use Bulldogs\SiteWorker\Monitor\UpdaterWitness;

/**
 * `sync`: a fresh update check with the vendor adapters forced in, then the same
 * `updates` and `security` sections the findings route sends.
 *
 * ---------------------------------------------------------------------------
 * THE SAME CLASSES, NOT A SECOND IMPLEMENTATION
 * ---------------------------------------------------------------------------
 * The sections come from UpdateReport::gather() and SecurityReport::gather(), for
 * the reason RestController::force_scan()'s docblock gives: two implementations of
 * one report drift, and then the CC and the fleet view disagree about the same
 * site. What sync adds is only what happens BEFORE those classes read state: the
 * transient is thrown away and rebuilt, with the Crocoblock adapter attached and an
 * UpdaterWitness watching, so an up-to-date Jet plugin can read `current` for the
 * first time.
 *
 * It changes nothing on the site except WordPress's own update cache, which is why
 * it has its own module and can be switched on fleet-wide (decision D7).
 *
 * ---------------------------------------------------------------------------
 * RATE: A FLOOR IN CODE
 * ---------------------------------------------------------------------------
 * One sync per site per 600 seconds, enforced by the controller from MIN_INTERVAL.
 * A constant, not an option, the way RestController::MIN_INTERVAL is a floor: a
 * hand-edited option must not be able to remove it. A sync costs vendor API calls,
 * and on Brixly it is a request against the pacing budget.
 */
class SyncRunner {
    public const MIN_INTERVAL = 600;

    /** Bound on the package checks in one sync: count, and total seconds. */
    public const MAX_PACKAGE_CHECKS = 40;
    public const PACKAGE_BUDGET     = 120;

    /** @var \Closure(): float */
    private \Closure $timer;

    public function __construct(
        private Environment $env,
        private CrocoblockAdapter $crocoblock,
        private PackageCheck $packages,
        private UpdateReport $updates,
        private SecurityReport $security,
        ?\Closure $timer = null,
        private ?\Bulldogs\SiteWorker\Vendors\VendorVersions $vendors = null
    ) {
        $this->timer = $timer ?? static fn (): float => microtime( true );
    }

    /**
     * Throw the update cache away and rebuild it with the adapters attached.
     *
     * Public because `update` runs exactly this before each plugin (spec §6.3).
     *
     * $vendors: also ask every vendor adapter, forced past its 12 h floor. Only
     * `sync` does (0.12.0): the vendor answers are report-only, they decide nothing
     * an update does, and asking seven vendors with 15 s timeouts before and after
     * every component was time the maintenance run spent on reporting.
     *
     * @return array{crocoblock:string} Each adapter's status.
     */
    public function refresh( bool $vendors = true ): array {
        $this->crocoblock->reset();
        $croc = $this->crocoblock->available();

        $witness = class_exists( UpdaterWitness::class ) ? new UpdaterWitness() : null;

        if ( $croc ) {
            $this->crocoblock->attach();
        }
        if ( null !== $witness && function_exists( 'add_filter' ) ) {
            // A witness of our own for this check, whether or not the versions module
            // registered one: a second witness records the same thing, harmlessly,
            // and without one an up-to-date Jet plugin could never read current.
            add_filter( 'pre_set_site_transient_update_plugins', [ $witness, 'witness_plugins' ], PHP_INT_MAX );
            add_filter( 'pre_set_site_transient_update_themes', [ $witness, 'witness_themes' ], PHP_INT_MAX );
        }

        try {
            // The scheduled vendor hook is held while the transient is rebuilt, and
            // the vendors are then asked once, forced, below.
            class_exists( \Bulldogs\SiteWorker\Vendors\VendorVersions::class )
                ? \Bulldogs\SiteWorker\Vendors\VendorVersions::hold( fn () => $this->env->refresh_update_check() )
                : $this->env->refresh_update_check();
        } finally {
            if ( $croc ) {
                $this->crocoblock->detach();
            }
            if ( null !== $witness && function_exists( 'remove_filter' ) ) {
                remove_filter( 'pre_set_site_transient_update_plugins', [ $witness, 'witness_plugins' ], PHP_INT_MAX );
                remove_filter( 'pre_set_site_transient_update_themes', [ $witness, 'witness_themes' ], PHP_INT_MAX );
            }
        }

        // 0.11.1: every vendor adapter, past its 12 h floor (this path has its own
        // 10 minute one). Report-only: into VendorStore, never the transient. Run
        // between plugins too, which is what re-asks Elementor Pro after Elementor.
        if ( $vendors && null !== $this->vendors ) {
            try {
                $this->vendors->run( true );
            } catch ( \Throwable $e ) {
                OutputSanitiser::log( 'vendor adapters failed during sync (' . get_class( $e ) . ')' );
            }
        }

        if ( ! $croc ) {
            return [ 'crocoblock' => CrocoblockAdapter::STATUS_ABSENT ];
        }
        // If core never saved the transient, the filter never ran; ask directly so
        // the status says what the vendor said, not that nobody asked.
        $this->crocoblock->probe();
        return [ 'crocoblock' => $this->crocoblock->status() ];
    }

    /**
     * The whole sync, minus the envelope the controller adds.
     *
     * @return array<string, mixed>
     */
    public function run(): array {
        $start    = ( $this->timer )();
        $adapters = $this->refresh( true );

        return [
            'checked_at'     => time(),
            'duration_ms'    => (int) round( ( ( $this->timer )() - $start ) * 1000 ),
            'updates'        => self::section( $this->updates ),
            'security'       => self::section( $this->security ),
            'package_checks' => $this->package_checks(),
            'adapters'       => $adapters,
            'memory_limit'       => $this->env->memory_limit(),
            'memory_limit_admin' => $this->env->memory_limit_admin(),
        ];
    }

    /**
     * A package check for every plugin with an update on offer, keyed by plugin file.
     * Past the count or time budget, the rest are `unknown` - never `ok`.
     *
     * @return array<string, array<string, mixed>>
     */
    public function package_checks(): array {
        $transient = $this->env->plugins_transient();
        $response  = is_object( $transient ) && isset( $transient->response ) && is_array( $transient->response ) ? $transient->response : [];

        $out   = [];
        $start = ( $this->timer )();
        $done  = 0;
        foreach ( $response as $file => $entry ) {
            if ( ! is_string( $file ) ) {
                continue;
            }
            $package = self::package_of( $entry );
            if ( $done >= self::MAX_PACKAGE_CHECKS || ( $this->timer )() - $start > self::PACKAGE_BUDGET ) {
                $host         = null !== $package ? parse_url( $package, PHP_URL_HOST ) : null;
                $out[ $file ] = [ 'state' => PackageCheck::UNKNOWN, 'host' => is_string( $host ) ? strtolower( $host ) : null ];
                continue;
            }
            $out[ $file ] = $this->packages->check( $package );
            ++$done;
        }
        return $out;
    }

    /** The package URL from one transient entry, or null. Stays on the site. */
    public static function package_of( mixed $entry ): ?string {
        $value = is_object( $entry ) ? ( $entry->package ?? null ) : ( is_array( $entry ) ? ( $entry['package'] ?? null ) : null );
        return is_string( $value ) && '' !== trim( $value ) ? trim( $value ) : null;
    }

    /** One report section, or `{"error": ...}` exactly as the findings route sends it. */
    public static function section( object $reporter ): array {
        try {
            $out = $reporter->gather();
            return is_array( $out ) ? $out : [ 'error' => 'unexpected report shape' ];
        } catch ( \Throwable $e ) {
            return [ 'error' => substr( $e->getMessage(), 0, 200 ) ];
        }
    }
}
