<?php
namespace Bulldogs\SiteWorker\Actions;

/**
 * Where stage 1's time went, step by step.
 *
 * Will, after the 0.12.0 pilot (24 Oct 2026): "the system must be robust and
 * snappy, we're designing this for routine wp maintenance". A core update's stage
 * 1 took ~295 s on template while its database dump took 5.7 s, and nothing in
 * the record said where the rest went. Every step is now timed (start, finish,
 * milliseconds), the list is written into `progress[]` as it grows, and the final
 * result carries it as `timings`. WordPress's own upgrader is timed from the
 * inside through its feedback marks (see Environment::core_upgrade()).
 *
 * Times are milliseconds from the start of this action, plus the unix second the
 * action started, so a row reads without a calculator and still lines up with
 * the server's logs.
 */
class Timings {
    private float $t0;

    /** @var array<int, array{step:string, start_ms:int, end_ms:?int, ms:?int}> */
    private array $rows = [];

    /** @var array<string, int> Open step => row index. */
    private array $open = [];

    /** @var \Closure(): float */
    private \Closure $clock;

    public function __construct( ?\Closure $clock = null ) {
        $this->clock = $clock ?? static fn (): float => microtime( true );
        $this->t0    = ( $this->clock )();
    }

    public function start( string $step ): void {
        $this->open[ $step ] = count( $this->rows );
        $this->rows[]        = [ 'step' => $step, 'start_ms' => $this->now_ms(), 'end_ms' => null, 'ms' => null ];
    }

    public function stop( string $step ): void {
        if ( ! isset( $this->open[ $step ] ) ) {
            return;
        }
        $i                        = $this->open[ $step ];
        $end                      = $this->now_ms();
        $this->rows[ $i ]['end_ms'] = $end;
        $this->rows[ $i ]['ms']     = $end - $this->rows[ $i ]['start_ms'];
        unset( $this->open[ $step ] );
    }

    /**
     * Time a closure as one step. The step is stopped even if the closure throws,
     * so a killed step reads as started-and-unfinished only when PHP itself died.
     *
     * @template T
     * @param \Closure(): T $fn
     * @return T
     */
    public function measure( string $step, \Closure $fn ): mixed {
        $this->start( $step );
        try {
            return $fn();
        } finally {
            $this->stop( $step );
        }
    }

    /** A zero-length mark (e.g. one of WordPress's own upgrader feedback lines). */
    public function mark( string $step ): void {
        $at           = $this->now_ms();
        $this->rows[] = [ 'step' => $step, 'start_ms' => $at, 'end_ms' => $at, 'ms' => 0 ];
    }

    /** @return array{started:int, total_ms:int, steps:array<int,array<string,mixed>>} */
    public function report(): array {
        return [
            'started'  => (int) floor( $this->t0 ),
            'total_ms' => $this->now_ms(),
            'steps'    => $this->rows,
        ];
    }

    private function now_ms(): int {
        return (int) round( ( ( $this->clock )() - $this->t0 ) * 1000 );
    }
}
