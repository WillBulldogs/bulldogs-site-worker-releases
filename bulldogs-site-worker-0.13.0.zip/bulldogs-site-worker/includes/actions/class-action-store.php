<?php
namespace Bulldogs\SiteWorker\Actions;

/**
 * Everything the actions layer remembers between requests: seen nonces, the site
 * lock, the last `sync`, the last 20 action records and the backup index.
 *
 * ---------------------------------------------------------------------------
 * ITS OWN OPTION ROW, NOT A KEY IN Settings::OPTION
 * ---------------------------------------------------------------------------
 * Settings::OPTION is the row Modules::migrate() reads to decide whether a site
 * was running a pre-registry build, and the row every module's configuration
 * lives in. This store is written on every action and by stage 2 after the
 * response has gone, so churn here must never be able to race or corrupt the row
 * that decides whether consent is on. A separate row, not autoloaded, so a site
 * that never runs an action pays nothing on a page load either.
 *
 * ---------------------------------------------------------------------------
 * FAIL-CLOSED READING
 * ---------------------------------------------------------------------------
 * The row is restored from backups and can be hand-edited, so every section is
 * validated on the way in and anything malformed is dropped rather than cast.
 * The direction matters per section: a corrupt nonce list is read as EMPTY (a
 * replay inside the 300 s window is still stopped by the timestamp check, and the
 * site secret plus the signature still have to be valid), a corrupt lock is read
 * as FREE only once its expiry cannot be read (so a junk lock cannot wedge a site
 * forever), and a corrupt backup entry is dropped, which can only ever REFUSE a
 * rollback, never allow one.
 *
 * ---------------------------------------------------------------------------
 * ⚠️ THE LOCK IS NOT A MUTEX, AND DOES NOT NEED TO BE
 * ---------------------------------------------------------------------------
 * It is a read-modify-write of an option. WordPress has no atomic option insert
 * (add_option() is INSERT ... ON DUPLICATE KEY UPDATE), so two requests landing in
 * the same millisecond could both see it free. The only caller is the CC
 * executor, which is strictly serial across the whole fleet (spec §7.2), so the
 * lock exists to refuse a SECOND, MISTAKEN request while the first is running -
 * a double-clicked button, a retry after a timeout - not to arbitrate a race the
 * caller never creates. The nonce check has the same shape and the same caller.
 */
class ActionStore {
    public const OPTION = 'bulldogs_sw_actions';

    /**
     * Seen nonces, in a row of their own (0.11.1, before the tag).
     *
     * ⚠️ Since stage 2 runs in its own WP-Cron request, it writes records WHILE the
     * CC polls `status`, and each of those requests claims a nonce. Both rows are
     * written whole, and each PHP process keeps its own cached copy of the option,
     * so with nonces and records in one row a status poll could put back a stale
     * record (stage 2 "done" read as running, then `died`), and stage 2's next write
     * could drop the poll's nonce (a replay window). Apart, a poll only ever writes
     * this row and stage 2 only ever writes the other, and the site lock keeps any
     * other writer of the records row out until stage 2 has released it.
     */
    public const NONCE_OPTION = 'bulldogs_sw_action_nonces';

    /**
     * WP Rocket / AccelerateWP preload paused while an update, rollback or cache cycle
     * holds the lock (0.12.4). The value is the lock's expiry as a unix time, so a run
     * that dies cannot leave preload off: the pause simply runs out with the lock.
     * Autoloaded, so the filter that reads it on every request costs no query.
     */
    public const PRELOAD_PAUSE_OPTION = 'bulldogs_sw_preload_pause';

    /** Seconds the pause runs on after a release (0.12.7, see pause_preload()). */
    public const PRELOAD_GRACE = 120;

    /** Kept records. The spec's number; enough for the CC to read stage 2 of the last run. */
    public const MAX_RECORDS = 20;

    /** Bound on stored nonces, so a flood of valid-but-refused requests cannot grow the row without limit. */
    private const MAX_NONCES = 500;

    /** @var \Closure(): int */
    private \Closure $clock;

    public function __construct( ?\Closure $clock = null ) {
        $this->clock = $clock ?? static fn (): int => time();
    }

    public function now(): int {
        return ( $this->clock )();
    }

    // -----------------------------------------------------------------------
    // Nonces
    // -----------------------------------------------------------------------

    /**
     * Record a nonce as used. False when it has been seen and has not expired.
     *
     * Kept until `issued_at + 600` (ActionAuth passes the expiry), not for the 300
     * second window alone: a nonce forgotten the moment its window closed could be
     * replayed with a request whose `issued_at` sits at the far edge of the window.
     */
    public function claim_nonce( string $nonce, int $expires ): bool {
        $now = $this->now();
        $raw = function_exists( 'get_option' ) ? get_option( self::NONCE_OPTION, [] ) : [];
        $raw = is_array( $raw ) ? $raw : [];

        // 🚨 FAIL CLOSED ACROSS THE UPGRADE. 0.11.0 kept seen nonces in the records
        // row. They are MERGED in until they age out, so a request captured in the
        // 600 s before the upgrade cannot be replayed straight after it. A missing
        // new row never means "nothing seen" while legacy entries exist.
        foreach ( $this->legacy_nonces() as $seen => $until ) {
            if ( ! isset( $raw[ $seen ] ) || ( is_int( $raw[ $seen ] ) && $raw[ $seen ] < $until ) ) {
                $raw[ $seen ] = $until;
            }
        }

        $nonces = [];
        foreach ( $raw as $seen => $until ) {
            if ( ! is_string( $seen ) || ! is_int( $until ) ) {
                continue;
            }
            if ( $until > $now ) {
                $nonces[ $seen ] = $until;
            }
        }

        $key = hash( 'sha256', $nonce );
        if ( isset( $nonces[ $key ] ) ) {
            return false;
        }

        $nonces[ $key ] = $expires;
        if ( count( $nonces ) > self::MAX_NONCES ) {
            asort( $nonces );
            $nonces = array_slice( $nonces, -self::MAX_NONCES, null, true );
        }

        if ( function_exists( 'update_option' ) ) {
            update_option( self::NONCE_OPTION, $nonces, false );
        }
        return true;
    }

    /**
     * Unexpired nonces a 0.11.0 build left in the records row. Read straight from
     * the option; state() carries them forward on every write of that row, so they
     * are only ever dropped by expiring, never by being rewritten away first.
     *
     * @return array<string, int>
     */
    private function legacy_nonces(): array {
        $raw = function_exists( 'get_option' ) ? get_option( self::OPTION, [] ) : [];
        return self::unexpired( is_array( $raw ) && is_array( $raw['nonces'] ?? null ) ? $raw['nonces'] : [], $this->now() );
    }

    /** @return array<string, int> */
    private static function unexpired( array $nonces, int $now ): array {
        $out = [];
        foreach ( $nonces as $seen => $until ) {
            if ( is_string( $seen ) && is_int( $until ) && $until > $now ) {
                $out[ $seen ] = $until;
            }
        }
        return $out;
    }

    // -----------------------------------------------------------------------
    // Lock
    // -----------------------------------------------------------------------

    /** Take the site lock for $ttl seconds. False when another action holds it. */
    public function acquire_lock( string $id, string $action, int $ttl ): bool {
        $now   = $this->now();
        $state = $this->state();
        $lock  = $state['lock'];

        if ( null !== $lock && $lock['expires'] > $now && $lock['id'] !== $id ) {
            return false;
        }

        $state['lock'] = [ 'id' => $id, 'action' => $action, 'expires' => $now + $ttl ];
        $this->save( $state );
        $this->pause_preload( $state['lock'] );
        return true;
    }

    /** Move the expiry of a lock this action holds. A lock someone else holds is left alone. */
    public function extend_lock( string $id, int $ttl ): void {
        $state = $this->state();
        if ( null === $state['lock'] || $state['lock']['id'] !== $id ) {
            return;
        }
        $state['lock']['expires'] = $this->now() + $ttl;
        $this->save( $state );
        $this->pause_preload( $state['lock'] );
    }

    public function release_lock( string $id ): void {
        $state = $this->state();
        if ( null !== $state['lock'] && $state['lock']['id'] === $id ) {
            $state['lock'] = null;
            $this->save( $state );
            $this->pause_preload( null );
        }
    }

    // -----------------------------------------------------------------------
    // WP Rocket preload pause (0.12.4)
    // -----------------------------------------------------------------------

    /**
     * Follow the lock: paused until the lock's expiry while an update, rollback or
     * cache cycle holds it, cleared when it is released. A sync changes nothing on the
     * site, so it never pauses.
     *
     * ⚠️ WHY. Every component an update changes makes WP Rocket purge and restart its
     * preload crawl, which then competes with the next component's update and health
     * renders. Measured on allroundglazing 24 Oct 2026 (0.12.3): the account hit its
     * 20 entry processes (508s, one to a visitor), the last component overran
     * Cloudflare's 100 s, and preload requests caught mid-swap logged fatals. Stage 2
     * warms the site at the end anyway, and WP Rocket skips URLs already cached when
     * its queue resumes, so nothing is lost.
     *
     * @param array{id:string, action:string, expires:int}|null $lock
     */
    private function pause_preload( ?array $lock ): void {
        if ( ! function_exists( 'update_option' ) || ! function_exists( 'get_option' ) ) {
            return;
        }
        $current = get_option( self::PRELOAD_PAUSE_OPTION, 0 );
        $current = is_numeric( $current ) ? (int) $current : 0;
        if ( null !== $lock && 'sync' === $lock['action'] ) {
            // A sync changes nothing on the site: it leaves the pause exactly as it is.
            return;
        }
        if ( null === $lock ) {
            // Released: the pause runs on for PRELOAD_GRACE seconds, never past what it
            // was, and nothing is written when nothing was paused (0.12.7).
            //
            // ⚠️ WHY NOT 0. Between two components the lock is released and re-taken a few
            // seconds later. A WP Rocket job runner that STARTS in that gap loads the
            // options with the pause off and keeps that copy for its whole life, so its
            // fetches go through even after the next component has paused again. Measured
            // on Hox Group, 25 Oct 2026: released 00:56:00, re-taken 00:56:05, a runner
            // fetched `/` at 00:56:10 and 00:56:14. The next component extends the pause
            // over the grace; after the last one, preload resumes two minutes later.
            $now   = $this->now();
            $until = min( $current, $now + self::PRELOAD_GRACE );
            if ( $current > $now && $until !== $current ) {
                update_option( self::PRELOAD_PAUSE_OPTION, $until, true );
            }
            return;
        }
        // Each heartbeat extends the lock; rewrite only when it moves by a minute or more,
        // so an autoloaded row is not rewritten on every step.
        if ( abs( $lock['expires'] - $current ) >= 60 ) {
            update_option( self::PRELOAD_PAUSE_OPTION, $lock['expires'], true );
        }
    }

    /** Whether WP Rocket's preload is paused right now. Expiry is checked, not trusted. */
    public static function preload_paused( ?int $now = null ): bool {
        if ( ! function_exists( 'get_option' ) ) {
            return false;
        }
        $until = get_option( self::PRELOAD_PAUSE_OPTION, 0 );
        return is_numeric( $until ) && (int) $until > ( $now ?? time() );
    }

    /** @return array{id:string, action:string, expires:int}|null The live lock, or null. */
    public function lock(): ?array {
        $lock = $this->state()['lock'];
        return null !== $lock && $lock['expires'] > $this->now() ? $lock : null;
    }

    // -----------------------------------------------------------------------
    // Sync rate
    // -----------------------------------------------------------------------

    public function last_sync(): int {
        return $this->state()['last_sync'];
    }

    public function mark_sync(): void {
        $state              = $this->state();
        $state['last_sync'] = $this->now();
        $this->save( $state );
    }

    /** When a `wordfence_scan` last ran here (0.13.0), for its rate floor. */
    public function last_wordfence_scan(): int {
        return $this->state()['last_wordfence_scan'];
    }

    public function mark_wordfence_scan(): void {
        $state                        = $this->state();
        $state['last_wordfence_scan'] = $this->now();
        $this->save( $state );
    }

    // -----------------------------------------------------------------------
    // Records
    // -----------------------------------------------------------------------

    /**
     * Open a record for an action that has just taken the lock.
     *
     * `deadline` is when stage 1 counts as dead if it has not finished - the lock
     * expiry, by construction, so "the lock expired and nobody finished" is a
     * statement about the record and not a guess.
     */
    public function start_record( string $id, string $action, int $deadline ): void {
        $this->put_record(
            $id,
            [
                'of'       => $id,
                'action'   => $action,
                'stage'    => 1,
                'started'  => $this->now(),
                'finished' => null,
                'deadline' => $deadline,
                'result'   => null,
                'stage2'   => null,
            ]
        );
    }

    /**
     * Stage 1 is done. $stage2 is `queued` or `skipped`; a queued stage 2 gets its
     * own deadline, because the stage 2 lock is the one that is now running.
     *
     * @param array<string, mixed> $result Already sanitised.
     */
    public function finish_stage1( string $id, array $result, string $stage2, int $stage2_deadline = 0, ?string $stage2_reason = null ): void {
        $record = $this->record( $id );
        if ( null === $record ) {
            return;
        }
        $now                = $this->now();
        $record['result']   = $result;
        $record['stage1_finished'] = $now;
        if ( 'queued' === $stage2 ) {
            $record['stage']    = 2;
            $record['deadline'] = $stage2_deadline;
            $record['stage2']   = self::stage2_blank( 'queued' );
        } else {
            $record['finished'] = $now;
            $record['stage2']   = self::stage2_blank( 'skipped' );
            if ( null !== $stage2_reason ) {
                $record['stage2']['reason'] = $stage2_reason;
            }
        }
        $this->put_record( $id, $record );
    }

    /** @param array<string, mixed> $fields Merged into the stage 2 sub-record. */
    public function update_stage2( string $id, array $fields, bool $finished = false ): void {
        $record = $this->record( $id );
        if ( null === $record ) {
            return;
        }
        $stage2 = is_array( $record['stage2'] ) ? $record['stage2'] : self::stage2_blank( 'running' );
        foreach ( $fields as $key => $value ) {
            $stage2[ $key ] = $value;
        }
        if ( $finished ) {
            $now                = $this->now();
            $stage2['state']    = 'done';
            $stage2['finished'] = $now;
            $record['finished'] = $now;
        }
        $record['stage2'] = $stage2;
        $this->put_record( $id, $record );
    }

    /**
     * Mark an unfinished record dead now, rather than at its deadline. For a stage
     * that threw: it did not finish, and saying so straight away is more useful than
     * reading `running` for half an hour.
     */
    public function expire( string $id ): void {
        $record = $this->record( $id );
        if ( null === $record || null !== ( $record['finished'] ?? null ) ) {
            return;
        }
        $record['deadline'] = $this->now() - 1;
        $this->put_record( $id, $record );
    }

    /**
     * One component's result so far, written after every step (0.12.0, A2).
     *
     * 🚨 bandcservices, 23 Oct 2026: a request killed mid-update left `result: null`
     * and nobody could say which of nine plugins had changed. `progress` is written
     * BEFORE each next step starts, so a record whose stage 1 died still says, per
     * component, how far it got (`step`), what it changed, and its backup id.
     *
     * @param array<string, mixed> $row Already sanitised.
     */
    public function progress( string $id, int $index, array $row ): void {
        $record = $this->record( $id );
        if ( null === $record ) {
            return;
        }
        $progress           = is_array( $record['progress'] ?? null ) ? $record['progress'] : [];
        $progress[ $index ] = $row;
        ksort( $progress );
        $record['progress'] = $progress;
        $this->put_record( $id, $record );
    }

    /**
     * Merge fields into a record's top level (not reported by `status`; for the
     * site's own use, e.g. the key paths stage 2 needs when it runs from WP-Cron).
     *
     * @param array<string, mixed> $fields
     */
    public function annotate( string $id, array $fields ): void {
        $record = $this->record( $id );
        if ( null === $record ) {
            return;
        }
        foreach ( $fields as $key => $value ) {
            $record[ $key ] = $value;
        }
        $this->put_record( $id, $record );
    }

    /** @return array<string, mixed>|null The raw stored record. */
    public function record( string $id ): ?array {
        foreach ( $this->state()['records'] as $record ) {
            if ( $record['of'] === $id ) {
                return $record;
            }
        }
        return null;
    }

    /**
     * One record as `status` reports it, with the state worked out from the clock.
     *
     * 🚨 A STAGE THAT STARTED AND NEVER FINISHED IS `died`, NEVER `done`. A host
     * that kills long requests is exactly the case where the cache cycle silently
     * did not happen, and a record still saying `queued` or `running` hours later
     * would be read as "still going" forever. Past its deadline, unfinished is dead.
     *
     * @return array<string, mixed>
     */
    public function view( string $id ): array {
        $record = $this->record( $id );
        if ( null === $record ) {
            return [ 'of' => $id, 'action' => null, 'state' => 'unknown_id', 'stage' => null, 'started' => null, 'finished' => null, 'result' => null, 'progress' => [], 'stage2' => null ];
        }
        return self::present( $record, $this->now() );
    }

    /** @return array<int, array{id:string, action:string, state:string, finished:?int}> Newest first. */
    public function recent(): array {
        $now = $this->now();
        $out = [];
        foreach ( array_reverse( $this->state()['records'] ) as $record ) {
            $view  = self::present( $record, $now );
            $out[] = [
                'id'       => $record['of'],
                'action'   => $record['action'],
                'state'    => $view['state'],
                'finished' => $view['finished'],
            ];
        }
        return $out;
    }

    /**
     * Pure: a stored record plus the time, in; the reported record, out.
     *
     * @param array<string, mixed> $record
     * @return array<string, mixed>
     */
    public static function present( array $record, int $now ): array {
        $deadline = is_int( $record['deadline'] ?? null ) ? $record['deadline'] : 0;
        $stage    = 2 === ( $record['stage'] ?? 1 ) ? 2 : 1;
        $finished = is_int( $record['finished'] ?? null ) ? $record['finished'] : null;
        $stage2   = is_array( $record['stage2'] ?? null ) ? $record['stage2'] : null;

        if ( null !== $finished ) {
            $state = 'done';
        } elseif ( $now > $deadline ) {
            $state = 'died';
            if ( null !== $stage2 && in_array( $stage2['state'] ?? '', [ 'queued', 'running' ], true ) ) {
                $stage2['state'] = 'died';
            }
        } else {
            $state = 'running';
        }

        return [
            'of'       => $record['of'],
            'action'   => $record['action'],
            'state'    => $state,
            'stage'    => $stage,
            'started'  => is_int( $record['started'] ?? null ) ? $record['started'] : null,
            'finished' => $finished,
            'result'   => is_array( $record['result'] ?? null ) ? $record['result'] : null,
            'progress' => is_array( $record['progress'] ?? null ) ? array_values( $record['progress'] ) : [],
            'stage2'   => $stage2,
        ];
    }

    /** @return array<string, mixed> */
    private static function stage2_blank( string $state ): array {
        return [
            'state'             => $state,
            'urls_warmed'       => 0,
            'urls_cut'          => 0,
            'min_missing'       => 0,
            'cache'             => null,
            'elementor_flushed' => false,
            'finished'          => null,
        ];
    }

    /** @param array<string, mixed> $record */
    private function put_record( string $id, array $record ): void {
        $state   = $this->state();
        $records = [];
        foreach ( $state['records'] as $existing ) {
            if ( $existing['of'] !== $id ) {
                $records[] = $existing;
            }
        }
        $records[]        = $record;
        $state['records'] = array_slice( $records, -self::MAX_RECORDS );
        $this->save( $state );
    }

    // -----------------------------------------------------------------------
    // Backup index. Backups owns what goes in it; this only keeps it.
    // -----------------------------------------------------------------------

    /** @return array<int, array<string, mixed>> */
    public function backups(): array {
        return $this->state()['backups'];
    }

    /** @param array<int, array<string, mixed>> $backups */
    public function set_backups( array $backups ): void {
        $state            = $this->state();
        $state['backups'] = array_values( $backups );
        $this->save( $state );
    }

    // -----------------------------------------------------------------------
    // The row
    // -----------------------------------------------------------------------

    /**
     * The stored row, validated section by section.
     *
     * Nonces now live in NONCE_OPTION. Unexpired ones a 0.11.0 build left in THIS
     * row are carried forward under `nonces` until they age out, so no write of
     * this row can drop them before claim_nonce() has had the chance to see them.
     *
     * @return array{nonces:array<string,int>, lock:?array{id:string,action:string,expires:int}, last_sync:int, last_wordfence_scan:int, records:array<int,array<string,mixed>>, backups:array<int,array<string,mixed>>}
     */
    private function state(): array {
        $raw = function_exists( 'get_option' ) ? get_option( self::OPTION, [] ) : [];
        $raw = is_array( $raw ) ? $raw : [];

        $lock = null;
        $l    = $raw['lock'] ?? null;
        if ( is_array( $l ) && is_string( $l['id'] ?? null ) && is_string( $l['action'] ?? null ) && is_int( $l['expires'] ?? null ) ) {
            $lock = [ 'id' => $l['id'], 'action' => $l['action'], 'expires' => $l['expires'] ];
        }

        $records = [];
        foreach ( is_array( $raw['records'] ?? null ) ? $raw['records'] : [] as $record ) {
            if ( is_array( $record ) && is_string( $record['of'] ?? null ) && is_string( $record['action'] ?? null ) ) {
                $records[] = $record;
            }
        }

        $backups = [];
        foreach ( is_array( $raw['backups'] ?? null ) ? $raw['backups'] : [] as $backup ) {
            if (
                is_array( $backup )
                && is_string( $backup['id'] ?? null )
                && is_string( $backup['file'] ?? null )
                && is_string( $backup['version'] ?? null )
                && is_string( $backup['path'] ?? null )
                && is_int( $backup['created'] ?? null )
            ) {
                $backups[] = $backup;
            }
        }

        return [
            'nonces'    => self::unexpired( is_array( $raw['nonces'] ?? null ) ? $raw['nonces'] : [], $this->now() ),
            'lock'      => $lock,
            'last_sync' => is_int( $raw['last_sync'] ?? null ) ? $raw['last_sync'] : 0,
            'last_wordfence_scan' => is_int( $raw['last_wordfence_scan'] ?? null ) ? $raw['last_wordfence_scan'] : 0,
            'records'   => $records,
            'backups'   => $backups,
        ];
    }

    /** @param array<string, mixed> $state */
    private function save( array $state ): void {
        if ( function_exists( 'update_option' ) ) {
            // Not autoloaded: nothing on a page load reads this.
            update_option( self::OPTION, $state, false );
        }
    }
}
