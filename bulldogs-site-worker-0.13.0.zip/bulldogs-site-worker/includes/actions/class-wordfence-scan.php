<?php
namespace Bulldogs\SiteWorker\Actions;

use Bulldogs\SiteWorker\Monitor\SecurityReport;

/**
 * The `wordfence_scan` action (0.13.0): bring Wordfence's own issue list up to
 * date with the site, as the last step on a site in a fleet update run.
 *
 * ---------------------------------------------------------------------------
 * WHY THIS EXISTS
 * ---------------------------------------------------------------------------
 * The `security` section reports what Wordfence found at its LAST scan. After a
 * run of updates from the Control Centre, that list still says "needs an
 * upgrade" and "has a security vulnerability" about versions that are no longer
 * installed, until Wordfence's next scheduled scan - and on free installs
 * Wordfence's own servers set that schedule, so it can be days (Will, 26 Oct
 * 2026: "wordfence alerts for plugins being outdated even though we've updated
 * them").
 *
 * Two steps, both Wordfence's own code, never SQL against its tables:
 *
 *   1. reconcileUpgradeIssues() - what Wordfence itself runs on the shutdown of
 *      an upgrade request. It deletes the `wfUpgrade` / `wfPluginUpgrade` /
 *      `wfThemeUpgrade` issues for anything no longer offered an update. It is
 *      instant, and it reads WordPress's update transients, which the update
 *      action has just refreshed. It does NOT touch `wfPluginVulnerable` or any
 *      other type: only a scan clears those.
 *   2. wfScanEngine::startScan() - exactly what the "Start New Scan" button
 *      calls. It forks the scan into Wordfence's own loopback request and
 *      returns; the scan runs on after this response. Its results reach the CC
 *      through the next findings poll or `sync`, with `last_completed` moving.
 *
 * A scan Wordfence says is already running is left alone (`already_running`),
 * never stopped and restarted.
 *
 * Every Wordfence call is behind this class so the controller suite can run
 * without Wordfence present.
 */
class WordfenceScan {
    public const STARTED         = 'started';
    public const ALREADY_RUNNING = 'already_running';
    public const FAILED          = 'failed';
    public const NOT_AVAILABLE   = 'not_available';

    /** One scan start per site per this many seconds. Wordfence's scan is heavy. */
    public const MIN_INTERVAL = 900;

    /** absent / inactive / active, as the security section says it. */
    public function state(): string {
        $security = $this->security();
        $state    = $security['wordfence'] ?? SecurityReport::WORDFENCE_ABSENT;
        return is_string( $state ) ? $state : SecurityReport::WORDFENCE_ABSENT;
    }

    /** @return array<string, mixed> The live `security` section. */
    public function security(): array {
        try {
            return ( new SecurityReport() )->gather();
        } catch ( \Throwable $e ) {
            return [ 'error' => 'Reading the Wordfence scan failed: ' . $e->getMessage() ];
        }
    }

    /**
     * Wordfence's own clean-up of update issues, from the update transients.
     *
     * @return string|null null on success, else why it could not run.
     */
    public function reconcile(): ?string {
        if ( ! class_exists( '\wfIssues' ) || ! method_exists( '\wfIssues', 'reconcileUpgradeIssues' ) ) {
            return 'Wordfence has no reconcileUpgradeIssues() in this version.';
        }
        try {
            ( new \wfIssues() )->reconcileUpgradeIssues( null, true );
            return null;
        } catch ( \Throwable $e ) {
            return 'reconcileUpgradeIssues failed: ' . $e->getMessage();
        }
    }

    public function running(): bool {
        if ( ! class_exists( '\wfScanner' ) ) {
            return false;
        }
        try {
            return (bool) \wfScanner::shared()->isRunning();
        } catch ( \Throwable $e ) {
            return false;
        }
    }

    /**
     * Start a scan the way the wp-admin button does.
     *
     * @return array{state:string, message:?string}
     */
    public function start(): array {
        if ( ! class_exists( '\wfScanEngine' ) || ! method_exists( '\wfScanEngine', 'startScan' ) ) {
            return [ 'state' => self::NOT_AVAILABLE, 'message' => 'Wordfence has no startScan() in this version.' ];
        }
        try {
            // A string is Wordfence's refusal ("A scan is already running..."). false
            // and null both mean it forked - startScan() returns false on success too.
            $err = \wfScanEngine::startScan();
            if ( is_string( $err ) && '' !== $err ) {
                return [ 'state' => self::FAILED, 'message' => $err ];
            }
            return [ 'state' => self::STARTED, 'message' => null ];
        } catch ( \Throwable $e ) {
            // As Wordfence's own REST controller does on a failed callback test.
            if ( class_exists( '\wfUtils' ) && method_exists( '\wfUtils', 'clearScanLock' ) ) {
                \wfUtils::clearScanLock();
            }
            return [ 'state' => self::FAILED, 'message' => $e->getMessage() ];
        }
    }

    /**
     * The whole action, given the controller has the site lock.
     *
     * @return array<string, mixed>
     */
    public function run(): array {
        $state = $this->state();
        if ( SecurityReport::WORDFENCE_ACTIVE !== $state ) {
            return [ 'wordfence' => $state, 'reconcile' => 'skipped', 'scan' => self::NOT_AVAILABLE, 'security' => $this->security() ];
        }

        $before = self::open_count( $this->security() );
        $error  = $this->reconcile();
        $after  = $this->security();

        $out = [
            'wordfence' => $state,
            'reconcile' => null === $error ? 'ok' : 'failed',
            'cleared'   => null !== $before && null !== self::open_count( $after ) ? max( 0, $before - (int) self::open_count( $after ) ) : null,
        ];
        if ( null !== $error ) {
            $out['reconcile_message'] = substr( $error, 0, 200 );
        }

        if ( $this->running() ) {
            $out['scan'] = self::ALREADY_RUNNING;
        } else {
            $start       = $this->start();
            $out['scan'] = $start['state'];
            if ( null !== $start['message'] ) {
                $out['scan_message'] = substr( trim( strip_tags( $start['message'] ) ), 0, 200 );
            }
        }

        $out['security'] = $after;
        return $out;
    }

    /** @param array<string, mixed> $security */
    private static function open_count( array $security ): ?int {
        return isset( $security['issue_total'] ) && is_int( $security['issue_total'] ) ? $security['issue_total'] : null;
    }
}
