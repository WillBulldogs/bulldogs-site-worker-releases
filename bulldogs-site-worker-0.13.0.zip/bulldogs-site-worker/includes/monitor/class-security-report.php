<?php
namespace Bulldogs\SiteWorker\Monitor;

/**
 * The `security` section of the findings response: what Wordfence's own scan
 * found on THIS site, and whether that scan can be believed.
 *
 * ---------------------------------------------------------------------------
 * A SECOND SOURCE, NOT A REPLACEMENT FOR THE FEED
 * ---------------------------------------------------------------------------
 * WP Fleet already matches every installed component against the Wordfence
 * Intelligence feed, centrally, once for the whole estate. This adds the class of
 * finding the feed cannot produce: modified core files, malware signatures,
 * abandoned plugins, weak admin passwords - what Wordfence found by looking at
 * the site itself. The issues table is unreachable agentlessly (cPanel has no
 * query function), which is why it needs a plugin at all.
 *
 * ---------------------------------------------------------------------------
 * 🚨 AN EMPTY ISSUES LIST IS NOT A CLEAN SITE
 * ---------------------------------------------------------------------------
 * A site whose scan is disabled, failing, or has never run has an empty issues
 * table, exactly like a site that was scanned and found clean. So the section
 * always carries the SCAN STATUS and the time of the last COMPLETED scan beside
 * the issues, and WP Fleet reads anything other than a recent `ok` as unknown.
 * This report does not decide what "recent" means - it reports the timestamp and
 * lets the collector judge, so the threshold lives in one place.
 *
 * Three states for Wordfence itself, because "not installed" is a finding and
 * "installed but deactivated" is a different one:
 *
 *   absent   - not installed at all
 *   inactive - installed, not running. Its tables may still hold issues from
 *              before it was switched off; they are NOT reported, because they
 *              describe a site that no longer exists.
 *   active   - running. Scan status and issues follow.
 *
 * Everything Wordfence-specific is read through Wordfence's own classes rather
 * than by SQL against its tables. Its table names have changed case across
 * versions and it has a multisite network-table indirection; its own code
 * already knows both. If those classes are missing on an active install, the
 * scan status is `unreadable` - unknown, never clean.
 */
class SecurityReport {
    public const WORDFENCE_FILE = 'wordfence/wordfence.php';

    public const WORDFENCE_ABSENT   = 'absent';
    public const WORDFENCE_INACTIVE = 'inactive';
    public const WORDFENCE_ACTIVE   = 'active';

    public const SCAN_OK         = 'ok';
    public const SCAN_FAILED     = 'failed';
    public const SCAN_NEVER      = 'never';
    public const SCAN_UNREADABLE = 'unreadable';

    /** Bound on the response. The true total is reported beside it. */
    public const MAX_ISSUES = 50;

    /**
     * Read the live state and interpret it.
     *
     * @return array<string, mixed>
     */
    public function gather(): array {
        if ( ! function_exists( 'get_plugins' ) && defined( 'ABSPATH' ) && is_readable( ABSPATH . 'wp-admin/includes/plugin.php' ) ) {
            require_once ABSPATH . 'wp-admin/includes/plugin.php';
        }

        $installed = function_exists( 'get_plugins' ) ? (array) get_plugins() : [];
        if ( ! isset( $installed[ self::WORDFENCE_FILE ] ) ) {
            return $this->interpret( [ 'installed' => false ], time() );
        }

        $headers = $installed[ self::WORDFENCE_FILE ];
        $raw     = [
            'installed' => true,
            'version'   => is_array( $headers ) && isset( $headers['Version'] ) && is_string( $headers['Version'] ) ? $headers['Version'] : null,
            'active'    => function_exists( 'is_plugin_active' ) && is_plugin_active( self::WORDFENCE_FILE ),
        ];

        if ( $raw['active'] ) {
            $raw = array_merge( $raw, $this->read_wordfence() );
        }

        return $this->interpret( $raw, time() );
    }

    /**
     * Pure: the raw readings, in; the section, out.
     *
     * @param array<string, mixed> $raw
     * @return array<string, mixed>
     */
    public function interpret( array $raw, int $now ): array {
        if ( empty( $raw['installed'] ) ) {
            return [ 'wordfence' => self::WORDFENCE_ABSENT ];
        }

        $version = isset( $raw['version'] ) && is_string( $raw['version'] ) ? $raw['version'] : null;

        if ( empty( $raw['active'] ) ) {
            return [ 'wordfence' => self::WORDFENCE_INACTIVE, 'version' => $version ];
        }

        $out = [
            'wordfence'   => self::WORDFENCE_ACTIVE,
            'version'     => $version,
            'scan'        => [
                'status'            => self::SCAN_UNREADABLE,
                'last_completed'    => null,
                'message'           => null,
                'scheduled'         => null,
            ],
            'issues'      => [],
            'issue_total' => null,
            'truncated'   => false,
        ];

        if ( ! empty( $raw['error'] ) ) {
            $out['scan']['message'] = self::clean( (string) $raw['error'], 200 );
            return $out;
        }

        // wfConfig::get('lastScanCompleted') is 'ok' after a scan that finished,
        // the failure message after one that did not, and empty when none ever ran.
        $completed = $raw['last_scan_completed'] ?? null;
        if ( null === $completed || false === $completed || '' === $completed ) {
            $out['scan']['status'] = self::SCAN_NEVER;
        } elseif ( 'ok' === $completed ) {
            $out['scan']['status'] = self::SCAN_OK;
        } else {
            $out['scan']['status']  = self::SCAN_FAILED;
            $out['scan']['message'] = self::clean( (string) $completed, 200 );
        }

        // `scanTime` is stamped only when a full scan finishes, as microtime(true).
        $scan_time = $raw['scan_time'] ?? null;
        if ( is_numeric( $scan_time ) && (float) $scan_time > 0 && (int) $scan_time <= $now + 300 ) {
            $out['scan']['last_completed'] = (int) $scan_time;
        }

        if ( array_key_exists( 'scheduled', $raw ) && null !== $raw['scheduled'] ) {
            $out['scan']['scheduled'] = (bool) $raw['scheduled'];
        }

        $themes = is_array( $raw['theme_slugs'] ?? null ) ? $raw['theme_slugs'] : [];
        $issues = [];
        foreach ( is_array( $raw['issues'] ?? null ) ? $raw['issues'] : [] as $issue ) {
            $row = self::issue( $issue, $themes );
            if ( null !== $row ) {
                $issues[] = $row;
            }
        }

        $total = isset( $raw['issue_total'] ) && is_numeric( $raw['issue_total'] ) ? max( 0, (int) $raw['issue_total'] ) : count( $issues );
        // Never report fewer issues in total than we are actually returning.
        $total = max( $total, count( $issues ) );

        $out['issues']      = array_slice( $issues, 0, self::MAX_ISSUES );
        $out['issue_total'] = $total;
        $out['truncated']   = $total > count( $out['issues'] );

        return $out;
    }

    /**
     * The Wordfence readings, via Wordfence's own classes. Any failure becomes an
     * `error`, which interpret() turns into an unreadable scan - never an empty one.
     *
     * @return array<string, mixed>
     */
    private function read_wordfence(): array {
        if ( ! class_exists( '\wfConfig' ) || ! class_exists( '\wfIssues' ) ) {
            return [ 'error' => 'Wordfence is active but its classes are not loaded, so its scan could not be read.' ];
        }

        try {
            $issues = new \wfIssues();
            $counts = method_exists( $issues, 'getIssueCounts' ) ? $issues->getIssueCounts() : [];
            $list   = $issues->getIssues( 0, self::MAX_ISSUES, 0, 0 );

            return [
                'theme_slugs'         => self::theme_slugs(),
                'last_scan_completed' => \wfConfig::get( 'lastScanCompleted' ),
                'scan_time'           => \wfConfig::get( 'scanTime' ),
                'scheduled'           => \wfConfig::get( 'scheduledScansEnabled' ),
                'issue_total'         => is_array( $counts ) && isset( $counts['new'] ) ? (int) $counts['new'] : 0,
                'issues'              => is_array( $list ) && isset( $list['new'] ) && is_array( $list['new'] ) ? $list['new'] : [],
            ];
        } catch ( \Throwable $e ) {
            return [ 'error' => 'Reading the Wordfence scan failed: ' . $e->getMessage() ];
        }
    }

    /**
     * Theme name => stylesheet, because Wordfence's theme issues carry the theme's
     * display name and nothing else that identifies it.
     *
     * @return array<string, string>
     */
    private static function theme_slugs(): array {
        if ( ! function_exists( 'wp_get_themes' ) ) {
            return [];
        }
        $out = [];
        foreach ( (array) wp_get_themes() as $stylesheet => $theme ) {
            $name = is_object( $theme ) && method_exists( $theme, 'get' ) ? $theme->get( 'Name' ) : null;
            if ( is_string( $name ) && '' !== $name && is_string( $stylesheet ) && ! isset( $out[ $name ] ) ) {
                $out[ $name ] = $stylesheet;
            }
        }
        return $out;
    }

    /**
     * The component an update or vulnerability issue is about (0.13.0), so the CC
     * can tell an issue about a version that is no longer installed from one that
     * still applies. Only the slug and version numbers leave the site - never the
     * issue data itself, which can carry paths and user names.
     *
     * Wordfence's shapes, from 9.0.2's scan engine:
     *   wfUpgrade           {currentVersion, newVersion}                    core
     *   wfPluginUpgrade     {pluginFile, slug?, Version, newVersion, ...}   plugin
     *   wfPluginVulnerable  {pluginFile, slug?, Version, ...}               plugin
     *   wfPluginAbandoned / wfPluginRemoved: the same plugin fields, when present
     *   wfThemeUpgrade      {Name, version, newVersion, ...}                theme, by name
     *
     * @param array<string, string> $themes name => stylesheet
     * @return array{kind:string, slug:string, version:?string, offered:?string}|null
     */
    public static function component( string $type, mixed $data, array $themes = [] ): ?array {
        if ( ! is_array( $data ) ) {
            return null;
        }
        $str     = static fn ( mixed $v ): ?string => is_string( $v ) && '' !== $v && 'Unknown' !== $v ? substr( $v, 0, 64 ) : null;
        $offered = $str( $data['newVersion'] ?? null );

        if ( 'wfUpgrade' === $type ) {
            return [ 'kind' => 'core', 'slug' => 'core', 'version' => $str( $data['currentVersion'] ?? null ), 'offered' => $offered ];
        }
        if ( str_starts_with( $type, 'wfPlugin' ) ) {
            $file = $str( $data['pluginFile'] ?? null );
            $slug = $str( $data['slug'] ?? null );
            if ( null === $slug && null !== $file ) {
                $slug = str_contains( $file, '/' ) ? strstr( $file, '/', true ) : preg_replace( '/\.php$/', '', $file );
            }
            if ( null === $slug || '' === $slug ) {
                return null;
            }
            return [ 'kind' => 'plugin', 'slug' => $slug, 'version' => $str( $data['Version'] ?? ( $data['version'] ?? null ) ), 'offered' => $offered ];
        }
        if ( str_starts_with( $type, 'wfTheme' ) ) {
            $name = $str( $data['Name'] ?? ( $data['name'] ?? null ) );
            $slug = null !== $name ? ( $themes[ $name ] ?? null ) : null;
            if ( ! is_string( $slug ) || '' === $slug ) {
                return null;
            }
            return [ 'kind' => 'theme', 'slug' => $slug, 'version' => $str( $data['version'] ?? ( $data['Version'] ?? null ) ), 'offered' => $offered ];
        }
        return null;
    }

    /**
     * One issue, reduced to what WP Fleet needs. Never the long message or the
     * issue data: those carry file paths and user names, and this response leaves
     * the site. The component it is about, when it is about one, is extracted.
     *
     * @param array<string, string> $themes
     * @return array<string, mixed>|null
     */
    private static function issue( mixed $issue, array $themes = [] ): ?array {
        if ( ! is_array( $issue ) || ! isset( $issue['type'] ) || ! is_string( $issue['type'] ) || '' === $issue['type'] ) {
            return null;
        }

        $message = isset( $issue['shortMsg'] ) && is_string( $issue['shortMsg'] ) ? self::clean( $issue['shortMsg'], 300 ) : '';

        // ignoreP is Wordfence's own stable hash of the issue - the value it uses
        // to recognise the same issue across scans. It is the natural identity.
        $key = isset( $issue['ignoreP'] ) && is_string( $issue['ignoreP'] ) && '' !== $issue['ignoreP']
            ? $issue['ignoreP']
            : md5( $issue['type'] . "\0" . $message );

        $row = [
            'key'          => substr( $key, 0, 64 ),
            'type'         => substr( $issue['type'], 0, 64 ),
            'severity'     => self::severity( $issue['severity'] ?? null ),
            'message'      => $message,
            'first_seen'   => isset( $issue['time'] ) && is_numeric( $issue['time'] ) ? (int) $issue['time'] : null,
            'last_updated' => isset( $issue['lastUpdated'] ) && is_numeric( $issue['lastUpdated'] ) ? (int) $issue['lastUpdated'] : null,
        ];
        $component = self::component( $issue['type'], $issue['data'] ?? null, $themes );
        if ( null !== $component ) {
            $row['component'] = $component;
        }
        return $row;
    }

    /** Wordfence's numeric severity (0/25/50/75/100) as a word. */
    public static function severity( mixed $value ): string {
        $n = is_numeric( $value ) ? (int) $value : 0;
        if ( $n >= 100 ) {
            return 'critical';
        }
        if ( $n >= 75 ) {
            return 'high';
        }
        if ( $n >= 50 ) {
            return 'medium';
        }
        if ( $n >= 25 ) {
            return 'low';
        }
        return 'info';
    }

    private static function clean( string $text, int $max ): string {
        $text = trim( preg_replace( '/\s+/', ' ', strip_tags( $text ) ) ?? '' );
        // mbstring is not guaranteed on every host PHP build; a byte cut is an
        // acceptable fallback for a display string.
        if ( function_exists( 'mb_strlen' ) && function_exists( 'mb_substr' ) ) {
            return mb_strlen( $text ) > $max ? mb_substr( $text, 0, $max - 1 ) . '…' : $text;
        }
        return strlen( $text ) > $max ? substr( $text, 0, $max - 3 ) . '...' : $text;
    }
}
