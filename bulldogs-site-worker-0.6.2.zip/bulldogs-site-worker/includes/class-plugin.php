<?php
namespace Bulldogs\SiteWorker;

/**
 * Boots modules in isolation. A module that throws is recorded and skipped;
 * it must never surface as a fatal, because that is a white screen on a
 * client site.
 */
class Plugin {
    /** @var array<string, callable> */
    private array $modules = [];
    /** @var string[] */
    private array $failed = [];

    public function add_module( string $name, callable $boot ): void {
        $this->modules[ $name ] = $boot;
    }

    public function boot(): void {
        foreach ( $this->modules as $name => $boot ) {
            try {
                $boot();
            } catch ( \Throwable $e ) {
                $this->failed[] = $name;
                $this->log_failure( $name, $e );
            }
        }
    }

    /** @return string[] */
    public function failed_modules(): array {
        return $this->failed;
    }

    private function log_failure( string $name, \Throwable $e ): void {
        if ( function_exists( 'error_log' ) ) {
            error_log( sprintf( 'bulldogs-site-worker: module "%s" failed to boot: %s', $name, $e->getMessage() ) );
        }
    }
}
