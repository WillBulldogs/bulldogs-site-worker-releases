<?php
namespace Bulldogs\SiteWorker;

/** Shared option store for both modules. Degrades rather than raising. */
class Settings {
    public const OPTION = 'bulldogs_site_worker';

    private function all(): array {
        $raw = get_option( self::OPTION, [] );
        return is_array( $raw ) ? $raw : [];
    }

    public function get( string $key, mixed $default = null ): mixed {
        return $this->all()[ $key ] ?? $default;
    }

    public function set( string $key, mixed $value ): void {
        $all         = $this->all();
        $all[ $key ] = $value;
        update_option( self::OPTION, $all );
    }
}
