<?php
namespace Bulldogs\SiteWorker\CLI;

use Bulldogs\SiteWorker\Consent\BannerCategories;
use Bulldogs\SiteWorker\Consent\BannerRenderer;
use Bulldogs\SiteWorker\Consent\TagRegistry;
use Bulldogs\SiteWorker\Monitor\FindingsStore;
use Bulldogs\SiteWorker\Monitor\RestController;
use Bulldogs\SiteWorker\Monitor\Scanner;
use Bulldogs\SiteWorker\Monitor\SiteSecret;
use Bulldogs\SiteWorker\Settings;
use WP_CLI;

/**
 * `wp bulldogs consent ...`
 *
 * WP-CLI is the ONLY supported configuration surface - there is no admin UI, and the
 * fleet rollout is scripted over SSH. Two consequences shape this class:
 *
 *  1. The list-manipulation logic is extracted into pure static methods (upsert(),
 *     without(), normalise_id(), normalise_category()) so it can be unit tested. The
 *     WP_CLI class does not exist outside a real install, so anything touching it is
 *     untestable here; keeping that surface down to argument reading and output is
 *     what makes the rest verifiable.
 *  2. Every method assumes the stored option is arbitrary junk. A tag list written by
 *     an older version, a half-finished edit or a corrupted option must not fatal the
 *     command - `wp` fatalling mid-rollout across 29 sites is the failure to avoid.
 */
class Commands {
    /** Fields `list` will print. Anything else asked for is rejected rather than ignored. */
    private const LIST_FIELDS = [ 'id', 'category', 'markup' ];

    /**
     * List registered tags.
     *
     * Reads through TagRegistry, so this prints exactly the tags the site will emit.
     * Malformed entries are omitted here for the same reason they are omitted on the
     * page; TagRegistry logs each drop to the error log.
     *
     * ## OPTIONS
     *
     * [--fields=<fields>]
     * : Comma-separated list of fields to show. One or more of id, category, markup.
     * ---
     * default: id,category
     * ---
     *
     * [--format=<format>]
     * : Render output in a particular format.
     * ---
     * default: table
     * options:
     *   - table
     *   - json
     *   - csv
     *   - yaml
     *   - count
     * ---
     *
     * ## EXAMPLES
     *
     *     wp bulldogs consent list
     *     wp bulldogs consent list --fields=id,category,markup --format=json
     *
     * @subcommand list
     *
     * @param array $args  Positional arguments. Unused.
     * @param array $assoc Associative arguments.
     */
    public function list_( $args, $assoc ): void {
        $format = isset( $assoc['format'] ) && is_string( $assoc['format'] ) ? $assoc['format'] : 'table';
        $fields = self::normalise_fields( $assoc['fields'] ?? null );

        if ( null === $fields ) {
            // WP_CLI::error() halts, but the explicit return is not decoration: without
            // it, any future path where it does not halt walks a null into a typed
            // array parameter, which is a TypeError on a client's site.
            WP_CLI::error( '--fields must be a comma-separated subset of: ' . implode( ', ', self::LIST_FIELDS ) );
            return;
        }

        \WP_CLI\Utils\format_items(
            $format,
            ( new TagRegistry( new Settings() ) )->all(),
            $fields
        );
    }

    /**
     * Register a tag, replacing any existing tag with the same id.
     *
     * ## OPTIONS
     *
     * --id=<id>
     * : Unique identifier for this tag.
     *
     * --category=<category>
     * : One of functional, preferences, statistics, marketing.
     *
     * --markup=<markup>
     * : The full script markup, or - to read from stdin.
     *
     * [--label=<label>]
     * : Display name for this service, shown on the banner's "Set by:" line.
     * Set this on every tag before the site goes live - it defaults to the id,
     * which puts a slug in front of visitors.
     *
     * ## EXAMPLES
     *
     *     wp bulldogs consent add --id=gtm --category=statistics --markup=- < gtm.html
     *     wp bulldogs consent add --id=meta-pixel --category=marketing --label="Meta Pixel" --markup=- < pixel.html
     *
     * @param array $args  Positional arguments. Unused.
     * @param array $assoc Associative arguments.
     */
    public function add( $args, $assoc ): void {
        // Guard explicitly rather than trusting the synopsis to enforce it, and guard
        // BEFORE touching stdin: `--markup=-` with a bad category would otherwise block
        // on a read that never comes, hanging an unattended rollout script.
        //
        // The `return` after each error() is not decoration - error() halts today, but
        // without it a null id or category would walk into a string parameter below,
        // and a TypeError mid-rollout is exactly the failure this plugin exists to
        // stop being a white screen.
        $id = self::normalise_id( $assoc['id'] ?? null );
        if ( null === $id ) {
            WP_CLI::error( '--id is required' );
            return;
        }

        $category = self::normalise_category( $assoc['category'] ?? null );
        if ( null === $category ) {
            WP_CLI::error( 'category must be one of: ' . implode( ', ', TagRegistry::CATEGORIES ) );
            return;
        }

        $given = $assoc['markup'] ?? null;
        if ( ! is_string( $given ) ) {
            WP_CLI::error( '--markup is required (pass - to read from stdin)' );
            return;
        }

        // Cast rather than trust: file_get_contents() returns false on a failed read,
        // and trim(false) is deprecated in 8.1. An unreadable stdin then falls through
        // to the empty-markup error below, which is the right answer either way.
        $markup = '-' === $given ? (string) file_get_contents( 'php://stdin' ) : $given;
        if ( '' === trim( $markup ) ) {
            WP_CLI::error( 'markup is empty' );
            return;
        }

        // Not guarded with an error(). The label is cosmetic - it decides what the
        // banner CALLS this tag, not whether the tag runs - so an unusable one
        // degrades to the id rather than failing a rollout that is otherwise fine.
        $label = self::normalise_label( $assoc['label'] ?? null );

        $settings = new Settings();
        $stored   = $settings->get( 'tags', [] );
        $settings->set( 'tags', self::upsert( is_array( $stored ) ? $stored : [], $id, $category, $markup, $label ) );

        WP_CLI::success(
            null === $label
                ? sprintf( 'Registered "%s" under %s.', $id, $category )
                : sprintf( 'Registered "%s" under %s, shown as "%s".', $id, $category, $label )
        );
    }

    /**
     * Remove a tag.
     *
     * ## OPTIONS
     *
     * --id=<id>
     * : Identifier to remove.
     *
     * ## EXAMPLES
     *
     *     wp bulldogs consent remove --id=gtm
     *
     * @param array $args  Positional arguments. Unused.
     * @param array $assoc Associative arguments.
     */
    public function remove( $args, $assoc ): void {
        $id = self::normalise_id( $assoc['id'] ?? null );
        if ( null === $id ) {
            WP_CLI::error( '--id is required' );
            return;
        }

        $settings  = new Settings();
        $stored    = $settings->get( 'tags', [] );
        $stored    = is_array( $stored ) ? $stored : [];
        $remaining = self::without( $stored, $id );

        // Only write when something actually changed. A no-op write would re-index and
        // rewrite the option for nothing, and - if the option is currently corrupt -
        // would quietly replace it with an empty list on a command that matched nothing.
        if ( count( $remaining ) === count( $stored ) ) {
            WP_CLI::warning( sprintf( 'No tag with id "%s".', $id ) );
            return;
        }

        $settings->set( 'tags', $remaining );
        WP_CLI::success( sprintf( 'Removed "%s".', $id ) );
    }

    // ⚠️ In the ## OPTIONS block below, a WRAPPED option description must NOT repeat
    // the leading ": " on its continuation line. WP-CLI builds the synopsis with
    // Subcommand::extract_synopsis(), which is preg_match_all('/(.+?)[\r\n]+:/') over
    // the long description - it captures every run of text that is followed by a line
    // starting with a colon. A second ": " line therefore makes the FIRST description
    // line itself a synopsis token, it is split on whitespace, and every word becomes
    // an "invalid synopsis part" warning. The consequence is not cosmetic: `--url` is
    // then dropped from $assoc, so `wp bulldogs consent policy-url --url=...` reports
    // "No usable policy URL set" and writes nothing, exit code 0. Measured on
    // WordPress 7.0.4 / WP-CLI 2.12.0 during the first real deployment; no unit test
    // can catch it, because WP-CLI's parser is not in the suite. WP-CLI core wraps
    // without the colon (see Config_Command, DB_Command, Core_Command).
    /**
     * Show or set the COOKIE POLICY the banner links to.
     *
     * This is the primary of the banner's two links, and it is the one that
     * discharges the PECR duty: a cookie policy is the document that says what
     * cookies are set, what each is for, how long it lasts and which third
     * parties see it. The wider UK GDPR privacy notice is a different document
     * and lives under `wp bulldogs consent privacy-url`; it does not substitute
     * for this one.
     *
     * The ICO expects a visitor to be told what the cookies do and where to read
     * more, so a banner with no route to a policy is a compliance gap. With no
     * URL stored the banner still renders - it just carries no link, rather than
     * an invented or empty one.
     *
     * ⚠️ The stored option is still `policy_url`, unchanged, and it still means
     * the cookie policy - which is what it has always rendered as. It is not
     * renamed to something tidier on purpose: renaming it would need a migration
     * across the fleet whose only failure mode is silent (a site that missed it
     * would simply stop showing its link, with nothing to notice).
     *
     * Validation goes through BannerRenderer::normalise_policy_url(), the same
     * method the banner itself uses. That is deliberate: a second rule here would
     * let this command report success on a URL the banner then silently refuses
     * to render, and nobody would find out until someone read the page source.
     *
     * ## OPTIONS
     *
     * [<url>]
     * : An http(s) URL, or a root-relative path such as /cookie-policy. Omit to
     * print the URL currently stored.
     *
     * [--clear]
     * : Remove the stored URL. The banner then renders with no cookie policy link.
     *
     * ## EXAMPLES
     *
     *     wp bulldogs consent policy-url
     *     wp bulldogs consent policy-url https://example.com/cookie-policy
     *     wp bulldogs consent policy-url --clear
     *
     * @subcommand policy-url
     *
     * @param array $args  Positional arguments. $args[0] is the URL to store.
     * @param array $assoc Associative arguments.
     */
    public function policy_url( $args, $assoc ): void {
        // ⚠️ POSITIONAL, NOT `--url`. This was `--url=<url>` and it could never work
        // on any install: `url` is a WP-CLI GLOBAL runtime parameter ("Pretend request
        // came from given URL", config-spec.php), so the runner consumes it before the
        // subcommand is dispatched and it never appears in $assoc. The command then
        // took the read-back branch, printed "No usable policy URL set", wrote nothing
        // and exited 0 - a silent no-op on the only surface that can set the policy
        // link, i.e. the ICO compliance gap the command exists to close. Measured on
        // WordPress 7.0.4 / WP-CLI 2.12.0 during the first real deployment. Do not
        // reintroduce a `--url` flag here under any name WP-CLI reserves: see
        // config-spec.php for the list (path, url, ssh, http, user, require, ...).
        self::store_url( $args, $assoc, 'policy_url', 'cookie policy' );
    }

    // ⚠️ Same wrapped-description trap as policy-url above: a continuation line in
    // the ## OPTIONS block must NOT begin with ": ". See the long note there.
    /**
     * Show or set the PRIVACY POLICY the banner links to.
     *
     * The wider UK GDPR notice - who the controller is, what personal data is
     * processed, on what lawful basis, and what rights the visitor has. It sits
     * beside the cookie policy in the banner text rather than replacing it: a
     * privacy notice does not on its own tell a visitor which cookies are set or
     * how long they last, which is what PECR asks for.
     *
     * Both links are optional and independent. Set neither and the banner renders
     * with no links at all; set one and only that one appears. There is never an
     * empty or `#` link, because a link that goes nowhere looks like the
     * information is there.
     *
     * Validation goes through BannerRenderer::normalise_policy_url() - the SAME
     * rule as the cookie policy and as the banner. There is deliberately no
     * second notion here of what a renderable URL is.
     *
     * ## OPTIONS
     *
     * [<url>]
     * : An http(s) URL, or a root-relative path such as /privacy-policy. Omit to
     * print the URL currently stored.
     *
     * [--clear]
     * : Remove the stored URL. The banner then renders with no privacy link.
     *
     * ## EXAMPLES
     *
     *     wp bulldogs consent privacy-url
     *     wp bulldogs consent privacy-url https://example.com/privacy-policy
     *     wp bulldogs consent privacy-url --clear
     *
     * @subcommand privacy-url
     *
     * @param array $args  Positional arguments. $args[0] is the URL to store.
     * @param array $assoc Associative arguments.
     */
    public function privacy_url( $args, $assoc ): void {
        // ⚠️ POSITIONAL, for the same reason policy-url is - and note the trap is
        // not limited to `url`: WP-CLI's reserved globals are a list that has grown
        // before. Both commands take the same shape rather than betting on it
        // staying still.
        self::store_url( $args, $assoc, 'privacy_url', 'privacy policy' );
    }

    /**
     * The show/set/clear body both URL commands share.
     *
     * ONE implementation, because the two commands must be indistinguishable in
     * behaviour: same validation rule, same read-back-through-the-rule, same
     * clear-wins ordering, same refusal messages. A copy would drift, and the
     * drift would be silent - one command accepting a URL the banner will not
     * render is exactly the failure that made policy-url a no-op on every install.
     *
     * @param array  $args  WP-CLI positional arguments.
     * @param array  $assoc WP-CLI associative arguments.
     * @param string $key   The Settings key to read and write.
     * @param string $label What to call this document in the operator's output.
     */
    private static function store_url( $args, $assoc, string $key, string $label ): void {
        $settings = new Settings();

        // Checked before the URL so `--clear https://...` cannot half-apply: clearing
        // wins, and the operator sees which one happened.
        if ( ! empty( $assoc['clear'] ) ) {
            $settings->set( $key, '' );
            WP_CLI::success( sprintf( 'Cleared the %s URL. The banner will render without that link.', $label ) );
            return;
        }

        if ( ! isset( $args[0] ) ) {
            // Read back through the same rule, so a hand-edited or migrated option
            // holding something the banner will not render reports as unset here
            // rather than being echoed back as if it were live.
            $current = BannerRenderer::normalise_policy_url( $settings->get( $key, '' ) );
            if ( null === $current ) {
                WP_CLI::warning( sprintf( 'No usable %s URL set - the banner renders without that link.', $label ) );
                return;
            }
            WP_CLI::line( $current );
            return;
        }

        $url = BannerRenderer::normalise_policy_url( $args[0] );
        if ( null === $url ) {
            // The `return` matters for the same reason it does in add(): error()
            // halts today, but a null walking into set() is a corrupt option.
            WP_CLI::error( 'the URL must be an http(s) URL or a root-relative path like /cookie-policy (use --clear to remove it)' );
            return;
        }

        $settings->set( $key, $url );
        WP_CLI::success( sprintf( '%s URL set to %s.', ucfirst( $label ), $url ) );
    }

    // ⚠️ Same wrapped-description trap as policy-url above: a continuation line in
    // the ## OPTIONS block must NOT begin with ": ". See the long note there.
    /**
     * Show or set the banner's visual preset.
     *
     * The banner ships two complete palettes of its own rather than inheriting the
     * host theme's colours. Inheriting is what put raspberry-pink Accept and Reject
     * buttons on the pilot site: Elementor's kit styles `button` at a specificity
     * our old `color: inherit` rule could not beat.
     *
     * Pick the one that matches the site's page furniture - `light` for a site with
     * a light background, `dark` for a dark one. Both meet WCAG AA, and both render
     * Accept and Reject identically; there is no preset in which refusing is harder
     * than accepting, and there never may be.
     *
     * Validation goes through BannerRenderer::normalise_theme(), the same method the
     * renderer uses, so this command cannot report success on a value the banner
     * would silently ignore.
     *
     * ## OPTIONS
     *
     * [<theme>]
     * : light or dark. Omit to print the preset currently in force.
     *
     * [--clear]
     * : Remove the stored preset. The banner falls back to light.
     *
     * ## EXAMPLES
     *
     *     wp bulldogs consent banner-theme
     *     wp bulldogs consent banner-theme dark
     *     wp bulldogs consent banner-theme --clear
     *
     * @subcommand banner-theme
     *
     * @param array $args  Positional arguments. $args[0] is the preset to store.
     * @param array $assoc Associative arguments.
     */
    public function banner_theme( $args, $assoc ): void {
        $settings = new Settings();

        // Checked first so `--clear dark` cannot half-apply, exactly as in policy_url.
        if ( ! empty( $assoc['clear'] ) ) {
            $settings->set( 'banner_theme', '' );
            WP_CLI::success( sprintf( 'Cleared the banner theme. The banner renders in %s.', BannerRenderer::DEFAULT_THEME ) );
            return;
        }

        // ⚠️ POSITIONAL. `theme` is not a WP-CLI global today, but `url` was not
        // obviously one either until `policy-url` shipped as a silent no-op on every
        // install - so this command takes the same shape as the one next to it
        // rather than betting on a reserved-word list staying still.
        if ( ! isset( $args[0] ) ) {
            // Read back through the same rule the renderer uses, so a hand-edited
            // option holding something unusable reports the fallback that will
            // actually render rather than echoing the junk back as if it were live.
            $stored  = BannerRenderer::normalise_theme( $settings->get( 'banner_theme', null ) );
            $current = $stored ?? BannerRenderer::DEFAULT_THEME;

            WP_CLI::line( $current );
            if ( null === $stored ) {
                WP_CLI::log( sprintf( 'No theme stored - this is the %s default.', BannerRenderer::DEFAULT_THEME ) );
            }
            return;
        }

        $theme = BannerRenderer::normalise_theme( $args[0] );
        if ( null === $theme ) {
            // The `return` matters for the same reason it does in add(): error()
            // halts today, but a null walking into set() is a corrupt option.
            WP_CLI::error( 'the theme must be one of: ' . implode( ', ', BannerRenderer::THEMES ) . ' (use --clear to remove it)' );
            return;
        }

        $settings->set( 'banner_theme', $theme );
        WP_CLI::success( sprintf( 'Banner theme set to %s.', $theme ) );
    }

    /**
     * Insert or replace a tag, in place.
     *
     * Replacing in position rather than remove-and-append is deliberate: tags are
     * emitted in registry order, and script order matters on a page (a consent-mode
     * default has to run before the tag it configures). Re-running the rollout script
     * to update a tag's markup must not silently reorder the page.
     *
     * Any further entries sharing the id are dropped - a duplicate id would otherwise
     * be emitted twice and could not be removed in one pass.
     *
     * @param array       $tags     Raw registry entries. Unvalidated - may contain anything.
     * @param string      $id       Tag id, already normalised.
     * @param string      $category Consent category, already validated.
     * @param string      $markup   Script markup.
     * @param string|null $label    Display name, already normalised, or null. When
     *                              null the `label` key is OMITTED rather than
     *                              written empty: an absent key is the shape every
     *                              entry across the fleet already has, and
     *                              TagRegistry::is_valid_entry() is shared with
     *                              VersionStamp, so writing a key where there was
     *                              none changes the stored entry on what an
     *                              operator experienced as a routine re-register.
     * @return array Normalised list.
     */
    public static function upsert( array $tags, string $id, string $category, string $markup, ?string $label = null ): array {
        $entry = [ 'id' => $id, 'category' => $category, 'markup' => $markup ];
        if ( null !== $label ) {
            $entry['label'] = $label;
        }

        $replaced = false;
        $out      = [];

        foreach ( $tags as $existing ) {
            if ( $id !== self::entry_id( $existing ) ) {
                $out[] = $existing;
                continue;
            }
            if ( ! $replaced ) {
                $out[]    = $entry;
                $replaced = true;
            }
        }

        if ( ! $replaced ) {
            $out[] = $entry;
        }

        return $out;
    }

    /**
     * The registry without any entry carrying this id.
     *
     * Entries whose id cannot be read at all (not an array, id missing, id not a
     * scalar) are KEPT. They are junk TagRegistry already drops at read time, and a
     * remove of one named tag silently deleting unrelated stored data is the worse
     * outcome.
     *
     * @param array  $tags Raw registry entries. Unvalidated.
     * @param string $id   Tag id, already normalised.
     */
    public static function without( array $tags, string $id ): array {
        return array_values(
            array_filter( $tags, static fn ( $entry ) => $id !== self::entry_id( $entry ) )
        );
    }

    /**
     * The id an operator would have to type to address this entry, or null if the
     * entry has no readable id.
     *
     * The is_scalar() gate is load-bearing: (string) on an array raises a notice and
     * yields "Array", and on an object without __toString it throws an Error. Either
     * would come from nothing worse than a corrupt option.
     */
    private static function entry_id( mixed $entry ): ?string {
        if ( ! is_array( $entry ) || ! isset( $entry['id'] ) || ! is_scalar( $entry['id'] ) ) {
            return null;
        }
        // Stored ids should be strings, but an older or hand-edited option may hold an
        // int. Comparing as strings means `--id=5` still matches a stored 5.
        return (string) $entry['id'];
    }

    /**
     * A usable tag id from a WP-CLI argument, or null.
     *
     * Note the '' === trim() test rather than empty(): TagRegistry deliberately accepts
     * the string '0' as a valid id, so rejecting it here would leave the one supported
     * configuration surface unable to create a tag the registry is documented to allow.
     */
    public static function normalise_id( mixed $value ): ?string {
        // A bare `--id` flag arrives as boolean true, not a string. Treat that as absent
        // rather than casting it to the id "1".
        if ( ! is_string( $value ) ) {
            return null;
        }
        $id = trim( $value );
        return '' === $id ? null : $id;
    }

    /**
     * A usable display name from a WP-CLI argument, or null for "no label".
     *
     * Null rather than '' throughout, because the difference is what upsert()
     * branches on: an empty string would be written into the entry and change the
     * stored shape, whereas null leaves the key off exactly as it has always been.
     *
     * Trimmed for the same reason the theme is: the value comes from a shell, and a
     * rollout script that pastes `Meta Pixel\n` is not making a mistake worth
     * failing over. Unlike normalise_id() there is no '0' special case to protect -
     * a service called "0" is not a thing, and treating a lone zero as absent is
     * the safer read of a stray argument.
     */
    public static function normalise_label( mixed $value ): ?string {
        // A bare `--label` flag arrives as boolean true. Casting that would print
        // the digit 1 at visitors as the name of a company.
        if ( ! is_string( $value ) ) {
            return null;
        }
        $label = trim( $value );
        return '' === $label ? null : $label;
    }

    /** A recognised consent category from a WP-CLI argument, or null. */
    public static function normalise_category( mixed $value ): ?string {
        if ( ! is_string( $value ) ) {
            return null;
        }
        $category = trim( $value );
        return in_array( $category, TagRegistry::CATEGORIES, true ) ? $category : null;
    }

    /**
     * The requested list fields, or null if any of them is not a field we have.
     *
     * @return string[]|null
     */
    private static function normalise_fields( mixed $value ): ?array {
        if ( null === $value ) {
            return [ 'id', 'category' ];
        }
        if ( ! is_string( $value ) ) {
            return null;
        }

        $fields = array_values(
            array_filter( array_map( 'trim', explode( ',', $value ) ), static fn ( $f ) => '' !== $f )
        );
        if ( [] === $fields || [] !== array_diff( $fields, self::LIST_FIELDS ) ) {
            return null;
        }
        return $fields;
    }
}

/**
 * `wp bulldogs monitor ...`
 *
 * The reporting side of the plugin, from the operator's end. Same standing
 * constraint as Commands above: there is no admin UI and none is planned, so
 * anything an agent needs to do during the rollout SOP has to be doable here.
 *
 * ---------------------------------------------------------------------------
 * `scan` DELEGATES. IT DOES NOT REIMPLEMENT.
 * ---------------------------------------------------------------------------
 * RestController::force_scan() is the one scan path, and this command calls it.
 * A second, simpler implementation here is the obvious thing to write and would
 * be wrong in three specific ways at once:
 *
 *   1. It would not pass site_kit_active() to Scanner, so the Site Kit exemption
 *      would not apply and every one of the 24 Site Kit sites would report a
 *      permanent High "unregistered tracker" for its own GA4 tag.
 *   2. It would not pass consent_mode_on(), so the site_kit_consent_mode_off
 *      finding - a real, one-toggle compliance break - would never fire.
 *   3. It would scan the home page only, so a tag on the single-post template
 *      would be invisible to the command a human actually runs.
 *
 * The endpoint would meanwhile be right about all three. Two monitors disagreeing
 * about whether a site is compliant is worse than one, because the cheaper one is
 * the one people check.
 *
 * ---------------------------------------------------------------------------
 * NAMESPACE
 * ---------------------------------------------------------------------------
 * This file is Bulldogs\SiteWorker\CLI. Every monitor class named below is
 * imported in the `use` block at the top of the file. Without the import, `new
 * SiteSecret(...)` resolves to Bulldogs\SiteWorker\CLI\SiteSecret, which does not
 * exist, and the command fatals on a live site during the rollout.
 */
class MonitorCommands {
    /** Fields `scan` prints. */
    private const SCAN_FIELDS = [ 'severity', 'type', 'urls', 'detail' ];

    /** Read order for a human: the things that need doing first, first. */
    private const SEVERITY_ORDER = [
        Scanner::SEVERITY_HIGH   => 0,
        Scanner::SEVERITY_MEDIUM => 1,
        Scanner::SEVERITY_LOW    => 2,
    ];

    /**
     * Print this site's monitoring secret, generating one if it has none.
     *
     * Step 9 of the per-site SOP: read this over SSH and register it against the
     * site record in WP Fleet. Until it is registered the endpoint 403s everything,
     * which is the intended state, not a fault.
     *
     * Generating on read rather than erroring is deliberate. Activation creates the
     * secret, but a site that was activated by an older build, or restored from a
     * backup taken before this version, would otherwise leave the operator with an
     * error and no way forward from the only supported interface.
     *
     * ## OPTIONS
     *
     * [--porcelain]
     * : Print only the secret, with no surrounding text, for piping into a script.
     *
     * ## EXAMPLES
     *
     *     wp bulldogs monitor secret
     *     wp bulldogs monitor secret --porcelain
     *
     * @param array $args  Positional arguments. Unused.
     * @param array $assoc Associative arguments.
     */
    public function secret( $args, $assoc ): void {
        $secret = ( new SiteSecret( new Settings() ) )->ensure();

        if ( ! empty( $assoc['porcelain'] ) ) {
            WP_CLI::line( $secret );
            return;
        }

        WP_CLI::line( $secret );
        WP_CLI::log( 'Register this against the site record in WP Fleet. Until then the findings endpoint returns 403.' );
    }

    /**
     * Replace this site's monitoring secret.
     *
     * The old value stops working immediately, so WP Fleet's copy must be updated
     * in the same sitting or collection for this site starts failing.
     *
     * ## OPTIONS
     *
     * [--porcelain]
     * : Print only the new secret, with no surrounding text.
     *
     * ## EXAMPLES
     *
     *     wp bulldogs monitor rotate
     *
     * @param array $args  Positional arguments. Unused.
     * @param array $assoc Associative arguments.
     */
    public function rotate( $args, $assoc ): void {
        $secret = ( new SiteSecret( new Settings() ) )->rotate();

        if ( ! empty( $assoc['porcelain'] ) ) {
            WP_CLI::line( $secret );
            return;
        }

        WP_CLI::line( $secret );
        WP_CLI::warning( 'The previous secret no longer works. Update the site record in WP Fleet now, or collection for this site will 403.' );
    }

    /**
     * Run a drift scan now and print what it found.
     *
     * Ignores the polling interval - this is the operator asking, not a pull. The
     * result is stored, so the next pull inside the interval will serve exactly
     * what is printed here.
     *
     * A clean result means "nothing wrong in what WordPress rendered". It does not
     * mean the site is fine: edge-injected tags and tags loaded by other tags are
     * structurally invisible to a server-side scan. Those are the harness's job.
     *
     * ## OPTIONS
     *
     * [--format=<format>]
     * : Render output in a particular format.
     * ---
     * default: table
     * options:
     *   - table
     *   - json
     *   - csv
     *   - yaml
     *   - count
     * ---
     *
     * ## EXAMPLES
     *
     *     wp bulldogs monitor scan
     *     wp bulldogs monitor scan --format=json
     *
     * @param array $args  Positional arguments. Unused.
     * @param array $assoc Associative arguments.
     */
    public function scan( $args, $assoc ): void {
        $format   = isset( $assoc['format'] ) && is_string( $assoc['format'] ) ? $assoc['format'] : 'table';
        $findings = self::controller()->force_scan();

        if ( [] === $findings ) {
            // Not an error, and not silence either: an empty table tells the
            // operator nothing about whether the scan ran.
            WP_CLI::success( 'No findings in what WordPress rendered. Run the harness for what a server-side scan cannot see.' );
            return;
        }

        \WP_CLI\Utils\format_items( $format, self::rows( $findings ), self::SCAN_FIELDS );
    }

    /**
     * Findings as flat printable rows, highest severity first.
     *
     * Pure and static so it can be tested: everything else on this class touches
     * WP_CLI or the database and cannot be exercised without a real install.
     *
     * Nothing is cast. A findings row round-trips through an option, so 'urls' may
     * be a string and 'detail' may be an object on a corrupted store; (string) on
     * the latter throws, and a `wp` command fatalling mid-rollout across 29 sites
     * is the failure this whole file is written to avoid.
     *
     * @param array<int, mixed> $findings
     * @return array<int, array{severity:string, type:string, urls:string, detail:string}>
     */
    public static function rows( array $findings ): array {
        $rows = [];

        foreach ( $findings as $finding ) {
            if ( ! is_array( $finding ) ) {
                continue;
            }

            $urls = [];
            if ( isset( $finding['urls'] ) && is_array( $finding['urls'] ) ) {
                foreach ( $finding['urls'] as $url ) {
                    if ( is_string( $url ) && '' !== $url ) {
                        $urls[] = $url;
                    }
                }
            }

            $rows[] = [
                'severity' => self::text( $finding, 'severity' ),
                'type'     => self::text( $finding, 'type' ),
                'urls'     => implode( ' ', $urls ),
                'detail'   => self::text( $finding, 'detail' ),
            ];
        }

        // Stable since PHP 8.0, so findings of equal severity keep scan order -
        // which is page order, and therefore the order someone reading the source
        // would find them in.
        usort(
            $rows,
            static fn ( array $a, array $b ): int => self::rank( $a['severity'] ) <=> self::rank( $b['severity'] )
        );

        return $rows;
    }

    /** An unknown severity sorts last rather than being dropped or crashing. */
    private static function rank( string $severity ): int {
        return self::SEVERITY_ORDER[ $severity ] ?? count( self::SEVERITY_ORDER );
    }

    /** @param array<string, mixed> $finding */
    private static function text( array $finding, string $key ): string {
        return isset( $finding[ $key ] ) && is_string( $finding[ $key ] ) ? $finding[ $key ] : '';
    }

    /**
     * The one wiring of the scan path, shared by every command here.
     *
     * A fresh TagRegistry rather than the one the consent module built: that one is
     * memoised for a page render, and a long-running WP-CLI process that has just
     * changed the registry must not scan against a stale copy.
     */
    private static function controller(): RestController {
        $settings = new Settings();
        $registry = new TagRegistry( $settings );

        return new RestController(
            $settings,
            new SiteSecret( $settings ),
            new FindingsStore( $settings ),
            new Scanner(),
            new BannerCategories( $registry )
        );
    }
}
