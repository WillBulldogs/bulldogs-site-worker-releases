<?php
namespace Bulldogs\SiteWorker\Monitor;

use Bulldogs\SiteWorker\Consent\BannerCategories;
use Bulldogs\SiteWorker\Settings;

/**
 * `GET /wp-json/bulldogs-sw/v1/findings` - the surface WP Fleet pulls.
 *
 * ---------------------------------------------------------------------------
 * PULL, NOT PUSH, AND WHAT THAT COSTS
 * ---------------------------------------------------------------------------
 * WP Fleet collects from the sites rather than the sites reporting in: cadence
 * stays central, client sites need no outbound access, and a compromised site
 * cannot flood the central store. The cost is that this is the ONE new
 * externally-reachable surface the plugin adds, on 29 public client sites, so
 * every decision below is about keeping that surface boring.
 *
 *   - Findings only. Never the registry, never the policy URL, never a consent
 *     record. A read of this endpoint must not tell an attacker how the site is
 *     configured or who consented to what.
 *   - show_in_index => false. The route still works; it just is not advertised in
 *     the public /wp-json/ discovery document. Not a security control - the path
 *     is in this file and this plugin is on 29 sites - but there is no reason to
 *     publish it either.
 *   - 403 before a secret is registered, and 403 on every wrong header. See
 *     SiteSecret: verify() fails closed when nothing is stored.
 *
 * ---------------------------------------------------------------------------
 * IT TRIGGERS A SCAN, SO IT IS RATE LIMITED. THIS IS THE IMPORTANT PART.
 * ---------------------------------------------------------------------------
 * WP-Cron is unreliable on low-traffic sites, so the pull has to be able to
 * trigger the work. That makes a GET side-effecting AND resource-amplifying: one
 * cheap request causes several loopback HTTP requests, each rendering a full
 * WordPress page, on a shared cPanel box with LVE limits and ~33 vhosts. Polled
 * in a loop, unguarded, this is a self-inflicted denial of service against the
 * whole box - not just the site.
 *
 * So the endpoint serves CACHED findings and re-scans at most once per interval,
 * however often it is polled, and FindingsStore::claim() marks the slot taken
 * before the scan starts rather than after it finishes.
 *
 * ⚠️ A scan holds its own PHP worker while it loopback-fetches, which is the same
 * shape as the well-known WP-Cron/Site Health loopback problem: on an account with
 * very few workers, a request that waits on the site serving itself can stall. The
 * bound is deliberate and small - at most three URLs, FETCH_TIMEOUT seconds each -
 * so the worst case is one worker held for about half a minute, once per interval,
 * rather than indefinitely. If a site is ever measured to deadlock on this, the fix
 * is to move the scan onto a cron trigger and leave this endpoint read-only; the
 * pull can trigger it because WP-Cron is unreliable on low-traffic sites, which is
 * a trade made knowingly rather than by omission.
 *
 * ---------------------------------------------------------------------------
 * WHY SEVERAL URLs, AND WHY THE ABSENT-TAG FINDING IS THE ODD ONE OUT
 * ---------------------------------------------------------------------------
 * Scanning the home page alone means a tag added to the single-post template, or
 * a theme that swallows the banner on pages but not the front page, is invisible.
 * So home, the newest published post and the newest published page are all
 * scanned and their findings unioned.
 *
 * `registered_tag_absent` cannot be unioned, and this is the subtle one. It means
 * "a tag we registered did not render". Unioned across three URLs, a tag that is
 * correctly emitted on two of them still produces a finding from the third, and
 * the detector that exists to catch a lying registry instead reports every tag
 * that is conditional on template. So that one type is INTERSECTED: reported only
 * when the tag was absent from every URL that could be scanned.
 *
 * ---------------------------------------------------------------------------
 * THE SCAN READS WHAT VISITORS GET, CACHE AND ALL
 * ---------------------------------------------------------------------------
 * The loopback fetch deliberately does NOT bust the page cache. WP Rocket or
 * AccelerateWP serving a stale page to a visitor IS the visitor's experience, and
 * a scanner that cache-busts would have reported the pilot site healthy while
 * every real visitor got the broken cached copy. The trade is that findings lag
 * the cache lifetime after a change, which the SOP already handles by purging.
 */
class RestController {
    /** Not `NAMESPACE`: legal as a class constant, but confusing next to the keyword. */
    public const REST_NAMESPACE = 'bulldogs-sw/v1';
    public const ROUTE          = '/findings';

    /**
     * Deliberately a custom header rather than Authorization. Apache/LiteSpeed
     * under CGI routinely strip Authorization before PHP sees it, which would
     * present as an intermittent 403 that reproduces on some sites and not others.
     */
    public const HEADER = 'x-bsw-secret';

    /** Seconds between scans. */
    public const DEFAULT_INTERVAL = 900;

    /**
     * Floor on the configured interval. The interval is readable from the option
     * store, and an option that has been hand-edited, migrated or corrupted to 0
     * would turn the rate limit off entirely - re-creating exactly the
     * amplification the limit exists to prevent. A floor means the worst a bad
     * value can do is scan more often than we intended, not on every request.
     */
    public const MIN_INTERVAL = 300;

    /** Settings key for the override. There is no CLI command for it yet, by design. */
    public const KEY_INTERVAL = 'scan_interval';

    /** Emitted by this class, not Scanner: it describes the scan, not the site. */
    public const TYPE_SCAN_UNAVAILABLE = 'scan_unavailable';

    private const FETCH_TIMEOUT = 10;

    public function __construct(
        private Settings $settings,
        private SiteSecret $secret,
        private FindingsStore $store,
        private Scanner $scanner,
        private BannerCategories $categories
    ) {}

    /** Hooked to rest_api_init. */
    public function register_routes(): void {
        if ( ! function_exists( 'register_rest_route' ) ) {
            return;
        }

        register_rest_route(
            self::REST_NAMESPACE,
            self::ROUTE,
            [
                [
                    // The literal, not WP_REST_Server::READABLE. Same value, and it
                    // does not make this file depend on a class being loaded.
                    'methods'             => 'GET',
                    'callback'            => [ $this, 'handle' ],
                    'permission_callback' => [ $this, 'permission_check' ],
                    'show_in_index'       => false,
                    'args'                => [],
                ],
            ]
        );
    }

    /**
     * true, or a WP_Error carrying a 403.
     *
     * Not type-hinted to WP_REST_Request on purpose: that class does not exist
     * outside a real install, so hinting it would make the callback impossible to
     * exercise in the unit suite - and this is the one method on the plugin's only
     * public surface that must not be taken on trust. The shape is checked instead.
     *
     * @param mixed $request WP_REST_Request in production.
     * @return true|\WP_Error
     */
    public function permission_check( $request ) {
        if ( $this->secret->verify( $this->header_from( $request ) ) ) {
            return true;
        }

        // An explicit WP_Error rather than returning false: false yields a 401 with
        // WordPress's own wording, which reads as "log in" and sends the operator
        // hunting for a user account that does not exist.
        return new \WP_Error(
            'bulldogs_sw_forbidden',
            'A valid ' . self::HEADER . ' header is required.',
            [ 'status' => 403 ]
        );
    }

    /**
     * The response body: findings, when they were gathered, and the plugin version.
     *
     * A plain array. WordPress wraps a returned array in a WP_REST_Response itself,
     * and not calling rest_ensure_response() keeps this method callable in the
     * suite without another stub.
     *
     * @param mixed $request Unused. Present because WordPress passes it.
     * @return array{findings:array, last_scan:int, version:string}
     */
    public function handle( $request = null ): array {
        $now = time();

        $findings = $this->store->is_scan_due( $this->interval(), $now )
            ? $this->force_scan( $now )
            : $this->store->findings();

        return [
            'findings'  => $findings,
            // Read AFTER the scan, so a response that just re-scanned reports the
            // scan it is returning rather than the one before it.
            'last_scan' => $this->store->last_scan(),
            'version'   => defined( 'BULLDOGS_SW_VERSION' ) ? BULLDOGS_SW_VERSION : 'unknown',
        ];
    }

    /**
     * Scan now, ignoring the interval, and store the result.
     *
     * Public so `wp bulldogs monitor scan` runs THIS code rather than a second,
     * simpler implementation of it. That is not tidiness: a hand-rolled CLI scan
     * would not pass site_kit_active() to Scanner, and Scanner without the Site Kit
     * exemption reports a permanent High "unregistered tracker" on all 24 Site Kit
     * sites. The CLI and the endpoint would then disagree about whether the fleet
     * was compliant, and the CLI is the one a human looks at.
     *
     * @return array<int, array{type:string, severity:string, detail:string, urls:string[]}>
     */
    public function force_scan( ?int $now = null ): array {
        $now = $now ?? time();

        // Before the work, not after. See FindingsStore::claim().
        $this->store->claim( $now );

        $findings = $this->scan();
        $this->store->save( $findings, $now );

        // Read back rather than returning $findings directly, so the caller sees
        // exactly what a later pull will see - capped and normalised included.
        return $this->store->findings();
    }

    /**
     * @return array<int, array{type:string, severity:string, detail:string, urls:string[]}>
     */
    private function scan(): array {
        $urls = $this->representative_urls();

        // Raw, straight from the option. Scanner validates rows itself with
        // TagRegistry::is_valid_entry - the same single rule the emitter uses -
        // so handing it a pre-filtered list would be a second opinion that could
        // drift from what the page actually renders.
        $registry = $this->settings->get( 'tags', [] );
        $registry = is_array( $registry ) ? $registry : [];

        $site_kit          = $this->categories->site_kit_active();
        $consent_mode      = $this->categories->consent_mode_on();
        $banner_categories = $this->categories->all();

        $per_url = [];
        $failed  = [];

        foreach ( $urls as $url ) {
            $html = $this->fetch( $url );
            if ( null === $html ) {
                $failed[] = $url;
                continue;
            }
            $per_url[ $url ] = $this->scanner->analyse( $html, $registry, $site_kit, $consent_mode, $banner_categories );
        }

        $findings = $this->merge( $per_url );

        if ( [] !== $failed ) {
            // A scanner that cannot see the site must say so. Reporting "no
            // findings" because every fetch failed is the failure mode where a
            // monitor is worse than no monitor: it reads as a clean bill of health.
            array_unshift(
                $findings,
                [
                    'type'     => self::TYPE_SCAN_UNAVAILABLE,
                    'severity' => [] === $per_url ? Scanner::SEVERITY_MEDIUM : Scanner::SEVERITY_LOW,
                    'detail'   => [] === $per_url
                        ? 'No representative URL could be fetched, so nothing was checked. This result is '
                            . '"we cannot see the site", not "the site is fine". Usually a blocked loopback '
                            . 'request, HTTP auth on a staging site, or a firewall rule.'
                        : sprintf( 'Some representative URLs could not be fetched, so they were not checked: %s.', implode( ', ', $failed ) ),
                    'urls'     => $failed,
                ]
            );
        }

        return $findings;
    }

    /**
     * Union the per-URL findings, except for the absent-tag type, which is
     * intersected. See the class docblock for why those two differ.
     *
     * @param array<string, array<int, array{type:string, severity:string, detail:string}>> $per_url
     * @return array<int, array{type:string, severity:string, detail:string, urls:string[]}>
     */
    private function merge( array $per_url ): array {
        $scanned = count( $per_url );
        $merged  = [];

        foreach ( $per_url as $url => $findings ) {
            foreach ( $findings as $finding ) {
                if ( ! is_array( $finding ) || ! isset( $finding['type'], $finding['severity'], $finding['detail'] ) ) {
                    continue;
                }
                if ( ! is_string( $finding['type'] ) || ! is_string( $finding['severity'] ) || ! is_string( $finding['detail'] ) ) {
                    continue;
                }

                // Keyed on type AND detail, so two different unregistered trackers
                // stay two findings while the same one seen on three URLs stays one.
                // "\0" cannot occur in either, so the key cannot be forged by a
                // detail string that happens to contain the separator.
                $key = $finding['type'] . "\0" . $finding['detail'];

                if ( ! isset( $merged[ $key ] ) ) {
                    $merged[ $key ] = [
                        'type'     => $finding['type'],
                        'severity' => $finding['severity'],
                        'detail'   => $finding['detail'],
                        'urls'     => [],
                    ];
                }
                if ( ! in_array( $url, $merged[ $key ]['urls'], true ) ) {
                    $merged[ $key ]['urls'][] = $url;
                }
            }
        }

        $out = [];
        foreach ( $merged as $finding ) {
            if ( Scanner::TYPE_REGISTERED_TAG_ABSENT === $finding['type'] && count( $finding['urls'] ) < $scanned ) {
                continue;
            }
            $out[] = $finding;
        }

        return $out;
    }

    /**
     * Home, the newest published post, the newest published page.
     *
     * Deduplicated, because a site with a static front page returns the same URL
     * for home and for its newest page on plenty of configurations, and scanning it
     * twice is a loopback request paid for nothing.
     *
     * @return string[]
     */
    private function representative_urls(): array {
        $urls = [];

        if ( function_exists( 'home_url' ) ) {
            $home = home_url( '/' );
            if ( is_string( $home ) && '' !== $home ) {
                $urls[] = $home;
            }
        }

        foreach ( [ 'post', 'page' ] as $type ) {
            $permalink = $this->newest_permalink( $type );
            if ( null !== $permalink ) {
                $urls[] = $permalink;
            }
        }

        return array_values( array_unique( $urls ) );
    }

    /** The newest published permalink of one post type, or null when there is none. */
    private function newest_permalink( string $type ): ?string {
        if ( ! function_exists( 'get_posts' ) || ! function_exists( 'get_permalink' ) ) {
            return null;
        }

        $ids = get_posts(
            [
                'post_type'        => $type,
                'post_status'      => 'publish',
                'numberposts'      => 1,
                'orderby'          => 'date',
                'order'            => 'DESC',
                'fields'           => 'ids',
                'no_found_rows'    => true,
                'suppress_filters' => false,
            ]
        );

        if ( ! is_array( $ids ) || [] === $ids || ! isset( $ids[0] ) ) {
            return null;
        }

        $permalink = get_permalink( $ids[0] );
        return is_string( $permalink ) && '' !== $permalink ? $permalink : null;
    }

    /** The rendered HTML of one URL, or null if it could not be read. */
    private function fetch( string $url ): ?string {
        if ( ! function_exists( 'wp_remote_get' ) ) {
            return null;
        }

        $response = wp_remote_get(
            $url,
            [
                'timeout'     => self::FETCH_TIMEOUT,
                'redirection' => 3,
                // A loopback to ourselves. On a box where the site's certificate is
                // issued for the public hostname but the request resolves locally,
                // verification fails and the scanner goes permanently blind while
                // reporting nothing wrong - the worst available outcome.
                'sslverify'   => false,
                // Identifiable in the access log, so "what is hitting the site every
                // 15 minutes" has an answer that is not an investigation.
                'headers'     => [ 'X-Bulldogs-SW-Scan' => '1' ],
            ]
        );

        if ( function_exists( 'is_wp_error' ) && is_wp_error( $response ) ) {
            return null;
        }

        $code = function_exists( 'wp_remote_retrieve_response_code' ) ? wp_remote_retrieve_response_code( $response ) : 0;
        // is_scalar first: this returns '' on a malformed response, and (int) on an
        // array is a notice plus the value 1, which would read as a status code.
        if ( 200 !== ( is_scalar( $code ) ? (int) $code : 0 ) ) {
            return null;
        }

        $body = function_exists( 'wp_remote_retrieve_body' ) ? wp_remote_retrieve_body( $response ) : '';
        return is_string( $body ) && '' !== $body ? $body : null;
    }

    /** Seconds between scans, floored. See MIN_INTERVAL. */
    private function interval(): int {
        $stored = $this->settings->get( self::KEY_INTERVAL, null );

        if ( is_int( $stored ) ) {
            return max( self::MIN_INTERVAL, $stored );
        }
        if ( is_string( $stored ) && ctype_digit( $stored ) ) {
            return max( self::MIN_INTERVAL, (int) $stored );
        }

        return self::DEFAULT_INTERVAL;
    }

    /**
     * The secret offered by the request, or '' when there is not one to read.
     *
     * Trimmed because the SOP has an agent paste this into a curl header over SSH
     * and a trailing newline is the classic result. The generated secret is
     * alphanumeric (SiteSecret), so trimming cannot discard a meaningful character.
     */
    private function header_from( mixed $request ): string {
        if ( ! is_object( $request ) || ! method_exists( $request, 'get_header' ) ) {
            return '';
        }

        $value = $request->get_header( self::HEADER );
        return is_string( $value ) ? trim( $value ) : '';
    }
}
