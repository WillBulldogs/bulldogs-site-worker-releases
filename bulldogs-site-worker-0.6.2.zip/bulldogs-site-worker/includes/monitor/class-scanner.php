<?php
namespace Bulldogs\SiteWorker\Monitor;

use Bulldogs\SiteWorker\Consent\TagRegistry;

/**
 * Drift detection over rendered HTML. Pure: HTML in, findings out. No WordPress,
 * no options, no clock, no network - so it is testable, and so the module that
 * schedules it can decide separately how often it is worth paying for.
 *
 * ---------------------------------------------------------------------------
 * WHY THIS EXISTS AT ALL
 * ---------------------------------------------------------------------------
 * Every part of the consent module fails CLOSED: if our code breaks, tags stay
 * inert. Safe - but "compliant, and analytics silently dead" is precisely the
 * state the pilot site sat in for months with nobody noticing, and it is the
 * state this whole project exists to end. Detection is what makes a fail-closed
 * design acceptable rather than merely safe.
 *
 * ---------------------------------------------------------------------------
 * WHAT THIS SCANNER STRUCTURALLY CANNOT SEE. Read before trusting a clean run.
 * ---------------------------------------------------------------------------
 * 1. EDGE-INJECTED TAGS. Measured on the pilot site: a Search Atlas tracker
 *    (`dashboard.searchatlas.com`) is ABSENT from the origin response and
 *    PRESENT through Cloudflare. It is injected at the CDN edge. It exists in no
 *    file, no database row, no template, no plugin. This scanner runs inside
 *    WordPress, on the origin, so it cannot see it - not "does not currently",
 *    cannot. Only the browser harness, fetching through the CDN and watching real
 *    network requests, will ever find that class of tag.
 * 2. TAGS LOADED BY OTHER TAGS. A GTM container that injects GA4 is one line of
 *    HTML here and two trackers at runtime. Also harness-only.
 * 3. JS ERRORS, and `wp_consent_type` unset at runtime. Not server-side
 *    detectable at all - there is no runtime to inspect. Harness-only, and
 *    deliberately not faked here.
 *
 * A clean result from this scanner therefore means "nothing wrong in what
 * WordPress rendered", never "this site is fine".
 *
 * ---------------------------------------------------------------------------
 * DELIBERATELY NOT IMPLEMENTED (a decision, not a gap)
 * ---------------------------------------------------------------------------
 * The design lists a "new header-script plugin or snippet" finding. It is not
 * built, and should not be added here. Any such plugin that has actually been
 * used to paste a tag already surfaces as `unregistered_tracker` - the finding
 * that matters, naming the tracker rather than the vehicle. Detecting the plugin
 * WITHOUT a tag needs a plugin inventory, which fleet tooling already collects
 * across every site; duplicating it per-site would be a second, worse copy.
 *
 * ---------------------------------------------------------------------------
 * THE SITE KIT EXEMPTION
 * ---------------------------------------------------------------------------
 * Site Kit's own tag is deliberately never registered with TagRegistry. It keeps
 * emitting, ungated, governed by its own Consent Mode denied defaults; our plugin
 * only ever grants. So a naive "tracker present but not in the registry" check
 * raises a permanent High on all 24 Site-Kit sites and the drift signal is pure
 * noise from day one - the failure mode where a monitor is worse than no monitor,
 * because people learn to ignore it.
 *
 * The exemption is deliberately NARROWER than "ignore every Google domain on a
 * Site Kit site", which would blind the scanner to the single most common way a
 * tag gets pasted onto one of our sites. A hit on a Site-Kit-emitted domain is
 * exempt only when nothing in its context names a container id Site Kit does not
 * itself emit. Site Kit's GA4 and Ads tags carry `G-`/`GT-`/`AW-`/`UA-` ids, so
 * they are exempt; a hand-pasted `GTM-` container is reported.
 *
 * The residual cost is stated plainly: on a site running Site Kit's own Tag
 * Manager module, that container is reported once, permanently, until triage
 * registers it. That is a bounded, self-resolving false positive on a small
 * number of sites, traded against keeping the detector alive on all of them.
 */
class Scanner {
    public const TYPE_UNREGISTERED_TRACKER       = 'unregistered_tracker';
    public const TYPE_CONSENT_MODULE_UNHEALTHY   = 'consent_module_unhealthy';
    public const TYPE_SITE_KIT_CONSENT_MODE_OFF  = 'site_kit_consent_mode_off';
    public const TYPE_WITHDRAWAL_CONTROL_MISSING = 'withdrawal_control_missing';
    public const TYPE_REGISTERED_TAG_ABSENT      = 'registered_tag_absent';
    public const TYPE_SITE_KIT_CONSENT_REGION_SCOPED = 'site_kit_consent_region_scoped';

    public const SEVERITY_HIGH   = 'high';
    public const SEVERITY_MEDIUM = 'medium';
    public const SEVERITY_LOW    = 'low';

    /** Must stay in step with BannerRenderer::BANNER_ID. */
    private const BANNER_PATTERN = '/\bid\s*=\s*(["\'])bsw-banner\1/i';

    /** Must stay in step with BannerRenderer::render_withdrawal_control(). */
    private const REOPEN_PATTERN = '/\bdata-bsw-action\s*=\s*(["\'])reopen\1/i';

    /** Must stay in step with TagEmitter's data-bsw-id attribute. */
    private const EMITTED_ID_PATTERN = '/\bdata-bsw-id\s*=\s*(["\'])(.*?)\1/is';

    /**
     * Our consent CLIENT on the page - the file that carries the Clarity bridge.
     *
     * Matched on the script path and on the localized payload wp_localize_script
     * prints immediately before it, either of which is enough. Both are named in
     * our own `rocket_delay_js_exclusions` filter precisely so a cache plugin
     * cannot separate them, and matching either means a rewritten or concatenated
     * bundle still answers yes.
     *
     * 🚨 This is NOT "the banner is present". A site with no non-essential
     * categories renders no banner and still runs the client - the client is
     * enqueued on every front-end request, deliberately, so Site Kit is never
     * left waiting on an event nothing fires. Keying the Clarity exemption off
     * the banner would put a High back on exactly those sites.
     */
    private const CONSENT_CLIENT_PATTERN = '/assets\/js\/consent\.js|\bBulldogsSW\b/i';

    /**
     * Id prefix Site Kit does not emit from its GA4 or Ads modules. See the class
     * docblock: this is what keeps the Site Kit exemption from swallowing a
     * hand-pasted Tag Manager container.
     */
    private const SITE_KIT_FOREIGN_ID_PREFIX = 'GTM-';

    /**
     * The argument object of a `gtag( 'consent', 'default', {...} )` call.
     *
     * Non-greedy up to the first `}` is safe rather than lazy: Site Kit's defaults
     * object has no nested object - `region` is a flat ARRAY of ISO codes, and
     * every other value is a string or an int. Verified against the emitted
     * snippet on Site Kit 1.135.0.
     *
     * Matched on the CALL rather than on Site Kit's `id="google_gtagjs-js-consent-
     * mode-data-layer"` wrapper on purpose. The wrapper id is a second internal
     * that can be renamed, and a detector that silently stops looking when its
     * anchor moves is the failure mode this check exists to prevent.
     */
    private const CONSENT_DEFAULT_PATTERN = '/gtag\s*\(\s*([\'"])consent\1\s*,\s*([\'"])default\2\s*,\s*(\{[^{}]*\})/is';

    /** A `region` key inside that object. */
    private const CONSENT_REGION_KEY_PATTERN = '/([\'"])region\1\s*:/i';

    private TrackerList $trackers;

    public function __construct( ?TrackerList $trackers = null ) {
        $this->trackers = $trackers ?? new TrackerList();
    }

    /**
     * @param string $html              Rendered HTML of one representative URL.
     * @param array  $registry          Raw registry rows. NOT trusted - this may be the
     *                                  stored option straight from the database, so it may
     *                                  hold anything. Rows are validated with
     *                                  TagRegistry::is_valid_entry (the same single rule the
     *                                  emitter and the version stamp use) and anything that
     *                                  fails is ignored rather than cast, guessed at, or
     *                                  allowed to throw.
     * @param bool   $site_kit_active   BannerCategories::site_kit_active().
     * @param bool   $consent_mode_on   BannerCategories::consent_mode_on(). Defaults true so
     *                                  a caller that forgets it cannot manufacture a High.
     * @param array  $banner_categories BannerCategories::all() - NOT the registry. A
     *                                  Site-Kit-only site has an empty registry and still
     *                                  needs a banner, so banner health is keyed off this.
     *
     * @return array<int, array{type:string, severity:string, detail:string}>
     */
    public function analyse(
        string $html,
        array $registry,
        bool $site_kit_active = false,
        bool $consent_mode_on = true,
        array $banner_categories = []
    ): array {
        $findings = [];
        $entries  = $this->registry_entries( $registry );

        // Is the bridge that makes a self-gating tracker safe actually running?
        $consent_client = true === $this->matches( self::CONSENT_CLIENT_PATTERN, $html );

        foreach ( $this->unregistered( $html, $entries, $site_kit_active, $consent_client ) as $hit ) {
            $findings[] = [
                'type'     => self::TYPE_UNREGISTERED_TRACKER,
                'severity' => self::SEVERITY_HIGH,
                'detail'   => sprintf(
                    '%s (%s) is present in the page %s, and is not in the tag registry, so nothing gates it.',
                    $hit['label'],
                    $hit['domain'],
                    [] === $hit['ids']
                        ? 'with no container or measurement id in the surrounding markup'
                        : 'as ' . implode( ', ', $hit['ids'] )
                ),
            ];
        }

        // A banner is a dialog with a well-known id. Not "the plugin is active":
        // the plugin can be active and the theme still be swallowing the output,
        // which is the failure we are looking for.
        $banner_present = true === $this->matches( self::BANNER_PATTERN, $html );
        $categories     = $this->clean_categories( $banner_categories );

        if ( [] !== $categories && ! $banner_present ) {
            $findings[] = [
                'type'     => self::TYPE_CONSENT_MODULE_UNHEALTHY,
                'severity' => self::SEVERITY_HIGH,
                'detail'   => sprintf(
                    'This site should be asking about %s, but the page carries no id="bsw-banner". '
                    . 'Tracking is present, consent is impossible, and the tags stay denied: the site is '
                    . 'compliant with permanently dead analytics.',
                    implode( ', ', $categories )
                ),
            ];
        }

        if ( $site_kit_active && ! $consent_mode_on ) {
            $findings[] = [
                'type'     => self::TYPE_SITE_KIT_CONSENT_MODE_OFF,
                'severity' => self::SEVERITY_HIGH,
                'detail'   => 'Site Kit is active but its Consent Mode is switched off, so its tag never '
                    . 'receives the denied defaults and is not gated by anything. One wp-admin toggle '
                    . 'silently breaks the whole chain.',
            ];
        }

        foreach ( $this->region_scoped_consent_defaults( $html, $site_kit_active, $consent_mode_on ) as $regions ) {
            $findings[] = [
                'type'     => self::TYPE_SITE_KIT_CONSENT_REGION_SCOPED,
                'severity' => self::SEVERITY_MEDIUM,
                'detail'   => sprintf(
                    'Site Kit\'s denied defaults still carry a "region" key (%s), so they apply only to '
                    . 'visitors in those countries and its tag runs ungated everywhere else. The plugin '
                    . 'filters googlesitekit_consent_defaults to remove it, so this means the filter did '
                    . 'not apply: Site Kit renamed or dropped the hook, something hooked later put the '
                    . 'region back, or the consent module is not loading. Nothing errors when that '
                    . 'happens, which is why it is checked here.',
                    $regions
                ),
            ];
        }

        // Only meaningful when there is a banner: no banner is already reported
        // above, and reporting both would double-count one broken thing.
        if ( $banner_present && false === $this->matches( self::REOPEN_PATTERN, $html ) ) {
            $findings[] = [
                'type'     => self::TYPE_WITHDRAWAL_CONTROL_MISSING,
                'severity' => self::SEVERITY_MEDIUM,
                'detail'   => 'The banner is present but the page carries no data-bsw-action="reopen" '
                    . 'control, so a visitor who has consented has no way back. Withdrawing consent must '
                    . 'be as easy as giving it (ICO).',
            ];
        }

        foreach ( $this->absent_registered_ids( $html, $entries ) as $id ) {
            $findings[] = [
                'type'     => self::TYPE_REGISTERED_TAG_ABSENT,
                'severity' => self::SEVERITY_LOW,
                'detail'   => sprintf(
                    'Registered tag "%s" was not rendered on this page - no data-bsw-id="%s" in the '
                    . 'markup. Either the registry is lying or the tag is only emitted on other URLs.',
                    $id,
                    $id
                ),
            ];
        }

        return $findings;
    }

    /**
     * Tracker occurrences that no registry row accounts for.
     *
     * @param array<int, array{id:string, markup:string, ids:string[]}> $entries
     * @return array<int, array{label:string, domain:string, ids:string[]}>
     */
    private function unregistered( string $html, array $entries, bool $site_kit_active, bool $consent_client = false ): array {
        $out  = [];
        $seen = [];

        foreach ( $this->trackers->find( $html ) as $hit ) {
            if ( $this->is_registered( $hit, $entries ) ) {
                continue;
            }
            if ( $site_kit_active && $hit['site_kit'] && ! $this->names_a_foreign_id( $hit['ids'] ) ) {
                continue;
            }

            /*
             * 🚨 SELF-GATING TRACKERS. "Unregistered" and "ungated" are not the
             * same thing, and conflating them made this monitor cry wolf on most
             * of the fleet.
             *
             * Microsoft Clarity governs its own storage from the `consentv2`
             * signal our client sends it, so it is deliberately absent from the
             * registry - blocking its script would defeat the very mechanism that
             * makes it safe. Reported HIGH on every Clarity site, which is most of
             * them, the first thing anyone learned about this tool was that its
             * High findings are noise.
             *
             * The exemption is conditional on the BRIDGE, not on the vendor:
             * `$consent_client` says our client is on the page, which is the file
             * that carries the `clarity('consentv2', …)` call. Clarity present
             * with our client absent is still a finding, because then nothing is
             * bridging it - which is the case actually worth an alert.
             *
             * Same shape as the Site Kit exemption above, deliberately: a flag on
             * the tracker rather than a vendor name in an `if`, so the next one is
             * a data change.
             */
            if ( $consent_client && ! empty( $hit['self_gating'] ) ) {
                continue;
            }

            // One finding per tracker per id-set, not per occurrence. The stock
            // Tag Manager install prints the same container twice (the script and
            // the noscript iframe), and three copies of one finding trains the
            // reader to skim.
            $ids = $hit['ids'];
            sort( $ids );
            $key = $hit['label'] . '|' . implode( ',', $ids );
            if ( isset( $seen[ $key ] ) ) {
                continue;
            }
            $seen[ $key ] = true;

            $out[] = [ 'label' => $hit['label'], 'domain' => $hit['domain'], 'ids' => $hit['ids'] ];
        }

        return $out;
    }

    /**
     * Does any registry row account for this occurrence?
     *
     * Domain agreement alone is not enough. Two different Tag Manager containers
     * both contain `googletagmanager.com`, so a domain-only match means registering
     * one suppresses the finding for the other - the masking bug TrackerList::find
     * exists to prevent, re-introduced one layer up. Where BOTH sides name an id
     * they must agree; where either side names none, the domain is all there is to
     * go on and it has to do.
     *
     * @param array{label:string, domain:string, site_kit:bool, offset:int, context:string, ids:string[]} $hit
     * @param array<int, array{id:string, markup:string, ids:string[]}>                                   $entries
     */
    private function is_registered( array $hit, array $entries ): bool {
        foreach ( $entries as $entry ) {
            if ( ! $this->entry_names_tracker( $entry['markup'], $hit['label'] ) ) {
                continue;
            }
            if ( [] === $hit['ids'] || [] === $entry['ids'] ) {
                return true;
            }
            if ( [] !== array_intersect( $hit['ids'], $entry['ids'] ) ) {
                return true;
            }
        }
        return false;
    }

    /**
     * Matched on the tracker's whole domain set, not the one domain that happened
     * to hit. Meta's noscript pixel is on facebook.com/tr while the snippet
     * registered for it quotes connect.facebook.net; comparing domain-to-domain
     * would report a correctly registered pixel as unregistered.
     */
    private function entry_names_tracker( string $markup, string $label ): bool {
        foreach ( $this->trackers->all() as $tracker ) {
            if ( $tracker['label'] !== $label ) {
                continue;
            }
            foreach ( $tracker['domains'] as $domain ) {
                if ( false !== stripos( $markup, $domain ) ) {
                    return true;
                }
            }
        }
        return false;
    }

    /** @param string[] $ids */
    private function names_a_foreign_id( array $ids ): bool {
        foreach ( $ids as $id ) {
            if ( str_starts_with( $id, self::SITE_KIT_FOREIGN_ID_PREFIX ) ) {
                return true;
            }
        }
        return false;
    }

    /**
     * @param array<int, array{id:string, markup:string, ids:string[]}> $entries
     * @return string[] Registered ids with no rendered tag, in registry order, deduplicated.
     */
    private function absent_registered_ids( string $html, array $entries ): array {
        $rendered = $this->rendered_ids( $html );

        $absent = [];
        foreach ( $entries as $entry ) {
            if ( in_array( $entry['id'], $rendered, true ) || in_array( $entry['id'], $absent, true ) ) {
                continue;
            }
            $absent[] = $entry['id'];
        }
        return $absent;
    }

    /**
     * The tag ids the page actually carries.
     *
     * Values are entity-decoded because TagEmitter runs the id through esc_attr on
     * the way out, so a registered id containing `&` renders as `&amp;` and a raw
     * string comparison would report a tag that is right there in the page as absent.
     *
     * @return string[]
     */
    private function rendered_ids( string $html ): array {
        if ( ! preg_match_all( self::EMITTED_ID_PATTERN, $html, $m ) ) {
            return [];
        }

        $ids = [];
        foreach ( $m[2] as $raw ) {
            $ids[] = html_entity_decode( $raw, ENT_QUOTES, 'UTF-8' );
        }
        return array_values( array_unique( $ids ) );
    }

    /**
     * Validated registry rows with their ids pre-extracted.
     *
     * No `(string)` casts anywhere near this. A row whose markup is an object
     * fatals on cast - a white screen on a live client site - and one whose markup
     * key is missing casts null to '' and then silently compares against nothing.
     * TagRegistry::is_valid_entry is the single shared definition of a well-formed
     * row; reusing it is what keeps the scanner's idea of the registry from
     * drifting away from the emitter's.
     *
     * @param array<int|string, mixed> $registry
     * @return array<int, array{id:string, markup:string, ids:string[]}>
     */
    private function registry_entries( array $registry ): array {
        $entries = [];
        foreach ( $registry as $entry ) {
            if ( ! TagRegistry::is_valid_entry( $entry ) ) {
                continue;
            }
            $entries[] = [
                'id'     => $entry['id'],
                'markup' => $entry['markup'],
                'ids'    => TrackerList::ids( $entry['markup'] ),
            ];
        }
        return $entries;
    }

    /**
     * $banner_categories may come from a stored option, so it may hold anything.
     * Anything that is not a non-empty string is dropped rather than cast.
     *
     * @param array<int|string, mixed> $categories
     * @return string[]
     */
    private function clean_categories( array $categories ): array {
        $clean = [];
        foreach ( $categories as $category ) {
            if ( is_string( $category ) && '' !== $category && ! in_array( $category, $clean, true ) ) {
                $clean[] = $category;
            }
        }
        return $clean;
    }

    /**
     * Consent defaults that are still region-scoped.
     *
     * The drift detector for ConsentModule::site_kit_consent_defaults(). Read that
     * method first - it carries the reasoning and the Site Kit source it is written
     * against.
     *
     * 🚨 This asserts the EFFECT, not the mechanism, and that is the whole point.
     * `googlesitekit_consent_defaults` is a Site Kit internal. A check that our
     * callback is hooked would stay green forever after Site Kit renamed the hook,
     * because being hooked to a filter nobody calls is indistinguishable, from
     * inside PHP, from being hooked to one that works. Reading the rendered page
     * instead means a rename, a removal, a later callback outbidding our
     * PHP_INT_MAX, and Site Kit restructuring the snippet all surface as the same
     * finding - the one thing that actually matters, which is that a visitor
     * outside the EEA is not being asked first.
     *
     * Returns at most one entry per distinct region list, because Site Kit prints
     * the same defaults twice (the `gtag` call and `window._googlesitekitConsents`)
     * and one broken thing must not read as two.
     *
     * @return array<int, string> A short rendering of each offending region value.
     */
    private function region_scoped_consent_defaults( string $html, bool $site_kit_active, bool $consent_mode_on ): array {
        /*
         * Site Kit off, or its Consent Mode switched off, means it prints no
         * defaults snippet at all - and consent mode being off is already its own
         * High above. Raising this as well would put two findings on one cause.
         */
        if ( ! $site_kit_active || ! $consent_mode_on ) {
            return [];
        }

        $matched = preg_match_all( self::CONSENT_DEFAULT_PATTERN, $html, $calls, PREG_SET_ORDER );
        if ( false === $matched || 0 === $matched ) {
            /*
             * No consent-default call found. NOT reported, deliberately. The scan
             * runs against one representative URL and Site Kit legitimately prints
             * nothing on some of them; a finding here would be noise on a site that
             * is fine, and noise is what kills a monitor. The absence is visible to
             * the harness, which watches the real dataLayer in a real browser.
             */
            return [];
        }

        $out  = [];
        $seen = [];

        foreach ( $calls as $call ) {
            $object = $call[3];
            if ( true !== $this->matches( self::CONSENT_REGION_KEY_PATTERN, $object ) ) {
                continue;
            }

            // Just the codes, capped. The real list is 32 ISO codes, and a finding
            // detail is read by a human rather than parsed.
            $rendered = $this->describe_regions( $object );
            if ( isset( $seen[ $rendered ] ) ) {
                continue;
            }
            $seen[ $rendered ] = true;
            $out[]             = $rendered;
        }

        return $out;
    }

    /** A short, human-readable rendering of the `region` value found in $object. */
    private function describe_regions( string $object ): string {
        if ( 1 !== preg_match( '/(["\'])region\1\s*:\s*\[([^\]]*)\]/i', $object, $m ) ) {
            // A region key that is not an array - a bare string, or a value we
            // cannot read. Still a finding; we just cannot name the countries.
            return 'unreadable region value';
        }

        preg_match_all( '/[A-Za-z]{2,3}/', $m[2], $codes );
        $found = $codes[0];
        if ( [] === $found ) {
            return 'an empty region list';
        }

        $shown = array_slice( $found, 0, 6 );
        return count( $found ) > count( $shown )
            ? implode( ', ', $shown ) . ' and ' . ( count( $found ) - count( $shown ) ) . ' more'
            : implode( ', ', $shown );
    }

    /**
     * true / false / null, where null means the PCRE engine gave up.
     *
     * The distinction is load-bearing: treating an engine failure as "not found"
     * would report a missing withdrawal control on a page that has one, and a
     * finding nobody can reproduce is how a monitor loses its readers.
     */
    private function matches( string $pattern, string $subject ): ?bool {
        $result = preg_match( $pattern, $subject );
        return false === $result ? null : ( 1 === $result );
    }
}
