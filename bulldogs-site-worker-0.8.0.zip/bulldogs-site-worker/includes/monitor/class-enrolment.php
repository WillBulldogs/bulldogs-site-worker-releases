<?php
namespace Bulldogs\SiteWorker\Monitor;

use Bulldogs\SiteWorker\Settings;

/**
 * Offers this site's monitoring secret to WP Fleet, and waits to be approved.
 *
 * ---------------------------------------------------------------------------
 * WHY THE SITE ASKS, INSTEAD OF AN OPERATOR TELLING WP FLEET
 * ---------------------------------------------------------------------------
 * The secret is generated here, on activation, and used to be read off the box
 * with `wp bulldogs monitor secret` and registered by hand.
 *
 * That is IMPOSSIBLE on a reseller host. Brixly runs CageFS: no shell, no
 * WP-CLI, so nothing can read the value this plugin just generated. Its 16
 * installs could never be monitored at all. It was also a manual step per site
 * everywhere else, which is why 34 of 36 published sites sat unread.
 *
 * So the site offers, and a human approves in Control Centre.
 *
 * ---------------------------------------------------------------------------
 * WHAT THIS CLASS DELIBERATELY DOES NOT DO
 * ---------------------------------------------------------------------------
 * It does not prove anything about itself, and it does not try to. The offer is
 * an unauthenticated POST from a client site to a public endpoint, so on its own
 * it is worth nothing - anybody could send the same shape claiming to be this
 * domain. The proof happens at the other end, where Control Centre matches the
 * domain against its own agentless inventory and then polls THIS site's findings
 * endpoint with the offered secret to confirm the pairing is real.
 *
 * That asymmetry is the point. Nothing secret-bearing has to be trusted here.
 *
 * ---------------------------------------------------------------------------
 * 🚨 IT NEVER RUNS ON A VISITOR REQUEST
 * ---------------------------------------------------------------------------
 * An outbound HTTP call on a front-end page load would put our latency into a
 * client's page render, on every site in the fleet, to solve a problem the
 * visitor does not have. So attempts are confined to contexts where a human or a
 * scheduler is already waiting: wp-admin, WP-Cron, and WP-CLI.
 *
 * The cost is honest and worth stating: a site with no admin logins AND dead
 * WP-Cron will never enrol by itself. That is not a silent failure - it shows as
 * a site still sitting unenrolled in the fleet view - and `wp bulldogs monitor
 * enrol` fixes it wherever a shell exists. On Brixly, where no shell exists,
 * WP-Cron is spawned by visitor traffic, which those sites have.
 *
 * ---------------------------------------------------------------------------
 * EVERY FAILURE IS SILENT AND RETRIED
 * ---------------------------------------------------------------------------
 * Same rule as ManifestClient: this must never put a red box on a client's
 * dashboard. A refused, unreachable or malformed answer is recorded in the
 * option store and retried later. Retries back off, and re-offer the SAME
 * secret, so a site waiting a week for approval produces ONE queue entry rather
 * than one per attempt.
 */
class Enrolment {
    /**
     * Where offers go.
     *
     * ⚠️ A hostname we own and control, for the same reason ManifestClient's
     * manifest URL is: it is baked into every installed copy, and this one
     * carries a live credential outbound. It must never become a host somebody
     * else can start answering for.
     */
    public const ENDPOINT = 'https://cp.bulldogsdigital.com/api/wp-fleet/enrol';

    /** Settings key holding the enrolment state machine. */
    public const KEY = 'enrolment';

    public const STATE_UNKNOWN  = 'unknown';
    public const STATE_PENDING  = 'pending';
    public const STATE_APPROVED = 'approved';
    /** Declined, or already registered centrally. Either way: stop asking. */
    public const STATE_SETTLED  = 'settled';

    /** Seconds between attempts while waiting. */
    private const RETRY_SECONDS = 3600;

    /**
     * Seconds between attempts after a hard failure (unreachable, 5xx). Longer
     * than RETRY_SECONDS: if Control Centre is down, every site in the fleet is
     * failing at once, and a short retry turns an outage into a stampede.
     */
    private const BACKOFF_SECONDS = 21600;

    private const TIMEOUT = 8;

    public function __construct(
        private Settings $settings,
        private SiteSecret $secret
    ) {}

    /**
     * Attempt an offer if one is due. Safe to call on every request.
     *
     * @param bool $force Ignore the schedule. `wp bulldogs monitor enrol`.
     * @return string The state after this call.
     */
    public function maybe_enrol( bool $force = false ): string {
        $state = $this->state();

        // Terminal. An approved or settled site asking again would, at best,
        // produce noise in an approval queue a human has already cleared.
        if ( self::STATE_APPROVED === $state['state'] || self::STATE_SETTLED === $state['state'] ) {
            return $state['state'];
        }

        if ( ! $force && ! $this->due( $state ) ) {
            return $state['state'];
        }

        return $this->offer( $state );
    }

    /** Should this context be making outbound requests at all? See the docblock. */
    public function context_allows(): bool {
        if ( defined( 'WP_CLI' ) && WP_CLI ) {
            return true;
        }

        if ( function_exists( 'wp_doing_cron' ) && wp_doing_cron() ) {
            return true;
        }

        // is_admin() is true for admin-ajax too, which is fine: something is
        // already waiting on a server round trip there.
        return function_exists( 'is_admin' ) && is_admin();
    }

    /**
     * The stored state, normalised.
     *
     * Nothing casts. The option is hand-editable, written by WP-CLI and restored
     * from backups, so an unrecognised value falls back to `unknown`, which means
     * "ask again" - the safe direction. The dangerous fallback would be treating
     * junk as `approved`, which would leave a site permanently unenrolled and
     * silent about it.
     *
     * @return array{state:string, attempted:int, attempts:int, last:string}
     */
    public function state(): array {
        $raw = $this->settings->get( self::KEY, [] );
        $raw = is_array( $raw ) ? $raw : [];

        $state = isset( $raw['state'] ) && is_string( $raw['state'] ) ? $raw['state'] : self::STATE_UNKNOWN;

        if ( ! in_array( $state, [ self::STATE_UNKNOWN, self::STATE_PENDING, self::STATE_APPROVED, self::STATE_SETTLED ], true ) ) {
            $state = self::STATE_UNKNOWN;
        }

        return [
            'state'     => $state,
            'attempted' => isset( $raw['attempted'] ) && is_int( $raw['attempted'] ) ? $raw['attempted'] : 0,
            'attempts'  => isset( $raw['attempts'] ) && is_int( $raw['attempts'] ) ? $raw['attempts'] : 0,
            'last'      => isset( $raw['last'] ) && is_string( $raw['last'] ) ? $raw['last'] : '',
        ];
    }

    /** @param array{state:string, attempted:int, attempts:int, last:string} $state */
    private function due( array $state ): bool {
        if ( 0 === $state['attempted'] ) {
            return true;
        }

        $wait = self::STATE_PENDING === $state['state'] ? self::RETRY_SECONDS : self::BACKOFF_SECONDS;

        return ( time() - $state['attempted'] ) >= $wait;
    }

    /**
     * @param array{state:string, attempted:int, attempts:int, last:string} $state
     */
    private function offer( array $state ): string {
        $secret = $this->secret->get();

        if ( null === $secret ) {
            // Nothing to offer. Not an error state: the activation hook mints one,
            // and `wp bulldogs monitor secret` mints one on demand.
            return $this->remember( self::STATE_UNKNOWN, 'no secret has been generated on this site yet', $state );
        }

        if ( ! function_exists( 'wp_remote_post' ) ) {
            return $this->remember( self::STATE_UNKNOWN, 'WordPress HTTP is not available in this context', $state );
        }

        $response = wp_remote_post(
            self::ENDPOINT,
            [
                'timeout'     => self::TIMEOUT,
                'redirection' => 2,
                'headers'     => [ 'Content-Type' => 'application/json' ],
                'user-agent'  => 'bulldogs-site-worker/' . ( defined( 'BULLDOGS_SW_VERSION' ) ? BULLDOGS_SW_VERSION : 'unknown' ),
                'body'        => wp_json_encode(
                    [
                        'domain'        => $this->domain(),
                        'siteUrl'       => function_exists( 'home_url' ) ? home_url() : '',
                        'secret'        => $secret,
                        'pluginVersion' => defined( 'BULLDOGS_SW_VERSION' ) ? BULLDOGS_SW_VERSION : 'unknown',
                    ]
                ),
            ]
        );

        if ( is_wp_error( $response ) ) {
            return $this->remember( self::STATE_UNKNOWN, 'could not reach WP Fleet: ' . $response->get_error_message(), $state );
        }

        $code = (int) wp_remote_retrieve_response_code( $response );
        $body = json_decode( (string) wp_remote_retrieve_body( $response ), true );
        $status = is_array( $body ) && isset( $body['status'] ) && is_string( $body['status'] ) ? $body['status'] : '';
        $reason = is_array( $body ) && isset( $body['reason'] ) && is_string( $body['reason'] ) ? $body['reason'] : '';

        if ( 'pending' === $status ) {
            return $this->remember( self::STATE_PENDING, 'offered, waiting for approval', $state );
        }

        if ( 'approved' === $status ) {
            return $this->remember( self::STATE_APPROVED, 'approved', $state );
        }

        /*
         * Already registered centrally. Terminal, and NOT a failure: it means
         * somebody registered this secret by hand, which is the old SOP path.
         * Continuing to ask would put a site that is working correctly into an
         * approval queue every hour.
         */
        if ( 'already_enrolled' === $status ) {
            return $this->remember( self::STATE_SETTLED, 'already registered in WP Fleet', $state );
        }

        /*
         * A 403 is a decision - unknown domain, unproven secret, or an offer a
         * human declined - and re-asking hourly will not change any of them. Back
         * off hard rather than treating it as a transient error, but stay in a
         * state that CAN be retried later, because the first two become true the
         * moment WP Fleet discovers the site.
         */
        if ( 403 === $code ) {
            return $this->remember( self::STATE_UNKNOWN, 'refused: ' . ( '' !== $reason ? $reason : 'no reason given' ), $state );
        }

        return $this->remember(
            self::STATE_UNKNOWN,
            sprintf( 'unexpected answer: HTTP %d%s', $code, '' !== $reason ? ' - ' . $reason : '' ),
            $state
        );
    }

    /**
     * The bare hostname, which is what WP Fleet stores.
     *
     * `www.` is left on deliberately: stripping it here would hide the site's
     * real canonical form from the audit trail, and the matching end normalises
     * anyway. Better for the two ends to disagree visibly than to both guess.
     */
    private function domain(): string {
        $url = function_exists( 'home_url' ) ? home_url() : '';
        $host = is_string( $url ) ? (string) wp_parse_url( $url, PHP_URL_HOST ) : '';

        return strtolower( $host );
    }

    /**
     * @param array{state:string, attempted:int, attempts:int, last:string} $previous
     */
    private function remember( string $state, string $note, array $previous ): string {
        $this->settings->set(
            self::KEY,
            [
                'state'     => $state,
                'attempted' => time(),
                'attempts'  => $previous['attempts'] + 1,
                'last'      => substr( $note, 0, 300 ),
            ]
        );

        return $state;
    }
}
