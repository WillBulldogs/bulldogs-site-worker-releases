/**
 * Bulldogs Site Worker - consent client.
 *
 * ---------------------------------------------------------------------------
 * WHAT THIS FILE IS FOR
 * ---------------------------------------------------------------------------
 * Our PHP sets `wp_consent_api_waitfor_consent_hook` to true, which tells every
 * WP Consent API consumer on the site to hold and wait for US to define the
 * consent type. wp-consent-api itself dispatches only
 * `wp_consent_api_status_change_service` and `wp_listen_for_consent_change`; it
 * never fires `wp_consent_type_defined` (0 occurrences in 2.0.1's source). So
 * this file is the SOLE source of that event on our sites. If it does not run,
 * or throws before it announces, consumers wait forever and analytics is dead
 * on every site in the fleet.
 *
 * It also closes a fail-open. Upstream `wp_has_consent()` returns true for every
 * category when the consent type is empty ("there's no consent management, we
 * should return true to activate all cookies"), and `wp_get_consent_type()`
 * defaults to ''. Setting the type to `optin` is the entire gate, which is why
 * it is the very first statement below - before anything that could throw.
 *
 * ---------------------------------------------------------------------------
 * ORDERING
 * ---------------------------------------------------------------------------
 * Enqueued in <head> with no defer, and excluded from WP Rocket's delay-JS,
 * because the explicit deny for a stale stamp must be written to the
 * `wp_consent_*` cookies BEFORE Site Kit's own DOMContentLoaded handler reads
 * them. Site Kit grants from those cookies; they outlive our stamp, so a return
 * visitor whose stamp has gone stale would be granted before being re-asked.
 *
 * That ordering is the FIRST line of defence and it is not sufficient on its own,
 * because a cache plugin can defeat it from outside this file - see the read shim
 * on applyConsent(), which is what holds when the exclusion is missing.
 *
 * ---------------------------------------------------------------------------
 * THE STORE  (see README.md - the Chunk 4 harness constructs and corrupts this)
 * ---------------------------------------------------------------------------
 *   localStorage["bulldogs_consent_v1"] = JSON.stringify( {
 *       categories: { "<category>": { granted: <bool>, stamp: "<16-hex>" } },
 *       ts: <epoch ms>
 *   } )
 *
 * A record is only usable if it parses, is an object, has a `categories` object,
 * and that object has at least one key. Anything else is treated as no consent
 * at all - re-ask, and actively deny in the meantime.
 *
 * ---------------------------------------------------------------------------
 * ES5, no build step. This ships as-is to ~29 client sites on unknown themes.
 * ---------------------------------------------------------------------------
 */
( function () {
	'use strict';

	/*
	 * FIRST, and deliberately before anything that reads config or calls a
	 * function: this single assignment is what stops `wp_has_consent()` from
	 * returning true for every category. Everything below can fail without
	 * opening that hole; nothing below may run before it is closed.
	 *
	 * Unconditional, even if something else already set it. `optin` is the
	 * strictest value, and two consent managers on one site is a
	 * misconfiguration the rollout SOP removes - not a state to defer to.
	 */
	window.wp_consent_type = 'optin';

	var STORE_NAME = 'bulldogs_consent_v1';
	var BANNER_ID = 'bsw-banner';

	/*
	 * Category names are interpolated into attribute selectors below. A value
	 * with a quote in it would throw a SyntaxError out of querySelector and take
	 * the whole handler with it, so the shape is checked once here rather than
	 * trusted. PHP restricts the set already; this is the client not depending on
	 * that being true of whatever actually reached the page.
	 */
	var CATEGORY_PATTERN = /^[a-z][a-z0-9_-]*$/i;

	/*
	 * Clarity's own key names, including its unusual capitalisation - that casing
	 * is what its `consentv2` API expects, not a typo.
	 */
	var CLARITY_KEYS = [ [ 'marketing', 'ad_Storage' ], [ 'statistics', 'analytics_Storage' ] ];

	/*
	 * BulldogsSW is localised by PHP, but a caching plugin that strips inline
	 * script, a JS error in a theme script printed above us, or delay-JS eating
	 * the inline var while letting the file through, all leave it absent. Reading
	 * `.categories` off undefined throws, and a throw here means the event never
	 * fires and every consumer waits forever - so this is guarded rather than
	 * assumed, and an absent config degrades to "no categories" (deny nothing,
	 * grant nothing, still announce the type).
	 */
	var CFG        = ( window.BulldogsSW && 'object' === typeof window.BulldogsSW ) ? window.BulldogsSW : {};
	var CATEGORIES = normaliseCategories( CFG.categories );

	/*
	 * NOTE: `stamps` is only ever INDEXED, never iterated. wp_json_encode turns an
	 * empty PHP array into `[]`, not `{}`, so on a site with no categories this is
	 * an array - which indexes fine and iterates into nonsense. A PHP test pins
	 * that shape; do not start walking its keys.
	 */
	var STAMPS = ( CFG.stamps && 'object' === typeof CFG.stamps ) ? CFG.stamps : {};

	/*
	 * The state currently in force on THIS page. Late milestones (window load) and
	 * the Clarity bridge read this rather than re-reading the store, so that a
	 * choice made in a private-mode window - where the write is silently swallowed
	 * - is not contradicted a moment later by a store that never took it.
	 */
	var current = null;

	/* Set once the visitor has made a choice on this page load. */
	var decided = false;

	/* The control that opened the banner, so focus can be handed back to it. */
	var openTrigger = null;

	/**
	 * The control that opened LAYER 2, so Escape and the ✕ can hand focus back to
	 * the thing the visitor actually pressed rather than dropping it on <body>.
	 */
	var panelTrigger = null;

	/**
	 * Are the page's leftover Usercentrics controls OURS to drive?
	 *
	 * 🚨 False until DOMContentLoaded has confirmed real Usercentrics is absent.
	 * If it is live, those controls belong to ITS banner and binding them would
	 * replace a working consent UI with ours on a site mid-migration - far worse
	 * than the dead link this whole mechanism exists to fix.
	 *
	 * The delegated click handler is bound during boot, long before that check
	 * can run (the Usercentrics loader sits below us in <head> and has not parsed
	 * yet), so the handler asks this flag rather than re-deciding. Nothing can
	 * click a footer link before the footer exists, so no interaction is lost.
	 */
	var legacyLinksAreOurs = false;

	/* A reopen click that landed before the footer had parsed. */
	var pendingOpen = null;

	// -----------------------------------------------------------------------
	// Small helpers. Written long-hand so this file has no ES6 or polyfill
	// dependency of any kind.
	// -----------------------------------------------------------------------

	/** Works for arrays, NodeLists and NamedNodeMap alike. */
	function each( list, fn ) {
		if ( ! list ) {
			return;
		}
		for ( var i = 0; i < list.length; i++ ) {
			fn( list[ i ], i );
		}
	}

	function has( list, value ) {
		for ( var i = 0; i < list.length; i++ ) {
			if ( list[ i ] === value ) {
				return true;
			}
		}
		return false;
	}

	/**
	 * @param {*} list Whatever `categories` arrived as. May be absent, a string,
	 *                 an object, or an array containing anything at all.
	 * @return {string[]} Known-shaped, de-duplicated category names.
	 */
	function normaliseCategories( list ) {
		var out = [];
		if ( ! list || 'object' !== typeof list || 'number' !== typeof list.length ) {
			return out;
		}
		each( list, function ( cat ) {
			if ( 'string' !== typeof cat || ! CATEGORY_PATTERN.test( cat ) ) {
				return;
			}
			if ( ! has( out, cat ) ) {
				out.push( cat );
			}
		} );
		return out;
	}

	/**
	 * Always a string. A missing stamp normalises to '' so that it round-trips
	 * through JSON: `undefined` is dropped by JSON.stringify, and comparing a
	 * dropped key to a missing config key happens to work, but only by accident.
	 */
	function stampFor( category ) {
		var stamp = STAMPS[ category ];
		return 'string' === typeof stamp ? stamp : '';
	}

	function ready( fn ) {
		if ( 'loading' !== document.readyState ) {
			// Delay-JS, a late injection, or an async loader: DOMContentLoaded has
			// already been and gone, and waiting for it would mean the banner is
			// never shown and tags are never flipped.
			fn();
			return;
		}
		document.addEventListener( 'DOMContentLoaded', fn );
	}

	function loaded( fn ) {
		if ( 'complete' === document.readyState ) {
			fn();
			return;
		}
		window.addEventListener( 'load', fn );
	}

	// -----------------------------------------------------------------------
	// The store
	// -----------------------------------------------------------------------

	/**
	 * @return {Object|null} The stored `categories` map, or null when there is no
	 *                       record we are willing to treat as an answer.
	 */
	function readStore() {
		try {
			// Accessing window.localStorage - not just using it - throws outright in
			// a sandboxed iframe and in Safari with storage disabled, so the access
			// is inside the try, not above it.
			var raw = window.localStorage.getItem( STORE_NAME );
			if ( ! raw ) {
				return null;
			}

			var parsed = JSON.parse( raw );
			if ( ! parsed || 'object' !== typeof parsed ) {
				return null;
			}

			/*
			 * A parsed object is not enough. `{}`, or a record whose categories map
			 * is empty or is not a map at all, would otherwise count as "answered":
			 * the banner never shows and the visitor is silently never asked, while
			 * we report a record exists. Treat it as no consent.
			 */
			var categories = parsed.categories;
			if ( ! categories || 'object' !== typeof categories ) {
				return null;
			}
			var keys = 0;
			for ( var key in categories ) {
				if ( Object.prototype.hasOwnProperty.call( categories, key ) ) {
					keys++;
				}
			}
			return keys > 0 ? categories : null;
		} catch ( e ) {
			return null;
		}
	}

	function writeStore( record ) {
		try {
			window.localStorage.setItem( STORE_NAME, JSON.stringify( record ) );
		} catch ( e ) {
			/*
			 * Private mode, a full quota, or storage disabled. Consent simply will
			 * not persist beyond this page - which is why apply() builds its state
			 * from the decision rather than re-reading this back.
			 */
		}
	}

	/**
	 * Read the store and decide, per category, what is granted and what must be
	 * re-asked.
	 *
	 * @return {{granted: Object, stale: string[], hasRecord: boolean}}
	 */
	function resolve() {
		var stored  = readStore();
		var granted = {};
		var stale   = [];

		each( CATEGORIES, function ( category ) {
			granted[ category ] = false;

			var entry = stored ? stored[ category ] : null;

			/*
			 * An ABSENT category is stale, not merely ungranted. Otherwise adding a
			 * marketing category to a site that previously only had statistics
			 * leaves hasRecord true and nothing stale, so the banner never
			 * reappears and the new category can never be consented to.
			 */
			if ( ! entry || 'object' !== typeof entry ) {
				stale.push( category );
				return;
			}

			if ( entry.stamp !== stampFor( category ) ) {
				stale.push( category );
				return;
			}

			granted[ category ] = true === entry.granted;
		} );

		return { granted: granted, stale: stale, hasRecord: !! stored };
	}

	function persist( decisions ) {
		if ( 0 === CATEGORIES.length ) {
			// A record with no categories is one readStore() would reject anyway.
			return;
		}
		var categories = {};
		each( CATEGORIES, function ( category ) {
			categories[ category ] = { granted: !! decisions[ category ], stamp: stampFor( category ) };
		} );
		writeStore( { categories: categories, ts: ( new Date() ).getTime() } );
	}

	// -----------------------------------------------------------------------
	// Telling the rest of the page
	// -----------------------------------------------------------------------

	/**
	 * Apply the resolved state to every category - without ever letting a consumer
	 * observe a HALF-APPLIED one.
	 *
	 * Every category is set EXPLICITLY, including the stale ones, for two reasons:
	 * an explicit deny emits an observable `consent update denied` that the harness
	 * can assert on, and leaving a category unset lets Site Kit grant it from its
	 * own surviving cookies.
	 *
	 * Upstream `wp_set_consent()` does not dispatch its change event when the value
	 * is unchanged, so re-applying an already-stored state is a cheap no-op rather
	 * than a storm of events. That is also why the return-visit grant depends on
	 * Site Kit re-reading the cookies, not on anything we emit.
	 *
	 * -----------------------------------------------------------------------
	 * 🚨 THE READ SHIM. DO NOT "SIMPLIFY" THIS BACK INTO A BARE LOOP.
	 * -----------------------------------------------------------------------
	 * `wp_set_consent()` is per-category by design and there is no batch call -
	 * checked in the published wp-consent-api source, whose only writers are
	 * `wp_set_consent()` and `wp_set_service_consent()`. It writes the cookie and
	 * then, WHENEVER THE VALUE ACTUALLY CHANGED, dispatches
	 * `wp_listen_for_consent_change` SYNCHRONOUSLY, from inside our call.
	 *
	 * Google Site Kit listens for that event, and answers it by re-reading EVERY
	 * category through `wp_has_consent()` and emitting one gtag `consent update`
	 * covering all of them. So a bare loop hands Site Kit the state as at iteration
	 * 1 of N: the category we have just written, plus every category we have NOT
	 * reached yet - which on a stale return visit still hold `allow` in the
	 * `wp_consent_*` cookies the earlier visit left behind. Nothing clears those;
	 * they outlive our stamp.
	 *
	 * MEASURED, on the harness `delayed-client` scenario - categories
	 * [ marketing, statistics ], stored stamp gone stale, both cookies still
	 * `allow`, consent.js released after DOMContentLoaded by a delay-JS shim so
	 * that Site Kit is already listening. With the bare loop:
	 *
	 *     0:default=denied  1:update=GRANTED  2:update=denied  3:update=denied
	 *     4:update=denied   5:update=denied
	 *
	 * Index 1 is Site Kit reacting to our deny of `marketing` by reading
	 * `statistics` - not reached yet - as `allow`, and granting
	 * `analytics_storage`. The five denies that follow do not undo it: `_ga` is
	 * written inside that granted window, and the visitor is measured on the very
	 * load where we are re-asking them.
	 *
	 * Re-ordering the categories does NOT fix this. It only moves which signal
	 * leaks, because whichever category goes first, the rest are still unread.
	 *
	 * So for the duration of the write - and only for that duration -
	 * `wp_has_consent()` is replaced with one that answers `false` for everything.
	 * A consumer that re-reads mid-sequence is told "nothing is consented", which
	 * is the one answer that is always safe to be wrong about, and the truth
	 * reaches it a moment later from `announce()`, which every caller of this
	 * function runs immediately afterwards. That re-announcement is not new
	 * plumbing: it is the same event an unchanged return visit has always depended
	 * on, because upstream stays silent when nothing changed.
	 *
	 * WHY NOT write the `wp_consent_*` cookies to `deny` ourselves first and then
	 * make a single call. Because upstream does not own that cookie name in a way
	 * we can rely on: it is `consent_api.cookie_prefix + '_' + category`, localised
	 * from PHP and filterable, written with upstream's own expiry and a conditional
	 * `;secure`. Guess the prefix wrong on one site and our writes land on a cookie
	 * nobody reads while the real one keeps saying `allow` - silently, and with the
	 * harness unable to catch it, because the double hardcodes the default prefix.
	 * That fix would couple us to a cookie NAME, an expiry policy and a
	 * change-detection rule. This one couples to a single public function name, and
	 * its only possible effect is to under-report.
	 *
	 * WHAT IT DOES NOT COVER, stated plainly: a consumer that captured a reference
	 * to `wp_has_consent` before we swapped it, or one that reads the cookies for
	 * itself. Neither applies to the consumer this plugin exists to serve -
	 * wp-consent-api declares `wp_has_consent` as a global function declaration, so
	 * `wp_has_consent(...)` and `window.wp_has_consent(...)` resolve the same
	 * property at call time, and Site Kit's bundle asks for it at call time.
	 */
	function applyConsent( state ) {
		if ( 'function' !== typeof window.wp_set_consent ) {
			return; // Dependency missing or not yet printed: nothing is granted.
		}

		var shim = suppressConsentReads();

		try {
			each( CATEGORIES, function ( category ) {
				try {
					window.wp_set_consent( category, state.granted[ category ] ? 'allow' : 'deny' );
				} catch ( e ) {
					// One category failing must not abort the deny for the others.
				}
			} );
		} finally {
			// finally, not merely after the loop: someone else's listener throwing
			// out of a dispatch must not leave the page permanently reading `false`
			// for every category, which would look exactly like a site whose
			// analytics never grants.
			restoreConsentReads( shim );
		}
	}

	/**
	 * The stand-in installed by suppressConsentReads(). A named function, not an
	 * inline closure, so restoreConsentReads() can tell "still ours" from "someone
	 * else has replaced it since" by identity.
	 */
	function denyEveryRead() {
		return false;
	}

	/**
	 * @return {{installed: boolean, existed: boolean, previous: *}} Hand this to
	 *         restoreConsentReads(), always, from a finally.
	 */
	function suppressConsentReads() {
		var token = { installed: false, existed: false, previous: undefined };

		try {
			token.existed  = 'undefined' !== typeof window.wp_has_consent;
			token.previous = window.wp_has_consent;

			window.wp_has_consent = denyEveryRead;

			/*
			 * Verified rather than assumed. This file is strict-mode, so assigning
			 * over a non-writable property throws and is caught below - but a page
			 * that has installed a no-op setter would fail SILENTLY. If the swap did
			 * not take, the loop still runs: a leaked grant is bad, and leaving the
			 * cookies on `allow` because we declined to write them is worse and
			 * permanent.
			 */
			token.installed = ( window.wp_has_consent === denyEveryRead );
		} catch ( e ) {
			token.installed = false;
		}

		return token;
	}

	function restoreConsentReads( token ) {
		if ( ! token.installed ) {
			return;
		}

		try {
			if ( window.wp_has_consent !== denyEveryRead ) {
				// Something replaced it while we held it. Theirs is newer than what we
				// captured, so putting ours back would be a regression, not a restore.
				return;
			}

			if ( token.existed ) {
				window.wp_has_consent = token.previous;
				return;
			}

			/*
			 * It did not exist before us, so it must not exist after us: a consumer
			 * that feature-detects `typeof wp_has_consent === 'function'` would
			 * otherwise find ours and read every category as denied for the rest of
			 * the page's life.
			 */
			try {
				delete window.wp_has_consent;
			} catch ( e ) {
				window.wp_has_consent = undefined;
			}
		} catch ( e2 ) {
			// A frozen or otherwise exotic global. Nothing further we can do.
		}
	}

	/**
	 * 🚨 Dispatch is NOT once. Read this before "fixing" it.
	 *
	 * `document.dispatchEvent()` is synchronous and walks the listener list as it
	 * stands at that instant. DOM events are not sticky and are never replayed, so
	 * a listener registered afterwards hears nothing, ever.
	 *
	 * This script is enqueued at wp_enqueue_scripts priority 1 and depends on
	 * wp-consent-api, so it runs at the very top of <head> - BEFORE Site Kit's
	 * consent-mode bundle has parsed, and therefore before Site Kit has called
	 * addEventListener( 'wp_consent_type_defined', ... ). A single dispatch at boot
	 * is guaranteed to reach nobody at all, including the one consumer this plugin
	 * exists to serve.
	 *
	 * So we announce at each of the standard milestones instead - boot,
	 * DOMContentLoaded, window load - which covers every listener registered by a
	 * script that parsed after us. The event carries no payload and every correct
	 * consumer responds by re-reading wp_has_consent(), so repeating it is
	 * idempotent; the cost of an extra dispatch is a duplicate gtag consent update,
	 * and the cost of one missed dispatch is dead analytics on the whole fleet.
	 *
	 * window.wp_consent_type is set before the first dispatch (top of file) so that
	 * a consumer which reads the global when it registers, rather than waiting for
	 * the event, also gets the right answer.
	 */
	function announce() {
		var event;

		try {
			event = new window.CustomEvent( 'wp_consent_type_defined' );
		} catch ( e ) {
			// IE11 and old WebViews expose CustomEvent but it is not constructible.
			try {
				event = document.createEvent( 'CustomEvent' );
				event.initCustomEvent( 'wp_consent_type_defined', false, false, null );
			} catch ( e2 ) {
				return;
			}
		}

		try {
			document.dispatchEvent( event );
		} catch ( e3 ) {
			// A listener of someone else's threw. Not our page to break.
		}
	}

	/**
	 * Clarity is compliant by default; we only tell it when our answer differs.
	 *
	 * A category this site does not offer maps to `denied`, which is correct under
	 * opt-in - no category means no consent was ever collected for it. The one case
	 * that would be wrong is a site offering NEITHER statistics nor marketing: it
	 * has no consent UI at all, so unilaterally denying a tracker nobody asked us
	 * to gate would break it for no compliance gain. That case returns early. A
	 * site running Clarity with no statistics category is an SOP failure for the
	 * monitor module to report, not something this bridge papers over.
	 */
	function updateClarity( state ) {
		if ( 'function' !== typeof window.clarity ) {
			// Not present, or its async loader has not defined the queue stub yet -
			// which is why this is also called at window load, not only once.
			return;
		}

		var payload    = {};
		var applicable = false;

		each( CLARITY_KEYS, function ( pair ) {
			if ( has( CATEGORIES, pair[ 0 ] ) ) {
				applicable = true;
			}
			payload[ pair[ 1 ] ] = state.granted[ pair[ 0 ] ] ? 'granted' : 'denied';
		} );

		if ( ! applicable ) {
			return;
		}

		try {
			window.clarity( 'consentv2', payload );
		} catch ( e ) {
			// Never let a vendor error break the page.
		}
	}

	/**
	 * Flip inert tags for granted categories. Only ever touches nodes the emitter
	 * marked; never rewrites server output.
	 *
	 * The live node keeps data-bsw-id AND data-bsw-category, plus a
	 * data-bsw-flipped marker, so the harness and the monitor can assert the whole
	 * invariant in one pass: every registered tag on the page is either still
	 * type="text/plain" (inert) or carries data-bsw-flipped (granted). It cannot be
	 * re-selected and flipped twice because the selector requires type="text/plain"
	 * and we never copy the type across.
	 */
	function flipTags( state ) {
		var nodes = document.querySelectorAll( 'script[type="text/plain"][data-bsw-category]' );

		each( nodes, function ( node ) {
			if ( ! state.granted[ node.getAttribute( 'data-bsw-category' ) ] ) {
				return;
			}
			if ( ! node.parentNode ) {
				return;
			}

			var live = document.createElement( 'script' );

			each( node.attributes, function ( attr ) {
				// Ours is the only `type` decision. Everything else is the tag's own.
				if ( 'type' !== attr.name ) {
					live.setAttribute( attr.name, attr.value );
				}
			} );
			live.setAttribute( 'data-bsw-flipped', '1' );

			/*
			 * Under a nonce-based CSP the browser blanks the nonce CONTENT attribute
			 * after parsing and keeps the value only on the IDL property, so copying
			 * attributes alone yields a nonce-less script that CSP then refuses to
			 * run - silently, and only on the sites that use CSP.
			 */
			if ( node.nonce ) {
				live.setAttribute( 'nonce', node.nonce );
				live.nonce = node.nonce;
			}

			/*
			 * Dynamically inserted external scripts are async by default, so a
			 * container and a snippet that depends on it can execute out of order.
			 * This deliberately overrides an author's own `async` attribute: ordering
			 * between a container and its dependants is correctness, and async is a
			 * performance preference.
			 */
			live.async = false;

			var body = node.text || node.textContent || '';
			if ( body ) {
				live.text = body;
			}

			node.parentNode.replaceChild( live, node );
		} );
	}

	/**
	 * One place that pushes the resolved state at everything downstream, so the
	 * boot path, the milestone re-announcements and a fresh click all emit the same
	 * signals in the same order.
	 */
	function sync( state ) {
		announce();
		updateClarity( state );
	}

	// -----------------------------------------------------------------------
	// Banner
	// -----------------------------------------------------------------------

	function bannerEl() {
		return document.getElementById( BANNER_ID );
	}

	/**
	 * The withdrawal control renders aria-expanded="false" because the banner
	 * renders hidden, and that pair is baked into cached HTML. Keeping them in step
	 * from here on is this script's job. querySelectorAll, not one lookup: a site
	 * may place the control in the footer AND a nav menu.
	 */
	function setExpanded( open ) {
		each( document.querySelectorAll( '[data-bsw-action="reopen"]' ), function ( control ) {
			control.setAttribute( 'aria-expanded', open ? 'true' : 'false' );
		} );
	}

	/**
	 * Open or close LAYER 2, the full panel.
	 *
	 * 🚨 THIS TOUCHES NO CONSENT STATE AT ALL, and that is the whole contract.
	 * No apply(), no persist(), no write to the store, no box.checked. Reading
	 * what a category does must not consent to it, and neither closing the panel
	 * nor opening it is an answer to the question the banner is asking.
	 *
	 * Exactly one layer is visible at a time, and that mutual exclusion is not
	 * cosmetic: it is what keeps the equal-prominence rule intact with two sets of
	 * Accept/Reject buttons in the document. See BannerRenderer::actions().
	 *
	 * Scoped to the banner rather than the document: a page-builder preview or a
	 * duplicated footer widget can put a second copy of this markup on the page,
	 * and the visitor's actual banner is the one that has to respond.
	 */
	function setPanel( open, trigger ) {
		var el = bannerEl();
		if ( ! el ) {
			return;
		}

		var one = el.querySelector( '.bsw-layer-1' );
		var two = el.querySelector( '.bsw-layer-2' );
		if ( ! one || ! two ) {
			return;
		}

		one.hidden = !! open;
		two.hidden = ! open;

		each( el.querySelectorAll( '[data-bsw-action="details"]' ), function ( control ) {
			control.setAttribute( 'aria-expanded', open ? 'true' : 'false' );
		} );

		if ( open ) {
			// Remember what opened it so Escape and the ✕ can hand focus back to
			// the control the visitor actually pressed.
			panelTrigger = trigger || null;
			try {
				two.setAttribute( 'tabindex', '-1' );
				two.focus();
			} catch ( e ) {
				// A theme has done something odd to the element. Not fatal.
			}
			return;
		}

		/*
		 * Closing returns focus to whatever opened the panel, or to the "More
		 * information" control if we have lost track. Dropping focus on <body>
		 * would send the next Tab to the top of the page, which on a long page
		 * means the visitor loses the banner entirely.
		 */
		var target = panelTrigger || el.querySelector( '[data-bsw-action="details"]' );
		panelTrigger = null;
		if ( target ) {
			try {
				target.focus();
			} catch ( e ) {}
		}
	}

	/** Is layer 2 open? Read from the panel itself, which is what the visitor sees. */
	function panelOpen() {
		var el = bannerEl();
		if ( ! el ) {
			return false;
		}
		var two = el.querySelector( '.bsw-layer-2' );
		return !! two && ! two.hidden;
	}

	/**
	 * Select a tab in layer 2.
	 *
	 * SELECTS rather than cycles, so it is idempotent - handling the same click
	 * twice lands on the same tab. That matters because WP Rocket's delay-JS
	 * replays the first click on the page; see the guard in bindUI().
	 *
	 * `aria-selected` is both the state a screen reader reads and the hook the
	 * stylesheet paints the active tab with, so there is one source of truth for
	 * the look and the announcement and they cannot drift apart.
	 */
	function selectTab( name ) {
		var el = bannerEl();
		if ( ! el || ! name ) {
			return;
		}

		each( el.querySelectorAll( '[data-bsw-action="tab"]' ), function ( tab ) {
			var selected = tab.getAttribute( 'data-bsw-tab' ) === name;
			tab.setAttribute( 'aria-selected', selected ? 'true' : 'false' );

			var panel = document.getElementById( tab.getAttribute( 'aria-controls' ) );
			if ( panel ) {
				panel.hidden = ! selected;
			}
		} );
	}

	/**
	 * The chevron on a category card.
	 *
	 * 🚨 THE ONLY TOGGLE LEFT IN THE BANNER, and therefore the only control
	 * exposed to the delay-JS click replay. Everything else - open, close, tab -
	 * was deliberately built to set a state rather than flip one. Keep it that
	 * way: a new toggle is a new control that has to rely on the guard.
	 */
	function toggleServices( control ) {
		if ( ! control ) {
			return;
		}

		var region = document.getElementById( control.getAttribute( 'aria-controls' ) );
		if ( ! region ) {
			return;
		}

		var open = !! region.hidden;
		region.hidden = ! open;
		control.setAttribute( 'aria-expanded', open ? 'true' : 'false' );
	}

	/**
	 * Put every switch for a category into the same state.
	 *
	 * 🚨 THE SAME CATEGORIES ARE SHOWN TWICE - layer 1's inline pair and layer 2's
	 * card - and there is exactly ONE state behind them. Two independent sets
	 * would let a visitor flip a switch in the panel, close it, and see the card
	 * still saying the opposite, with only one of the two reaching the record.
	 *
	 * Derived rather than duplicated: nothing stores "the layer-2 answer". The
	 * checkboxes are the state, this keeps them identical, and save() reads any
	 * one of them because by then they cannot disagree.
	 */
	function syncCategory( category, checked ) {
		var el = bannerEl();
		if ( ! el || ! category ) {
			return;
		}

		each( el.querySelectorAll( '[data-bsw-category-toggle="' + category + '"]' ), function ( box ) {
			box.checked = !! checked;
		} );
	}

	/**
	 * @param {Object}       state   Resolved state, used to tick the toggles.
	 * @param {Element|null} trigger The control that opened it, or null when the
	 *                               banner is being shown automatically on load.
	 */
	function showBanner( state, trigger ) {
		var el = bannerEl();
		if ( ! el ) {
			// The footer has not parsed yet. Remember the intent rather than losing
			// the click, and open at DOMContentLoaded instead.
			if ( trigger ) {
				pendingOpen = trigger;
			}
			return;
		}

		/*
		 * Sync the toggles to the resolved state. Boxes render unticked and must
		 * never be pre-ticked in cached HTML (ICO, and Planet49 C-673/17), so
		 * without this a visitor who rejected and then reopened the banner would see
		 * their stored choices presented as if unset.
		 */
		each( CATEGORIES, function ( category ) {
			// querySelectorAll, not querySelector: the same category has a switch in
			// each layer and BOTH have to be set, or reopening the banner shows the
			// panel disagreeing with the card about what was consented to.
			syncCategory( category, state.granted[ category ] );
		} );

		/*
		 * The banner always reopens on LAYER 1. A visitor who opened the panel,
		 * answered, and came back later to change their mind should get the compact
		 * card they were first shown, not whatever state they left behind - and on a
		 * short viewport the panel is the one whose actions are furthest from view
		 * at the moment it appears.
		 */
		setPanel( false, null );
		selectTab( 'categories' );

		el.hidden = false;
		setExpanded( true );

		/*
		 * Focus moves ONLY on a user-initiated open. Pulling focus into a banner
		 * that appeared by itself on page load throws the visitor out of whatever
		 * they were doing, and nothing requires it - the banner is reachable by Tab
		 * either way.
		 */
		if ( trigger ) {
			openTrigger = trigger;
			el.setAttribute( 'tabindex', '-1' );
			try {
				el.focus();
			} catch ( e ) {
				// A theme has done something odd to the element. Not fatal.
			}
		}
	}

	function hideBanner() {
		var el = bannerEl();
		setExpanded( false );

		if ( ! el ) {
			openTrigger = null;
			return;
		}

		// Read before hiding: once it is display:none the activeElement has moved.
		var hadFocus = el.contains( document.activeElement );

		el.hidden = true;

		/*
		 * Only reclaim focus if it was actually inside the banner - otherwise we
		 * would yank the visitor away from wherever they really are. Falling back to
		 * the withdrawal control when the banner was auto-shown puts focus on the
		 * one element that is semantically related to what just closed, rather than
		 * dropping it on <body> and sending the next Tab to the top of the page.
		 */
		if ( hadFocus ) {
			var target = openTrigger || document.querySelector( '[data-bsw-action="reopen"]' );
			if ( target ) {
				try {
					target.focus();
				} catch ( e ) {}
			}
		}

		openTrigger = null;
	}

	// -----------------------------------------------------------------------
	// Legacy Usercentrics links
	//
	// Sites across this fleet carry leftover Termageddon/Usercentrics footer
	// markup, verbatim:
	//
	//     <a href="javascript:UC_UI.showSecondLayer();" id="usercentrics-psl">
	//       Privacy Settings</a>
	//
	// Once Usercentrics is removed, `UC_UI` is undefined and that link silently
	// does nothing. It is a DEAD CONSENT-WITHDRAWAL CONTROL sitting in exactly
	// the place a visitor would look for a live one, which is itself an ICO
	// problem - withdrawing consent has to be as easy as giving it.
	//
	// So we define the entry points those links call, and route them at our own
	// banner. Nothing else about Usercentrics is emulated.
	// -----------------------------------------------------------------------

	/**
	 * Matches the calls that appear in real leftover markup, in an href or an
	 * onclick. Used ONLY to decide whether the page already offers a route back -
	 * never to decide whether Usercentrics itself is live, because this pattern
	 * matches the abandoned link as readily as a working one.
	 */
	var UC_LINK_PATTERN = /UC_UI\s*\.\s*show(First|Second)Layer/;

	/**
	 * 🚨 THE FORM REAL SITES ACTUALLY CARRY, and the one we missed.
	 *
	 * Measured on the Beau Property Staging pilot. Termageddon/Usercentrics does
	 * NOT ship the inline-handler markup our own comment above quotes. It ships:
	 *
	 *     <a id="usercentrics-psl">Privacy Settings</a>
	 *
	 * No href. No onclick. Just an id - Usercentrics' own bundle binds the click
	 * by id at runtime, so once the plugin is deactivated there is nothing on the
	 * element to find. `psl` is "privacy settings link".
	 *
	 * That cost us twice on every migrated site: the leftover link was dead, AND
	 * hasLegacyWithdrawalLink() returned false, so the floating pill never stood
	 * down and the page carried two withdrawal affordances, one of them broken.
	 *
	 * ⚠️ WHAT IS AND IS NOT IN THIS LIST. `usercentrics-psl` as an id and as a
	 * class, and any element carrying `data-usercentrics`, are what we can
	 * evidence - from the pilot's own rendered footer and from Usercentrics'
	 * documented markup. Nothing else is guessed at. A selector that matches
	 * nothing costs nothing, but one that matches ANOTHER plugin's element would
	 * hijack an unrelated control, which is a worse bug than the one this fixes.
	 * If a second site turns up a different id, add it here with the markup
	 * recorded beside it.
	 */
	var UC_LEGACY_SELECTOR = '#usercentrics-psl,.usercentrics-psl,[data-usercentrics]';

	/**
	 * Is this href one we are willing to take over?
	 *
	 * 🚨 A REAL DESTINATION IS LEFT ALONE. An element carrying one of the classes
	 * above but pointing at an actual page is a working link to somewhere, and
	 * hijacking it would replace a visitor's navigation with a banner - a new bug
	 * in place of the old one. Only a link that goes NOWHERE is a dead control we
	 * can adopt: no href at all (the pilot's shape), an empty one, `#`, or a
	 * `javascript:` call that no longer resolves.
	 */
	function isDeadHref( href ) {
		if ( '' === href || '#' === href ) {
			return true;
		}
		return 0 === href.toLowerCase().indexOf( 'javascript:' );
	}

	/**
	 * Is this element a leftover Usercentrics withdrawal control?
	 *
	 * One definition, used by BOTH the stand-down check and the click handler, so
	 * the page can never be in the state that caused this bug in reverse: a link
	 * we bind but do not count, leaving two live controls instead of two dead ones.
	 */
	function isLegacyWithdrawalElement( node ) {
		if ( ! node || 1 !== node.nodeType || ! node.getAttribute ) {
			return false;
		}

		var href    = node.getAttribute( 'href' ) || '';
		var onclick = node.getAttribute( 'onclick' ) || '';

		// The inline-handler form. It names UC_UI outright, so there is nothing to
		// weigh: it is ours whatever the href says.
		if ( UC_LINK_PATTERN.test( href ) || UC_LINK_PATTERN.test( onclick ) ) {
			return true;
		}

		/*
		 * The id/class/data form. `getAttribute('class')` rather than `.className`
		 * on purpose: on an SVG element className is an SVGAnimatedString, not a
		 * string, and `.indexOf` on it throws - which during boot would take the
		 * banner with it.
		 */
		var id      = node.getAttribute( 'id' ) || '';
		var classes = ' ' + ( node.getAttribute( 'class' ) || '' ) + ' ';

		var named = 'usercentrics-psl' === id
			|| classes.indexOf( ' usercentrics-psl ' ) > -1
			|| null !== node.getAttribute( 'data-usercentrics' );

		return named && isDeadHref( href );
	}

	/**
	 * The category switch a click will end up OPERATING, or null.
	 *
	 * 🚨 Not simply "is the target a switch". Layer 1 wraps its switch in a
	 * <label>, so a click on the name is a click on a <span> - and the browser
	 * then runs the label's activation behaviour and flips the input. This has to
	 * resolve that case to the same input, or the guard below protects a direct
	 * click on the switch and misses the ordinary way a visitor uses it.
	 *
	 * Walks up rather than reading ev.target alone for the same reason actionFor()
	 * does: page builders wrap labels in their own elements.
	 */
	function categoryToggleFor( node ) {
		while ( node && node !== document ) {
			if ( 1 === node.nodeType && node.getAttribute ) {
				if ( node.getAttribute( 'data-bsw-category-toggle' ) ) {
					return node;
				}

				// A label activates the control it labels, whatever was clicked
				// inside it.
				if ( 'label' === ( node.tagName || '' ).toLowerCase() ) {
					var inner = node.querySelector( '[data-bsw-category-toggle]' );
					if ( inner ) {
						return inner;
					}
				}
			}
			node = node.parentNode;
		}

		return null;
	}

	/**
	 * Walk up from an event target to a leftover Usercentrics control.
	 *
	 * Returns the SAME shape actionFor() does, deliberately: the caller then
	 * treats a legacy link as an ordinary `reopen`, so it takes the identical
	 * code path, inherits the delay-JS replay guard, and needs no branch of its
	 * own that could drift from the real one.
	 *
	 * Walking up matters because the clickable thing is often a <span> inside the
	 * anchor - a page builder wrapping the label in its own element is the norm,
	 * not the exception.
	 */
	function legacyReopenFor( node ) {
		if ( ! legacyLinksAreOurs ) {
			return null;
		}

		while ( node && node !== document ) {
			if ( isLegacyWithdrawalElement( node ) ) {
				return { action: 'reopen', el: node };
			}
			node = node.parentNode;
		}

		return null;
	}

	/**
	 * 🚨 Is REAL Usercentrics on this page?
	 *
	 * If it is, we stand down entirely. Assigning over a live `UC_UI` would break
	 * a working banner on a site mid-migration, which is a far worse outcome than
	 * a dead link on a site that has finished migrating.
	 *
	 * Two signals, and the second is the one that matters. The real loader is
	 * async: `window.UC_UI` is published only once the bundle has initialised,
	 * which on a slow connection is well after DOMContentLoaded. Checking the
	 * object alone would find nothing, install our shim, and leave the two of us
	 * racing. So the page is also searched for the loader ITSELF, which is in the
	 * markup from the first byte.
	 *
	 * Every attribute of every script is checked rather than `src` alone: an
	 * optimiser that defers third-party JS rewrites `src` to `data-<something>-src`,
	 * and a src-only check would then miss a Usercentrics that is merely late.
	 */
	function usercentricsIsPresent() {
		if ( window.UC_UI || window.UC_Integrations || window.__ucCmp || window.usercentrics ) {
			return true;
		}

		var scripts = document.getElementsByTagName( 'script' );
		for ( var i = 0; i < scripts.length; i++ ) {
			if ( 'usercentrics-cmp' === scripts[ i ].id ) {
				return true;
			}
			var attrs = scripts[ i ].attributes;
			for ( var j = 0; attrs && j < attrs.length; j++ ) {
				if ( /usercentrics/i.test( String( attrs[ j ].value ) ) ) {
					return true;
				}
			}
		}

		return false;
	}

	/**
	 * Open the banner in response to something that is not one of our own
	 * controls, so there is no element to hand focus back to on close.
	 *
	 * The active element is preferred because that IS the legacy link in the
	 * common case: a click focuses the anchor, and returning focus there on close
	 * puts the visitor back where they were. Falling back to one of our own reopen
	 * controls is second best but still semantically related to what just closed.
	 *
	 * Returns undefined, always, and see the note on the shim below for why that
	 * is load-bearing rather than incidental.
	 */
	function openWithdrawalUi() {
		// A page with no non-essential tracking renders no banner at all. The link
		// then correctly does nothing - there is nothing to withdraw - and, more to
		// the point, it must not throw. showBanner() would stash a pendingOpen that
		// nothing will ever consume.
		if ( ! bannerEl() ) {
			return;
		}

		var trigger = null;
		var active  = document.activeElement;

		if ( active && 1 === active.nodeType && active !== document.body && active !== document.documentElement ) {
			trigger = active;
		} else {
			trigger = document.querySelector( '[data-bsw-action="reopen"]' );
		}

		// resolve(), not the page's current state, for the same reason the reopen
		// handler re-reads: this asks "what did I actually agree to", whose only
		// honest answer is the persisted record. showBanner() ticks the toggles
		// from it and moves focus.
		showBanner( resolve(), trigger );
	}

	/**
	 * Define window.UC_UI, but only if the real thing is absent.
	 *
	 * ---------------------------------------------------------------------------
	 * WHAT IS SHIMMED, AND WHAT IS DELIBERATELY NOT
	 * ---------------------------------------------------------------------------
	 * Usercentrics' documented CMP v2 browser API is four functions -
	 * showFirstLayer, showSecondLayer, acceptService(id), rejectService(id) - plus
	 * isInitialized() in the v3 surface. Only the ones legacy markup plausibly
	 * calls are defined here, and only where the mapping is honest:
	 *
	 *   showSecondLayer  -> open our banner. This is the one in the fleet's markup.
	 *   showFirstLayer   -> open our banner. We have one layer, not two.
	 *   isInitialized    -> true. Legacy code guards the calls above with it.
	 *
	 * 🚨 acceptService / rejectService / acceptAllConsents / denyAllConsents are
	 * NOT shimmed, and that is a compliance decision rather than an oversight.
	 * They take a Usercentrics service ID, which has no meaning in our category
	 * model, so any mapping would be invented. Worse, they DECIDE consent: a shim
	 * for them would let a leftover script or a stray link grant consent with
	 * nobody asked, which is precisely the failure this plugin exists to prevent.
	 * Left undefined, they throw exactly as they did before this change - so
	 * nothing regresses, and nothing silently consents.
	 *
	 * ---------------------------------------------------------------------------
	 * 🚨 EVERY METHOD HERE RETURNS undefined, AND THAT IS NOT INCIDENTAL
	 * ---------------------------------------------------------------------------
	 * These are called from `href="javascript:..."`. Per the HTML spec, if the
	 * completion value of a javascript: URL is a String, the browser NAVIGATES and
	 * renders that string as the new document. Return a string from
	 * showSecondLayer and clicking the footer link replaces the page with the word
	 * it returned. isInitialized returns a boolean, which is not a String and is
	 * therefore safe.
	 *
	 * @return {boolean} Whether the shim was installed.
	 */
	function installUcUiShim() {
		if ( usercentricsIsPresent() ) {
			return false;
		}

		try {
			window.UC_UI = {
				/* Identifies ours, so a page can tell the shim from the real thing. */
				__bulldogsShim: true,
				showSecondLayer: function () { openWithdrawalUi(); },
				showFirstLayer:  function () { openWithdrawalUi(); },
				isInitialized:   function () { return true; }
			};
		} catch ( e ) {
			// A page that has made window.UC_UI non-writable. Nothing to do about
			// it, and certainly nothing worth throwing out of here for: a throw
			// during boot would take the banner with it.
			return false;
		}

		return true;
	}

	/**
	 * Does the page already carry a legacy control we have made work?
	 *
	 * Two passes, because the two forms live in different places. The id/class/
	 * data form is found by selector and can be on ANY element - Usercentrics'
	 * own docs use a button as readily as an anchor - while the inline-handler
	 * form is only ever on an anchor and is cheapest to find by scanning them.
	 *
	 * Both funnel through isLegacyWithdrawalElement(), so "what counts as a
	 * leftover control" has exactly one definition. Two copies of that rule
	 * drifting apart is how the page ends up standing our pill down for a link
	 * nothing is bound to - which is the bug this function is half of.
	 */
	function hasLegacyWithdrawalLink() {
		var matched = [];

		try {
			matched = document.querySelectorAll( UC_LEGACY_SELECTOR );
		} catch ( e ) {
			// An engine that cannot parse the selector. Fall through to the anchor
			// scan rather than throwing during boot.
			matched = [];
		}

		for ( var i = 0; i < matched.length; i++ ) {
			if ( isLegacyWithdrawalElement( matched[ i ] ) ) {
				return true;
			}
		}

		var anchors = document.getElementsByTagName( 'a' );
		for ( var j = 0; j < anchors.length; j++ ) {
			if ( isLegacyWithdrawalElement( anchors[ j ] ) ) {
				return true;
			}
		}

		return false;
	}

	/**
	 * Stand the floating withdrawal pill down when the page already has a route
	 * back that a visitor would find.
	 *
	 * ConsentModule prints that pill as a FALLBACK - it suppresses it server-side
	 * when the site has placed the [bulldogs_cookie_settings] shortcode, but it
	 * cannot see a legacy Usercentrics link, because only the browser knows
	 * whether one is on the page. This is that half.
	 *
	 * Gated on the shim having installed: if real Usercentrics is live, the link
	 * belongs to ITS banner, not ours, and suppressing our own control would leave
	 * our banner with no route back at all.
	 *
	 * The `hidden` attribute rather than a style, so the control leaves the
	 * accessibility tree too - a pill that is invisible but still tabbable is a
	 * worse outcome than either state on its own.
	 */
	function standDownFixedControls() {
		each( document.querySelectorAll( '[data-bsw-reopen-variant="fixed"]' ), function ( control ) {
			control.hidden = true;
		} );
	}

	// -----------------------------------------------------------------------
	// Decisions
	// -----------------------------------------------------------------------

	function allCategories( value ) {
		var out = {};
		each( CATEGORIES, function ( category ) {
			out[ category ] = value;
		} );
		return out;
	}

	/**
	 * Record a decision and make it true on this page.
	 *
	 * State is built from the decision directly and NOT by re-reading the store. In
	 * private mode the write above is silently swallowed, resolve() would come back
	 * empty, everything would resolve to denied, nothing would flip - and the banner
	 * would still hide. The visitor clicks Accept and the banner simply disappears
	 * with no effect.
	 *
	 * applyConsent runs before flipTags on purpose: Site Kit's gtag defaults are
	 * `denied` with wait_for_update, so its consent update needs to land before a
	 * flipped GTM container starts firing tags into it.
	 *
	 * It is sync(), not updateClarity() alone, and that announce() is REQUIRED
	 * rather than a spare: applyConsent() suppresses consent READS for the length
	 * of its write, so the change events upstream dispatches during it all answer
	 * "denied". The announcement afterwards is what tells a consumer to go and read
	 * the state that is now actually in force - including, on Accept, the grant.
	 * Take it out and a visitor who accepts is never measured.
	 *
	 * The cost, stated so nobody discovers it later: Accept now reaches Site Kit
	 * through announce() alone, where it used to also arrive on the change event
	 * wp_set_consent() dispatches. That is the same single route the return visit
	 * has always depended on - upstream stays silent when nothing changed - so it
	 * adds no new failure mode, it removes a redundancy on one path. Both are
	 * asserted: phase 2 (accept grants) and phase 3 (the return visit grants).
	 */
	function apply( decisions ) {
		persist( decisions );

		var granted = {};
		each( CATEGORIES, function ( category ) {
			granted[ category ] = !! decisions[ category ];
		} );

		current = { granted: granted, stale: [], hasRecord: true };
		decided = true;

		applyConsent( current );
		sync( current );
		flipTags( current );
		hideBanner();
	}

	/**
	 * Walks up from the event target by hand rather than using Element.closest.
	 * ev.target can be a text node, an SVG node inside a button, or the document
	 * itself depending on how the click arrived, and closest() is absent on some of
	 * those - a thrown TypeError here would kill the banner outright.
	 */
	function actionFor( node ) {
		while ( node && node !== document ) {
			if ( 1 === node.nodeType && node.getAttribute ) {
				var action = node.getAttribute( 'data-bsw-action' );
				if ( action ) {
					return { action: action, el: node };
				}
			}
			node = node.parentNode;
		}
		return null;
	}

	/*
	 * -----------------------------------------------------------------------
	 * 🚨 THE DELAY-JS CLICK REPLAY GUARD. Do not remove this.
	 * -----------------------------------------------------------------------
	 * MEASURED IN PRODUCTION on the pilot (template.bulldogs.digital, WP Rocket
	 * + Elementor). WP Rocket's "Delay JavaScript execution" swallows the first
	 * user interaction on the page so it can load its delayed bucket, and then
	 * RE-DISPATCHES that interaction so the visitor's click is not lost.
	 *
	 * That replay is PAGE-GLOBAL. It is not scoped to the scripts WP Rocket
	 * delayed, so it reaches a script it correctly EXCLUDED - and this one is
	 * excluded, by our own `rocket_delay_js_exclusions` filter, verified on the
	 * live page (`data-rocket-src` null, plain `src`). Being excluded does not
	 * help. Logging every capture-phase click on document, then clicking "More
	 * information" three times:
	 *
	 *     CLICK 1: clicks=2  [trusted=true, trusted=false 219ms later]  expanded=false
	 *     CLICK 2: clicks=3  [..., trusted=true]                        expanded=true
	 *     CLICK 3: clicks=4  [..., trusted=true]                        expanded=false
	 *
	 * The original click is NOT suppressed - both events arrive here, which is
	 * why the count rises by two on the first one only.
	 *
	 * WHY IT ONLY BROKE `details`. Every other control in this banner is
	 * IDEMPOTENT: accept, reject and continue-without call apply() with a
	 * decision set fixed at the moment of the click, and save recomputes the same
	 * answer from checkbox state that apply() does not modify. Handling any of
	 * them twice reaches the identical end state, which is why this has been
	 * happening on ~20 WP Rocket / AccelerateWP sites since the plugin shipped
	 * and was invisible. `details` TOGGLES, so two dispatches opened layer 2 and
	 * shut it again: a real visitor's first click did nothing at all, and the
	 * second worked.
	 *
	 * WHY THE GUARD IS SHAPED THE WAY IT IS. It swallows "an untrusted duplicate
	 * of a trusted click I just handled", never "untrusted". Rejecting untrusted
	 * clicks outright would be a quieter bug of its own: synthetic clicks are a
	 * legitimate way for other code to drive our controls, and the whole point of
	 * the UC_UI shim is to serve integrations we do not control. (As it stands
	 * the shim calls showBanner() directly rather than dispatching a click, so it
	 * is unaffected either way - but that is a fact about today's shim, not a
	 * licence to assume no synthetic click ever matters.)
	 *
	 * Keyboard is unaffected: Enter and Space on a <button> produce a TRUSTED
	 * click, which takes the recording branch and is never swallowed. Pinned by
	 * an e2e test rather than left as an assumption.
	 *
	 * The guard lives in the delegated handler, once, rather than inside the
	 * `details` branch. It costs nothing on the idempotent actions and it
	 * protects whatever non-idempotent control is added next - which is the one
	 * that would otherwise rediscover this the same way.
	 */
	var REPLAY_WINDOW_MS = 1000;
	var lastTrustedKey   = null;
	var lastTrustedAt    = 0;

	/**
	 * What the last trusted click LEFT a category switch set to, so a replay that
	 * gets past everything else can still be undone. See restoreToggle().
	 */
	var lastToggleCategory = null;
	var lastToggleChecked  = false;

	/**
	 * A stable name for the control a click resolved to.
	 *
	 * 🚨 NOT the element. This is DEFENCE IN DEPTH rather than the fix for the
	 * live bug - be clear about which, because guessing wrong here cost a release.
	 *
	 * The live cause was non-cancelable dispatch (see the guard below); node
	 * identity was a THEORY that testing disproved. But comparing nodes is fragile
	 * on its own terms: it identifies a replay only if the optimiser hands back
	 * the same object, and nothing obliges it to - cloning the node would produce
	 * a different object for the same control and the comparison would silently
	 * answer "not a replay".
	 *
	 * A key survives that, because it describes what the control IS rather than
	 * which object it happens to be. Category and action names are unique per
	 * layer, and the layer is folded in so the same category in the card and in
	 * the panel cannot be mistaken for each other.
	 */
	function controlKey( el, kind ) {
		if ( ! el || ! el.getAttribute ) {
			return null;
		}

		var name = el.getAttribute( 'toggle' === kind ? 'data-bsw-category-toggle' : 'data-bsw-action' );
		if ( ! name ) {
			return null;
		}

		// Which layer, so layer 1's Analytics and layer 2's Analytics are distinct.
		var layer = '';
		var node  = el;
		while ( node && node !== document ) {
			if ( 1 === node.nodeType && node.getAttribute ) {
				var classes = ' ' + ( node.getAttribute( 'class' ) || '' ) + ' ';
				if ( classes.indexOf( ' bsw-layer-1 ' ) > -1 ) { layer = '1'; break; }
				if ( classes.indexOf( ' bsw-layer-2 ' ) > -1 ) { layer = '2'; break; }
			}
			node = node.parentNode;
		}

		return kind + ':' + layer + ':' + name;
	}

	function nowMs() {
		return Date.now ? Date.now() : ( new Date() ).getTime();
	}

	/**
	 * @param {Event}   ev   The click, trusted or otherwise.
	 * @param {Element} el   The control it resolved to - NOT ev.target. Resolving
	 *                       first means a replay landing on a different descendant
	 *                       of the same button is still caught.
	 * @param {string}  kind `action` or `toggle`, so the key names what it is.
	 * @return {boolean} True if this is a replay of a click we already handled.
	 */
	function isReplayedClick( ev, el, kind ) {
		/*
		 * `false === ev.isTrusted`, not `! ev.isTrusted`. On a browser that does
		 * not implement isTrusted the property is undefined, and treating that as
		 * untrusted would swallow REAL clicks - the one failure direction that
		 * matters, because it would make the banner unusable rather than merely
		 * doubly-responsive. Unknown means trusted.
		 */
		var key = controlKey( el, kind || 'action' );

		if ( false !== ev.isTrusted ) {
			lastTrustedKey = key;
			lastTrustedAt  = nowMs();
			return false;
		}

		return null !== key && key === lastTrustedKey && ( nowMs() - lastTrustedAt ) < REPLAY_WINDOW_MS;
	}

	/**
	 * Put a category switch back to what the visitor's own click left it at.
	 *
	 * 🚨 THIS IS THE FIX, not a nicety. preventDefault() alone does not work.
	 *
	 * WP Rocket dispatches the replayed click NON-CANCELABLE, so preventDefault()
	 * is a no-op and the browser's checkbox activation runs whatever our listener
	 * decides. That is why the 0.5.2 guard - which suppressed our handler and
	 * called preventDefault - passed every test and still flipped switches back on
	 * the live pilot, three runs out of three.
	 *
	 * Established by dispatching six replay shapes at the shipped guard and
	 * measuring which reproduced the live symptom. Exactly one did:
	 * `cancelable: false`. The harness now dispatches that shape, so this is
	 * reproduced here rather than only in production.
	 *
	 * Re-asserting the state works regardless: it does not depend on the event
	 * being cancelable, on the activation ordering, or on which node object the
	 * optimiser hands back. A timeout rather than an inline write, because the
	 * activation runs after this listener returns.
	 *
	 * It only ever restores the value a TRUSTED click established, so it cannot
	 * invent a choice or fight a later genuine one: a real click in the meantime
	 * updates the record it reads from.
	 */
	function restoreToggle( category, checked ) {
		window.setTimeout( function () {
			// Only if it actually moved. A no-op write would still fire nothing,
			// but checking keeps this from touching the DOM on every replay.
			var el = bannerEl();
			if ( ! el ) {
				return;
			}

			var box = el.querySelector( '[data-bsw-category-toggle="' + category + '"]' );
			if ( box && box.checked !== checked ) {
				syncCategory( category, checked );
			}
		}, 0 );
	}

	/**
	 * Delegated, and bound during boot rather than at DOMContentLoaded: the
	 * withdrawal control is server-rendered and clickable as soon as the footer
	 * paints, which on a page with blocking footer scripts is well before
	 * DOMContentLoaded fires.
	 *
	 * Capture phase, because a theme or plugin calling stopPropagation() on clicks
	 * inside its own container would otherwise silently disable every control in
	 * this banner, on an unknown theme, with no error to find.
	 */
	function bindUI() {
		document.addEventListener( 'click', function ( ev ) {
			/*
			 * Our own controls first, then the page's leftover Usercentrics ones.
			 *
			 * 🚨 DELEGATED, not bound to a node list captured once. Divi and
			 * Elementor inject footers after DOMContentLoaded, and a list built at
			 * load time would miss exactly the sites this is for. Delegation also
			 * handles however many leftovers a page carries - they turn up more than
			 * once on real sites - with no bookkeeping at all.
			 *
			 * legacyReopenFor() returns the same shape as actionFor(), so a legacy
			 * link becomes an ordinary `reopen` from here down: same code path, same
			 * delay-JS replay guard below, and no second implementation to drift.
			 * Reopening is idempotent - showBanner() opens, it does not toggle - so
			 * a replayed first click cannot open-then-close it.
			 */
			var hit = actionFor( ev.target ) || legacyReopenFor( ev.target );

			if ( ! hit ) {
				/*
				 * 🚨 A CATEGORY SWITCH IS ALSO REPLAYED, and this was missed the
				 * first time round. MEASURED on the delay-JS fixture: check
				 * Analytics as the first interaction on the page, wait 600ms, and it
				 * is unchecked again.
				 *
				 * The guard used to sit AFTER this early return, so it only ever saw
				 * clicks on `data-bsw-action` controls. A switch carries
				 * `data-bsw-category-toggle` and nothing else, so the handler bailed
				 * out, the guard never recorded it, and the browser's own checkbox
				 * activation flipped it back - none of our code had to run for the
				 * damage to happen.
				 *
				 * This is WORSE than the `details` bug that prompted the guard. That
				 * one made a disclosure do nothing; this silently REVERSES a consent
				 * choice, and if the visitor then presses Save we persist the
				 * opposite of what they picked.
				 *
				 * preventDefault() is what undoes it, and it works because this
				 * listener is on the CAPTURE phase: we run before the checkbox's
				 * activation behaviour, and a cancelled activation is reverted by the
				 * browser rather than merely not applied. Cancelling the replayed
				 * click on a <span> inside the label likewise stops the label ever
				 * activating the input.
				 */
				var toggle = categoryToggleFor( ev.target );
				if ( ! toggle ) {
					return;
				}

				if ( isReplayedClick( ev, toggle, 'toggle' ) ) {
					/*
					 * Both halves, and the SECOND is the one that works.
					 * preventDefault() handles a cancelable replay; restoreToggle()
					 * handles the non-cancelable one WP Rocket actually sends, where
					 * preventDefault is a no-op. See restoreToggle().
					 */
					ev.preventDefault();

					if ( null !== lastToggleCategory ) {
						restoreToggle( lastToggleCategory, lastToggleChecked );
					}
					return;
				}

				/*
				 * A trusted click. Record what the visitor chose.
				 *
				 * 🚨 `toggle.checked` ALREADY HOLDS THE NEW VALUE here, and an
				 * earlier version of this line got that backwards and recorded the
				 * inverse. The HTML spec runs a checkbox's "pre-click activation
				 * steps" - which flip `checked` - BEFORE the click event is
				 * dispatched, so by the time a capture-phase listener sees the
				 * event the box already reads what the visitor asked for.
				 *
				 * Measured, not reasoned: on a trusted click the capture-phase
				 * trace reads `checked: true` on the way to turning something on.
				 */
				lastToggleCategory = toggle.getAttribute( 'data-bsw-category-toggle' );
				lastToggleChecked  = !! toggle.checked;
				return;
			}

			// AFTER actionFor, deliberately: only clicks on OUR controls are
			// recorded, so a first interaction elsewhere on the page cannot leave a
			// stale timestamp that swallows something of ours a moment later.
			if ( isReplayedClick( ev, hit.el, 'action' ) ) {
				return;
			}

			if ( 'accept' === hit.action ) {
				apply( allCategories( true ) );
				return;
			}

			/*
			 * 🚨 ONE branch, two controls, and that is the point.
			 *
			 * `continue-without` is the "Continue without accepting →" link in the
			 * card header. It must record a GENUINE, PERSISTED refusal - the same
			 * state Reject writes - and not merely dismiss the banner.
			 *
			 * A dismissal leaves no record, so resolve() finds nothing on the next
			 * page and the banner re-opens. That is nagging rather than a refusal
			 * route, and under the ICO's "refusing must be as easy as consenting" it
			 * is worse than having no such link at all: the visitor believes they
			 * have answered and is asked again on every page.
			 *
			 * The two share this single `apply( allCategories( false ) )` call rather
			 * than having one each, so no later edit can make one of them weaker
			 * than the other without deleting the other outright.
			 */
			if ( 'reject' === hit.action || 'continue-without' === hit.action ) {
				apply( allCategories( false ) );
				return;
			}

			/*
			 * 🚨 DISCLOSURE CONTROLS, NOT CHOICES. None of these four record
			 * anything: no apply(), no persist(), no store write, no box.checked,
			 * and none of them closes the banner. The visitor has read more and
			 * still has to answer.
			 *
			 * They are also all deliberately IDEMPOTENT except the chevron - open
			 * and close are separate actions rather than one toggle, and a tab is
			 * selected rather than cycled. That is a direct response to the
			 * delay-JS click replay above: a toggle is the shape that gets opened
			 * and shut again by one physical click, so there is exactly one of them
			 * left and the guard covers it.
			 */
			if ( 'details' === hit.action ) {
				setPanel( true, hit.el );
				return;
			}

			if ( 'details-close' === hit.action ) {
				setPanel( false, null );
				return;
			}

			if ( 'tab' === hit.action ) {
				selectTab( hit.el.getAttribute( 'data-bsw-tab' ) );
				return;
			}

			if ( 'services-toggle' === hit.action ) {
				toggleServices( hit.el );
				return;
			}

			if ( 'reopen' === hit.action ) {
				/*
				 * Re-reads the store, where apply() deliberately does not, and the
				 * asymmetry is correct: apply() is about what is in force on this page
				 * right now, whereas reopening asks "what did I actually agree to",
				 * whose only honest answer is the persisted record - the thing that
				 * will still be in force on the next page. The two only diverge where
				 * persistence is impossible anyway, and there the store is telling the
				 * truth: the choice did not stick.
				 */
				showBanner( resolve(), hit.el );
				return;
			}

			if ( 'save' === hit.action ) {
				/*
				 * Scoped to the banner, not the document. A second element carrying the
				 * same data attribute elsewhere on the page - a duplicated footer
				 * widget, a page builder preview - would otherwise be read instead of
				 * the box the visitor just ticked.
				 */
				var el = bannerEl();
				if ( ! el ) {
					return;
				}
				/*
				 * One switch per category is enough: syncCategory() keeps layer 1's
				 * and layer 2's identical on every change, so by the time Save is
				 * pressed they cannot disagree. An e2e test flips in the panel and
				 * saves from there, which is the path that would break first if the
				 * sync ever stopped running.
				 */
				var chosen = {};
				each( CATEGORIES, function ( category ) {
					var box = el.querySelector( '[data-bsw-category-toggle="' + category + '"]' );
					chosen[ category ] = !! ( box && box.checked );
				} );
				apply( chosen );
			}
		}, true );

		/*
		 * 🚨 KEEP THE TWO SETS OF SWITCHES IN STEP.
		 *
		 * The same categories are shown twice - layer 1's inline pair and layer 2's
		 * card - and there is exactly ONE state behind them. Without this a visitor
		 * could flip Analytics in the panel, close it, and see the card still
		 * saying the opposite; only one of the two would reach the record, and
		 * which one would depend on document order.
		 *
		 * A `change` listener rather than a click one, because a checkbox also
		 * changes from the keyboard (Space) and from assistive technology, and a
		 * click handler hears none of that.
		 *
		 * NOT capture phase, deliberately: `change` does not fire until the browser
		 * has settled the new checked value, and reading it during capture on the
		 * way down would be reading it before it is true.
		 */
		document.addEventListener( 'change', function ( ev ) {
			var box = ev.target;
			if ( ! box || 1 !== box.nodeType || ! box.getAttribute ) {
				return;
			}

			var category = box.getAttribute( 'data-bsw-category-toggle' );
			if ( ! category ) {
				return;
			}

			// No consent is recorded here. Flipping a switch is not an answer - the
			// answer is Save, or Accept, or Reject. This only mirrors the state.
			syncCategory( category, box.checked );
		} );

		/*
		 * Escape closes LAYER 2 and returns focus to whatever opened it.
		 *
		 * Only the panel. Escape does NOT dismiss the banner: a keypress that
		 * silently closed a consent notice would leave no record, so the banner
		 * would return on the next page - nagging rather than a refusal, which is
		 * the exact failure "Continue without accepting" exists to avoid.
		 */
		document.addEventListener( 'keydown', function ( ev ) {
			// `key` first, `keyCode` for the old WebViews that never got it.
			if ( 'Escape' !== ev.key && 'Esc' !== ev.key && 27 !== ev.keyCode ) {
				return;
			}
			if ( panelOpen() ) {
				setPanel( false, null );
			}
		} );
	}

	// -----------------------------------------------------------------------
	// Boot - synchronously, in <head>, before Site Kit's DOMContentLoaded handler
	// -----------------------------------------------------------------------

	bindUI();

	current = resolve();

	// The explicit deny for stale and absent categories lands here, which is the
	// whole reason this file is not deferred.
	applyConsent( current );

	sync( current );

	ready( function () {
		/*
		 * Re-resolve rather than reuse the boot capture. Between <head> and
		 * DOMContentLoaded another tab can write the store, or a script can clear
		 * localStorage wholesale, and the tags we flip, the cookies we set and the
		 * banner we show must all derive from one read rather than from a stale one.
		 * Skipped once the visitor has already answered on this page, so a decision
		 * that could not be persisted is not immediately overwritten by an empty
		 * store.
		 */
		if ( ! decided ) {
			current = resolve();
			applyConsent( current );
		}

		/*
		 * Announce before flipping, for the same reason applyConsent runs before
		 * flipTags in apply(): the boot dispatch reached nobody, so THIS is the
		 * announcement Site Kit actually hears, and its gtag consent update should
		 * land before a flipped GTM container starts pushing events at it.
		 */
		sync( current );
		flipTags( current );

		/*
		 * The legacy-link work, at DOMContentLoaded rather than during boot.
		 *
		 * Both halves need the DOM: the stand-down check has to see the footer's
		 * anchors, and the Usercentrics detection has to see the whole of <head>
		 * (our own script is at the TOP of it, so at boot a Usercentrics loader
		 * printed below us has not been parsed yet and we would wrongly conclude
		 * it is absent). Nothing can click a footer link before the footer exists,
		 * so no interaction is lost by waiting.
		 */
		if ( installUcUiShim() ) {
			/*
			 * Set BEFORE the stand-down check, and unconditionally on shim install.
			 *
			 * The flag says "real Usercentrics is absent, so these controls are ours
			 * to drive"; the stand-down says "and there is at least one of them, so
			 * our pill is redundant". A page with none is still a page where any
			 * that arrive LATER - a Divi or Elementor footer injected after
			 * DOMContentLoaded - should work when clicked, and the delegated handler
			 * is what makes that free.
			 */
			legacyLinksAreOurs = true;

			if ( hasLegacyWithdrawalLink() ) {
				standDownFixedControls();
			}
		}

		if ( pendingOpen ) {
			var trigger = pendingOpen;
			pendingOpen = null;
			showBanner( resolve(), trigger );
			return;
		}

		if ( ! decided && ( ! current.hasRecord || current.stale.length > 0 ) ) {
			showBanner( current, null );
		}
	} );

	// Last chance for a consumer whose script loaded async, and for Clarity's own
	// async loader to have defined its queue stub.
	loaded( function () {
		sync( current );
	} );
}() );
