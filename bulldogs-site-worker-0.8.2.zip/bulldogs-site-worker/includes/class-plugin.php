<?php
namespace Bulldogs\SiteWorker;

/**
 * Boots modules in isolation. A module that throws is recorded and skipped;
 * it must never surface as a fatal, because that is a white screen on a
 * client site.
 *
 * ---------------------------------------------------------------------------
 * A DISABLED MODULE IS NOT BOOTED. NOT BOOTED QUIETLY - NOT BOOTED.
 * ---------------------------------------------------------------------------
 * Modules decides which are on (see that class for what "off" has to mean and
 * why). This class's only job with that answer is to skip the callback entirely:
 * no hooks registered, no filters added, no assets enqueued, no output. A module
 * that booted and then checked a flag inside each of its callbacks would leave a
 * trail - a `wp_get_consent_type` filter, an enqueued script - and a dormant
 * install has to be indistinguishable from no install.
 *
 * Skipped and failed are kept apart deliberately. "We chose not to run this" and
 * "this blew up" look identical from the outside and mean opposite things to
 * whoever is reading a fleet report.
 */
class Plugin {
    /** @var array<string, callable> */
    private array $modules = [];
    /** @var string[] */
    private array $failed = [];
    /** @var string[] */
    private array $skipped = [];

    /**
     * @param Modules|null $enabled Which modules are switched on. Null means boot
     *                              everything that was added, which is what the
     *                              tests of this class's isolation behaviour want
     *                              and what any caller that has already decided
     *                              wants; the real plugin always passes one.
     */
    public function __construct( private ?Modules $enabled = null ) {}

    public function add_module( string $name, callable $boot ): void {
        $this->modules[ $name ] = $boot;
    }

    public function boot(): void {
        foreach ( $this->modules as $name => $boot ) {
            try {
                if ( ! $this->is_enabled( $name ) ) {
                    $this->skipped[] = $name;
                    continue;
                }
                $boot();
            } catch ( \Throwable $e ) {
                $this->failed[] = $name;
                $this->log_failure( $name, $e );
            }
        }
    }

    /** @return string[] Modules whose boot callback threw. */
    public function failed_modules(): array {
        return $this->failed;
    }

    /** @return string[] Modules that are switched off on this site. */
    public function skipped_modules(): array {
        return $this->skipped;
    }

    /**
     * Inside the try/catch, deliberately.
     *
     * Reading the flags touches the option store, and a database that is refusing
     * reads must not take the site down. The consequence of a throw here is that
     * the module is recorded as FAILED and skipped - the same treatment a module
     * that blew up on boot has always had, and the state Scanner's
     * `consent_module_unhealthy` finding exists to catch. Inventing a different
     * failure direction for this one case would mean two answers to "why is the
     * consent module not running".
     */
    private function is_enabled( string $name ): bool {
        return null === $this->enabled || $this->enabled->is_enabled( $name );
    }

    private function log_failure( string $name, \Throwable $e ): void {
        if ( function_exists( 'error_log' ) ) {
            error_log( sprintf( 'bulldogs-site-worker: module "%s" failed to boot: %s', $name, $e->getMessage() ) );
        }
    }
}
