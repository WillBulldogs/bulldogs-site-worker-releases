<?php
namespace Bulldogs\SiteWorker;

/** Shared option store for both modules. Degrades rather than raising. */
class Settings {
    public const OPTION = 'bulldogs_site_worker';

    private function all(): array {
        $raw = get_option( self::OPTION, [] );
        return is_array( $raw ) ? $raw : [];
    }

    public function get( string $key, mixed $default = null ): mixed {
        return $this->all()[ $key ] ?? $default;
    }

    /**
     * Every key currently stored.
     *
     * Exists for Modules::migrate(), which has to answer "has ANY earlier version
     * of this plugin ever written to this site" without caring what it wrote. The
     * alternative is exposing all(), and a public accessor returning the whole
     * option would invite callers to read keys directly rather than through the
     * class that owns each one.
     *
     * @return string[]
     */
    public function keys(): array {
        return array_map( 'strval', array_keys( $this->all() ) );
    }

    public function set( string $key, mixed $value ): void {
        $all         = $this->all();
        $all[ $key ] = $value;
        update_option( self::OPTION, $all );
    }
}
