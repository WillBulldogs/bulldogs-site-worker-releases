<?php
namespace Bulldogs\SiteWorker\CLI;

use Bulldogs\SiteWorker\Update\Manifest;
use Bulldogs\SiteWorker\Update\ManifestClient;
use WP_CLI;

/**
 * `wp bulldogs update ...`
 *
 * The answer to "what version is this site on, and does it know about the new
 * one?" without SSHing in and reading a plugin header. It is the command that
 * gets looped over 29 sites after a release to prove the release actually
 * reached them, so its output is a single row and its exit code is boring.
 *
 * ---------------------------------------------------------------------------
 * WHY THIS NEVER EXITS NON-ZERO FOR AN UNREACHABLE MANIFEST
 * ---------------------------------------------------------------------------
 * The expected use is a shell loop across the fleet. WP_CLI::error() exits 1 and
 * would stop that loop - or, worse, be swallowed by `&&` and make one unreachable
 * site look like the whole fleet failed. An unreachable release host is reported
 * in the row and as a warning, and the command still succeeds, because the useful
 * output is the installed version and that is known regardless.
 */
class UpdateCommands {
    /** Fields `check` prints. */
    private const CHECK_FIELDS = [ 'installed', 'available', 'update', 'manifest', 'source' ];

    /**
     * Report the installed version against the published one.
     *
     * Reads through the same ManifestClient the update filter uses, including its
     * transient - so what this prints is what WordPress would act on, not a
     * separate opinion. Pass --refresh when that is the wrong thing, e.g. straight
     * after a release.
     *
     * ## OPTIONS
     *
     * [--refresh]
     * : Ignore the cached manifest and re-read it from the release host.
     *
     * [--format=<format>]
     * : Render output in a particular format.
     * ---
     * default: table
     * options:
     *   - table
     *   - json
     *   - csv
     *   - yaml
     * ---
     *
     * ## EXAMPLES
     *
     *     wp bulldogs update check
     *     wp bulldogs update check --refresh
     *     wp bulldogs update check --format=json
     *
     * @param array $args  Positional arguments. Unused.
     * @param array $assoc Associative arguments.
     */
    public function check( $args, $assoc ): void {
        $format = isset( $assoc['format'] ) && is_string( $assoc['format'] ) ? $assoc['format'] : 'table';

        $client = new ManifestClient();

        if ( ! empty( $assoc['refresh'] ) ) {
            // forget() as well as bypassing, so the next ordinary update check on
            // this site also sees the fresh answer rather than the stale cache
            // this command just worked around.
            $client->forget();
        }

        $manifest = $client->fetch( ! empty( $assoc['refresh'] ) );

        $row = self::report(
            defined( 'BULLDOGS_SW_VERSION' ) ? BULLDOGS_SW_VERSION : '',
            $manifest,
            $client->last_error(),
            $client->was_cached()
        );

        \WP_CLI\Utils\format_items( $format, [ $row ], self::CHECK_FIELDS );

        if ( null === $manifest ) {
            WP_CLI::warning( 'No usable manifest, so this site will not be offered an update. ' . (string) $client->last_error() . '.' );
            return;
        }

        if ( 'yes' === $row['update'] ) {
            WP_CLI::log( sprintf( 'Update available: %s -> %s.', $row['installed'], $row['available'] ) );
        }
    }

    /**
     * The printable row.
     *
     * Pure and static so it can be tested: everything else on this class touches
     * WP_CLI, which does not exist outside a real install. Same split as
     * MonitorCommands::rows().
     *
     * @param string        $installed The running version.
     * @param Manifest|null $manifest  What the release host said, if anything usable.
     * @param string|null   $error     Why there is no manifest, in words.
     * @param bool          $cached    Whether that answer came from the transient.
     * @return array{installed:string, available:string, update:string, manifest:string, source:string}
     */
    public static function report( string $installed, ?Manifest $manifest, ?string $error, bool $cached ): array {
        if ( null === $manifest ) {
            return [
                'installed' => $installed,
                'available' => '',
                // Not 'no'. "No update available" and "we could not find out" are
                // different states, and reporting the second as the first is how a
                // fleet quietly stops updating without anyone noticing.
                'update'    => 'unknown',
                'manifest'  => null === $error || '' === $error ? 'unreadable' : $error,
                'source'    => $cached ? 'cache' : 'release host',
            ];
        }

        return [
            'installed' => $installed,
            'available' => $manifest->version(),
            'update'    => '' !== $installed && $manifest->is_newer_than( $installed ) ? 'yes' : 'no',
            'manifest'  => 'ok',
            'source'    => $cached ? 'cache' : 'release host',
        ];
    }
}
