<?php
namespace Bulldogs\SiteWorker\Consent;

/**
 * Which categories the banner must offer on THIS site.
 *
 * ---------------------------------------------------------------------------
 * DRIVEN BY TRACKING PRESENT, NOT BY THE REGISTRY. Read this before editing.
 * ---------------------------------------------------------------------------
 * Google Site Kit's own tag is deliberately never registered with TagRegistry.
 * It keeps emitting, ungated, governed by its own Consent Mode `denied`
 * defaults - our only job for it is to GRANT once the visitor consents.
 *
 * So on a site whose only tracker is Site-Kit-managed GA4 - likely most of the
 * fleet, since 24 of 29 run Site Kit and few have anything else - the registry
 * is EMPTY. Key the banner off the registry alone and those sites render no
 * banner, nobody can consent, Site Kit's denied defaults stand forever: the
 * site is perfectly compliant and its analytics is permanently dead. That is
 * the exact failure this plugin exists to eliminate.
 *
 *     banner categories = registry categories
 *                       u categories implied by active Site Kit modules
 *                         (analytics-4 -> statistics; ads -> marketing)
 *
 * Its own class, not a private method on ConsentModule, because MonitorModule
 * needs the identical answer - "what should this site be asking about" is the
 * same question for "what do we render" and "what do we check for". A private
 * copy over there would drift, and the two would disagree silently.
 */
class BannerCategories {
    /**
     * Site Kit's active-module list. Slugs, e.g. search-console, analytics-4, ads.
     */
    private const OPTION = 'googlesitekit_active_modules';

    /**
     * Site Kit's pre-1.x option name. Site Kit itself still falls back to this
     * when the modern option is absent, so a site that has not re-saved its
     * module list since upgrading can still be running analytics with only the
     * legacy option present. Missing that reproduces exactly the dead-analytics
     * failure this class exists to prevent, and consulting it can only ever ADD
     * a category - never remove one - so the downside is a toggle for a category
     * with nothing behind it, against an upside of the banner existing at all.
     */
    private const LEGACY_OPTION = 'googlesitekit-active-modules';

    /** Site Kit's own consent-mode settings. */
    private const CONSENT_MODE_OPTION = 'googlesitekit_consent_mode';

    /** Site Kit module slug => the consent category its tag needs. */
    private const MODULE_CATEGORIES = [
        'analytics-4' => 'statistics',
        'ads'         => 'marketing',
    ];

    /**
     * Site Kit module slug => what to CALL it in front of a visitor.
     *
     * The banner's layer-2 detail regions name the third parties in each category,
     * which is what a visitor needs in order to judge one and what PECR asks the
     * cookie policy to carry. Site Kit's tags are deliberately never registered
     * with TagRegistry, so without this the Site-Kit-only sites - most of the fleet
     * - would open a detail region with no services line on the one category that
     * genuinely has a service behind it.
     *
     * Product names, not module slugs: "analytics-4" means nothing to a visitor.
     * Deliberately NOT run through __(): these are proper nouns, and a translator
     * inventing a local name for Google Analytics would make the disclosure less
     * accurate rather than more readable.
     *
     * Keyed on the same slugs as MODULE_CATEGORIES so the two lists cannot cover
     * different modules.
     */
    private const MODULE_SERVICES = [
        'analytics-4' => 'Google Analytics',
        'ads'         => 'Google Ads',
    ];

    /**
     * Memoised for the life of this instance.
     *
     * Not just a saving: ConsentModule asks twice per request (once to build the
     * localized stamps, once to render the banner rows) and those two answers
     * MUST agree. If an option changed between the two calls the page would
     * carry a stamp for a category with no toggle, or a toggle with no stamp.
     * Per-instance rather than static, matching TagRegistry, so a long-running
     * WP-CLI process that mutates options can build a fresh one.
     *
     * @var string[]|null
     */
    private ?array $categories = null;

    /**
     * Memoised for the same reason, and it is the same reason rather than a
     * similar one: the banner renders its rows and its detail regions from two
     * separate reads, and two different answers on one page would be a banner
     * whose rows and whose disclosure describe different sites.
     *
     * @var array<string, string[]>|null
     */
    private ?array $services = null;

    public function __construct( private TagRegistry $registry ) {}

    /** @return string[] */
    public function all(): array {
        if ( null !== $this->categories ) {
            return $this->categories;
        }

        $categories = $this->registry->active_categories();

        foreach ( self::MODULE_CATEGORIES as $module => $category ) {
            if ( $this->site_kit_module_active( $module ) ) {
                $categories[] = $category;
            }
        }

        return $this->categories = array_values( array_unique( $categories ) );
    }

    /**
     * The Site-Kit-managed services running on this site, by category.
     *
     * ---------------------------------------------------------------------------
     * WHY THIS IS HERE AND NOT IN ConsentModule
     * ---------------------------------------------------------------------------
     * Exactly the argument that put all() here. "What is Site Kit running" is one
     * question with one answer, and both the consent module (which renders it) and
     * the monitor module (which checks the page against it) need it. A private copy
     * on either side would drift, and the drift would be silent.
     *
     * ---------------------------------------------------------------------------
     * WHAT IT DOES *NOT* COVER
     * ---------------------------------------------------------------------------
     * Registered tags. Those live in TagRegistry and carry their own optional
     * `label`, and ConsentModule merges the two. Splitting it that way keeps each
     * source answering only for its own data - this class has no business deciding
     * what a registry entry should be called.
     *
     * Every key returned is a category all() also returns, and that is an invariant
     * rather than a coincidence: both are derived from the same active-module list,
     * through the same two maps, keyed on the same slugs. A services line for a
     * category with no row would be a claim about tracking the visitor is offered
     * no control over.
     *
     * @return array<string, string[]> category => service names, in module order.
     */
    public function services(): array {
        if ( null !== $this->services ) {
            return $this->services;
        }

        $services = [];
        foreach ( self::MODULE_CATEGORIES as $module => $category ) {
            if ( ! $this->site_kit_module_active( $module ) ) {
                continue;
            }
            // Guarded rather than assumed. The two maps are keyed identically today;
            // adding a slug to one and not the other must produce a category with no
            // services line, not an undefined-index notice on a live page.
            if ( ! isset( self::MODULE_SERVICES[ $module ] ) ) {
                continue;
            }
            $services[ $category ][] = self::MODULE_SERVICES[ $module ];
        }

        return $this->services = $services;
    }

    /** Is Site Kit present and managing at least one module? */
    public function site_kit_active(): bool {
        return [] !== $this->active_modules();
    }

    /**
     * Has Site Kit's own Consent Mode been switched on?
     *
     * If it has not, Site Kit's gtag never receives the `default` denied state,
     * so its tag is not gated by anything and consent is decorative. The monitor
     * module reports on this; nothing here acts on it.
     */
    public function consent_mode_on(): bool {
        $mode = $this->option( self::CONSENT_MODE_OPTION );
        return is_array( $mode ) && ! empty( $mode['enabled'] );
    }

    private function site_kit_module_active( string $module ): bool {
        // Strict, so a nested array or a stray 0 in the option cannot loosely
        // match a module slug and invent a category.
        return in_array( $module, $this->active_modules(), true );
    }

    /**
     * @return array<int|string, mixed> Whatever Site Kit stored - unvalidated. Callers
     *                                  must only ever ask "is this slug in here".
     */
    private function active_modules(): array {
        $modules = $this->option( self::OPTION );
        if ( is_array( $modules ) && [] !== $modules ) {
            return $modules;
        }

        $legacy = $this->option( self::LEGACY_OPTION );
        return is_array( $legacy ) ? $legacy : [];
    }

    /**
     * get_option() exists from wp-settings.php onwards and this class is only
     * constructed on plugins_loaded, so the guard is belt-and-braces against the
     * standing rule that nothing throws at runtime: calling an undefined function
     * is a fatal, and a fatal is a white screen on a live client site.
     */
    private function option( string $name ): mixed {
        return function_exists( 'get_option' ) ? get_option( $name, [] ) : [];
    }
}
