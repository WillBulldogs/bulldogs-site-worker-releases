<?php
namespace Bulldogs\SiteWorker\Consent;

/**
 * Banner markup. Rendered identically for every visitor and hidden by default;
 * the client script decides visibility from the stored record.
 *
 * Three invariants, in priority order:
 *
 *   1. REJECT IS AS PROMINENT AS ACCEPT. Both buttons are the same element type,
 *      carry the same class, sit in the same container, and neither carries an
 *      inline style. That is deliberate: it is what stops a theme stylesheet -
 *      or a later edit here - quietly demoting Reject, which is the single most
 *      common way a consent banner is found non-compliant (ICO guidance on
 *      cookies and similar technologies).
 *
 *      "Save settings" is NOT bound by this and is deliberately quieter (see
 *      BTN_SECONDARY). It is a third action, not the counterpart to consenting.
 *      Refusing has two equal-or-better routes - the Reject button, and
 *      "Continue without accepting" in the card header - so the balance the rule
 *      protects is intact.
 *   2. NO PRE-TICKED BOXES, AND NO PRE-FLIPPED SWITCHES. Category inputs render
 *      unchecked, always. The reference banner this layout was taken from ships
 *      Marketing and Functional pre-enabled; that is precisely what Planet49
 *      (CJEU C-673/17) held is not consent, and the ICO says the same about
 *      pre-ticked and pre-toggled controls. Adopting the LOOK of that banner
 *      does not adopt its defaults. The client script sets the checked state
 *      from the stored record when the banner is reopened, which is also why the
 *      checked state must never be baked into the cached HTML.
 *
 *      The switches are real `<input type="checkbox">` elements drawn by CSS, not
 *      divs with a role. Keyboard operation, focus-visible and the announced
 *      semantics all come free that way and all break silently the other way.
 *   3. CACHE-INVARIANT AND PURE. Same input, same output, every call. Full-page
 *      caches serve one rendered body to every visitor, so this markup must not
 *      vary by consent state, request state, clock or randomness. If it ever
 *      did, the first visitor to hit a cold cache would decide what every later
 *      visitor sees.
 *
 * Withdrawal is served by render_withdrawal_control(), a persistent control that
 * reopens the banner. Withdrawing consent has to be as easy as giving it, so the
 * route back cannot live only inside a banner that is dismissed and gone.
 *
 * ---------------------------------------------------------------------------
 * TWO LAYERS, BOTH CACHED, ONLY ONE EVER VISIBLE
 * ---------------------------------------------------------------------------
 * LAYER 1 is the compact card: a strip carrying "Continue without accepting",
 * the title, one sentence of intro, ONE INLINE RUN of name-and-switch pairs, a
 * row of links (Cookie policy, Privacy policy, More information) and the three
 * actions.
 *
 * 🚨 LAYER 1 CARRIES NO PER-CATEGORY DESCRIPTION. Not a sentence, not a hint,
 * not two words. Every word of explanation lives in layer 2, and that is the
 * entire point of layer 2 existing. A future edit that puts a hint back beside a
 * category name has undone the change - BannerRendererTest asserts there is no
 * descriptive element in layer 1 at all.
 *
 * LAYER 2 is the full panel behind "More information": a heading with a close
 * control, an intro, a privacy link, two tabs (Categories and Services), a
 * bordered card per category carrying the full sentence, its switch and a
 * chevron revealing its services, and the same three actions.
 *
 * Both render into the CACHED HTML and layer 2 renders `hidden`, because a
 * full-page cache serves one body to every visitor and the closed state has to
 * be the state in the markup. Nothing here is built in JavaScript.
 *
 * Opening layer 2 HIDES layer 1. That is what keeps the equal-prominence rule
 * intact with two sets of buttons on the page - see actions().
 *
 * ---------------------------------------------------------------------------
 * WHICH CONTROLS TOGGLE, AND WHY IT MATTERS
 * ---------------------------------------------------------------------------
 * WP Rocket's delay-JS replays the first click on the page as an untrusted
 * synthetic event, so any control that TOGGLES is opened and shut again by one
 * physical click. That shipped as a bug once already (see the guard in
 * consent.js), so this layout is deliberately built to minimise the surface:
 *
 *   - `details` OPENS layer 2 and `details-close` CLOSES it. Two controls, not
 *     one toggle, so both are idempotent.
 *   - `tab` SELECTS a tab rather than cycling, so it is idempotent.
 *   - the chevron is the ONLY toggle left in the banner. The guard covers it and
 *     an e2e test on the delay-JS scenario pins that it does.
 *
 * Keep it that way. A new control that toggles is a new control exposed to this.
 *
 * ---------------------------------------------------------------------------
 * THE THEME CLASS
 * ---------------------------------------------------------------------------
 * The root carries `bsw-theme-light` or `bsw-theme-dark` alongside `bsw-banner`.
 * assets/css/banner.css holds one complete palette per preset and inherits
 * nothing but `font-family`, because inheriting `color` is what let a host theme
 * paint our buttons: Elementor's kit prints a `button` rule at a specificity our
 * old `.bsw-btn { color: inherit }` could not beat, and Accept/Reject rendered
 * raspberry pink on the pilot site.
 *
 * The class is emitted on OUR element rather than switched by a body class or a
 * media query on purpose. A preset is a per-site decision an operator makes with
 * `wp bulldogs consent banner-theme`; it must not move because a visitor's OS is
 * in dark mode, and it must not depend on markup we do not own.
 */
class BannerRenderer {
    /**
     * Accept and Reject share this class deliberately - see invariant 1. Anything
     * that gives one of them a class, element type or container the other does not
     * have is a compliance regression, not a styling choice.
     */
    private const BTN = 'bsw-btn';

    /**
     * The de-emphasised THIRD action, and only ever the third action.
     *
     * "Save settings" may look quieter than Accept and Reject: it is not the
     * counterpart to consenting, it is the thing you press after using the
     * toggles, and the ICO rule is about the balance between GIVING and REFUSING
     * consent. Refusing has two equally-weighted routes here (Reject all, and
     * "Continue without accepting"), so nothing about a quiet Save makes refusing
     * harder than accepting.
     *
     * It is a SEPARATE class rather than a modifier on .bsw-btn, and the name has
     * no `bsw-btn` in it on purpose. BannerStyleTest requires every selector that
     * mentions `.bsw-btn` to be the one shared rule; a `.bsw-btn-secondary` would
     * satisfy that substring test and silently open the door to
     * `.bsw-btn-accept`. Accept and Reject carry `bsw-btn` and NOTHING else, and
     * BannerRendererTest asserts the class attribute is exactly that string.
     */
    private const BTN_SECONDARY = 'bsw-secondary';

    /** Must match the id the client script and the reopen control's aria-controls use. */
    private const BANNER_ID = 'bsw-banner';

    /** The panel "More information" opens. Named once; aria-controls and the client script share it. */
    private const LAYER_TWO_ID = 'bsw-layer-2';

    /**
     * The two tabs in layer 2. Constants rather than literals because each name is
     * used in four places - the tab's `data-bsw-tab`, its id, its panel's id and
     * the panel's aria-labelledby - and a typo in any one of them breaks the
     * association silently rather than visibly.
     */
    private const TAB_CATEGORIES = 'categories';
    private const TAB_SERVICES   = 'services';

    /**
     * The pseudo-category the locked first row is addressed by.
     *
     * It is NOT in TagRegistry::CATEGORIES and must never be: a category there is a
     * key in the stored consent record and a thing the client script grants and
     * denies. This constant exists only so the Essential row's detail region has a
     * stable id, and clean_services() drops it along with every other unknown key -
     * so a services line can never be attached to it.
     */
    private const ESSENTIAL = 'essential';

    /**
     * The visual presets. `light` is for a site with light page furniture (a dark
     * banner on a light site reads as an interstitial), `dark` for a dark one.
     *
     * Public because the WP-CLI command prints the list, and because the one
     * definition has to be shared - a second copy in the command would let the CLI
     * accept a value the stylesheet has no palette for, and the banner would then
     * render with the default preset while the operator was told otherwise.
     */
    public const THEMES = [ 'light', 'dark' ];

    /**
     * What an unset, corrupt or unrecognised stored value renders as.
     *
     * Light, not dark, and not "whatever the visitor's OS says": the overwhelming
     * majority of the fleet is light, and a preset that guesses wrong is merely
     * ugly, whereas a preset that CHANGES under a visitor is a banner the operator
     * cannot check.
     */
    public const DEFAULT_THEME = 'light';

    /**
     * @param string[] $categories Categories the banner should offer. NOT trusted:
     *                             this may arrive from a stored option or straight
     *                             from TagRegistry::active_categories(). Non-strings,
     *                             duplicates and unknown categories are dropped.
     * @param mixed    $policy_url Optional link to the site's cookie or privacy
     *                             policy. NOT trusted - it comes from a stored
     *                             option, so it may be any type at all. Anything
     *                             that is not a URL we are willing to render is
     *                             dropped and the banner renders without a link;
     *                             an empty or `#` link is never emitted.
     * @param mixed    $theme      `light` or `dark`. NOT trusted - it comes from a
     *                             stored option. Anything else falls back to
     *                             DEFAULT_THEME, so a hand-edited option can make
     *                             the banner the wrong colour but never unstyled.
     * @param mixed    $privacy_url The wider UK GDPR privacy notice, as opposed to
     *                             the cookie policy above. Same trust level and the
     *                             same rule: rendered only if it survives
     *                             normalise_policy_url(), never as an empty or `#`
     *                             link. Appended LAST so every existing caller and
     *                             every existing test keeps its positional meaning.
     * @param mixed    $services   Optional map of category => list of service names,
     *                             rendered as a line inside that category's layer-2
     *                             detail region. NOT trusted: ConsentModule composes
     *                             it from the stored tag registry and Site Kit's own
     *                             option, so it may be any type at all. Non-string
     *                             keys, unknown categories, non-array values and
     *                             non-string or empty entries are dropped, and a
     *                             category left with nothing gets NO line rather than
     *                             an empty one - an invented or blank list of third
     *                             parties is worse than none, exactly as with the
     *                             policy links. Appended LAST, again, so every
     *                             existing caller keeps its positional meaning.
     * @return string Markup, or '' if no category survived - a banner offering
     *                nothing to decide should not be shown at all.
     */
    public function render_banner( array $categories, mixed $policy_url = null, mixed $theme = null, mixed $privacy_url = null, mixed $services = null ): string {
        $categories = $this->clean( $categories );
        if ( [] === $categories ) {
            return '';
        }

        $services = $this->clean_services( $services );

        /*
         * TWO LAYERS, BOTH IN THE CACHED HTML, ONLY ONE EVER VISIBLE.
         *
         * Layer 1 is the compact card: a title, a sentence, one inline run of
         * name-and-switch pairs, a row of links, and the actions. It carries NO
         * per-category description of any kind - that is the whole reason layer 2
         * exists, and putting a hint back on the card undoes it.
         *
         * Layer 2 is the full panel behind "More information": a heading with a
         * close control, tabs, a bordered card per category carrying the full
         * sentence and its services, and the same three actions.
         *
         * Both are rendered server-side and layer 2 renders `hidden`, because a
         * full-page cache serves one body to every visitor and the collapsed state
         * has to be baked into it. Nothing here is built in JavaScript.
         */
        return sprintf(
            '<div id="%s" class="bsw-banner %s" role="dialog" aria-modal="false" aria-label="%s" hidden>%s%s</div>',
            self::BANNER_ID,
            // esc_attr'd like everything else even though theme_class() can only
            // return one of two literals: the rule is that nothing reaches an
            // attribute unescaped, and an exception here is one fewer place the
            // next person can copy from safely.
            $this->esc_attr( $this->theme_class( $theme ) ),
            $this->esc_attr( __( 'Cookie settings', 'bulldogs-site-worker' ) ),
            $this->layer_one( $categories, $policy_url, $privacy_url ),
            $this->layer_two( $categories, $privacy_url, $services )
        );
    }

    /**
     * LAYER 1 - the compact card.
     *
     * 🚨 NO DESCRIPTIONS. Not a sentence, not a hint, not two words. The card is
     * the title, the intro, one inline run of name-and-switch pairs, the links and
     * the actions. Every word of explanation lives in layer 2, and a future edit
     * that puts a hint back beside a category name has undone the change this
     * layout exists to make. BannerRendererTest asserts there is no per-category
     * descriptive element here at all.
     */
    private function layer_one( array $categories, mixed $policy_url, mixed $privacy_url ): string {
        $pairs = '';
        foreach ( $categories as $category ) {
            $pairs .= $this->category_pair( $category );
        }
        // Essential LAST, after the things the visitor can actually act on. It is
        // context rather than a choice, and it is the one entry that is not a
        // control at all.
        $pairs .= $this->locked_pair();

        return sprintf(
            '<div class="bsw-layer bsw-layer-1">'
            /*
             * 🚨 "Continue without accepting" is a REFUSAL, not a dismissal, and it
             * sits alone in a strip of its own above the title.
             *
             * Its own action name, handled in assets/js/consent.js by the same
             * branch as `reject` - one code path, so the two cannot drift into
             * "one records a denial and the other just closes the banner". A
             * control that only hides the banner leaves no record, so the banner
             * returns on the next page: that is nagging, not a refusal route, and
             * it is what the ICO means by refusing not being as easy as consenting.
             *
             * It is deliberately NOT given `data-bsw-action="reject"`: the tests
             * that pin equal prominence assert each layer holds exactly ONE accept
             * control and exactly ONE reject control, and that the two are
             * indistinguishable. A third element carrying the reject action would
             * defeat that check.
             */
            . '<div class="bsw-top">'
            . '<button type="button" class="bsw-dismiss" data-bsw-action="continue-without">%s<span class="bsw-arrow" aria-hidden="true"> &rarr;</span></button>'
            . '</div>'
            . '<p class="bsw-title">%s</p>'
            . '<p class="bsw-text">%s</p>'
            . '<div class="bsw-cats">%s</div>'
            /*
             * "More information" is a LINK in the same row as the two policy links,
             * not a button under the categories - it is a route to more reading,
             * which is what the things beside it are.
             *
             * It is still a real <button>, because it opens a panel rather than
             * navigating anywhere, and a link with no href is not keyboard
             * operable. Only the STYLING is a link's.
             *
             * It OPENS layer 2; it does not toggle it. `details-close` closes.
             * Splitting them keeps both idempotent, which matters because WP
             * Rocket's delay-JS replays the first click on the page - see the guard
             * in consent.js. A toggle here is exactly the shape that broke before.
             */
            . '<p class="bsw-links">%s%s <button type="button" class="bsw-more" data-bsw-action="details" aria-expanded="false" aria-controls="%s">%s</button></p>'
            . '%s'
            . '</div>',
            $this->esc_html( __( 'Continue without accepting', 'bulldogs-site-worker' ) ),
            $this->esc_html( __( 'Cookies on this site', 'bulldogs-site-worker' ) ),
            /*
             * Concrete about purpose, deliberately. Regulators single out the
             * "technologies to continually improve your experience" euphemism, so
             * this sentence says what is optional and states the default rather
             * than implying it.
             *
             * 🚨 TWO THINGS HERE ARE DOING COMPLIANCE WORK and must survive any
             * rewrite: that everything non-essential is OPTIONAL, and that it
             * STAYS SWITCHED OFF UNTIL YOU CHOOSE. The rest is negotiable prose.
             *
             * It is deliberately short. This is the largest block on the card -
             * three lines and 65 of its 327px before this pass - so it is where
             * tightening pays best. The trailing pointer to "More information"
             * was cut because that link sits directly beneath it and says so
             * itself. Cut WORDS before cutting type size: 12px is the floor for
             * body text in this design and the intro is already at 13.
             */
            $this->esc_html( __( 'Essential cookies keep this site working. Everything else is optional and stays switched off until you choose.', 'bulldogs-site-worker' ) ),
            $pairs,
            // Passed as arguments, never concatenated into the format string: a
            // policy URL containing a percent sign (any percent-encoded character
            // will) would otherwise be read by sprintf as a conversion spec.
            $this->policy_link( $policy_url ),
            $this->privacy_link( $privacy_url ),
            $this->esc_attr( self::LAYER_TWO_ID ),
            $this->esc_html( __( 'More information', 'bulldogs-site-worker' ) ),
            $this->actions()
        );
    }

    /**
     * LAYER 2 - the full panel.
     *
     * Renders `hidden`, always, for the same reason the banner root does: a
     * full-page cache serves one body to every visitor, so the closed state has to
     * be the state in the HTML. The client script owns opening it from there.
     */
    private function layer_two( array $categories, mixed $privacy_url, array $services ): string {
        $cards = '';
        foreach ( $categories as $category ) {
            $cards .= $this->category_card( $category, $services[ $category ] ?? [] );
        }
        $cards .= $this->locked_card();

        /*
         * No services known anywhere means no Services tab and no chevrons - the
         * same rule the policy links follow, one level up: an empty tab is a
         * disclosure that looks like it holds something and does not.
         *
         * ConsentModule cannot actually produce this state. Its map is composed
         * from registered tags (every valid entry yields a name, falling back to
         * the tag id) and Site Kit's active modules (each yields a product name),
         * and a banner renders only when one of those produced a category. So an
         * empty map means an empty banner. It is handled anyway because the
         * renderer is a public method that validates its own input and must not
         * depend on who called it.
         */
        $tabs = [] === $services
            ? ''
            : sprintf(
                '<div class="bsw-tabs" role="tablist" aria-label="%s">'
                . '<button type="button" class="bsw-tab" data-bsw-action="tab" data-bsw-tab="%s" role="tab" id="%s" aria-controls="%s" aria-selected="true">%s</button>'
                . '<button type="button" class="bsw-tab" data-bsw-action="tab" data-bsw-tab="%s" role="tab" id="%s" aria-controls="%s" aria-selected="false">%s</button>'
                . '</div>',
                $this->esc_attr( __( 'Privacy settings', 'bulldogs-site-worker' ) ),
                self::TAB_CATEGORIES,
                $this->esc_attr( $this->tab_id( self::TAB_CATEGORIES ) ),
                $this->esc_attr( $this->panel_id( self::TAB_CATEGORIES ) ),
                $this->esc_html( __( 'Categories', 'bulldogs-site-worker' ) ),
                self::TAB_SERVICES,
                $this->esc_attr( $this->tab_id( self::TAB_SERVICES ) ),
                $this->esc_attr( $this->panel_id( self::TAB_SERVICES ) ),
                $this->esc_html( __( 'Services', 'bulldogs-site-worker' ) )
            );

        return sprintf(
            '<div class="bsw-layer bsw-layer-2" id="%s" hidden>'
            . '<div class="bsw-panel-head">'
            . '<p class="bsw-panel-title">%s</p>'
            /*
             * The ✕ RETURNS TO LAYER 1. It records nothing - it is not a refusal,
             * and it is not a dismissal of the banner either. "Continue without
             * accepting" is the only refusal shortcut and it stays in layer 1,
             * where a visitor who has not opened the panel can still reach it.
             *
             * The glyph is aria-hidden and the button carries an aria-label, so a
             * screen reader announces "Close" rather than a multiplication sign.
             */
            . '<button type="button" class="bsw-close" data-bsw-action="details-close" aria-label="%s"><span class="bsw-close-glyph" aria-hidden="true">&times;</span></button>'
            . '</div>'
            . '<p class="bsw-text">%s</p>'
            . '<p class="bsw-links">%s</p>'
            . '%s'
            . '<div class="bsw-tabpanel" id="%s" role="tabpanel" aria-labelledby="%s">%s</div>'
            . '%s'
            . '%s'
            . '</div>',
            $this->esc_attr( self::LAYER_TWO_ID ),
            $this->esc_html( __( 'Privacy settings', 'bulldogs-site-worker' ) ),
            $this->esc_attr( __( 'Close', 'bulldogs-site-worker' ) ),
            $this->esc_html( __( 'Choose which optional cookies this site may use. Each purpose below says what it does and which companies it involves.', 'bulldogs-site-worker' ) ),
            $this->privacy_link( $privacy_url ),
            $tabs,
            $this->esc_attr( $this->panel_id( self::TAB_CATEGORIES ) ),
            $this->esc_attr( $this->tab_id( self::TAB_CATEGORIES ) ),
            $cards,
            $this->services_panel( $categories, $services ),
            $this->actions()
        );
    }

    /**
     * The three actions, rendered IDENTICALLY into both layers.
     *
     * ---------------------------------------------------------------------------
     * 🚨 TWO SETS OF BUTTONS, AND THE EQUAL-PROMINENCE RULE
     * ---------------------------------------------------------------------------
     * There are now two accept controls and two reject controls in the document,
     * where the tests used to assert exactly one of each. The rule was NOT
     * weakened to accommodate that. What the ICO cares about is what a visitor
     * SEES, and only one layer is ever visible - opening layer 2 hides layer 1 -
     * so the assertion moved from "one per document" to "one per layer, and
     * exactly two layers", which is strictly stronger than what it replaced:
     *
     *   - each layer holds exactly one accept and exactly one reject;
     *   - within a layer they are the same element, in the same container, with a
     *     `class` attribute of exactly `bsw-btn`, and no inline style;
     *   - the document holds exactly two of each and no more;
     *   - both layers' action rows are BYTE-IDENTICAL, which is what this shared
     *     method guarantees and a test asserts. Neither layer can offer a weaker
     *     refusal than the other, because neither layer has its own copy.
     *
     * Order is Save, Reject, Accept - Accept rightmost. That is DOM order and
     * nothing else; the stylesheet cannot tell them apart and must never be able
     * to. Save is the quiet outlined third action (see BTN_SECONDARY).
     *
     * Both sets carry the same `data-bsw-action` values on purpose. The handler in
     * consent.js is delegated on document, so one code path serves both and there
     * is no second implementation to drift - the same argument that has
     * `continue-without` sharing the reject branch.
     */
    private function actions(): string {
        return sprintf(
            '<div class="bsw-actions">'
            // type="button" is load-bearing, not boilerplate: a button with no type
            // defaults to submit, and if the banner is ever printed inside a theme's
            // form, accepting consent would submit that form instead.
            . '<button type="button" class="%s" data-bsw-action="save">%s</button>'
            . '<button type="button" class="%s" data-bsw-action="reject">%s</button>'
            . '<button type="button" class="%s" data-bsw-action="accept">%s</button>'
            . '</div>',
            self::BTN_SECONDARY,
            $this->esc_html( __( 'Save settings', 'bulldogs-site-worker' ) ),
            self::BTN,
            $this->esc_html( __( 'Reject all', 'bulldogs-site-worker' ) ),
            self::BTN,
            $this->esc_html( __( 'Accept all', 'bulldogs-site-worker' ) )
        );
    }

    /**
     * One name-and-switch pair on layer 1's inline run.
     *
     * 🚨 No `checked` attribute here, and never a conditional one. See invariant 2.
     * The input is a real checkbox that the stylesheet DRAWS as a switch
     * (appearance: none plus a ::before thumb) - it is not a <div> wearing a role,
     * because a div-based toggle looks modern and silently breaks the keyboard and
     * the accessibility tree.
     *
     * A <label> WRAPPING the input, so the name is part of the control's hit area
     * and its accessible name comes for free. That is safe here precisely because
     * layer 1 carries no description: there is nothing inside this label a visitor
     * could want to read without also meaning to flip the switch. Layer 2's card
     * does carry a description, and for that reason is deliberately NOT a label.
     */
    private function category_pair( string $category ): string {
        return sprintf(
            '<label class="bsw-cat"><span class="bsw-cat-name">%s</span><input type="checkbox" class="bsw-switch" data-bsw-category-toggle="%s"></label>',
            $this->esc_html( $this->name( $category ) ),
            $this->esc_attr( $category )
        );
    }

    /**
     * The Essential pair: shown, locked on, and not a choice.
     *
     * Essential cookies need no consent, so there is no `essential` entry in
     * TagRegistry::CATEGORIES and there must never be one: a category in the
     * registry is a key in the stored consent record and a thing the client script
     * grants or denies. This exists purely so the visitor can see what is NOT
     * optional - PECR reg. 6(4) exempts strictly necessary storage from consent, it
     * does not exempt it from being disclosed.
     *
     * So it renders as a <span>, with no <input> of any kind, and NOT as a <label>
     * - a label with nothing to label is a lie to the accessibility tree. The lock
     * graphic is drawn by the stylesheet on an aria-hidden span, so nothing in the
     * accessibility tree pretends to be a switch either.
     */
    private function locked_pair(): string {
        return sprintf(
            '<span class="bsw-cat bsw-cat-locked"><span class="bsw-cat-name">%s</span><span class="bsw-locked" aria-hidden="true"></span></span>',
            $this->esc_html( __( 'Essential', 'bulldogs-site-worker' ) )
        );
    }

    /**
     * One bordered card in layer 2's Categories tab: name, the full sentence, the
     * switch, and - where we know them - a chevron revealing the services.
     *
     * 🚨 NOT a <label>. The description lives inside this card, and a label would
     * make reading it flip the switch: clicking anywhere in a label activates its
     * control. That is not consent, and it would be invisible in a screenshot. The
     * input takes an explicit aria-label instead, so it is still named without the
     * wrapper.
     *
     * @param string[] $services Already cleaned. Empty means no chevron at all.
     */
    private function category_card( string $category, array $services ): string {
        return sprintf(
            '<div class="bsw-card">'
            . '<div class="bsw-card-head">'
            . '<span class="bsw-card-copy"><span class="bsw-card-name">%s</span><span class="bsw-card-desc">%s</span></span>'
            . '<input type="checkbox" class="bsw-switch" data-bsw-category-toggle="%s" aria-label="%s">'
            . '%s'
            . '</div>%s</div>',
            $this->esc_html( $this->name( $category ) ),
            $this->esc_html( $this->detail( $category ) ),
            $this->esc_attr( $category ),
            $this->esc_attr( $this->name( $category ) ),
            $this->chevron( $category, $services ),
            $this->card_services( $category, $services )
        );
    }

    /** The Essential card: the same shape, with the lock in place of the switch. */
    private function locked_card(): string {
        return sprintf(
            '<div class="bsw-card bsw-card-locked">'
            . '<div class="bsw-card-head">'
            . '<span class="bsw-card-copy"><span class="bsw-card-name">%s</span><span class="bsw-card-desc">%s</span></span>'
            . '<span class="bsw-locked" aria-hidden="true"></span>'
            . '</div></div>',
            $this->esc_html( __( 'Essential', 'bulldogs-site-worker' ) ),
            $this->esc_html( $this->detail( self::ESSENTIAL ) )
        );
    }

    /**
     * The chevron that expands a card's services, or '' when there are none.
     *
     * 🚨 The ONLY non-idempotent control left in the banner - it toggles, where
     * everything else applies a fixed state. WP Rocket's delay-JS replays the
     * first click on the page as an untrusted synthetic event, so a toggle is
     * exactly the shape that gets opened and shut again by one physical click.
     * The guard in consent.js covers it; an e2e test on the delay-JS scenario
     * pins that it does.
     *
     * @param string[] $services Already cleaned.
     */
    private function chevron( string $category, array $services ): string {
        if ( [] === $services ) {
            return '';
        }

        return sprintf(
            '<button type="button" class="bsw-chevron" data-bsw-action="services-toggle" aria-expanded="false" aria-controls="%s" aria-label="%s"><span class="bsw-chevron-glyph" aria-hidden="true"></span></button>',
            $this->esc_attr( $this->services_id( $category ) ),
            $this->esc_attr( __( 'Show the services in this category', 'bulldogs-site-worker' ) )
        );
    }

    /**
     * The per-card services list, hidden until the chevron is pressed.
     *
     * @param string[] $services Already cleaned.
     */
    private function card_services( string $category, array $services ): string {
        if ( [] === $services ) {
            return '';
        }

        $items = '';
        foreach ( $services as $service ) {
            $items .= sprintf( '<span class="bsw-service">%s</span>', $this->esc_html( $service ) );
        }

        return sprintf(
            '<div class="bsw-card-services" id="%s" hidden>%s</div>',
            $this->esc_attr( $this->services_id( $category ) ),
            $items
        );
    }

    /**
     * The Services tab: every service we know about, flat, each labelled with the
     * category it belongs to.
     *
     * 🚨 Built from the SAME cleaned map the cards are built from, iterated in the
     * same order. There is no second copy of this data and there must never be
     * one: two lists that could disagree about which services a site runs is a
     * disclosure that contradicts itself.
     *
     * Iterated in CATEGORY order - the same order the cards above are built in,
     * driven by the same `$categories` list - rather than in whatever order the
     * services map happened to arrive in. Two views of one dataset that disagree
     * about its order are two views a visitor has to reconcile by hand.
     *
     * @param string[]                $categories Already cleaned.
     * @param array<string, string[]> $services   Already cleaned.
     */
    private function services_panel( array $categories, array $services ): string {
        if ( [] === $services ) {
            return '';
        }

        $rows = '';
        foreach ( $categories as $category ) {
            foreach ( $services[ $category ] ?? [] as $service ) {
                $rows .= sprintf(
                    '<div class="bsw-service-row"><span class="bsw-service-name">%s</span><span class="bsw-service-cat">%s</span></div>',
                    $this->esc_html( $service ),
                    $this->esc_html( $this->name( $category ) )
                );
            }
        }

        return sprintf(
            '<div class="bsw-tabpanel" id="%s" role="tabpanel" aria-labelledby="%s" hidden>%s</div>',
            $this->esc_attr( $this->panel_id( self::TAB_SERVICES ) ),
            $this->esc_attr( $this->tab_id( self::TAB_SERVICES ) ),
            $rows
        );
    }

    /**
     * The three id builders. One method each so the element and whatever points at
     * it with aria-controls or aria-labelledby cannot disagree - an aria-controls
     * naming an element that is not on the page tells a screen reader nothing at
     * all, and does it silently.
     */
    private function services_id( string $category ): string {
        return 'bsw-services-' . $category;
    }

    private function tab_id( string $tab ): string {
        return 'bsw-tab-' . $tab;
    }

    private function panel_id( string $tab ): string {
        return 'bsw-tabpanel-' . $tab;
    }

    /**
     * Drop anything that is not a list of service names for a category this banner
     * can actually render.
     *
     * Same trust level and the same failure mode as clean(): the map is composed by
     * ConsentModule from the stored tag registry and Site Kit's own option, both of
     * which are hand-editable and neither of which is validated on the way in.
     * esc_html() on an array warns and on an object without __toString throws, and a
     * fatal here is a white screen on a live client site.
     *
     * `essential` is dropped along with every other unknown key, deliberately: it is
     * not in TagRegistry::CATEGORIES, and services on the locked card would be a
     * claim about third parties in a category that exists precisely because it has
     * none to consent to.
     *
     * Order is preserved and duplicates removed, so the output is a pure function of
     * the input - invariant 3.
     *
     * @param mixed $services
     * @return array<string, string[]>
     */
    private function clean_services( mixed $services ): array {
        if ( ! is_array( $services ) ) {
            return [];
        }

        $out = [];
        foreach ( $services as $category => $names ) {
            // Strict, and against the SAME list clean() uses. A key of 0 must not
            // loosely match a category name, and a category the banner cannot render
            // a card for must not get services either.
            if ( ! is_string( $category ) || ! in_array( $category, TagRegistry::CATEGORIES, true ) ) {
                continue;
            }
            if ( ! is_array( $names ) ) {
                continue;
            }

            $clean = [];
            foreach ( $names as $name ) {
                if ( ! is_string( $name ) ) {
                    continue;
                }
                $name = trim( $name );
                // '' !== rather than empty(): empty() also rejects the string '0',
                // and a silently dropped legitimate value is the harder bug to spot.
                if ( '' === $name || in_array( $name, $clean, true ) ) {
                    continue;
                }
                $clean[] = $name;
            }

            if ( [] !== $clean ) {
                $out[ $category ] = $clean;
            }
        }

        return $out;
    }

    /**
     * The persistent withdrawal control. Deliberately a bare inline-level <button>
     * with no wrapper: the caller places it in a footer, a nav menu item or a
     * paragraph, and a wrapper <div> would be invalid inside two of those three.
     *
     * aria-expanded is rendered false because the banner renders hidden - the two
     * must agree in the cached HTML. The client script owns keeping them in step
     * after that, and owns moving focus into the banner on open and back to this
     * control on close.
     *
     * ---------------------------------------------------------------------------
     * TWO VARIANTS, AND WHY THEY ARE STYLED DIFFERENTLY
     * ---------------------------------------------------------------------------
     *   - `inline` is what the [bulldogs_cookie_settings] shortcode renders. The
     *     site owner has placed it deliberately, inside their own furniture - a
     *     footer menu, a legal column - so it is styled as a text control that
     *     INHERITS colour and font. That inheritance is correct here and wrong on
     *     the banner buttons: a footer link that does not match the footer looks
     *     pasted on, whereas a consent button that does not match its own banner
     *     is the ICO problem this work started from.
     *   - `fixed` is the fallback ConsentModule prints when nothing else on the
     *     page offers a route back. It is a small themed pill, positioned by our
     *     own stylesheet, because it is not sitting in anybody's furniture.
     *
     * The two carry the same element, the same data-bsw-action and the same
     * aria-controls, so every client-side lookup finds both.
     *
     * @param string $variant `inline` or `fixed`. Anything else is treated as
     *                        `inline` - the variant is ours, not user input, and a
     *                        typo should degrade to the unpositioned control rather
     *                        than to nothing.
     * @param mixed  $theme   Only read for the `fixed` variant. See render_banner().
     */
    public function render_withdrawal_control( string $variant = 'inline', mixed $theme = null ): string {
        $classes = 'fixed' === $variant
            // data-bsw-reopen-variant is not decoration: it is how the client script
            // finds the control it may suppress when the page already carries a
            // working legacy withdrawal link, and how the stylesheet reaches the
            // positioned variant without also reaching the one in somebody's footer.
            ? sprintf( 'bsw-reopen bsw-reopen-fixed %s', $this->theme_class( $theme ) )
            : 'bsw-reopen';

        return sprintf(
            '<button type="button" class="%s"%s data-bsw-action="reopen" aria-controls="%s" aria-expanded="false">%s</button>',
            $this->esc_attr( $classes ),
            'fixed' === $variant ? ' data-bsw-reopen-variant="fixed"' : '',
            self::BANNER_ID,
            $this->esc_html( __( 'Cookie settings', 'bulldogs-site-worker' ) )
        );
    }

    /**
     * The one shared rule for "is this a theme we have a palette for", or null.
     *
     * Public and static for exactly the reason normalise_policy_url() is: the
     * WP-CLI command validates with THIS method. Two copies drift, and the drift is
     * silent in the worst direction - the CLI reports success on `Dark`, the option
     * holds something the renderer will not use, and the banner quietly renders in
     * the other preset with nobody told.
     *
     * Case-insensitive and trimmed, because the value arrives from a shell: a
     * rollout script that pastes `Dark\n` is not making a mistake worth failing.
     */
    public static function normalise_theme( mixed $theme ): ?string {
        if ( ! is_string( $theme ) ) {
            return null;
        }

        $theme = strtolower( trim( $theme ) );

        return in_array( $theme, self::THEMES, true ) ? $theme : null;
    }

    /** The class the stylesheet keys its palette off. Never empty. */
    private function theme_class( mixed $theme ): string {
        return 'bsw-theme-' . ( self::normalise_theme( $theme ) ?? self::DEFAULT_THEME );
    }

    /**
     * The single shared rule for "is this a policy URL we will put in front of a
     * visitor", or null.
     *
     * Public and static because the WP-CLI command that sets the option validates
     * with THIS method. Two copies of the rule would drift, and the drift is silent
     * in the worst direction: the CLI reports success, the banner quietly renders
     * no link, and the site ships a consent notice that never says what the cookies
     * do - which is the compliance gap this parameter was added to close.
     *
     * What is accepted, and why nothing looser is:
     *   - `http://` / `https://` absolute URLs.
     *   - Root-relative paths (`/cookie-policy`). NOT protocol-relative `//host`,
     *     which reads as root-relative at a glance and is not.
     *   - Nothing else. A bare relative path (`cookie-policy`) resolves against the
     *     current page, and this banner renders on every page, so the one link
     *     would point somewhere different on each of them.
     *   - `javascript:` and `data:` are rejected here rather than left to esc_url,
     *     so the rejection is a property of our code and not of WordPress's.
     */
    public static function normalise_policy_url( mixed $url ): ?string {
        if ( ! is_string( $url ) ) {
            return null;
        }

        $url = trim( $url );
        if ( '' === $url ) {
            return null;
        }

        // A control character or an embedded space inside an href is the classic
        // way past a scheme check (`java\nscript:`), so reject rather than strip.
        if ( preg_match( '/[\x00-\x20\x7F"\'<>\\\\]/', $url ) ) {
            return null;
        }

        if ( preg_match( '#^https?://[^/?\#]#i', $url ) ) {
            return $url;
        }

        // Root-relative, but not protocol-relative and not a backslash trick.
        if ( preg_match( '#^/(?![/\\\\])#', $url ) || '/' === $url ) {
            return $url;
        }

        return null;
    }

    /**
     * The trailing COOKIE POLICY link, or '' when there is no usable URL.
     *
     * This is the primary of the two, because it is the one that discharges the
     * PECR duty: what cookies are set, what each is for, how long it lasts and
     * which third parties see it. The privacy notice below is the wider UK GDPR
     * document and does not substitute for it.
     *
     * Never an empty href and never `#`: a link that goes nowhere is worse than no
     * link, because it looks like the information is there.
     */
    private function policy_link( mixed $url ): string {
        return $this->link( $url, 'bsw-policy', __( 'Cookie policy', 'bulldogs-site-worker' ) );
    }

    /** The wider UK GDPR privacy notice. Rendered only if set; see policy_link(). */
    private function privacy_link( mixed $url ): string {
        return $this->link( $url, 'bsw-privacy', __( 'Privacy policy', 'bulldogs-site-worker' ) );
    }

    /**
     * One builder for both links, so the two can never disagree about what a
     * renderable URL is or about what an unusable one produces.
     *
     * @param mixed  $url   Untrusted. Dropped unless normalise_policy_url() and
     *                      esc_url() both vouch for it.
     * @param string $class The class the link is addressed by. Distinct per link
     *                      so a test - and a stylesheet - can tell them apart.
     * @param string $text  Already run through __(); passed in rather than looked
     *                      up here so `wp i18n make-pot` still sees the literals.
     */
    private function link( mixed $url, string $class, string $text ): string {
        $url = self::normalise_policy_url( $url );
        if ( null === $url ) {
            return '';
        }

        $escaped = $this->esc_url( $url );
        if ( '' === $escaped ) {
            return ''; // esc_url refused it. Believe it.
        }

        return sprintf(
            ' <a class="%s" href="%s">%s</a>',
            $this->esc_attr( $class ),
            $escaped,
            $this->esc_html( $text )
        );
    }

    /**
     * Drop anything that is not a category this stack can actually act on, and
     * de-duplicate while preserving order.
     *
     * Two separate reasons, both real:
     *   - esc_attr() on an array warns and on an object without __toString throws.
     *     A fatal here is a white screen on a live client site.
     *   - A toggle for a category outside TagRegistry::CATEGORIES is a control that
     *     does nothing: the registry drops tags in unknown categories, so the
     *     visitor would be offered a choice with no effect. TagRegistry is the one
     *     shared definition of an acceptable category, so it is used here rather
     *     than a second copy of the list drifting alongside it.
     *
     * @param array<int|string, mixed> $categories
     * @return string[]
     */
    private function clean( array $categories ): array {
        $out = [];
        foreach ( $categories as $category ) {
            // Strict comparison: no loose match can promote 0, null or true into a
            // category name.
            if ( ! in_array( $category, TagRegistry::CATEGORIES, true ) ) {
                continue;
            }
            if ( ! in_array( $category, $out, true ) ) {
                $out[] = $category;
            }
        }
        return $out;
    }

    /**
     * The row's heading. Short, because the switch sits beside it.
     *
     * clean() has already restricted $category to the known set, so the fallback is
     * unreachable today. It stays so that adding a category to
     * TagRegistry::CATEGORIES renders a plain row rather than a fatal.
     */
    private function name( string $category ): string {
        $names = [
            'statistics'  => __( 'Analytics', 'bulldogs-site-worker' ),
            'marketing'   => __( 'Marketing', 'bulldogs-site-worker' ),
            'functional'  => __( 'Functional', 'bulldogs-site-worker' ),
            'preferences' => __( 'Preferences', 'bulldogs-site-worker' ),
        ];
        return $names[ $category ] ?? $category;
    }

    /**
     * What the category actually DOES, in a sentence. This is LAYER 2 - it is the
     * copy that used to sit under the name on the card, unchanged, now behind the
     * "More information" disclosure.
     *
     * 🚨 Concrete, never the "technologies to continually improve your experience"
     * euphemism the reference banner used - that phrasing is one regulators name
     * directly, because it describes no purpose at all. Each of these says what is
     * collected and what it is used for, in words a visitor can act on.
     *
     * The `essential` entry has no toggle and never will (see ESSENTIAL), but PECR
     * reg. 6(4) exempts strictly necessary storage from CONSENT, not from
     * disclosure - so it gets the same sentence treatment as everything else.
     */
    private function detail( string $category ): string {
        $details = [
            self::ESSENTIAL => __( 'Always active. Needed to load pages, keep you signed in and remember the cookie choice you make here.', 'bulldogs-site-worker' ),
            'statistics'    => __( 'Counts visits and which pages get read, so we can see what is used.', 'bulldogs-site-worker' ),
            'marketing'     => __( 'Measures our advertising and builds the audiences our ads are shown to.', 'bulldogs-site-worker' ),
            'functional'    => __( 'Optional extras that load from other companies, such as embedded maps and videos.', 'bulldogs-site-worker' ),
            'preferences'   => __( 'Remembers settings you choose here, such as language or region.', 'bulldogs-site-worker' ),
        ];
        return $details[ $category ] ?? $category;
    }

    /**
     * These two wrappers exist because the standing rule is that nothing throws at
     * runtime, and calling an undefined function is a fatal.
     *
     * __() is deliberately NOT wrapped the same way. A wrapper would have to be
     * handed the string as a variable, and `wp i18n make-pot` only extracts literal
     * arguments - every string in this file would silently drop out of the .pot and
     * stop being translatable, which is a worse and much quieter failure than the
     * one the guard would protect against. l10n.php is loaded by wp-settings.php
     * before any plugin file runs, so __() cannot be missing here anyway.
     *
     * The fourth argument to htmlspecialchars is load-bearing and must stay false:
     * esc_attr reaches _wp_specialchars(), whose $double_encode defaults to false,
     * so the fallback has to match esc_attr rather than merely be safe.
     */
    private function esc_attr( string $value ): string {
        return function_exists( 'esc_attr' )
            ? (string) esc_attr( $value )
            : htmlspecialchars( $value, ENT_QUOTES, 'UTF-8', false );
    }

    private function esc_html( string $value ): string {
        return function_exists( 'esc_html' )
            ? (string) esc_html( $value )
            : htmlspecialchars( $value, ENT_QUOTES, 'UTF-8', false );
    }

    /**
     * esc_url is a second line of defence only. normalise_policy_url() has already
     * decided the URL is one we are prepared to render, so the fallback below does
     * not need to re-derive esc_url's scheme whitelist - it only has to make the
     * string safe inside a double-quoted attribute.
     */
    private function esc_url( string $value ): string {
        return function_exists( 'esc_url' )
            ? (string) esc_url( $value )
            : htmlspecialchars( $value, ENT_QUOTES, 'UTF-8', false );
    }
}
