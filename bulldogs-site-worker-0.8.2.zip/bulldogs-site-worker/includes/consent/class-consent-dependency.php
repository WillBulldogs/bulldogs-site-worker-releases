<?php
namespace Bulldogs\SiteWorker\Consent;

/**
 * Is the WP Consent API plugin actually here?
 *
 * ---------------------------------------------------------------------------
 * WHY THIS EXISTS AS A CLASS RATHER THAN A PLUGIN HEADER
 * ---------------------------------------------------------------------------
 * Until 0.8.1 this was `Requires Plugins: wp-consent-api` in the plugin header.
 * That was the right protection declared at the wrong level, and the cost only
 * became visible when the fleet rollout was attempted: WordPress refuses to
 * ACTIVATE a plugin whose required plugin is missing, so `bulldogs-site-worker`
 * could not be installed at all on the 50 of 52 fleet installs that do not run
 * consent. The headline feature of 0.7.0 - "installable dormant, changes
 * nothing" - was therefore impossible on every site it was designed for.
 *
 * Satisfying the header instead would mean installing wp-consent-api on 50
 * client sites. It enqueues its own front-end script, so that is not inert, and
 * it would trade the dormancy guarantee away to keep a header.
 *
 * The dependency belongs to the CONSENT MODULE, which is the only thing that
 * needs it. So it moved here.
 *
 * ---------------------------------------------------------------------------
 * 🚨 WHAT THE HEADER WAS PROTECTING AGAINST, AND HOW THAT IS PRESERVED
 * ---------------------------------------------------------------------------
 * Our banner script is enqueued with `wp-consent-api` as its dependency HANDLE.
 * If that plugin is not active the handle does not exist, and WordPress prints
 * NOTHING - no error, no script, no banner. Meanwhile our `wp_get_consent_type`
 * filter would still be registered, and upstream `wp_has_consent()` answers
 * FALSE for every category once a consent type is declared. The result is a site
 * where nothing can ever consent: Site Kit denied forever, the client's
 * analytics silently dead, and the site looking perfectly fine.
 *
 * That is the worst outcome available in this codebase, and it is why the
 * dependency is checked in three places rather than assumed:
 *
 *   1. `wp bulldogs module enable consent` refuses without it, so the state is
 *      not reachable by the supported route.
 *   2. The consent module is NOT BOOTED without it, so even if the flag is
 *      already on and the plugin is deactivated afterwards, no filter is
 *      registered and upstream returns to allowing everything. Ungated is bad;
 *      permanently blocked with no route to unblocking is worse, and unlike
 *      ungated it is invisible.
 *   3. The monitor then reports a `consent_module_unhealthy` HIGH, because the
 *      flag says consent is on and the page carries no gate. So the state is
 *      loud rather than silent, which is the whole point.
 *
 * ---------------------------------------------------------------------------
 * WHY A FUNCTION CHECK AND NOT is_plugin_active()
 * ---------------------------------------------------------------------------
 * `is_plugin_active()` lives in wp-admin and is not loaded on a front-end
 * request, so using it would mean requiring an admin file on every page load, or
 * being right on some requests and wrong on others.
 *
 * `wp_has_consent()` is the function our gate is actually built on, so testing
 * for it tests the thing we depend on rather than a proxy for it. It also
 * survives the plugin directory being renamed, which a basename check does not -
 * and this estate has renamed directories in it.
 *
 * ⚠️ Timing: this is only true from `plugins_loaded` onwards. Plugin files load
 * alphabetically, so `bulldogs-site-worker` loads BEFORE `wp-consent-api` and
 * the function does not exist at our file scope. Every caller here runs at
 * plugins_loaded or later. Checking earlier would report the dependency missing
 * on a site that has it, and disable consent on the two sites that need it.
 */
class ConsentDependency {
    /** The plugin we need, for messages. */
    public const PLUGIN = 'wp-consent-api';

    /**
     * The function the gate is built on. Present only when the WP Consent API
     * plugin is active.
     */
    public const MARKER = 'wp_has_consent';

    public function is_available(): bool {
        return function_exists( self::MARKER );
    }

    /** One line, for a CLI refusal or a log entry. */
    public function missing_message(): string {
        return sprintf(
            'The %s plugin is not active. The consent gate depends on it: without it the banner '
                . 'script has no dependency handle and WordPress renders nothing, while consent stays '
                . 'denied - which kills the site\'s analytics silently. Install and activate it first.',
            self::PLUGIN
        );
    }
}
