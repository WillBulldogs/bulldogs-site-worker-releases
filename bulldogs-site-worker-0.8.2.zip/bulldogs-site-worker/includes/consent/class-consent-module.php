<?php
namespace Bulldogs\SiteWorker\Consent;

use Bulldogs\SiteWorker\Settings;

/**
 * Wires the consent pieces into WordPress. This is the first class that produces
 * something a visitor sees, so the ordering rules below are load-bearing rather
 * than stylistic.
 *
 *   - The client script goes in <head>, at wp_enqueue_scripts priority 1. It has
 *     to have set window.wp_consent_type and dispatched wp_consent_type_defined
 *     before Site Kit's own DOMContentLoaded handler runs. ConsentType tells
 *     wp-consent-api to wait for us; if our script lands late, or not at all,
 *     consumers that honour that flag block forever and analytics is dead.
 *   - The script is enqueued on EVERY front-end request, including sites with no
 *     banner at all, for the same reason. Making the enqueue conditional on there
 *     being categories to offer would leave Site Kit waiting on an event nothing
 *     fires. The banner is conditional; the script is not.
 *   - Tags render in blocked form for every visitor regardless of consent state.
 *     Full-page caches store one body and serve it to everyone, so nothing this
 *     class prints may vary by who is asking.
 */
class ConsentModule {
    /**
     * The shortcode that lets a site place the withdrawal control itself.
     *
     * Namespaced with the plugin's own prefix rather than something generic like
     * `cookie_settings`: shortcode names are a single global namespace shared with
     * every other plugin and every theme on the site, and silently winning a
     * collision would replace somebody else's control with ours.
     */
    public const SHORTCODE = 'bulldogs_cookie_settings';

    /**
     * One render per request, each.
     *
     * A second banner duplicates id="bsw-banner", which makes the withdrawal
     * control's aria-controls ambiguous and leaves two sets of category toggles
     * writing one record. A second copy of the tags is worse: every registered
     * tag would execute twice once consent is granted, double-counting analytics
     * and firing conversion pixels twice.
     *
     * wp_head and wp_footer normally fire once, but a theme that calls either
     * twice - or a page builder that renders a template fragment through the
     * same hooks - is not hypothetical across a 29-site fleet.
     */
    private bool $tags_rendered   = false;
    private bool $banner_rendered = false;

    /**
     * Set when [bulldogs_cookie_settings] has rendered an inline withdrawal control
     * on THIS request.
     *
     * It suppresses the floating fallback control at wp_footer. The ordering that
     * makes this work is WordPress's, not ours: shortcodes run while the content is
     * filtered, and wp_footer fires after the template has finished with the
     * content - so by the time render_banner() asks, a shortcode anywhere in the
     * post body, a widget or a page-builder footer template has already answered.
     *
     * A theme that somehow renders content AFTER wp_footer would produce both
     * controls. That is the safe direction to be wrong in: two routes back rather
     * than none.
     */
    private bool $inline_control_rendered = false;

    public function __construct(
        private Settings $settings,
        private TagRegistry $registry,
        private VersionStamp $stamp,
        private TagEmitter $emitter,
        private BannerRenderer $banner,
        private ConsentType $type,
        private BannerCategories $banner_categories
    ) {}

    /**
     * @param string $plugin_basename MUST be plugin_basename( BULLDOGS_SW_FILE ) -
     *                                see ConsentType::register(). A hardcoded string
     *                                silently misses on any site whose plugin
     *                                directory has been renamed, and the site then
     *                                reports WP Consent API non-conformance.
     */
    public function register( string $plugin_basename ): void {
        $this->type->register( $plugin_basename );

        // Priority 1: our script must be in <head> and must run before Site Kit's
        // DOMContentLoaded handler.
        add_action( 'wp_enqueue_scripts', [ $this, 'enqueue' ], 1 );
        add_action( 'wp_head', [ $this, 'render_tags' ], 99 );
        add_action( 'wp_footer', [ $this, 'render_banner' ], 99 );

        /*
         * The withdrawal control, placeable. Registered on every front-end request
         * whether or not the site has anything to consent to, because a shortcode
         * that is not registered renders as its own literal text - a page reading
         * "[bulldogs_cookie_settings]" in the footer is worse than one rendering
         * nothing, and the callback itself returns '' when there is no banner.
         */
        add_shortcode( self::SHORTCODE, [ $this, 'withdrawal_shortcode' ] );

        // Self-exclude from WP Rocket's delay-JS. The rollout SOP covers this too,
        // but doing it in code means a site cannot silently regress if the cache
        // plugin is reconfigured by someone else.
        add_filter( 'rocket_delay_js_exclusions', [ $this, 'delay_js_exclusions' ] );

        /*
         * Make Site Kit's denied defaults global. See site_kit_consent_defaults().
         *
         * PHP_INT_MAX, not the default 10, and that is deliberate. The value of this
         * filter is whatever the LAST callback returned, so running early means any
         * plugin, mu-plugin or snippet that adds `region` back afterwards silently
         * undoes us and nothing anywhere reports it. Running last makes the outcome
         * ours regardless of what else is hooked. The cost is that a site which one
         * day WANTS region-scoping has to unhook us to get it - a discoverable,
         * deliberate act, which is the right way round.
         */
        add_filter( 'googlesitekit_consent_defaults', [ $this, 'site_kit_consent_defaults' ], PHP_INT_MAX );
    }

    public function enqueue(): void {
        wp_enqueue_script(
            'bulldogs-sw-consent',
            $this->asset_url( 'assets/js/consent.js' ),
            // wp-consent-api registers this handle. If that plugin is not active the
            // handle does not exist and WordPress prints nothing at all for us - no
            // error, no script, no banner. The plugin header's `Requires Plugins:
            // wp-consent-api` is what stops the site reaching that state, and it is
            // the reason the dependency is declared rather than assumed.
            [ 'wp-consent-api' ],
            $this->asset_version(),
            false // in <head>, not the footer - ordering requirement
        );

        wp_enqueue_style( 'bulldogs-sw-banner', $this->asset_url( 'assets/css/banner.css' ), [], $this->asset_version() );

        // NOT $this->registry->active_categories(). See BannerCategories: a
        // Site-Kit-only site has an empty registry and still needs a banner.
        $categories = $this->banner_categories->all();

        wp_localize_script( 'bulldogs-sw-consent', 'BulldogsSW', [
            // Both are always present, even when empty. wp_json_encode turns an
            // empty PHP array into `[]` rather than `{}`, so the client script must
            // treat `stamps` as a lookup it indexes, never as an object it iterates
            // assuming keys exist.
            'categories' => $categories,
            'stamps'     => $this->stamp->for_all( $categories, $this->registry->all(), $this->banner_config_version() ),
        ] );
    }

    public function render_tags(): void {
        if ( $this->tags_rendered ) {
            return;
        }
        $this->tags_rendered = true;

        // Always the full registry, in blocked form, for every visitor. Returns ''
        // when nothing is registered, so an empty registry adds nothing to <head>.
        echo $this->emitter->render( $this->registry->all() ); // phpcs:ignore WordPress.Security.EscapeOutput
    }

    public function render_banner(): void {
        if ( $this->banner_rendered ) {
            return;
        }

        $categories = $this->banner_categories->all();
        if ( [] === $categories ) {
            return; // No non-essential tracking at all - no banner needed.
        }

        // Rendered before either echo, and checked, because render_banner() returns
        // '' whenever no category survives ITS own validation - which is not the
        // same test as the one above. Printing the withdrawal control anyway would
        // leave a "Cookie settings" button whose aria-controls points at an element
        // that is not on the page, and which opens nothing when clicked.
        /*
         * TWO documents, two options.
         *
         * `policy_url` is - and always was - the COOKIE policy: it is the value the
         * banner has rendered as "Cookie policy" since the link existed, so it keeps
         * its key and its meaning rather than being migrated to a new name for
         * tidiness. Renaming it would have meant a data migration across the fleet
         * whose only failure mode is silent (a site that misses it loses its link).
         *
         * `privacy_url` is new and empty everywhere until an operator sets it. The
         * renderer drops whichever is unset, so a site with only the old value looks
         * exactly as it did before.
         */
        $markup = $this->banner->render_banner(
            $categories,
            $this->settings->get( 'policy_url', '' ),
            $this->banner_theme(),
            $this->settings->get( 'privacy_url', '' ),
            $this->services()
        );
        if ( '' === $markup ) {
            return;
        }

        // Set only once something is actually printed, so a request that rendered
        // nothing does not suppress a later hook that would have.
        $this->banner_rendered = true;

        echo $markup; // phpcs:ignore WordPress.Security.EscapeOutput

        /*
         * The FALLBACK route back, not the preferred one.
         *
         * Withdrawal has to be as easy as consent, and until this change our only
         * withdrawal control was an unstyled button printed last in <body>. On the
         * pilot that put it at y=4772 of a 4814px page, on a white strip under a
         * dark footer: present, functional, and findable by nobody.
         *
         * So the default is now a small fixed pill, and it stands down whenever the
         * page already carries a route back that a visitor would actually find:
         *
         *   - a [bulldogs_cookie_settings] shortcode, which the site has placed
         *     deliberately - handled here, server side;
         *   - a legacy Usercentrics "Privacy Settings" link, which our UC_UI shim
         *     has just made work again - handled in assets/js/consent.js, because
         *     only the browser can see whether such a link is on the page.
         *
         * Two visible controls saying the same thing is clutter, not belt and
         * braces; one that nobody can find is the compliance gap.
         */
        if ( ! $this->inline_control_rendered ) {
            echo $this->banner->render_withdrawal_control( 'fixed', $this->banner_theme() ); // phpcs:ignore WordPress.Security.EscapeOutput
        }
    }

    /**
     * [bulldogs_cookie_settings] - the withdrawal control, placed by the site.
     *
     * Returns '' rather than a control whenever the banner will not render, for the
     * same reason render_banner() checks twice: a "Cookie settings" button whose
     * aria-controls points at an element that is not on the page is a dead control
     * in the one place a visitor looks for a live one.
     *
     * This asks BannerCategories, NOT whether render_banner() has already run - the
     * shortcode is expanded while the content is filtered, which is BEFORE
     * wp_footer, so the banner does not exist yet at this point on any normal page.
     *
     * @param mixed $atts    Shortcode attributes. None are supported; the parameter
     *                       exists because WordPress passes it, and it is typed
     *                       mixed because a shortcode with no attributes is handed
     *                       the string '' rather than an empty array.
     * @param mixed $content Enclosed content, for `[x]...[/x]` usage. Unused.
     */
    public function withdrawal_shortcode( mixed $atts = [], mixed $content = null ): string {
        if ( [] === $this->banner_categories->all() ) {
            return '';
        }

        $this->inline_control_rendered = true;

        return $this->banner->render_withdrawal_control( 'inline', $this->banner_theme() );
    }

    /**
     * Who is actually running in each category, for the banner's layer-2 detail
     * regions.
     *
     * ---------------------------------------------------------------------------
     * COMPOSED HERE, NOT IN THE RENDERER
     * ---------------------------------------------------------------------------
     * BannerRenderer is pure and dumb by design - same input, same output, no
     * reads of anything. Handing it a Settings object or a BannerCategories so it
     * could look this up itself would end that, and the cache-invariance invariant
     * it protects is the one that decides what every visitor on a cached page
     * sees. So the assembly happens on this side of the boundary and the renderer
     * is handed a finished array which it then validates as untrusted anyway.
     *
     * Two sources, each answering only for its own data:
     *
     *   1. THE TAG REGISTRY. Entries carry an optional `label`; where there is
     *      none the tag's `id` is used. A tag id in front of a visitor is a rough
     *      name, but every tag registered before `label` existed has no label, and
     *      a rough name beats a blank line - so the fallback is the id and never ''.
     *   2. BannerCategories::services(). Site Kit's tags are deliberately never
     *      registered, so on the Site-Kit-only sites that make up most of the fleet
     *      the registry is EMPTY and this is the only source there is. Asked
     *      through BannerCategories rather than re-derived here, for the same
     *      reason the category list is: the monitor module asks the same question,
     *      and two copies would drift silently.
     *
     * Order is registry first, then Site Kit, and duplicates are dropped - so a
     * site running both a registered GA tag and Site Kit's own does not print the
     * same name twice. The renderer re-validates every value regardless: this
     * method reads two hand-editable options and is not a trusted source.
     *
     * @return array<string, string[]> category => service names.
     */
    private function services(): array {
        $services = [];

        foreach ( $this->registry->all() as $tag ) {
            // all() has already dropped anything is_valid_entry() refuses, so `id`
            // and `category` are known-good strings here. `label` is not: it is
            // optional and unvalidated, which is exactly why it is checked and the
            // other two are not.
            $label = isset( $tag['label'] ) && is_string( $tag['label'] ) && '' !== trim( $tag['label'] )
                ? trim( $tag['label'] )
                : $tag['id'];

            $services[ $tag['category'] ][] = $label;
        }

        foreach ( $this->banner_categories->services() as $category => $names ) {
            foreach ( $names as $name ) {
                $services[ $category ][] = $name;
            }
        }

        // Dedupe per category, preserving first-seen order. array_unique keeps the
        // original keys, so array_values is not optional - a gapped list would
        // still render, but it would stop being a list.
        foreach ( $services as $category => $names ) {
            $services[ $category ] = array_values( array_unique( $names ) );
        }

        return $services;
    }

    /**
     * The stored preset, or the renderer's default.
     *
     * Read through BannerRenderer::normalise_theme() rather than trusted: the option
     * is hand-editable over WP-CLI and may hold anything at all. Normalising here as
     * well as in the renderer costs nothing and keeps this method's return value a
     * value the CSS actually has a palette for, which is what makes it safe to hand
     * to the withdrawal control as well as to the banner.
     */
    private function banner_theme(): string {
        return BannerRenderer::normalise_theme( $this->settings->get( 'banner_theme', null ) )
            ?? BannerRenderer::DEFAULT_THEME;
    }

    /**
     * Drop `region` from Site Kit's Consent Mode defaults, so its denied defaults
     * apply to EVERY visitor rather than to 32 countries.
     *
     * ---------------------------------------------------------------------------
     * WHY THIS EXISTS - measured on the pilot, not inferred
     * ---------------------------------------------------------------------------
     * Site Kit 1.135.0 hardcodes the region list. `Consent_Mode.php` builds the
     * defaults with `'region' => Regions::get_regions()` - 32 EU/EEA ISO codes -
     * directly above this comment in its own source:
     *
     *   // TODO: The value for `region` should be retrieved from
     *   // $this->consent_mode_settings->get_regions() ...
     *   // See https://github.com/google/site-kit-wp/issues/8444.
     *
     * There is no regions control in Site Kit's admin UI, and storing all 249 ISO
     * codes in `googlesitekit_consent_mode` changed the emitted tag NOT AT ALL when
     * it was tried on the pilot site. The setting is not read. This filter is the
     * only lever there is.
     *
     * Without it, the two tag paths on one page behave differently by country:
     * tags we register are gated client-side for everyone, while Site Kit's own tag
     * is gated only inside the EEA. A visitor from the US got a fully live GA4 tag
     * before answering the banner they were nonetheless shown.
     *
     * ---------------------------------------------------------------------------
     * THE TRADEOFF, STATED PLAINLY. THIS IS INTENDED BEHAVIOUR.
     * ---------------------------------------------------------------------------
     * Every visitor is now denied by default until they answer the banner - not
     * just EEA ones. The banner itself has always been shown to everyone; what
     * changes is that Site Kit's tag now actually waits for them.
     *
     * So REPORTED TRAFFIC FROM OUTSIDE THE EEA WILL DROP, by roughly the share of
     * non-EEA visitors who leave without accepting. That is not a regression to be
     * investigated - it is the previously-missing gate doing its job, and the
     * numbers before the change were counting people who had not consented.
     *
     * ---------------------------------------------------------------------------
     * DRIFT: this filter name is a Site Kit INTERNAL
     * ---------------------------------------------------------------------------
     * If Site Kit renames or drops `googlesitekit_consent_defaults`, this callback
     * simply never fires. Nothing errors, nothing logs, and the region list quietly
     * comes back - the failure is invisible from here, which is exactly why it is
     * not left to be noticed.
     *
     * Detection does not live in this file, and deliberately not: a check that our
     * filter is hooked proves nothing about whether anyone called it. It lives in
     * Scanner::TYPE_SITE_KIT_CONSENT_REGION_SCOPED, which reads the RENDERED page
     * and reports a `gtag('consent','default', ...)` that still carries `region`.
     * That is the effect rather than the mechanism, so it survives a rename, a
     * removal, another plugin outbidding us, and Site Kit restructuring the snippet.
     *
     * @param mixed $defaults Site Kit passes an array. Every filter value is only
     *                        ever whatever the previous callback returned, so this
     *                        may be anything at all.
     * @return mixed The defaults with `region` removed, or the input untouched.
     */
    public function site_kit_consent_defaults( $defaults ) {
        /*
         * Pass anything we do not recognise straight through, and do NOT coerce.
         *
         * Returning [] for a non-array would hand Site Kit an EMPTY defaults object:
         * no `analytics_storage: denied`, no `wait_for_update`, nothing. Its tag
         * would then start from Google's own permissive baseline and measure every
         * visitor before they answered - the plugin causing the exact leak it exists
         * to close, on a site where the only thing actually wrong was some other
         * plugin returning a bad value from this filter. Ours is a subtractive
         * change or it is nothing.
         */
        if ( ! is_array( $defaults ) ) {
            return $defaults;
        }

        // unset() on an absent key is a no-op in PHP, so a defaults array that has
        // already had `region` dropped - by Site Kit, or by another callback - needs
        // no guard and produces no notice.
        unset( $defaults['region'] );

        return $defaults;
    }

    /**
     * @param mixed $exclusions WP Rocket passes an array, but every filter value is
     *                          whatever the last filter returned - another plugin
     *                          returning null or a string must not fatal us.
     * @return array
     */
    public function delay_js_exclusions( $exclusions ): array {
        $exclusions = is_array( $exclusions ) ? $exclusions : [];

        /*
         * EVERY PARTICIPANT IN THE CONSENT HANDSHAKE, NOT JUST OURS.
         *
         * Excluding only our own two entries is a one-sided exclusion, and it was
         * measured failing on a real WP Rocket 3.15.10 install (delay_js on, stored
         * exclusions empty). Our script ran on time and every party it has to talk
         * to was still held:
         *
         *   - `wp-consent-api.min.js` was delayed, so `wp_set_consent` was
         *     `undefined` at DOMContentLoaded AND at window load. applyConsent()
         *     takes its "dependency missing" early return and records NOTHING -
         *     silently, because that return is the correct fail-closed behaviour.
         *   - Site Kit's consent-mode bundle was delayed, so its
         *     `wp_consent_type_defined` listener did not exist yet. All three of
         *     announce()'s dispatches landed in an empty room, and nothing re-fires
         *     them. A returning visitor WITH valid consent was never measured.
         *
         * Both only released on first interaction, ~1.6s after our last dispatch.
         *
         * So the rule is: everything that takes part in the handshake is excluded
         * together, and only the measurement tags stay delayed. `gtag/js`, the gtag
         * config and Site Kit's other bundles are deliberately NOT listed - they are
         * the heavy third-party payload delay-JS exists to defer, they are gated by
         * the consent state rather than party to deciding it, and consent commands
         * queued on `dataLayer` before gtag.js loads are processed in order when it
         * does.
         */

        // Ours. The file is what runs; `BulldogsSW` is the inline var
        // wp_localize_script prints just before it. WP Rocket's own built-in list
        // happens to cover the inline half already (it ships a generic `js-extra`
        // pattern), but that list is remotely updated and is not ours to rely on -
        // measured: with only these two entries removed, the payload stayed live
        // while the file was delayed, and the banner never rendered at all.
        $exclusions[] = 'assets/js/consent.js';
        $exclusions[] = 'BulldogsSW';

        // Our declared dependency. Without it `wp_set_consent`/`wp_has_consent` do
        // not exist and nothing we do can be recorded. Matches the file and its
        // `-js-extra` payload both, which keeps that pair from coming apart too.
        $exclusions[] = 'wp-consent-api';

        // Site Kit's consent plumbing. The bundle is the listener our announce()
        // exists to reach; the inline data-layer script declares `dataLayer`, the
        // `gtag` shim, the denied defaults and `_googlesitekitConsentCategoryMap`.
        // The defaults MUST stay ahead of any update we cause, so these two are
        // excluded together or not at all - releasing the bundle while the defaults
        // stay delayed would order a granting update BEFORE the denied default and
        // leave the page denied after appearing to grant.
        $exclusions[] = 'googlesitekit-consent-mode';
        $exclusions[] = 'google_gtagjs-js-consent-mode-data-layer';

        return $exclusions;
    }

    private function banner_config_version(): string {
        $version = $this->settings->get( 'banner_config_version', '1' );
        // Cast rather than trust: the option is hand-editable and VersionStamp
        // takes a string. An array or object here would be a TypeError, and a
        // TypeError inside wp_enqueue_scripts is a white screen.
        return is_scalar( $version ) ? (string) $version : '1';
    }

    /**
     * These two guards exist because referencing an undefined constant is a fatal
     * in PHP 8, and the standing rule is that nothing throws at runtime. The main
     * plugin file defines both before this class is ever loaded, so the fallbacks
     * are unreachable on a healthy install - they are there so that loading this
     * file by any other route degrades to a broken asset URL rather than a white
     * screen.
     */
    private function asset_url( string $relative ): string {
        return ( defined( 'BULLDOGS_SW_URL' ) ? (string) BULLDOGS_SW_URL : '' ) . $relative;
    }

    private function asset_version(): string {
        return defined( 'BULLDOGS_SW_VERSION' ) ? (string) BULLDOGS_SW_VERSION : '0';
    }
}
