<?php
namespace Bulldogs\SiteWorker\Consent;

/**
 * The WP Consent API producer contract. Every element here is mandatory and
 * omitting the waitfor hook reintroduces a fail-open path.
 *
 * ---------------------------------------------------------------------------
 * INCOMPLETE ON ITS OWN - DO NOT SHIP THIS CLASS WITHOUT THE CLIENT SCRIPT.
 * ---------------------------------------------------------------------------
 * The producer contract has three mandatory parts. Two live here:
 *
 *   1. wp_get_consent_type                -> 'optin'
 *   2. wp_consent_api_waitfor_consent_hook -> true
 *
 * The third is ours too, and lands in Chunk 3's client script: we must set
 * window.wp_consent_type and dispatch the wp_consent_type_defined event after
 * the stored consent record has been resolved.
 *
 * NOTE, corrected while building that script: it dispatches the event at boot,
 * at DOMContentLoaded AND at window load - not once. dispatchEvent is
 * synchronous and DOM events are never replayed, and our script runs at the top
 * of <head>, so a single dispatch is measurably heard by nobody: Site Kit has
 * not registered its listener yet. See the block comment on announce() in
 * assets/js/consent.js.
 *
 * Part 2 without part 3 is WORSE than shipping neither. Telling the dependency
 * to wait for us and then never setting the consent type means consumers that
 * honour the flag - Site Kit among them - block on an event that never fires
 * and return early forever. Verified against wp-consent-api 2.0.1: its own
 * assets/js/wp-consent-api.js never dispatches wp_consent_type_defined; it only
 * publishes window.waitfor_consent_hook for consumers to act on. Nobody else
 * fires that event on our sites. If we do not, nothing does.
 */
class ConsentType {
    /**
     * @param string $plugin_basename MUST be plugin_basename( BULLDOGS_SW_FILE ), not a
     *                                hardcoded string. wp-consent-api's site-health check
     *                                calls consent_api_registered() with the basename WP
     *                                itself computed, so if the plugin directory is named
     *                                anything other than what we hardcode, the filter name
     *                                will not match and the site reports non-conformance.
     */
    public function register( string $plugin_basename ): void {
        add_filter( 'wp_get_consent_type', [ $this, 'consent_type' ] );
        add_filter( 'wp_consent_api_waitfor_consent_hook', [ $this, 'waitfor_consent_hook' ] );
        add_filter( "wp_consent_api_registered_{$plugin_basename}", '__return_true' );
    }

    /** UK/EEA: consent must be opt-in. */
    public function consent_type( $type ): string {
        return 'optin';
    }

    /**
     * Tell wp-consent-api to wait for us rather than defining the type and
     * dispatching wp_consent_type_defined itself. We own both, and fire the
     * event after the stored record is resolved (Chunk 3) - re-announced at
     * each load milestone, because a late-registering listener cannot hear an
     * event that has already been dispatched.
     */
    public function waitfor_consent_hook( $wait ): bool {
        return true;
    }
}
