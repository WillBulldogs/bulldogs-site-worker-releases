<?php
namespace Bulldogs\SiteWorker\Consent;

/**
 * Renders registered tags in blocked form. Output is identical for every visitor
 * regardless of consent state - full-page caches serve one body to everyone. The
 * client script flips these to executable after consent.
 *
 * Two invariants, in priority order:
 *
 *   1. FAIL CLOSED. Anything we cannot positively prove will render as an inert
 *      script carrying exactly one `type="text/plain"` and exactly one pair of our
 *      data-bsw-* attributes is dropped and logged, never emitted. A dropped tag
 *      is a site owner's analytics not working. An emitted-but-ungated tag is a
 *      UK GDPR breach on a client's site, which is the failure this plugin exists
 *      to prevent.
 *   2. PURE. Same input, same output, every call. No consent state, no request
 *      state, no clock, no randomness - see test_output_is_identical_on_every_call.
 *
 * The attributes are REBUILT from a tokenizer rather than rewritten with a regex.
 * That is not tidiness; four separate ungated-execution paths were measured on the
 * regex-rewrite version and verified against a real HTML parser:
 *
 *   - `<script foo="bar>`  (unbalanced quote) swallowed the appended type into
 *     foo's value, so the emitted tag had NO type attribute and executed.
 *   - `<script data-x="type=foo">` had its type= match INSIDE another attribute's
 *     value, producing `data-x="type="text/plain""` - again no type attribute.
 *   - `<script data-bsw-category="functional" ...>` in the source survived
 *     alongside ours, and HTML keeps the FIRST duplicate attribute - so a
 *     marketing tag presented itself to the flip script as functional.
 *   - `</script foo>` inside the body ends the element earlier than the regex
 *     thinks, so the remainder of the body was emitted as live markup - a
 *     tracking pixel in it would fire ungated.
 *
 * Rebuilding makes all four structurally impossible instead of individually patched.
 */
class TagEmitter {
    private const SCRIPT_PATTERN = '/<script\b([^>]*)>([\s\S]*?)<\/script>/i';

    /**
     * Comments are stripped before the residue check. They are inert - a comment
     * cannot make a network request - and the stock Google Tag Manager snippet
     * ships wrapped in `<!-- Google Tag Manager -->` markers, so without this the
     * single most commonly pasted tag on the fleet would be silently dropped.
     * Scripts are removed BEFORE comments so that a `-->` inside JavaScript
     * cannot cause a comment to be mis-stripped.
     */
    private const COMMENT_PATTERN = '/<!--.*?-->/s';

    /** Conservative, and deliberately so: an attribute name we do not recognise fails the tag closed. */
    private const ATTR_NAME_PATTERN = '/^[A-Za-z_:][A-Za-z0-9_:.\-]*$/';

    private const WHITESPACE = " \t\n\r\f";

    /**
     * @param array<int, mixed> $tags Entries are validated, not trusted. This may be
     *                                handed a raw option array straight from the DB.
     * @return string Blocked markup, or '' if nothing survived validation.
     */
    public function render( array $tags ): string {
        $out = '';
        foreach ( $tags as $tag ) {
            // No (string) casts. An entry whose markup is an object throws a fatal on
            // cast - a white screen on a live client site - and one whose markup key
            // is missing casts null to '' and renders nothing while looking fine.
            // TagRegistry::is_valid_entry is the single shared definition of a
            // well-formed row; VersionStamp fingerprints against the same rule, so
            // reusing it keeps the stamp and the emitted set from drifting apart.
            if ( ! TagRegistry::is_valid_entry( $tag ) ) {
                $this->log_rejected( $this->loggable_id( $tag ), 'entry is not a well-formed registry row' );
                continue;
            }

            $blocked = $this->block( $tag['markup'], $tag['id'], $tag['category'] );
            if ( '' !== $blocked ) {
                $out .= "\n" . $blocked;
            }
        }
        return $out;
    }

    private function block( string $markup, string $id, string $category ): string {
        $matched = false;
        $failed  = false;

        $result = preg_replace_callback(
            self::SCRIPT_PATTERN,
            function ( array $m ) use ( &$matched, &$failed, $id, $category ): string {
                $matched = true;
                if ( $failed ) {
                    return ''; // Already rejecting this tag; the return value is discarded.
                }

                // A `</script` anywhere in the body ends the element earlier than this
                // regex does. Everything after it would leave our <script> and be
                // emitted as live markup.
                if ( preg_match( '/<\/script/i', $m[2] ) ) {
                    $failed = true;
                    $this->log_rejected( $id, 'script body contains a nested closing tag' );
                    return '';
                }

                $attrs = $this->parse_attributes( $m[1] );
                if ( null === $attrs ) {
                    $failed = true;
                    $this->log_rejected( $id, 'script attributes could not be parsed safely' );
                    return '';
                }

                $rendered = '';
                foreach ( $attrs as [ $name, $value ] ) {
                    $lower = strtolower( $name );
                    // Ours are authoritative. Never let the source supply either, or a
                    // duplicate attribute lets it pick its own consent category.
                    if ( 'type' === $lower || str_starts_with( $lower, 'data-bsw-' ) ) {
                        continue;
                    }
                    $rendered .= null === $value
                        ? ' ' . $name
                        : sprintf( ' %s="%s"', $name, $this->esc( $value ) );
                }

                $rendered .= ' type="text/plain"';
                $rendered .= sprintf(
                    ' data-bsw-id="%s" data-bsw-category="%s"',
                    $this->esc( $id ),
                    $this->esc( $category )
                );

                return '<script' . $rendered . '>' . $m[2] . '</script>';
            },
            $markup
        );

        if ( $failed ) {
            return '';
        }

        if ( ! $matched ) {
            // No <script>...</script> at all, or an unclosed one. Nothing else can be
            // gated by the type-flip mechanism.
            $this->log_rejected( $id, 'markup contains no complete script tag' );
            return '';
        }

        // null means the PCRE engine gave up (backtrack/recursion limit). Treat an
        // engine failure as a rejection rather than trusting a partial result.
        if ( null === $result ) {
            $this->log_rejected( $id, 'regex engine failed while blocking the tag' );
            return '';
        }

        // The residue check matters: for `<script>..</script><img src=pixel>` the
        // script DOES match, so without this we would return the whole blob -
        // including a live, ungated tracking pixel.
        $residue = preg_replace( self::SCRIPT_PATTERN, '', $markup );
        if ( null === $residue ) {
            $this->log_rejected( $id, 'regex engine failed while checking for non-script content' );
            return '';
        }

        $residue = preg_replace( self::COMMENT_PATTERN, '', $residue );
        if ( null === $residue ) {
            $this->log_rejected( $id, 'regex engine failed while checking for non-script content' );
            return '';
        }

        if ( '' !== trim( $residue ) ) {
            $this->log_rejected( $id, 'markup contains non-script content' );
            return '';
        }

        return $result;
    }

    /**
     * Tokenizes a start tag's attribute string into ordered name/value pairs, closely
     * enough to the HTML tokenizer that we cannot disagree with the browser about
     * where one attribute ends and the next begins.
     *
     * Returns null - meaning "reject the whole tag" - for anything ambiguous: an
     * unterminated quoted value, an attribute name we do not recognise, or a bare
     * value containing a character that would make a browser re-interpret the tag.
     *
     * @return array<int, array{0:string, 1:string|null}>|null Value null = valueless attribute.
     */
    private function parse_attributes( string $attrs ): ?array {
        $out = [];
        $len = strlen( $attrs );
        $i   = 0;

        while ( $i < $len ) {
            $char = $attrs[ $i ];

            // A stray `/` between attributes is ignored by the HTML tokenizer
            // (`<script src=x />`), so ignore it here too rather than reading it
            // as part of a name.
            if ( false !== strpos( self::WHITESPACE, $char ) || '/' === $char ) {
                ++$i;
                continue;
            }

            $name_start = $i;
            while ( $i < $len && false === strpos( self::WHITESPACE . "/=\"'", $attrs[ $i ] ) ) {
                ++$i;
            }

            if ( $i === $name_start ) {
                return null; // `=`, `"` or `'` where a name should be.
            }

            $name = substr( $attrs, $name_start, $i - $name_start );
            if ( ! preg_match( self::ATTR_NAME_PATTERN, $name ) ) {
                return null;
            }

            $i = $this->skip_whitespace( $attrs, $i, $len );

            if ( $i >= $len || '=' !== $attrs[ $i ] ) {
                $out[] = [ $name, null ]; // Valueless attribute: async, defer, nomodule.
                continue;
            }

            ++$i; // Past the '='.
            $i = $this->skip_whitespace( $attrs, $i, $len );

            if ( $i >= $len ) {
                return null; // Trailing `=` with nothing after it.
            }

            $quote = $attrs[ $i ];
            if ( '"' === $quote || "'" === $quote ) {
                $close = strpos( $attrs, $quote, $i + 1 );
                if ( false === $close ) {
                    return null; // Unterminated value - this is case F above.
                }
                $out[] = [ $name, substr( $attrs, $i + 1, $close - $i - 1 ) ];
                $i     = $close + 1;
                continue;
            }

            $value_start = $i;
            while ( $i < $len && false === strpos( self::WHITESPACE, $attrs[ $i ] ) ) {
                ++$i;
            }
            $value = substr( $attrs, $value_start, $i - $value_start );

            // Per the HTML spec these are parse errors inside an unquoted value, and
            // each one means a browser may split the tag differently than we did.
            if ( '' === $value || preg_match( '/["\'<>=`]/', $value ) ) {
                return null;
            }

            $out[] = [ $name, $value ];
        }

        return $out;
    }

    private function skip_whitespace( string $subject, int $i, int $len ): int {
        while ( $i < $len && false !== strpos( self::WHITESPACE, $subject[ $i ] ) ) {
            ++$i;
        }
        return $i;
    }

    /**
     * esc_attr is always defined by the time a theme renders, but calling an
     * undefined function is a fatal and the standing rule is that nothing throws at
     * runtime.
     *
     * The fourth argument is load-bearing. esc_attr reaches _wp_specialchars(),
     * whose $double_encode defaults to FALSE, so a tag URL already containing
     * `&amp;` survives it unchanged. htmlspecialchars defaults the same argument to
     * TRUE, which would turn that into `&amp;amp;` and break the request the tag
     * makes. The fallback has to match esc_attr, not merely be safe.
     */
    private function esc( string $value ): string {
        return function_exists( 'esc_attr' )
            ? (string) esc_attr( $value )
            : htmlspecialchars( $value, ENT_QUOTES, 'UTF-8', false );
    }

    /** The id of a rejected entry cannot be trusted to be a string, or to exist. */
    private function loggable_id( mixed $entry ): string {
        return is_array( $entry ) && isset( $entry['id'] ) && is_scalar( $entry['id'] )
            ? (string) $entry['id']
            : '(unknown)';
    }

    private function log_rejected( string $id, string $why ): void {
        if ( function_exists( 'error_log' ) ) {
            error_log( sprintf( 'bulldogs-site-worker: refusing to emit tag "%s": %s', $id, $why ) );
        }
    }
}
