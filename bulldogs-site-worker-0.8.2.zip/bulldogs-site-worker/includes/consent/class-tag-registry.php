<?php
namespace Bulldogs\SiteWorker\Consent;

use Bulldogs\SiteWorker\Settings;

/**
 * The registered tags for this site. Holds everything EXCEPT Site-Kit-managed tags,
 * which stay with Site Kit and are never registered.
 *
 * ---------------------------------------------------------------------------
 * THE ENTRY SHAPE
 * ---------------------------------------------------------------------------
 * `id`, `category` and `markup` are required. `label` is OPTIONAL: it is the
 * display name the banner prints on its layer-2 "Set by:" line, and where it is
 * absent the entry's `id` is used instead. ConsentModule does that fallback, not
 * this class - a tag id is a perfectly serviceable name for a service, so a
 * missing label is a slightly rougher banner and never a missing one.
 *
 * 🚨 TWO THINGS `label` MUST NEVER BECOME, both of which would go unnoticed here
 * and cost the whole fleet:
 *
 *   1. REQUIRED. is_valid_entry() is shared with VersionStamp precisely so that
 *      the two cannot disagree about which tags count. Requiring a label would
 *      invalidate every entry already stored across the fleet at once: the tags
 *      would stop being emitted AND every stamp would move, so every visitor on
 *      every site would be re-prompted and their analytics would go dark until
 *      they answered again.
 *   2. PART OF THE FINGERPRINT. VersionStamp hashes `id` and `markup` only. A
 *      label changes nothing about what a tag DOES, so folding it in would mean
 *      that fixing a typo in a service name re-prompts every visitor on every
 *      site - for a change nobody could see except the typo. VersionStampTest
 *      pins this.
 */
class TagRegistry {
    /** WP Consent API categories we accept. `statistics-anonymous` is deliberately unused. */
    public const CATEGORIES = [ 'functional', 'preferences', 'statistics', 'marketing' ];

    /**
     * Parsed registry, memoised for the life of this instance.
     *
     * Parsing is pure but not free, and it logs. Without this, a request that asks
     * for_category() once per category plus active_categories() re-reads the option
     * and re-logs every malformed entry several times over. Deliberately per-INSTANCE
     * rather than static: a long-running process (WP-CLI) that mutates the option
     * builds a fresh registry rather than being stuck with a stale one.
     *
     * @var array<int, array{id:string, category:string, markup:string, label?:string}>|null
     */
    private ?array $tags = null;

    public function __construct( private Settings $settings ) {}

    /** @return array<int, array{id:string, category:string, markup:string, label?:string}> */
    public function all(): array {
        if ( null !== $this->tags ) {
            return $this->tags;
        }

        $raw = $this->settings->get( 'tags', [] );
        if ( ! is_array( $raw ) ) {
            return $this->tags = [];
        }

        $valid = [];
        foreach ( $raw as $entry ) {
            if ( self::is_valid_entry( $entry ) ) {
                $valid[] = $entry;
            } else {
                $this->log_invalid( $entry );
            }
        }
        return $this->tags = $valid;
    }

    /** @return array<int, array{id:string, category:string, markup:string, label?:string}> */
    public function for_category( string $category ): array {
        return array_values(
            array_filter( $this->all(), static fn ( $t ) => $t['category'] === $category )
        );
    }

    /** @return string[] Categories that actually have tags registered. */
    public function active_categories(): array {
        return array_values( array_unique( array_column( $this->all(), 'category' ) ) );
    }

    /**
     * Fails closed: anything we cannot positively confirm is a well-formed entry in a
     * category we recognise is dropped, never emitted. Note the explicit '' !== checks
     * rather than empty() - empty() also rejects the string '0', which is a legitimate
     * (if unlikely) tag id, and a silent drop of a valid tag is the harder bug to spot.
     *
     * Public and static because VersionStamp must fingerprint exactly the set of tags
     * this class will emit. Two copies of this rule drifting apart would make the
     * stamp move for tags that never run, re-prompting visitors for nothing.
     */
    public static function is_valid_entry( mixed $entry ): bool {
        return is_array( $entry )
            && isset( $entry['id'] ) && is_string( $entry['id'] ) && '' !== $entry['id']
            && isset( $entry['markup'] ) && is_string( $entry['markup'] ) && '' !== $entry['markup']
            && isset( $entry['category'] )
            && in_array( $entry['category'], self::CATEGORIES, true );
    }

    private function log_invalid( mixed $entry ): void {
        if ( function_exists( 'error_log' ) ) {
            $id = is_array( $entry ) && isset( $entry['id'] ) && is_scalar( $entry['id'] )
                ? (string) $entry['id']
                : '(unknown)';
            error_log( sprintf( 'bulldogs-site-worker: dropping invalid registry entry "%s"', $id ) );
        }
    }
}
