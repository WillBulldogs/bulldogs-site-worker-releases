<?php
namespace Bulldogs\SiteWorker\Consent;

/**
 * Per-category stamp. Scoped per category so that adding a tag in one category
 * does not re-prompt visitors who consented to another. Deliberately excludes any
 * policy version - that belongs to a separate project.
 *
 * Called with the RAW registry array, not TagRegistry::all() output, so it must
 * assume the option contains arbitrary junk and never raise on it.
 */
class VersionStamp {
    /**
     * Stamp for one category.
     *
     * @param string $category              WP Consent API category.
     * @param array  $tags                  Raw registry entries. Unvalidated.
     * @param string $banner_config_version Opaque token for the banner configuration.
     */
    public function for_category( string $category, array $tags, string $banner_config_version ): string {
        $fingerprints = [];

        foreach ( $tags as $tag ) {
            // Mirror the registry's acceptance rule exactly. An entry TagRegistry drops
            // is never emitted to the page, so counting it here would move the stamp -
            // and re-prompt the whole audience - for a tag that never runs. That is the
            // precise failure this per-category design exists to avoid, so the two rules
            // are shared rather than duplicated, and cannot drift apart.
            //
            // Skipped silently, on purpose: TagRegistry already logs each drop when it
            // parses the same option. Logging here too would repeat every line on every
            // request, once per category.
            if ( ! TagRegistry::is_valid_entry( $tag ) || $tag['category'] !== $category ) {
                continue;
            }

            // Fixed-width components, so concatenation is unambiguous. Building this
            // from raw values joined by a delimiter lets a value containing that
            // delimiter forge another tag's fingerprint, and two genuinely different
            // configurations then share a stamp - stale consent that is never
            // invalidated. Every field is hashed to a constant length instead.
            $fingerprints[] = hash( 'sha256', $tag['id'] ) . hash( 'sha256', $tag['markup'] );
        }

        // Sort so registry ordering is not significant.
        sort( $fingerprints );

        return substr(
            hash( 'sha256', hash( 'sha256', $banner_config_version ) . implode( '', $fingerprints ) ),
            0,
            16
        );
    }

    /**
     * Stamp for each of the given categories.
     *
     * Non-string categories are skipped rather than used. Passing one straight through
     * would be a fatal twice over - a TypeError on the for_category() argument, and
     * again on the array key - and this list can originate from stored settings.
     *
     * @return array<string,string> category => stamp
     */
    public function for_all( array $categories, array $tags, string $banner_config_version ): array {
        $out = [];
        foreach ( $categories as $category ) {
            if ( ! is_string( $category ) ) {
                continue;
            }
            $out[ $category ] = $this->for_category( $category, $tags, $banner_config_version );
        }
        return $out;
    }
}
