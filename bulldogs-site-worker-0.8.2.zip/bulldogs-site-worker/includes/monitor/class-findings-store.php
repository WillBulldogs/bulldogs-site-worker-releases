<?php
namespace Bulldogs\SiteWorker\Monitor;

use Bulldogs\SiteWorker\Settings;

/**
 * Where findings live between a scan and the pull that collects them, and the
 * arithmetic that decides whether a scan is owed.
 *
 * Backed by the shared Settings option, which is a deliberate trade with a real
 * cost: that option is autoloaded, so whatever is in it is read on every request
 * to the site, including every visitor page view. Findings are therefore CAPPED
 * (see MAX_FINDINGS) rather than allowed to grow. Without the cap, a site that
 * accumulated a large finding set would pay for it on every page load - a
 * monitoring feature quietly taxing the thing it monitors.
 *
 * ---------------------------------------------------------------------------
 * WHY THE DUE CHECK IS ITS OWN METHOD, TAKING $now
 * ---------------------------------------------------------------------------
 * The endpoint is public and side-effecting: a scan issues loopback HTTP requests
 * to several URLs on a shared cPanel box with LVE limits and ~33 vhosts. The rate
 * limit is the only thing standing between "WP Fleet polls us" and "anyone who
 * learns the URL can make us fetch ourselves in a loop". Passing the clock in
 * rather than calling time() internally is what makes the boundary testable at
 * all, and the boundary is where this sort of guard is usually wrong.
 *
 * Three cases the obvious `$now - $last > $interval` gets wrong, all handled:
 *   - never scanned (last = 0): due, not "0 seconds ago so wait".
 *   - exactly at the boundary (now - last === interval): due. Otherwise a caller
 *     on a fixed cadence equal to the interval never scans at all.
 *   - a stored stamp in the FUTURE: due. A clock correction, a restored database
 *     or a hand-edited option can leave a timestamp ahead of now, and a plain
 *     subtraction then returns a negative number that suppresses scanning for as
 *     long as the skew lasts - potentially forever, silently.
 */
class FindingsStore {
    /** Keys inside the shared Settings option. */
    public const KEY_FINDINGS  = 'findings';
    public const KEY_LAST_SCAN = 'last_scan';

    /**
     * Hard ceiling on stored findings. See the class docblock: this option is
     * autoloaded. Findings past the cap are dropped from the END, so the earliest
     * (and, given Scanner's ordering, the highest-value) ones survive.
     */
    public const MAX_FINDINGS = 50;

    public function __construct( private Settings $settings ) {}

    /**
     * Unix timestamp of the last completed scan, or 0 if there has never been one.
     *
     * A numeric string is accepted because options survive export/import and
     * hand-editing, and a stored "1755600000" meaning the same thing as the int is
     * not worth forcing a re-scan over. Anything else - an array, null, "soon" -
     * reads as 0, which means "due", which is the safe direction: a needless scan
     * beats a monitor that has silently stopped.
     */
    public function last_scan(): int {
        $stored = $this->settings->get( self::KEY_LAST_SCAN, 0 );

        if ( is_int( $stored ) ) {
            return max( 0, $stored );
        }
        // ctype_digit rather than is_numeric: is_numeric accepts "1e5", " 12" and
        // floats, and (int) on those is a guess rather than a read.
        if ( is_string( $stored ) && ctype_digit( $stored ) ) {
            return (int) $stored;
        }
        return 0;
    }

    /**
     * The stored findings, with anything malformed dropped.
     *
     * The store must survive an option written by an older version, a partial
     * write, or a hand edit. Nothing here casts: a row whose 'detail' is an object
     * would throw on (string), and a white screen produced by the monitor would be
     * the most embarrassing possible bug in a plugin whose entire purpose is
     * noticing when a site is broken.
     *
     * @return array<int, array{type:string, severity:string, detail:string, urls:string[]}>
     */
    public function findings(): array {
        $stored = $this->settings->get( self::KEY_FINDINGS, [] );
        return is_array( $stored ) ? self::normalise( $stored ) : [];
    }

    /** Is a scan owed? See the class docblock for the three edge cases. */
    public function is_scan_due( int $interval, int $now ): bool {
        // A negative interval is junk, not an instruction to scan constantly.
        $interval = max( 0, $interval );
        $last     = $this->last_scan();

        if ( 0 === $last ) {
            return true;
        }
        if ( $last > $now ) {
            return true;
        }

        return ( $now - $last ) >= $interval;
    }

    /**
     * Record a completed scan: the findings it produced and when it finished.
     *
     * @param array<int, mixed> $findings Unvalidated - normalised on the way in as
     *                                    well as on the way out, so a caller cannot
     *                                    write something findings() would then drop.
     */
    public function save( array $findings, int $now ): void {
        $this->settings->set( self::KEY_FINDINGS, array_slice( self::normalise( $findings ), 0, self::MAX_FINDINGS ) );
        $this->settings->set( self::KEY_LAST_SCAN, max( 0, $now ) );
    }

    /**
     * Claim the scan slot before doing the work.
     *
     * Check-then-scan is a race: N simultaneous polls all read the same stale
     * last_scan, all decide a scan is due, and all issue their own set of loopback
     * requests. That is precisely the resource amplification the rate limit exists
     * to prevent, and a public endpoint is exactly where it would be triggered.
     * Writing the timestamp first collapses the window to the length of one option
     * write.
     *
     * It is best-effort and stated as such: wp_options offers no compare-and-swap,
     * so two genuinely simultaneous requests can still both scan. The bound this
     * gives is "about one extra scan", not "never more than one" - which is the
     * difference between a nuisance and an outage.
     *
     * The cost of claiming first is that a scan which then fails outright still
     * suppresses the next one for a full interval. That is the right way round:
     * a stale finding set is a reporting delay, an unbounded fetch loop on a shared
     * box is an incident.
     */
    public function claim( int $now ): void {
        $this->settings->set( self::KEY_LAST_SCAN, max( 0, $now ) );
    }

    /**
     * Keep the well-formed rows, drop everything else.
     *
     * `urls` is optional and carries the representative URLs a finding was seen on
     * (see RestController). It is normalised rather than trusted for the same
     * reason as the rest: it is round-tripped through an option.
     *
     * @param array<int|string, mixed> $rows
     * @return array<int, array{type:string, severity:string, detail:string, urls:string[]}>
     */
    private static function normalise( array $rows ): array {
        $clean = [];

        foreach ( $rows as $row ) {
            if ( ! is_array( $row ) ) {
                continue;
            }
            foreach ( [ 'type', 'severity', 'detail' ] as $key ) {
                if ( ! isset( $row[ $key ] ) || ! is_string( $row[ $key ] ) || '' === $row[ $key ] ) {
                    continue 2;
                }
            }

            $urls = [];
            if ( isset( $row['urls'] ) && is_array( $row['urls'] ) ) {
                foreach ( $row['urls'] as $url ) {
                    if ( is_string( $url ) && '' !== $url && ! in_array( $url, $urls, true ) ) {
                        $urls[] = $url;
                    }
                }
            }

            $clean[] = [
                'type'     => $row['type'],
                'severity' => $row['severity'],
                'detail'   => $row['detail'],
                'urls'     => $urls,
            ];
        }

        return $clean;
    }
}
