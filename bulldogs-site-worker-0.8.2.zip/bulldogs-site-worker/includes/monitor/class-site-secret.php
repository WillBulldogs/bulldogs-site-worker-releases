<?php
namespace Bulldogs\SiteWorker\Monitor;

use Bulldogs\SiteWorker\Settings;

/**
 * The per-site shared secret that authenticates the findings endpoint.
 *
 * ---------------------------------------------------------------------------
 * WHY PER-SITE AND NOT FLEET-WIDE
 * ---------------------------------------------------------------------------
 * The endpoint is the only externally-reachable surface this plugin adds, and it
 * goes onto 29 public client sites. A fleet-wide secret would sit in plain text
 * in 29 wp_options rows on shared hosting; one compromised site would then read
 * findings from all of them. Per-site, a compromise is bounded to the site that
 * was already compromised.
 *
 * ---------------------------------------------------------------------------
 * FAIL CLOSED BEFORE REGISTRATION
 * ---------------------------------------------------------------------------
 * verify() returns false when NOTHING is stored. That is the whole point of the
 * class and the easiest thing to get backwards: the obvious implementation reads
 * the option, gets '' or null, compares it against an absent header, finds them
 * equal, and authorises everyone. Between activation and the SOP step that
 * registers the secret with WP Fleet there is a window on a live site, and during
 * that window the endpoint must refuse everything.
 *
 * ---------------------------------------------------------------------------
 * ensure() IS NOT rotate()
 * ---------------------------------------------------------------------------
 * Activation calls ensure(). register_activation_hook fires again on every
 * re-activation - including the deactivate/activate cycle a plugin update or a
 * troubleshooting step performs - so generating unconditionally would silently
 * invalidate the value already registered against the site record in WP Fleet,
 * and collection would start 403ing for reasons nobody would connect to a plugin
 * update. Rotation is a deliberate, separate operation.
 */
class SiteSecret {
    /** Key inside the shared Settings option. */
    public const KEY = 'site_secret';

    /** Characters, not bytes. Alphanumeric, so it survives shell quoting in the SOP. */
    private const LENGTH = 48;

    public function __construct( private Settings $settings ) {}

    /**
     * The stored secret, or null when there is not a usable one.
     *
     * "Usable" excludes an option holding an int, an array or an empty string. No
     * cast: (string) on an array is a notice and the string "Array", and a secret
     * of "Array" would be both wrong and, briefly, guessable.
     */
    public function get(): ?string {
        $stored = $this->settings->get( self::KEY, null );
        if ( ! is_string( $stored ) || '' === $stored ) {
            return null;
        }
        return $stored;
    }

    /** The stored secret, generating and storing one first if there is none. */
    public function ensure(): string {
        $existing = $this->get();
        if ( null !== $existing ) {
            return $existing;
        }
        return $this->rotate();
    }

    /**
     * Replace the secret with a fresh one and return it.
     *
     * The old value stops working the instant this returns, so WP Fleet's copy
     * must be updated in the same operation. That is an SOP step, not something
     * this class can enforce.
     */
    public function rotate(): string {
        $secret = $this->generate();
        $this->settings->set( self::KEY, $secret );
        return $secret;
    }

    /**
     * Is $candidate the stored secret?
     *
     * hash_equals(), not ===. The comparison runs on an unauthenticated request
     * from the public internet, and a short-circuiting compare leaks how many
     * leading characters were right through response timing. The secret is 48
     * alphanumeric characters, so a byte-at-a-time attack is the only realistic
     * one and it is exactly what a timing-safe compare removes.
     *
     * Empty is always false, even when a secret is stored: hash_equals( $secret,
     * '' ) is already false, but stating it here means an empty header can never
     * become "equal" through some future normalisation step.
     */
    public function verify( string $candidate ): bool {
        if ( '' === $candidate ) {
            return false;
        }

        $stored = $this->get();
        if ( null === $stored ) {
            return false;
        }

        return hash_equals( $stored, $candidate );
    }

    /**
     * wp_generate_password( 48, false, false ) - no special characters, so the
     * value can be pasted into an SSH command and a curl header without quoting
     * games during the rollout.
     *
     * The function_exists guard is not theoretical: wp_generate_password is
     * pluggable, so a site with a security plugin that redefines it badly could
     * return something unusable. The fallback is random_bytes, which is stronger
     * than anything hand-rolled here would be. It can throw, and it is allowed to:
     * failing activation is the correct outcome if the platform cannot produce
     * randomness, and the caller in the activation hook logs rather than fatals.
     */
    private function generate(): string {
        if ( function_exists( 'wp_generate_password' ) ) {
            $secret = wp_generate_password( self::LENGTH, false, false );
            if ( is_string( $secret ) && '' !== $secret ) {
                return $secret;
            }
        }

        return bin2hex( random_bytes( 24 ) );
    }
}
