<?php
namespace Bulldogs\SiteWorker\Monitor;

/**
 * The curated tracker-domain list, and the scan that locates them in rendered HTML.
 *
 * DELIBERATELY NOT EXHAUSTIVE. This is the handful of things our fleet actually
 * runs plus the obvious neighbours. Maintaining someone else's blocklist database
 * forever is not the job, and a list that pretends to be complete invites the
 * reader to trust a "no findings" result more than it deserves. Anything not on
 * this list is found by the browser harness watching real network requests, or
 * not at all.
 *
 * ---------------------------------------------------------------------------
 * WHY find() RETURNS EVERY OCCURRENCE, NOT THE FIRST
 * ---------------------------------------------------------------------------
 * A single stripos() per domain returns one hit. A page carrying a registered
 * `GTM-FIRST` and an unregistered `GTM-SECOND` therefore yields one hit for
 * googletagmanager.com - and if the registered container happens to be printed
 * first, the scanner matches it against the registry, calls the domain covered,
 * and the second container is MASKED. Silently, permanently, and in exactly the
 * arrangement a site accumulates tags in real life (the one we put there, then
 * the one someone pasted into a header-script plugin later).
 *
 * So every occurrence is returned, each with its own tight context window, and
 * the scanner compares container ids per occurrence.
 *
 * ---------------------------------------------------------------------------
 * WHY THE CONTEXT WINDOW IS CLAMPED TO THE ENCLOSING SCRIPT ELEMENT
 * ---------------------------------------------------------------------------
 * The window exists so the scanner can read the container/measurement id that
 * belongs to THIS occurrence. A plain character window re-introduces the masking
 * bug the moment two snippets sit close together: GTM-SECOND's window picks up
 * GTM-FIRST, the ids intersect, and the finding disappears again. Two tags are
 * two script elements, so the window is clipped at the element boundary as well
 * as at a character count. Occurrences outside any script element (a `<noscript>`
 * pixel, a `<link rel=preconnect>`) are clipped to the gap between elements.
 */
class TrackerList {
    /**
     * Matches TagEmitter's pattern on purpose - the two must agree about where a
     * script element starts and ends, or the emitter blocks a tag this class then
     * reads as belonging to its neighbour.
     */
    private const SCRIPT_PATTERN = '/<script\b([^>]*)>([\s\S]*?)<\/script>/i';

    /**
     * Container/measurement ids. Uppercase-only and deliberately so: matching
     * case-insensitively turns `class="g-recaptcha"` into the id `G-RECAPTCHA`,
     * which is a phantom id that then fails to agree with a real registry entry
     * and invents an unregistered-tracker finding. Real Google ids are canonically
     * uppercase.
     *
     * GTM- and GT- precede G- in the alternation so the longer prefixes win.
     * AW- is included beyond the four the design named because Google Ads is on
     * the domain list and AW- is how its conversion ids are written.
     */
    private const ID_PATTERN = '/\b(?:GTM-[A-Z0-9]+|GT-[A-Z0-9]+|AW-[A-Z0-9]+|UA-\d+-\d+|G-[A-Z0-9]+)\b/';

    /**
     * How much markup either side of the match to keep.
     *
     * Asymmetric because ids sit after the domain far more often than before it:
     * `gtag/js?id=G-XXXX` puts it 8 characters later, and the classic Tag Manager
     * snippet puts the container roughly 90 characters later, in the
     * `})(window,document,'script','dataLayer','GTM-XXXX');` tail.
     */
    private const CONTEXT_BEFORE = 160;
    private const CONTEXT_AFTER  = 320;

    /**
     * `site_kit` marks a tracker Google Site Kit emits itself. Site Kit's tag is
     * never registered with TagRegistry - it keeps emitting, ungated, governed by
     * its own Consent Mode denied defaults - so on a Site Kit site these domains
     * must not be reported as unregistered. See Scanner for the cost of that.
     *
     * ---------------------------------------------------------------------------
     * `self_gating`: THE SAME IDEA, A DIFFERENT REASON
     * ---------------------------------------------------------------------------
     * A tracker that governs its OWN storage from a consent signal we send it,
     * rather than one we block. It is not in the registry and must not be, because
     * blocking its script would defeat the mechanism that makes it safe.
     *
     * 🚨 THE BAR IS "WE BRIDGE IT", NOT "THE VENDOR OFFERS AN API". Several
     * trackers below publish a consent API - Meta has `fbq('consent', …)`,
     * Microsoft Advertising has a UET consent mode - and none of that helps,
     * because nothing in this plugin calls them. A flag set on the vendor's
     * capability rather than on our integration would silently downgrade a real
     * finding to nothing. If a bridge is added for one of them, set the flag in
     * the SAME change as the bridge.
     *
     * Microsoft Clarity is the only one today:
     *   - it has shipped Consent Mode ON BY DEFAULT for UK/EEA visitors since
     *     31 Oct 2025, so without consent it runs cookieless - it transmits, but
     *     stores nothing, and PECR reg. 6 governs storage on the device rather
     *     than transmission;
     *   - assets/js/consent.js additionally calls `clarity('consentv2', …)` on
     *     every category change, so the grant is explicit rather than implied.
     *
     * Measured on the Beau pilot: no `_clck`/`_clsk` before consent, both present
     * after. The scanner reported it HIGH anyway, on every fleet site running
     * Clarity - which is most of them - and a monitor whose High findings are
     * mostly noise is a monitor nobody reads.
     *
     * Several trackers own more than one domain (Meta's script host and its
     * noscript pixel host; Google Ads' two). They are grouped under one label so
     * a registry entry naming either one covers the tracker, rather than the
     * scanner reporting the same pixel twice because the entry happens to quote
     * the other host.
     *
     * @var array<int, array{label:string, domains:string[], site_kit:bool, self_gating:bool}>
     */
    private const TRACKERS = [
        [ 'label' => 'Google Tag Manager / gtag.js', 'domains' => [ 'googletagmanager.com' ],                    'site_kit' => true,  'self_gating' => false ],
        [ 'label' => 'Google Analytics',             'domains' => [ 'google-analytics.com' ],                    'site_kit' => true,  'self_gating' => false ],
        [ 'label' => 'Google Ads',                   'domains' => [ 'googleadservices.com', 'doubleclick.net' ], 'site_kit' => true,  'self_gating' => false ],
        // The only self-gating tracker. See the note above for the bar it clears
        // and why a vendor merely HAVING a consent API does not clear it.
        [ 'label' => 'Microsoft Clarity',            'domains' => [ 'clarity.ms' ],                              'site_kit' => false, 'self_gating' => true  ],
        [ 'label' => 'Meta Pixel',                   'domains' => [ 'connect.facebook.net', 'facebook.com/tr' ], 'site_kit' => false, 'self_gating' => false ],
        [ 'label' => 'Hotjar',                       'domains' => [ 'hotjar.com' ],                              'site_kit' => false, 'self_gating' => false ],
        [ 'label' => 'LinkedIn Insight',             'domains' => [ 'snap.licdn.com', 'px.ads.linkedin.com' ],   'site_kit' => false, 'self_gating' => false ],
        [ 'label' => 'TikTok Pixel',                 'domains' => [ 'analytics.tiktok.com' ],                    'site_kit' => false, 'self_gating' => false ],
        [ 'label' => 'Microsoft Advertising (UET)',  'domains' => [ 'bat.bing.com' ],                            'site_kit' => false, 'self_gating' => false ],
    ];

    /** @return array<int, array{label:string, domains:string[], site_kit:bool, self_gating:bool}> */
    public function all(): array {
        return self::TRACKERS;
    }

    /**
     * Every domain of every tracker, flat.
     *
     * @return string[]
     */
    public function domains(): array {
        return array_merge( ...array_column( self::TRACKERS, 'domains' ) );
    }

    /**
     * Every occurrence of every tracker domain in $html.
     *
     * @return array<int, array{label:string, domain:string, site_kit:bool, self_gating:bool, offset:int, context:string, ids:string[]}>
     *         Ordered by offset, so a caller reporting them reports them in page order.
     */
    public function find( string $html ): array {
        if ( '' === $html ) {
            return [];
        }

        $regions = $this->script_regions( $html );
        $length  = strlen( $html );
        $hits    = [];

        foreach ( self::TRACKERS as $tracker ) {
            foreach ( $tracker['domains'] as $domain ) {
                $needle = strlen( $domain );
                $from   = 0;

                // stripos in a loop rather than preg_match_all: the needles are
                // literals, and a domain containing a `.` must not be read as a
                // regex wildcard matching some unrelated host.
                while ( $from <= $length ) {
                    $at = stripos( $html, $domain, $from );
                    if ( false === $at ) {
                        break;
                    }

                    $context = $this->context( $html, $at, $needle, $regions, $length );

                    $hits[] = [
                        'label'       => $tracker['label'],
                        'domain'      => $domain,
                        'site_kit'    => $tracker['site_kit'],
                        // Carried through with site_kit, because the scanner
                        // decides the exemption per HIT and cannot see the table.
                        'self_gating' => $tracker['self_gating'],
                        'offset'      => $at,
                        'context'     => $context,
                        'ids'         => self::ids( $context ),
                    ];

                    $from = $at + $needle;
                }
            }
        }

        usort( $hits, static fn ( array $a, array $b ): int => $a['offset'] <=> $b['offset'] );

        return $hits;
    }

    /**
     * Container/measurement ids in a piece of markup.
     *
     * Public and static for the same reason TagRegistry::is_valid_entry is: the
     * scanner extracts ids from BOTH sides of the comparison - the page and the
     * registered markup - and two copies of this rule drifting apart would make a
     * registered tag stop matching itself.
     *
     * @return string[] Unique, in order of appearance. Empty when the markup carries none.
     */
    public static function ids( string $text ): array {
        if ( '' === $text || ! preg_match_all( self::ID_PATTERN, $text, $m ) ) {
            // preg_match_all returns false on engine failure and 0 on no match.
            // Both mean "we cannot name an id here", which the scanner already
            // treats as "compare on domain alone".
            return [];
        }
        return array_values( array_unique( $m[0] ) );
    }

    /**
     * @param array<int, array{0:int, 1:int}> $regions
     */
    private function context( string $html, int $at, int $needle_len, array $regions, int $length ): string {
        [ $low, $high ] = $this->bounds( $at, $regions, $length );

        $start = max( $low, $at - self::CONTEXT_BEFORE );
        $end   = min( $high, $at + $needle_len + self::CONTEXT_AFTER );

        if ( $end <= $start ) {
            return '';
        }

        return substr( $html, $start, $end - $start );
    }

    /**
     * The enclosing script element's span, or - for an occurrence outside every
     * script element - the gap between the elements either side of it.
     *
     * @param array<int, array{0:int, 1:int}> $regions Ascending, non-overlapping.
     * @return array{0:int, 1:int}
     */
    private function bounds( int $at, array $regions, int $length ): array {
        $low = 0;

        foreach ( $regions as [ $start, $end ] ) {
            if ( $end <= $at ) {
                $low = $end;
                continue;
            }
            if ( $at >= $start ) {
                return [ $start, $end ]; // Inside this element.
            }
            return [ $low, $start ];     // In the gap before it.
        }

        return [ $low, $length ];
    }

    /**
     * @return array<int, array{0:int, 1:int}> [start, end) of each script element.
     */
    private function script_regions( string $html ): array {
        $found = preg_match_all( self::SCRIPT_PATTERN, $html, $m, PREG_OFFSET_CAPTURE );
        if ( ! $found ) {
            // false is a PCRE engine failure, 0 is a page with no scripts. Neither
            // is worth failing the scan over: with no boundaries the context window
            // falls back to the character count alone, which is the weaker but still
            // useful behaviour.
            return [];
        }

        $regions = [];
        foreach ( $m[0] as $match ) {
            [ $text, $offset ] = $match;
            $regions[] = [ $offset, $offset + strlen( $text ) ];
        }
        return $regions;
    }
}
