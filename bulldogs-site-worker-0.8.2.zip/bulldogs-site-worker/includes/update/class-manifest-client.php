<?php
namespace Bulldogs\SiteWorker\Update;

/**
 * Fetches manifest.json, caches the answer, and never lets either go wrong in a
 * way an administrator can see.
 *
 * ---------------------------------------------------------------------------
 * THE THING THIS CLASS IS ACTUALLY FOR
 * ---------------------------------------------------------------------------
 * WordPress runs the plugin update check on admin page loads. Whatever happens
 * in here happens *while an administrator is waiting for wp-admin to render*, on
 * 29 client sites, synchronously. Three consequences, all of which are the whole
 * design:
 *
 *  1. Every failure degrades to "no update available". Host down, DNS gone, TLS
 *     failure, a 404 HTML page, a 200 with HTML in it, truncated JSON, valid JSON
 *     that is not a manifest, a `version` of "banana" - all of them return null
 *     and none of them throw. There is no error notice, no admin_notice, no
 *     WP_Error surfaced to the UI. A broken release server must not be able to
 *     put a red box on a client's dashboard.
 *
 *  2. FAILURES ARE CACHED TOO. Caching only successes is the version of this that
 *     looks right and is measurably wrong: an outage would then mean a fresh
 *     network attempt on every single update check, each one paying the full
 *     timeout before wp-admin renders. The outage would be felt as a slow admin
 *     on every site simultaneously - a monitoring-adjacent feature taxing the
 *     thing it exists to help. Failures cache for a shorter window than successes
 *     so recovery is not delayed by the length of the good-response TTL.
 *
 *  3. The request is bounded in every direction: a short timeout, a redirect cap,
 *     and a response-size cap. The manifest is roughly 300 bytes. Anything
 *     arriving that is not roughly 300 bytes is not our manifest, and a body we
 *     refuse to buffer cannot cost the site memory.
 *
 * ---------------------------------------------------------------------------
 * THE CACHE IS WHY A RELEASE IS NOT INSTANT
 * ---------------------------------------------------------------------------
 * A newly published release can take up to TTL_SUCCESS to be *offered* on a site,
 * on top of WordPress's own twice-daily update check. That is deliberate - see
 * point 2 - and `wp bulldogs update check --refresh` exists for when someone
 * needs the answer now.
 */
class ManifestClient {
    /**
     * Where the manifest lives.
     *
     * ⚠️ This string is also the plugin's `Update URI:` header, character for
     * character, and UpdaterTest asserts they are equal. Changing one without the
     * other does not break loudly: WordPress derives the update filter's name from
     * the HEADER's hostname, so a drifted pair means core calls a filter nobody
     * registered and the plugin silently stops receiving updates on every site.
     *
     * ⚠️ AND IT IS A HOSTNAME WE OWN. That is the load-bearing property, not the
     * pretty URL. This string is baked into every installed copy and WordPress
     * reads it from the INSTALLED plugin, so it cannot be changed retroactively:
     * moving off a hostname later means updating all ~29 sites by hand first,
     * which is the manual work this module exists to remove. A borrowed hostname
     * is also shared - the filter name is derived from it, so every plugin
     * updating from that host would share a filter - and it is somebody else's
     * uptime and somebody else's decision to stop serving it.
     *
     * `wpupdates.bulldogs.digital` is a CNAME to GitHub Pages today, serving
     * manifest.json out of the root of the public releases repo. If that ever
     * changes, the DNS record moves and no client site notices.
     *
     * The DOWNLOAD URL is not like this and does not need to be ours. It is read
     * out of the manifest at update time and SHA-256 verified, so it can move
     * between the hosts in Manifest::PACKAGE_HOSTS freely, and anywhere else with
     * one plugin release - which, now that this module exists, is cheap. Only
     * THIS URL is permanent.
     *
     * Public on purpose. The source repo is private, and a private release URL
     * would need a credential on all 29 client sites, which is exactly the thing
     * self-hosted updates are meant to avoid.
     */
    public const MANIFEST_URL = 'https://wpupdates.bulldogs.digital/manifest.json';

    /** Site transient name. Site-wide rather than per-blog: the plugin is too. */
    public const TRANSIENT = 'bulldogs_sw_update_manifest';

    /**
     * How long a good answer is trusted. Six hours: comfortably longer than
     * WordPress's own twice-daily plugin check, so the common case is a cache hit
     * and the release host sees roughly two requests per site per day.
     */
    public const TTL_SUCCESS = 6 * 3600;

    /**
     * How long a failure is remembered. Shorter than TTL_SUCCESS so a release host
     * that comes back up is picked up within the hour, but long enough that an
     * outage is not re-tested on every admin page load.
     */
    public const TTL_FAILURE = 3600;

    /** Seconds to wait for the release host. WordPress's own default for a non-cron update check is lower still. */
    private const TIMEOUT = 5;

    /** Bytes. The real document is ~300; this is two orders of magnitude of headroom. */
    private const MAX_BODY = 32768;

    /** Cache-payload format. Bumped if the stored shape ever changes, so an old payload is ignored rather than misread. */
    private const SCHEMA = 1;

    /** Human-readable reason the last fetch produced nothing, for the CLI. Never shown in wp-admin. */
    private ?string $error = null;

    /** Whether the last answer came from the transient rather than the network. */
    private bool $from_cache = false;

    public function __construct( private string $url = self::MANIFEST_URL ) {}

    /**
     * The hostname WordPress will build the update filter's name from.
     *
     * Static and public because Updater needs it before it has an instance, and
     * because the release workflow's own checks read the same value.
     */
    public static function host( string $url = self::MANIFEST_URL ): string {
        $host = parse_url( $url, PHP_URL_HOST );
        return is_string( $host ) ? $host : '';
    }

    /**
     * The current manifest, or null if there is not a usable one.
     *
     * @param bool $bypass_cache Skip the transient and go to the network. Used by
     *                           the CLI's --refresh, and by the download guard
     *                           when the package it is asked to verify is not the
     *                           one the cached manifest names.
     */
    public function fetch( bool $bypass_cache = false ): ?Manifest {
        $this->error      = null;
        $this->from_cache = false;

        if ( ! $bypass_cache ) {
            $cached = $this->cached();
            if ( null !== $cached ) {
                $this->from_cache = true;
                // A cached FAILURE is a hit as much as a cached success is. The
                // stored error is restored so the CLI reports the real reason
                // rather than "unreachable" for something that was a 404.
                $this->error = is_string( $cached['error'] ?? null ) ? $cached['error'] : null;
                return Manifest::from_array( $cached['manifest'] ?? null );
            }
        }

        $manifest = $this->fetch_from_network();

        $this->store(
            null === $manifest ? null : $manifest->to_array(),
            $this->error
        );

        return $manifest;
    }

    /** Why the last fetch() returned null, in words. Null when it did not. */
    public function last_error(): ?string {
        return $this->error;
    }

    /** Did the last fetch() answer from the transient? */
    public function was_cached(): bool {
        return $this->from_cache;
    }

    /** Drop the cached answer so the next fetch() goes to the network. */
    public function forget(): void {
        if ( function_exists( 'delete_site_transient' ) ) {
            delete_site_transient( self::TRANSIENT );
        }
    }

    /**
     * The stored payload, or null when there is not a usable one.
     *
     * Everything is checked rather than trusted. A transient survives a plugin
     * downgrade and an object-cache flush is not guaranteed on upgrade, so the
     * value here may have been written by a different version of this class.
     *
     * @return array<string, mixed>|null
     */
    private function cached(): ?array {
        if ( ! function_exists( 'get_site_transient' ) ) {
            return null;
        }

        $stored = get_site_transient( self::TRANSIENT );

        if ( ! is_array( $stored ) || self::SCHEMA !== ( $stored['schema'] ?? null ) ) {
            return null;
        }

        // The URL is part of the payload so that changing MANIFEST_URL - in a
        // release, or by hand while debugging - invalidates the cache instead of
        // serving an answer fetched from somewhere else.
        if ( ( $stored['url'] ?? null ) !== $this->url ) {
            return null;
        }

        return $stored;
    }

    /** @param array<string, mixed>|null $manifest */
    private function store( ?array $manifest, ?string $error ): void {
        if ( ! function_exists( 'set_site_transient' ) ) {
            return;
        }

        set_site_transient(
            self::TRANSIENT,
            [
                'schema'   => self::SCHEMA,
                'url'      => $this->url,
                'manifest' => $manifest,
                'error'    => $error,
                'at'       => time(),
            ],
            null === $manifest ? self::TTL_FAILURE : self::TTL_SUCCESS
        );
    }

    /**
     * One HTTP request, and every way it can go wrong turned into null plus a
     * sentence.
     *
     * No try/catch here: wp_remote_get() returns a WP_Error rather than throwing,
     * and the module-level boot in bulldogs-site-worker.php plus the try/catch in
     * Updater's filter callbacks cover anything unforeseen. Catching Throwable in
     * three nested places would only make a genuine bug harder to find in the log.
     */
    private function fetch_from_network(): ?Manifest {
        if ( ! function_exists( 'wp_remote_get' ) ) {
            $this->error = 'WordPress HTTP is not available in this context';
            return null;
        }

        $response = wp_remote_get(
            $this->url,
            [
                'timeout'             => self::TIMEOUT,
                'redirection'         => 3,
                'limit_response_size' => self::MAX_BODY,
                // Identifies the fleet in the release host's logs, and makes a
                // request from a client site distinguishable from a browser.
                'user-agent'          => 'bulldogs-site-worker/' . ( defined( 'BULLDOGS_SW_VERSION' ) ? BULLDOGS_SW_VERSION : 'unknown' ),
                // The answer is public and identical for every site; there is
                // nothing here worth a cookie jar.
                'cookies'             => [],
            ]
        );

        if ( is_wp_error( $response ) ) {
            $this->error = 'could not reach the release host';
            return null;
        }

        $code = wp_remote_retrieve_response_code( $response );
        if ( 200 !== (int) $code ) {
            // The code is safe to interpolate - it is an int from the transport,
            // not anything the remote body controls.
            $this->error = sprintf( 'the release host answered HTTP %d', (int) $code );
            return null;
        }

        $body = wp_remote_retrieve_body( $response );
        if ( ! is_string( $body ) ) {
            $this->error = 'the release host returned no body';
            return null;
        }

        $manifest = Manifest::from_string( $body );
        if ( null === $manifest ) {
            // Deliberately does NOT quote the body. This sentence can reach an
            // operator's terminal, and echoing an arbitrary remote response into
            // it - HTML, an error page, control characters - is how a log becomes
            // an injection surface.
            $this->error = 'the response was not a usable manifest';
            return null;
        }

        return $manifest;
    }
}
