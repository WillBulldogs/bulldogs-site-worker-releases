<?php
namespace Bulldogs\SiteWorker\Update;

/**
 * One release, as described by manifest.json - parsed, validated, and otherwise
 * refused.
 *
 * ---------------------------------------------------------------------------
 * WHY THIS IS A PARSER AND NOT AN ARRAY
 * ---------------------------------------------------------------------------
 * The manifest is a code-execution path into 29 client sites: whatever it names
 * in `download_url` is what WordPress downloads, unzips and runs. The document
 * arrives over the public internet from a host that is not this site, and the
 * only thing standing between it and wp-content/plugins is the checking done
 * here. So every field is validated on the way in and there is no way to build
 * an instance except through from_array(), which returns NULL rather than a
 * half-populated object.
 *
 * Null means "no update available". Every rejection below is silent by design -
 * see ManifestClient for why a broken manifest must never surface in wp-admin.
 *
 * ---------------------------------------------------------------------------
 * THE FIELDS THAT ARE MANDATORY, AND WHY sha256 IS ONE OF THEM
 * ---------------------------------------------------------------------------
 * version, download_url and sha256 are all required. The digest is required
 * rather than optional because "optional" is how a checksum gate quietly stops
 * being a gate: a manifest published without one would install unverified, and
 * nothing about that failure is visible - the update simply succeeds. A
 * manifest with no usable digest is therefore not a manifest, and this class
 * returns null for it.
 *
 * requires, tested and requires_php are optional. They are display and
 * compatibility hints WordPress shows in the UI; getting them wrong cannot
 * execute anything, so a malformed one is dropped rather than failing the whole
 * document.
 */
final class Manifest {
    /**
     * Hosts a package may be downloaded from.
     *
     * Defence in depth, not the primary control - the SHA-256 check is that. This
     * list exists because a tampered manifest could otherwise point `download_url`
     * at any host on the internet or, worse, at something inside the hosting
     * network, and make 29 sites fetch it on a schedule. Restricting it to the
     * hosts our own releases are actually served from means a substituted URL is
     * refused before a single request leaves the box.
     *
     * wpupdates.bulldogs.digital is where the zip actually comes from. Releases
     * are published by a deploy key, which cannot create GitHub release assets,
     * so the package ships in the public releases repo and is served by Pages
     * from the same host as the manifest. Nothing a client site fetches depends
     * on a github.com URL.
     *
     * github.com and objects.githubusercontent.com are kept as the fallback: a
     * release asset URL starts at the former and redirects to the latter, which
     * download_url() follows itself. Nothing uses them today, and they cost
     * nothing to allow - but if the package ever has to move back to release
     * assets, having them here means it takes a manifest edit rather than a
     * plugin release, and a plugin release is the one thing a site that cannot
     * download the package is unable to receive.
     *
     * ⚠️ Note the asymmetry with ManifestClient::MANIFEST_URL. That URL is baked
     * into every installed copy and cannot change without touching all 29 sites by
     * hand. This list can: moving the package to a host not named here costs one
     * ordinary release, which the updater then delivers itself. So "the download
     * URL can move later" is free within this list, and one release outside it.
     *
     * Deliberately a constant and deliberately NOT filterable. A filter here would
     * be a documented way to switch the control off, and this list changes about
     * as often as our release hosting does.
     */
    public const PACKAGE_HOSTS = [
        'github.com',
        'objects.githubusercontent.com',
        'wpupdates.bulldogs.digital',
    ];

    /**
     * What counts as a version string.
     *
     * This guard exists because version_compare() does not have one: it accepts
     * literally any string, never errors, and happily reports that "banana" is
     * newer than "0.5.5" (it splits on non-alphanumerics and compares parts, and
     * an unrecognised part outranks a number). So a manifest whose `version` is
     * junk - a truncated file, a templating accident, an HTML error page that
     * somehow parsed - would otherwise offer an update to every site on the fleet
     * and there would be no error anywhere to explain it.
     *
     * Deliberately narrow: up to four dot-separated numbers, with an optional
     * pre-release/build suffix. Every version this plugin has ever had fits.
     */
    private const VERSION_PATTERN = '/^\d+(\.\d+){0,3}([-+][0-9A-Za-z.\-]+)?$/';

    /** A SHA-256 digest, hex encoded. 64 characters, nothing else. */
    private const SHA256_PATTERN = '/^[0-9a-f]{64}$/i';

    private function __construct(
        private string $version,
        private string $download_url,
        private string $sha256,
        private ?string $requires,
        private ?string $tested,
        private ?string $requires_php
    ) {}

    /**
     * Parse a manifest from the raw response body.
     *
     * json_decode() with the depth capped: the document is six flat keys, and a
     * deeply nested body is either not our manifest or an attempt to spend the
     * site's memory on parsing it. Exceeding the depth returns null, which is the
     * same "no update" outcome as any other malformed body.
     */
    public static function from_string( string $json ): ?self {
        if ( '' === trim( $json ) ) {
            return null;
        }

        $decoded = json_decode( $json, true, 8 );

        return self::from_array( $decoded );
    }

    /**
     * Parse a manifest from a decoded body.
     *
     * Takes mixed rather than array on purpose: json_decode() returns null for
     * malformed JSON, a string for `"hello"`, an int for `3` and a list for a JSON
     * array, and every one of those has to land here as "no update" rather than as
     * a TypeError. A TypeError inside the update check is a fatal on an admin page
     * load, which is the one outcome this whole module exists to avoid.
     */
    public static function from_array( mixed $raw ): ?self {
        if ( ! is_array( $raw ) ) {
            return null;
        }

        $version = self::version_field( $raw, 'version' );
        if ( null === $version ) {
            return null;
        }

        $download_url = self::package_url( $raw['download_url'] ?? null );
        if ( null === $download_url ) {
            return null;
        }

        $sha256 = $raw['sha256'] ?? null;
        if ( ! is_string( $sha256 ) || 1 !== preg_match( self::SHA256_PATTERN, $sha256 ) ) {
            return null;
        }

        return new self(
            $version,
            $download_url,
            // Lowercased once, here, so nothing downstream has to remember that
            // hash_file() returns lowercase hex while a hand-written manifest may
            // not. hash_equals() is byte-exact and would report a mismatch on case
            // alone, which would read as tampering.
            strtolower( $sha256 ),
            self::version_field( $raw, 'requires' ),
            self::version_field( $raw, 'tested' ),
            self::version_field( $raw, 'requires_php' )
        );
    }

    /**
     * A field that must look like a version, or null.
     *
     * @param array<mixed, mixed> $raw
     */
    private static function version_field( array $raw, string $key ): ?string {
        $value = $raw[ $key ] ?? null;

        if ( ! is_string( $value ) || 1 !== preg_match( self::VERSION_PATTERN, $value ) ) {
            return null;
        }

        return $value;
    }

    /**
     * The download URL, if it is one we are willing to fetch.
     *
     * https only, and no credentials in the URL. A plain http package would be
     * modifiable in transit by anyone on the path; the digest check would catch
     * the substitution, but there is no reason to make the digest do work TLS
     * already does.
     */
    private static function package_url( mixed $value ): ?string {
        if ( ! is_string( $value ) || '' === $value ) {
            return null;
        }

        $parts = parse_url( $value );
        if ( ! is_array( $parts ) ) {
            return null;
        }

        if ( 'https' !== strtolower( $parts['scheme'] ?? '' ) ) {
            return null;
        }

        // A URL carrying user:pass@ is either a mistake or an attempt to get a
        // credential logged somewhere. Neither belongs in a fleet update.
        if ( isset( $parts['user'] ) || isset( $parts['pass'] ) ) {
            return null;
        }

        $host = strtolower( $parts['host'] ?? '' );
        if ( ! in_array( $host, self::PACKAGE_HOSTS, true ) ) {
            return null;
        }

        return $value;
    }

    public function version(): string {
        return $this->version;
    }

    public function download_url(): string {
        return $this->download_url;
    }

    public function sha256(): string {
        return $this->sha256;
    }

    public function requires(): ?string {
        return $this->requires;
    }

    public function tested(): ?string {
        return $this->tested;
    }

    public function requires_php(): ?string {
        return $this->requires_php;
    }

    /**
     * Is this release newer than what is installed?
     *
     * Used by the CLI to report, and by nothing else. WordPress core does this
     * same comparison itself on whatever the update filter returns and files the
     * result under `response` (offer it) or `no_update` (do not) - see Updater,
     * which deliberately does not second-guess it.
     */
    public function is_newer_than( string $installed ): bool {
        return version_compare( $this->version, $installed, '>' );
    }

    /** The document as it came in, for the CLI to print. */
    public function to_array(): array {
        return array_filter(
            [
                'version'      => $this->version,
                'download_url' => $this->download_url,
                'sha256'       => $this->sha256,
                'requires'     => $this->requires,
                'tested'       => $this->tested,
                'requires_php' => $this->requires_php,
            ],
            static fn ( mixed $value ): bool => null !== $value
        );
    }
}
