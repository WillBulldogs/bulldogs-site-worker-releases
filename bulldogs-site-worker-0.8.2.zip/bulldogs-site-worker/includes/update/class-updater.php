<?php
namespace Bulldogs\SiteWorker\Update;

/**
 * Self-hosted plugin updates: the four filters that make WordPress take its
 * update information from us, and refuse a package we did not publish.
 *
 * ---------------------------------------------------------------------------
 * WHY THE `Update URI:` HEADER IS A SECURITY CONTROL, NOT BOILERPLATE
 * ---------------------------------------------------------------------------
 * Without that header WordPress asks api.wordpress.org about every installed
 * plugin, matched by DIRECTORY NAME. Our directory is `bulldogs-site-worker`. If
 * anyone ever publishes a plugin to wordpress.org under that slug, .org's answer
 * wins on every one of our client sites, and WordPress offers - and with
 * auto-updates on, installs - a stranger's code over ours. Nobody has to attack
 * us for this to happen; someone picking the same name is enough.
 *
 * The header (WP 5.8+) closes it from both ends:
 *
 *   - wordpress.org's API is documented to return NO result for a plugin whose
 *     `Update URI` points anywhere other than wordpress.org. It ignores the
 *     plugin for update purposes, so the slug cannot be claimed out from under
 *     us.
 *   - core then routes the check to `update_plugins_{$hostname}`, where the
 *     hostname comes from the header. That is the filter registered below.
 *
 * ⚠️ The hostname is parsed from the HEADER, and the filter name is built from
 * ManifestClient::MANIFEST_URL. If those two ever disagree, core calls a filter
 * nobody registered: no error, no notice, updates simply stop arriving on all 29
 * sites. UpdaterTest asserts the header and the constant are byte-identical.
 *
 * We use the narrow `update_plugins_{$hostname}` filter rather than editing the
 * whole `site_transient_update_plugins` blob. The blob filter sees - and can
 * corrupt - every other plugin's update data on the site, runs on far more
 * requests, and is the documented cause of a whole genre of "our updater broke
 * unrelated plugins" bugs. The header exists precisely to enable the narrow one.
 *
 * ---------------------------------------------------------------------------
 * NOTHING HERE MAY THROW INTO wp-admin
 * ---------------------------------------------------------------------------
 * Both read-side callbacks catch \Throwable and return their input untouched,
 * matching the module isolation in Plugin. An updater that white-screens the
 * dashboard is worse than an updater that does not work.
 *
 * The DOWNLOAD guard is the deliberate exception: it fails CLOSED. If it cannot
 * satisfy itself about a package, it returns a WP_Error and the update stops. A
 * verification step that degrades to "allow" on error is not a verification
 * step.
 */
class Updater {
    /** Directory name of the plugin, and the slug used in the details modal. */
    public const SLUG = 'bulldogs-site-worker';

    /**
     * Where "View version details" points. Public, and the same page a human
     * would be sent to.
     *
     * The repo root, NOT /releases. Publishing is done by a deploy key, which
     * cannot create GitHub releases, so that page is permanently empty. The repo
     * root renders CHANGELOG.md, which is where each version's URL and SHA-256
     * actually live - and is what a rollback is read out of.
     *
     * The RELEASES repo, not the source repo: the source is private and would
     * 404 for anyone this link is ever shown to.
     */
    public const DETAILS_URL = 'https://github.com/WillBulldogs/bulldogs-site-worker-releases';

    /**
     * Opt-in filter for fleet-wide automatic updates. Returns null by default,
     * meaning "do not interfere" - see auto_update() for the full argument.
     */
    public const AUTO_UPDATE_FILTER = 'bulldogs_sw_auto_update';

    /** `bulldogs-site-worker/bulldogs-site-worker.php`, as WordPress computed it. */
    private string $basename = '';

    public function __construct( private ManifestClient $client ) {}

    /**
     * @param string $plugin_basename plugin_basename( BULLDOGS_SW_FILE ). Passed in
     *                                rather than computed, for the same reason
     *                                ConsentModule::register() takes it: a site whose
     *                                plugin directory has been renamed must still
     *                                match, and a literal would silently miss.
     */
    public function register( string $plugin_basename ): void {
        $this->basename = $plugin_basename;

        add_filter( 'update_plugins_' . ManifestClient::host(), [ $this, 'check' ], 10, 3 );
        add_filter( 'upgrader_pre_download', [ $this, 'verify_package' ], 10, 4 );
        add_filter( 'plugins_api', [ $this, 'plugin_information' ], 10, 3 );
        add_filter( 'auto_update_plugin', [ $this, 'auto_update' ], 10, 2 );
    }

    /**
     * Answer core's update check for this plugin.
     *
     * ⚠️ This filter fires for EVERY installed plugin whose `Update URI` host
     * matches ours - and ours is a shared host - so the first thing it does is
     * check the plugin file is this plugin and hand back the untouched input if
     * not. Answering for someone else's plugin would offer our zip as their
     * update.
     *
     * WE DO NOT COMPARE VERSIONS HERE, and that is not an omission. Core takes
     * what this returns, requires a `version`, then does the version_compare
     * itself: newer goes in `response` (an update is offered), same or older goes
     * in `no_update`. Returning the offer either way is what puts the plugin in
     * `no_update` when it is current - and a plugin absent from BOTH lists is one
     * WordPress reports as "Auto-updates are not available for this plugin",
     * which would take away the per-site toggle this module deliberately leaves
     * to WordPress's own UI.
     *
     * @param array|false $update      Whatever a previous callback said. False by default.
     * @param array       $plugin_data The plugin's headers.
     * @param string      $plugin_file The plugin basename core is asking about.
     * @return array|false
     */
    public function check( $update, $plugin_data, $plugin_file ) {
        try {
            if ( ! is_string( $plugin_file ) || $plugin_file !== $this->basename ) {
                return $update;
            }

            $manifest = $this->client->fetch();
            if ( null === $manifest ) {
                // The manifest host is down, or answered with something that is not
                // a manifest. Silence is the specification: see ManifestClient.
                return $update;
            }

            $offer = [
                'slug'    => self::SLUG,
                'version' => $manifest->version(),
                'url'     => self::DETAILS_URL,
                'package' => $manifest->download_url(),
            ];

            // Optional hints, included only when the manifest carried a usable
            // value. An empty 'tested' reads to WordPress as "untested", which is
            // a worse answer than not saying.
            foreach ( [ 'requires' => $manifest->requires(), 'tested' => $manifest->tested(), 'requires_php' => $manifest->requires_php() ] as $key => $value ) {
                if ( null !== $value ) {
                    $offer[ $key ] = $value;
                }
            }

            return $offer;
        } catch ( \Throwable $e ) {
            $this->log( 'update check failed', $e );
            return $update;
        }
    }

    /**
     * Verify the package's SHA-256 before WordPress installs it.
     *
     * ---------------------------------------------------------------------------
     * WHY `upgrader_pre_download` AND NOT `upgrader_pre_install`
     * ---------------------------------------------------------------------------
     * Both were candidates. The difference is what has already happened to the
     * filesystem by the time the hook runs.
     *
     * `upgrader_pre_download` fires inside WP_Upgrader::download_package(), BEFORE
     * anything is fetched. Returning a non-false value short-circuits core's own
     * download, so we can fetch the zip ourselves, hash the actual bytes on disk,
     * and hand back either the file path (core carries on) or a WP_Error (core
     * returns it from download_package() and WP_Upgrader::run() bails). At that
     * point nothing has been unpacked and nothing has been written anywhere near
     * wp-content/plugins - the only file that ever existed is our own temp
     * download, which is deleted on mismatch.
     *
     * `upgrader_pre_install` fires later, after core has downloaded AND unpacked
     * the package into wp-content/upgrade/. Failing there means untrusted archive
     * contents have already been extracted onto the box, and the zip we would
     * want to hash has already been consumed. It is the wrong side of the line.
     *
     * ---------------------------------------------------------------------------
     * WHY THE PACKAGE URL IS CHECKED AGAINST THE MANIFEST, NOT JUST HASHED
     * ---------------------------------------------------------------------------
     * The URL core hands us comes out of the `update_plugins` site transient,
     * which is site data. Anything able to write options on a compromised site
     * could put its own `package` URL there and let WordPress's own update button
     * execute it. Hashing "whatever we were given, against whatever digest came
     * with it" would verify that attack rather than stop it. So the package must
     * be the exact URL the manifest currently names, and the digest comes from
     * the manifest, never from the caller.
     *
     * A mismatch has one innocent cause - our cached manifest is a release behind
     * the update transient, or vice versa - so we re-read the manifest off the
     * network once before refusing.
     *
     * @param false|string|\WP_Error $reply      Short-circuit value; false means core downloads.
     * @param string                 $package    The package URL core is about to fetch.
     * @param mixed                  $upgrader   The WP_Upgrader instance. Unused.
     * @param array                  $hook_extra Context; carries `plugin` for a plugin update.
     * @return false|string|\WP_Error
     */
    public function verify_package( $reply, $package, $upgrader = null, $hook_extra = [] ) {
        // Someone else already short-circuited the download. Not ours to second
        // guess, and re-entering would double-download.
        if ( false !== $reply ) {
            return $reply;
        }

        // Ownership is decided on string comparisons only, outside the try below,
        // so that "is this ours?" can never itself be the thing that fails. Every
        // core, theme and other-plugin download on the site passes through here.
        //
        // `plugin` is set by Plugin_Upgrader for single, bulk AND automatic
        // updates, which is every path WordPress uses to update an installed
        // plugin. Installing a zip by URL by hand does not set it, and is
        // deliberately out of scope: that is a human handing WordPress a specific
        // file, not the update system choosing one.
        if ( ! is_string( $package ) || '' === $package ) {
            return $reply;
        }
        if ( ! is_array( $hook_extra ) || ( $hook_extra['plugin'] ?? null ) !== $this->basename ) {
            return $reply;
        }

        try {
            $manifest = $this->client->fetch();

            // Our cached copy may simply be stale against a release published in
            // the last few hours. Re-read once, off the network, before refusing.
            if ( null === $manifest || $manifest->download_url() !== $package ) {
                $manifest = $this->client->fetch( true );
            }

            if ( null === $manifest ) {
                return $this->refuse(
                    'bulldogs_sw_no_manifest',
                    'The Bulldogs release manifest could not be read, so this update was not installed. '
                    . 'Nothing has been changed. Try again once the release host is reachable.'
                );
            }

            if ( $manifest->download_url() !== $package ) {
                return $this->refuse(
                    'bulldogs_sw_unexpected_package',
                    'This update points at a file the Bulldogs release manifest does not list, so it was not '
                    . 'installed and nothing has been changed. Re-check for updates and try again; if it '
                    . 'happens a second time, stop and report it.'
                );
            }

            // download_url() lives in an admin include. Automatic updates load it
            // themselves, but a checked require costs nothing and a fatal here
            // would be a fatal during an update.
            if ( ! function_exists( 'download_url' ) && defined( 'ABSPATH' ) ) {
                require_once ABSPATH . 'wp-admin/includes/file.php';
            }
            if ( ! function_exists( 'download_url' ) ) {
                return $this->refuse(
                    'bulldogs_sw_no_downloader',
                    'WordPress could not download the update in this context, so nothing has been changed.'
                );
            }

            // Signature checking is deliberately not requested. Core's is dormant
            // on virtually every install (it needs trusted hosts configured and a
            // .sig alongside the package), and what replaces it here is the
            // digest check below - which is mandatory rather than best-effort.
            $file = download_url( $package, 300 );

            if ( is_wp_error( $file ) || ! is_string( $file ) ) {
                // Core's own download error, passed straight back so the operator
                // sees WordPress's wording for a network failure.
                return is_wp_error( $file ) ? $file : $this->refuse(
                    'bulldogs_sw_download_failed',
                    'The update package could not be downloaded, so nothing has been changed.'
                );
            }

            $actual = @hash_file( 'sha256', $file );

            if ( ! is_string( $actual ) || ! hash_equals( $manifest->sha256(), strtolower( $actual ) ) ) {
                // Delete first. Leaving an unverified archive on disk under a
                // predictable temp name is a small favour to whoever put it there.
                @unlink( $file );

                $this->log_line( sprintf(
                    'REFUSED update to %s: package checksum did not match the manifest (expected %s, got %s)',
                    $manifest->version(),
                    $manifest->sha256(),
                    is_string( $actual ) ? strtolower( $actual ) : 'nothing'
                ) );

                return $this->refuse(
                    'bulldogs_sw_checksum_mismatch',
                    'The update package did not match the checksum published for it, so it was NOT installed '
                    . 'and nothing has been changed. This means the file was corrupted in transit or is not '
                    . 'the file we published - do not retry until someone has looked at it.'
                );
            }

            return $file;
        } catch ( \Throwable $e ) {
            $this->log( 'package verification failed', $e );

            // Fail closed. We know this package is ours and we know we did not
            // finish checking it, so the only safe answer is no.
            return $this->refuse(
                'bulldogs_sw_verification_error',
                'The update could not be verified, so it was not installed and nothing has been changed.'
            );
        }
    }

    /**
     * Answer the "View version details" modal for our slug ourselves.
     *
     * Same reasoning as the Update URI header, one screen further on: left alone,
     * that modal calls plugins_api(), which asks api.wordpress.org about the slug
     * `bulldogs-site-worker`. Today that returns an error box. If the slug is ever
     * taken on .org it would show a stranger's plugin page, described as ours, on
     * a client's dashboard. Cheaper to answer it than to explain it.
     *
     * Read-only and cosmetic - no code path installs anything from here - so this
     * one degrades to "let WordPress handle it" on error rather than failing
     * closed.
     *
     * @param mixed  $result Whatever a previous callback returned; false by default.
     * @param string $action The plugins_api action being performed.
     * @param mixed  $args   Query arguments; an object in practice, guarded anyway.
     * @return mixed
     */
    public function plugin_information( $result, $action = '', $args = null ) {
        try {
            if ( 'plugin_information' !== $action ) {
                return $result;
            }

            $slug = is_object( $args ) ? ( $args->slug ?? null ) : ( is_array( $args ) ? ( $args['slug'] ?? null ) : null );
            if ( self::SLUG !== $slug ) {
                return $result;
            }

            $manifest = $this->client->fetch();
            $version  = null !== $manifest ? $manifest->version() : ( defined( 'BULLDOGS_SW_VERSION' ) ? BULLDOGS_SW_VERSION : '' );

            $information = (object) [
                'name'          => 'Bulldogs Site Worker',
                'slug'          => self::SLUG,
                'version'       => $version,
                'author'        => '<a href="https://bulldogsdigital.co.uk">Bulldogs Digital</a>',
                'homepage'      => self::DETAILS_URL,
                'download_link' => null !== $manifest ? $manifest->download_url() : '',
                'requires'      => null !== $manifest ? (string) $manifest->requires() : '',
                'tested'        => null !== $manifest ? (string) $manifest->tested() : '',
                'requires_php'  => null !== $manifest ? (string) $manifest->requires_php() : '',
                'sections'      => [
                    'description' => 'Consent gating and site monitoring for the Bulldogs Digital hosting fleet. '
                        . 'Updates are served from our own release repository, not from wordpress.org.',
                    'changelog'   => 'Every release, with its download URL and SHA-256, is listed in '
                        . 'CHANGELOG.md at <a href="' . self::DETAILS_URL . '">' . self::DETAILS_URL . '</a>.',
                ],
            ];

            return $information;
        } catch ( \Throwable $e ) {
            $this->log( 'plugin information lookup failed', $e );
            return $result;
        }
    }

    /**
     * Whether to auto-update this plugin. By default: we do not answer.
     *
     * ---------------------------------------------------------------------------
     * WHY THIS SHIPS OFF
     * ---------------------------------------------------------------------------
     * 0.5.0 through 0.5.5 all shipped in a single day, each one a real bug found
     * only on a live site. With auto-updates forced on, that day would have been
     * six unattended installs across 29 client sites, with the broken window
     * between each one landing on real visitors and nobody watching. Manual
     * updating is slower; it is not the worse failure.
     *
     * Returning $update unchanged means WordPress's own per-site setting decides -
     * the toggle in the plugins list, or `wp plugin auto-updates enable
     * bulldogs-site-worker`, which is the fleet-wide answer because it can be
     * looped over sites from the server. That toggle is only offered for plugins
     * core knows an update story for, which is why check() always returns an offer.
     *
     * The filter is the programmatic override, for an mu-plugin or a wp-config
     * snippet, when the fleet is ready for it:
     *
     *     add_filter( 'bulldogs_sw_auto_update', '__return_true' );
     *
     * Only a real boolean counts. A callback returning a truthy string or 1 by
     * accident does not silently switch automatic updates on across the fleet.
     *
     * @param mixed $update What WordPress currently intends.
     * @param mixed $item   The update offer; carries the plugin basename.
     * @return mixed
     */
    public function auto_update( $update, $item = null ) {
        try {
            $plugin = is_object( $item ) ? ( $item->plugin ?? null ) : ( is_array( $item ) ? ( $item['plugin'] ?? null ) : null );
            if ( $plugin !== $this->basename ) {
                return $update;
            }

            $override = apply_filters( self::AUTO_UPDATE_FILTER, null );

            return is_bool( $override ) ? $override : $update;
        } catch ( \Throwable $e ) {
            $this->log( 'auto-update decision failed', $e );
            return $update;
        }
    }

    /** A WP_Error carrying the operator-facing refusal, logged on the way out. */
    private function refuse( string $code, string $message ): \WP_Error {
        $this->log_line( $code . ': ' . $message );
        return new \WP_Error( $code, $message );
    }

    private function log( string $what, \Throwable $e ): void {
        $this->log_line( $what . ': ' . $e->getMessage() );
    }

    private function log_line( string $line ): void {
        if ( function_exists( 'error_log' ) ) {
            error_log( 'bulldogs-site-worker: ' . $line );
        }
    }
}
