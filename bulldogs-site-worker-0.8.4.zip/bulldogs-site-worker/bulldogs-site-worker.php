<?php
/**
 * Plugin Name:       Bulldogs Site Worker
 * Description:       Consent gating and site monitoring for the Bulldogs Digital hosting fleet.
 * Version:           0.8.4
 * Update URI:        https://wpupdates.bulldogs.digital/manifest.json
 * Requires at least: 6.5
 * Requires PHP:      8.1
 * Author:            Bulldogs Digital
 * License:           GPL-2.0-or-later
 * Text Domain:       bulldogs-site-worker
 */

/**
 * ⚠️ `Update URI:` above is a SECURITY control, not metadata, and it must stay
 * byte-identical to \Bulldogs\SiteWorker\Update\ManifestClient::MANIFEST_URL.
 *
 * Without it, WordPress asks api.wordpress.org about this plugin by DIRECTORY
 * NAME, and anyone publishing `bulldogs-site-worker` to .org would have their
 * code offered as an update on all 29 client sites. With it, .org withholds any
 * answer and core routes the check to `update_plugins_{hostname}` instead - the
 * filter the update module registers. The hostname comes from THIS string, so a
 * drift between it and the constant means core calls a filter nobody registered
 * and updates stop arriving, silently, everywhere. UpdaterTest asserts they match.
 *
 * ⚠️ AND IT IS A HOSTNAME WE OWN, WHICH IS NOT A PREFERENCE. This string is baked
 * into every installed copy, and WordPress reads it from the INSTALLED plugin -
 * so it cannot be changed retroactively. Moving off a hostname later means
 * updating all ~29 sites by hand FIRST, which is precisely the manual work this
 * module exists to remove. A borrowed hostname is also a shared one: the filter
 * name is derived from it, so every plugin updating from that host shares a
 * filter. Ours is ours alone, and it can be repointed at different hosting
 * without a single site knowing.
 */

defined( 'ABSPATH' ) || exit;

define( 'BULLDOGS_SW_VERSION', '0.8.4' );
define( 'BULLDOGS_SW_FILE', __FILE__ );
define( 'BULLDOGS_SW_PATH', plugin_dir_path( __FILE__ ) );
define( 'BULLDOGS_SW_URL', plugin_dir_url( __FILE__ ) );

// Runtime loading is manual and explicit. Never require vendor/autoload.php here.
require_once BULLDOGS_SW_PATH . 'includes/class-plugin.php';
require_once BULLDOGS_SW_PATH . 'includes/class-settings.php';
// ⚠️ FILE SCOPE, and for the same reason class-site-secret.php is below: the
// activation hook touches Modules before any plugins_loaded closure has run.
require_once BULLDOGS_SW_PATH . 'includes/class-modules.php';
require_once BULLDOGS_SW_PATH . 'includes/consent/class-consent-dependency.php';
require_once BULLDOGS_SW_PATH . 'includes/consent/class-consent-type.php';
require_once BULLDOGS_SW_PATH . 'includes/consent/class-tag-registry.php';
require_once BULLDOGS_SW_PATH . 'includes/consent/class-tag-emitter.php';
require_once BULLDOGS_SW_PATH . 'includes/consent/class-version-stamp.php';
require_once BULLDOGS_SW_PATH . 'includes/consent/class-banner-renderer.php';
require_once BULLDOGS_SW_PATH . 'includes/consent/class-banner-categories.php';
require_once BULLDOGS_SW_PATH . 'includes/consent/class-consent-module.php';
// ⚠️ FILE SCOPE, not the monitor module closure below, and this is not a style
// choice. register_activation_hook fires on the activation request, long before
// any plugins_loaded closure runs, so a class the activation callback touches
// which is only required inside a closure is UNDEFINED when the callback fires -
// and activation dies with "Class not found" on a live site, mid-rollout.
require_once BULLDOGS_SW_PATH . 'includes/monitor/class-site-secret.php';

/**
 * Settle the module flags, then generate the per-site monitoring secret.
 *
 * ---------------------------------------------------------------------------
 * 🚨 THE ORDER OF THESE TWO STEPS IS LOAD-BEARING. DO NOT SWAP THEM.
 * ---------------------------------------------------------------------------
 * Modules::migrate() identifies a site that has been running a pre-registry
 * build by finding data in the option row with no `installed_version` stamped
 * beside it, and switches consent ON for it - which is what stops an upgrade
 * silently un-gating the sites that are gating today.
 *
 * SiteSecret::ensure() WRITES to that same option row. Run it first on a brand
 * new install and the migration then sees a populated row that no version
 * stamped, concludes the site has been running an older build, and enables
 * consent at the moment of installation - the exact opposite of the dormant
 * install this release exists to make possible, on every new site, silently.
 *
 * ModulesActivationOrderTest pins this ordering by reading this file.
 *
 * ---------------------------------------------------------------------------
 * ensure(), never rotate(). This hook fires on EVERY activation, including the
 * deactivate/activate cycle that a plugin update or a bit of troubleshooting
 * performs. Generating unconditionally would silently invalidate the value
 * already registered against this site in WP Fleet, and collection would start
 * returning 403 for a reason nobody would connect to having updated a plugin.
 *
 * Wrapped, because activation is the one moment a fatal is guaranteed to be seen:
 * WordPress surfaces it as a white screen with the plugin left inactive. Failing
 * to mint a secret is not worth that - the endpoint simply keeps refusing
 * everything, which is the correct fail-closed state, and `wp bulldogs monitor
 * secret` mints one on demand.
 */
register_activation_hook( BULLDOGS_SW_FILE, static function (): void {
    $settings = new \Bulldogs\SiteWorker\Settings();

    // FIRST. See the ordering note above.
    try {
        ( new \Bulldogs\SiteWorker\Modules( $settings ) )->bootstrap( BULLDOGS_SW_VERSION );
    } catch ( \Throwable $e ) {
        if ( function_exists( 'error_log' ) ) {
            error_log( 'bulldogs-site-worker: could not settle the module flags on activation: ' . $e->getMessage() );
        }
    }

    try {
        ( new \Bulldogs\SiteWorker\Monitor\SiteSecret( $settings ) )->ensure();
    } catch ( \Throwable $e ) {
        if ( function_exists( 'error_log' ) ) {
            error_log( 'bulldogs-site-worker: could not generate the site secret on activation: ' . $e->getMessage() );
        }
    }
} );

if ( defined( 'WP_CLI' ) && WP_CLI ) {
    // Runtime loading is manual - vendor/autoload.php does not exist on a fleet
    // install. Every class the commands touch must be required. Settings and
    // TagRegistry are already required at file scope above, so only the command
    // class itself is new here; requiring them twice would be harmless but noise.
    require_once BULLDOGS_SW_PATH . 'includes/cli/class-cli-commands.php';
    WP_CLI::add_command( 'bulldogs consent', \Bulldogs\SiteWorker\CLI\Commands::class );

    // The module switches. Registered here rather than inside any module's own
    // closure, and that is the whole point: the command that turns a module on
    // has to exist on a site where that module is off. BannerCategories and
    // TagRegistry are already required at file scope; the consent-enable
    // preflight reads both, and reads them on a site where the consent module
    // has never booted.
    require_once BULLDOGS_SW_PATH . 'includes/cli/class-module-commands.php';
    WP_CLI::add_command( 'bulldogs module', \Bulldogs\SiteWorker\CLI\ModuleCommands::class );

    // The monitor classes are required again here, not left to the module closure
    // below. add_command() registers a class NAME and instantiates it later, so a
    // command would otherwise depend on the monitor module having booted - and the
    // module boots inside a try/catch that is designed to swallow failures. The
    // result would be that the one command an operator reaches for when something
    // looks wrong is the one that fatals when something IS wrong. require_once is
    // idempotent, so the duplication costs nothing.
    require_once BULLDOGS_SW_PATH . 'includes/monitor/class-tracker-list.php';
    require_once BULLDOGS_SW_PATH . 'includes/monitor/class-scanner.php';
    require_once BULLDOGS_SW_PATH . 'includes/monitor/class-findings-store.php';
    require_once BULLDOGS_SW_PATH . 'includes/monitor/class-rest-controller.php';
    require_once BULLDOGS_SW_PATH . 'includes/monitor/class-enrolment.php';
    WP_CLI::add_command( 'bulldogs monitor', \Bulldogs\SiteWorker\CLI\MonitorCommands::class );

    // Same reasoning as the monitor requires directly above: add_command()
    // registers a class NAME and instantiates it later, so leaving these to the
    // update module's closure would make `wp bulldogs update check` depend on a
    // module that boots inside a failure-swallowing try/catch.
    require_once BULLDOGS_SW_PATH . 'includes/update/class-manifest.php';
    require_once BULLDOGS_SW_PATH . 'includes/update/class-manifest-client.php';
    require_once BULLDOGS_SW_PATH . 'includes/cli/class-update-commands.php';
    WP_CLI::add_command( 'bulldogs update', \Bulldogs\SiteWorker\CLI\UpdateCommands::class );
}

add_action( 'plugins_loaded', static function (): void {
    /*
     * Which modules are switched on, on this site. Every module below is ADDED
     * unconditionally and Plugin::boot() decides what actually runs, so there is
     * one place that answers "is this module on" rather than a flag check inside
     * each closure - and a disabled module's closure is never entered at all.
     */
    $plugin = new \Bulldogs\SiteWorker\Plugin(
        new \Bulldogs\SiteWorker\Modules( new \Bulldogs\SiteWorker\Settings() )
    );

    $plugin->add_module( 'consent', static function (): void {
        /*
         * 🚨 THE DEPENDENCY GATE. Do not move this below the register() call.
         *
         * Until 0.8.1 this was a `Requires Plugins` header naming wp-consent-api,
         * header, which meant WordPress refused to ACTIVATE the plugin at all
         * without it - making the dormant fleet install impossible on the 50 of
         * 52 installs that do not run consent. See ConsentDependency for the
         * full reasoning and for what this check is protecting against.
         *
         * Returning here means the module is not booted: no wp_get_consent_type
         * filter, no banner, no enqueue. Upstream wp_has_consent() therefore
         * goes back to allowing everything, which is the SAFE failure direction
         * - ungated is bad, but permanently blocked with no route to unblocking
         * is worse and is invisible. The monitor reports the state as a HIGH
         * because the flag says consent is on and the page carries no gate.
         */
        $dependency = new \Bulldogs\SiteWorker\Consent\ConsentDependency();

        if ( ! $dependency->is_available() ) {
            if ( function_exists( 'error_log' ) ) {
                error_log( 'bulldogs-site-worker: consent is enabled but ' . $dependency->missing_message() );
            }
            return;
        }

        $settings = new \Bulldogs\SiteWorker\Settings();
        // One TagRegistry, shared: it memoises the parsed option, so a second
        // instance would re-parse and re-log every malformed entry.
        $registry = new \Bulldogs\SiteWorker\Consent\TagRegistry( $settings );

        ( new \Bulldogs\SiteWorker\Consent\ConsentModule(
            $settings,
            $registry,
            new \Bulldogs\SiteWorker\Consent\VersionStamp(),
            new \Bulldogs\SiteWorker\Consent\TagEmitter(),
            new \Bulldogs\SiteWorker\Consent\BannerRenderer(),
            new \Bulldogs\SiteWorker\Consent\ConsentType(),
            new \Bulldogs\SiteWorker\Consent\BannerCategories( $registry )
        ) )->register(
            // Never a hardcoded string. wp-consent-api builds its conformance
            // filter name from the basename WordPress itself computed, so on a
            // site whose plugin directory has been renamed a literal silently
            // misses and site health reports non-conformance. No unit test can
            // catch that - there is no WordPress in the suite to disagree with.
            plugin_basename( BULLDOGS_SW_FILE )
        );
    } );

    // Monitor module. The requires sit INSIDE the closure rather than at file scope
    // with the consent classes, because a drift scan runs on a pull or from WP-CLI
    // and never as part of rendering a page.
    //
    // ⚠️ SiteSecret is the exception and lives at file scope above: the ACTIVATION
    // hook touches it, and activation fires before this closure has ever run.
    // Anything else activation grows a dependency on has to move up there too.
    //
    // Booting this module costs one hook registration. Nothing here reads an option
    // or touches the database on a normal page load - RestController only does work
    // once WordPress has routed a request to /wp-json/bulldogs-sw/v1/findings, and
    // even then only when the interval says a scan is owed.
    $plugin->add_module( 'monitor', static function (): void {
        require_once BULLDOGS_SW_PATH . 'includes/monitor/class-tracker-list.php';
        require_once BULLDOGS_SW_PATH . 'includes/monitor/class-scanner.php';
        require_once BULLDOGS_SW_PATH . 'includes/monitor/class-findings-store.php';
        require_once BULLDOGS_SW_PATH . 'includes/monitor/class-rest-controller.php';
        require_once BULLDOGS_SW_PATH . 'includes/monitor/class-enrolment.php';

        $settings = new \Bulldogs\SiteWorker\Settings();

        $controller = new \Bulldogs\SiteWorker\Monitor\RestController(
            $settings,
            new \Bulldogs\SiteWorker\Monitor\SiteSecret( $settings ),
            new \Bulldogs\SiteWorker\Monitor\FindingsStore( $settings ),
            new \Bulldogs\SiteWorker\Monitor\Scanner(),
            // Its own BannerCategories, not the consent module's. The two never run
            // in the same request - one renders a page, the other answers a REST
            // call - and BannerCategories memoises per instance, so sharing would
            // buy nothing and couple the monitor's answer to the render's timing.
            new \Bulldogs\SiteWorker\Consent\BannerCategories(
                new \Bulldogs\SiteWorker\Consent\TagRegistry( $settings )
            ),
            // Which modules are on. Passed so the scan knows whether an ungated
            // tracker is a fault or the intended dormant state - see Scanner.
            new \Bulldogs\SiteWorker\Modules( $settings )
        );

        add_action( 'rest_api_init', [ $controller, 'register_routes' ] );

        /*
         * Offer this site's secret to WP Fleet until somebody approves it.
         *
         * ⚠️ NEVER ON A VISITOR REQUEST. Enrolment::context_allows() confines the
         * outbound call to wp-admin, WP-Cron and WP-CLI - contexts where a human
         * or a scheduler is already waiting on a round trip. Putting our latency
         * into a client's page render, on every site in the fleet, to solve a
         * problem the visitor does not have, is not a trade worth making.
         *
         * The condition is checked BEFORE the hook is registered rather than
         * inside the callback, so a front-end request does not even carry the
         * closure. Enrolment itself is also scheduled - at most one attempt an
         * hour while pending, six-hourly after a failure - so an admin clicking
         * around wp-admin does not produce a request per page load.
         */
        $enrolment = new \Bulldogs\SiteWorker\Monitor\Enrolment(
            $settings,
            new \Bulldogs\SiteWorker\Monitor\SiteSecret( $settings )
        );

        if ( $enrolment->context_allows() ) {
            add_action(
                'init',
                static function () use ( $enrolment ): void {
                    // Wrapped: enrolment is a convenience, and it must never be
                    // able to take down wp-admin on a client site.
                    try {
                        $enrolment->maybe_enrol();
                    } catch ( \Throwable $e ) {
                        if ( function_exists( 'error_log' ) ) {
                            error_log( 'bulldogs-site-worker: enrolment attempt failed: ' . $e->getMessage() );
                        }
                    }
                },
                // Late, so a slow or hanging request cannot delay anything else
                // that hooks init.
                99
            );
        }
    } );

    // Update module: self-hosted plugin updates from our own manifest.
    //
    // Booted on every request rather than gated behind is_admin(), and that is a
    // considered trade. The cost is three small requires and four add_filter
    // calls; the alternative is guessing every context in which WordPress may
    // run an update check or an upgrade - admin, cron, WP-CLI, an automatic
    // update fired from a request that is none of the above - and being silently
    // wrong about one of them on 29 client sites.
    //
    // No option is read and no HTTP request is made by booting: ManifestClient
    // only goes to the network when core actually asks for update information.
    $plugin->add_module( 'update', static function (): void {
        require_once BULLDOGS_SW_PATH . 'includes/update/class-manifest.php';
        require_once BULLDOGS_SW_PATH . 'includes/update/class-manifest-client.php';
        require_once BULLDOGS_SW_PATH . 'includes/update/class-updater.php';

        ( new \Bulldogs\SiteWorker\Update\Updater(
            new \Bulldogs\SiteWorker\Update\ManifestClient()
        ) )->register(
            // Never a hardcoded string, for the same reason the consent module
            // does not use one: core identifies the plugin by the basename IT
            // computed, so on a site whose plugin directory has been renamed a
            // literal would never match and the site would silently stop
            // receiving updates.
            plugin_basename( BULLDOGS_SW_FILE )
        );
    } );

    $plugin->boot();

    // Keep the instance reachable. The monitor needs to read failed_modules().
    $GLOBALS['bulldogs_sw_plugin'] = $plugin;
} );
