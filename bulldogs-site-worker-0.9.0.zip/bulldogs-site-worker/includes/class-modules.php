<?php
namespace Bulldogs\SiteWorker;

/**
 * Which of this plugin's modules are switched on, on THIS site.
 *
 * ---------------------------------------------------------------------------
 * WHAT "DISABLED" HAS TO MEAN, AND WHY IT IS NOT "HIDE THE BANNER"
 * ---------------------------------------------------------------------------
 * The plugin goes onto every site in the fleet dormant, and is switched on per
 * site later. That is only safe if a dormant install is indistinguishable from
 * no install at all - so a disabled module is one whose boot callback is NEVER
 * CALLED. Not called and then made to render nothing: not called.
 *
 * 🚨 For the consent module in particular, any softer reading is dangerous in a
 * way that is invisible from the outside. Upstream `wp_has_consent()` returns
 * TRUE for every category when `wp_get_consent_type()` is empty - "no consent
 * management is present, so allow everything". Our `optin` filter is not a
 * refinement of that, it is the entire gate. Two failure modes follow, and they
 * point in opposite directions:
 *
 *   - Register the filter and render no banner, and nothing on the page can ever
 *     consent. Site Kit stays denied forever and the client's analytics is dead,
 *     silently, while the site looks fine. That is the worst outcome available
 *     here, and it is what "disabled = hide the banner" produces.
 *   - Leave tags rendered inert without the banner, same thing: permanently
 *     blocked tracking with no route to unblocking it.
 *
 * So the test of dormancy is not "is the banner gone". It is: a site with this
 * plugin ACTIVE and consent DISABLED must be byte-equivalent, in rendered output
 * and in network behaviour, to that site with the plugin not installed at all.
 * The fixture suite's dormancy tests assert exactly that, against output built
 * by the real classes rather than against a description of them.
 *
 * ---------------------------------------------------------------------------
 * A REGISTRY, NOT A `consent_enabled` BOOLEAN
 * ---------------------------------------------------------------------------
 * WP Fleet modules are coming and will want the same treatment, so the shape is
 * general from the start: named modules, each independently enabled, each booted
 * in isolation by Plugin::boot(). Adding one is a line in DEFAULTS.
 *
 * ---------------------------------------------------------------------------
 * FAIL-SAFE READING
 * ---------------------------------------------------------------------------
 * The stored value is one key inside a hand-editable option that is also written
 * by WP-CLI and restored from backups, so it may hold anything. Nothing here
 * casts. A module is enabled only when its stored flag is LITERALLY `true`;
 * anything else - `1`, `"yes"`, an array, a missing key, a corrupt row, an
 * unknown module name - falls back to that module's static default, and
 * consent's static default is OFF. There is no path by which junk in the option
 * switches consent on.
 */
class Modules {
    public const CONSENT = 'consent';
    public const MONITOR = 'monitor';
    public const UPDATE  = 'update';
    /**
     * Reports what WordPress's own update check said about each plugin and theme.
     * Named `versions`, not `updates`, because `update` is already this plugin's
     * own update channel and two modules one letter apart is a mistyped
     * `module disable` waiting to happen.
     */
    public const VERSIONS = 'versions';
    /** Reports Wordfence's own scan results and scan health. */
    public const SECURITY = 'security';

    /** Settings key holding the flags: module name => bool. */
    public const KEY = 'modules';

    /**
     * Settings key stamped by the activation hook with the version that install
     * introduced itself as. See migrate(): its ABSENCE is what identifies a site
     * that has been running an older version, and it is therefore load-bearing
     * rather than diagnostic.
     */
    public const KEY_INSTALLED_VERSION = 'installed_version';

    /**
     * Recorded when the flags were written by the migration rather than chosen.
     * Nothing reads it to make a decision - `wp bulldogs module list` prints it so
     * that an operator checking a site after an upgrade can see WHY consent is on.
     */
    public const KEY_MIGRATED_FROM = 'modules_migrated_from';

    /**
     * Every module this plugin registers, and whether it is on by default.
     *
     * 🚨 CONSENT DEFAULTS OFF, and that is the whole point of this class.
     * Activating the plugin must change nothing about what a visitor sees. The
     * opposite default would put a banner on a site the moment it was activated,
     * before anyone had set a cookie policy URL - a banner with no policy link is
     * itself a compliance gap, so an install-time default of "on" trades one gap
     * for another on 29 sites at once.
     *
     * MONITOR DEFAULTS ON. It is what makes a dormant install worth having: the
     * findings endpoint gives fleet visibility from day one, and it reports
     * nothing to anyone until WP Fleet has been given the site's secret.
     *
     * UPDATE DEFAULTS ON. A site that cannot receive fixes is the reason this
     * plugin has an update channel of its own.
     *
     * VERSIONS AND SECURITY DEFAULT ON, and that does not touch dormancy. Neither
     * registers a hook, renders anything or makes a request: each only adds a
     * section to the findings response, which answers nobody until WP Fleet holds
     * the site's secret. Existing installs pick them up on upgrade through
     * normalise(), which fills a missing flag with its default.
     */
    private const DEFAULTS = [
        self::CONSENT  => false,
        self::MONITOR  => true,
        self::UPDATE   => true,
        self::VERSIONS => true,
        self::SECURITY => true,
    ];

    /**
     * Settings keys that only an operator configuring CONSENT ever writes.
     *
     * Used by migrate() as evidence that a site was already running the consent
     * module before this version existed. Deliberately none of the monitor's keys:
     * `site_secret` is written by the activation hook on a brand-new install too,
     * so it says nothing about which version wrote it.
     */
    private const CONSENT_CONFIG_KEYS = [ 'policy_url', 'privacy_url', 'banner_theme', 'tags' ];

    /**
     * Resolved once per instance.
     *
     * Per-instance rather than static, matching TagRegistry and BannerCategories:
     * a long-running WP-CLI process that has just flipped a module must be able to
     * build a fresh one and see the new answer.
     *
     * @var array<string, bool>|null
     */
    private ?array $flags = null;

    public function __construct( private Settings $settings ) {}

    /** @return string[] Module names, in boot order. */
    public static function known(): array {
        return array_keys( self::DEFAULTS );
    }

    public static function is_known( string $name ): bool {
        return array_key_exists( $name, self::DEFAULTS );
    }

    /** The compiled-in default for one module, ignoring anything stored. */
    public static function default_for( string $name ): bool {
        return self::DEFAULTS[ $name ] ?? false;
    }

    /**
     * Is this module switched on?
     *
     * An unknown name is false. Plugin::boot() only ever asks about modules it was
     * given, so an unknown name here means someone has hand-edited the option to
     * name a module that does not exist - answering "yes" to that would be
     * inventing a decision nobody made.
     */
    public function is_enabled( string $name ): bool {
        return $this->flags()[ $name ] ?? false;
    }

    /**
     * Every module's state, for `wp bulldogs module list`.
     *
     * `source` is how the answer was arrived at, which is the difference between
     * "somebody decided this" and "this is what it defaults to" - and, after an
     * upgrade, between "consent is on because we migrated it" and "consent is on
     * because someone switched it on".
     *
     * @return array<string, array{enabled:bool, source:string, default:bool}>
     */
    public function all(): array {
        // Resolved FIRST. On a site that has never been through the registry this
        // is the call that runs the migration and writes the flags, so reading the
        // stored value before it would report every module as "default" on exactly
        // the site an operator is checking after an upgrade - the one moment this
        // command has to be right about why consent is on.
        $this->flags();

        $stored   = $this->stored();
        $migrated = $this->migrated_from();

        $out = [];
        foreach ( self::known() as $name ) {
            $has_flag = is_array( $stored ) && array_key_exists( $name, $stored ) && is_bool( $stored[ $name ] );

            if ( ! $has_flag ) {
                $source = 'default';
            } elseif ( null !== $migrated ) {
                $source = 'migrated from ' . $migrated;
            } else {
                $source = 'set';
            }

            $out[ $name ] = [
                'enabled' => $this->is_enabled( $name ),
                'source'  => $source,
                'default' => self::default_for( $name ),
            ];
        }

        return $out;
    }

    /**
     * Switch a module on or off, and persist it.
     *
     * Writes the WHOLE resolved set, not just the one key, so that a site whose
     * flags were still implicit ends up with every module explicitly recorded.
     * Half-explicit state is what makes an upgrade path hard to reason about, and
     * this is the moment it costs nothing to remove.
     *
     * @return bool The state now in force. False for an unknown module, which is
     *              never written.
     */
    public function set( string $name, bool $enabled ): bool {
        if ( ! self::is_known( $name ) ) {
            return false;
        }

        $flags          = $this->flags();
        $flags[ $name ] = $enabled;

        $this->persist( $flags );
        $this->flags = $flags;

        // The stored flags are now a deliberate choice rather than a migration's
        // guess, so the note that explains the guess stops being true.
        if ( null !== $this->migrated_from() ) {
            $this->settings->set( self::KEY_MIGRATED_FROM, '' );
        }

        return $enabled;
    }

    /**
     * Settle this site's flags and record which version installed it.
     *
     * ---------------------------------------------------------------------------
     * 🚨 CALL THIS FIRST IN THE ACTIVATION HOOK. THE ORDER IS LOAD-BEARING.
     * ---------------------------------------------------------------------------
     * migrate() identifies a pre-registry site by the option row carrying data
     * with no `installed_version` beside it. The activation hook also mints the
     * monitoring secret, which WRITES to that row - so running the secret first on
     * a brand-new install would leave migrate() looking at a populated row that no
     * version stamped, concluding "this site has been running an older build", and
     * switching consent ON at the moment of installation. That is precisely the
     * outcome this whole class exists to prevent, and nothing would report it.
     *
     * ModulesActivationOrderTest pins the order in bulldogs-site-worker.php.
     */
    public function bootstrap( string $version ): void {
        // Resolves and persists, which is what actually settles the flags.
        $this->flags();

        $this->settings->set( self::KEY_INSTALLED_VERSION, $version );
    }

    /**
     * @return array<string, bool>
     */
    private function flags(): array {
        if ( null !== $this->flags ) {
            return $this->flags;
        }

        $stored = $this->stored();

        if ( is_array( $stored ) ) {
            return $this->flags = $this->normalise( $stored );
        }

        // Nothing stored: either a fresh install, or a site upgrading from a
        // version that had no registry. migrate() is the only thing that can tell
        // those apart, and it only ever runs once.
        $flags = $this->migrate();
        $this->persist( $flags );

        return $this->flags = $flags;
    }

    /**
     * The stored flags, or null when the key has never been written.
     *
     * The null/array distinction is the difference between "this site has been
     * through the registry" and "it has not", so the default is null rather than
     * [] - an empty array is a legitimate stored value meaning "every module on
     * its default", and conflating the two would re-run the migration forever.
     */
    private function stored(): ?array {
        $raw = $this->settings->get( self::KEY, null );
        return is_array( $raw ) ? $raw : null;
    }

    /**
     * Stored flags -> a complete, trustworthy set.
     *
     * Strict `true`/`false` only. A module whose flag is missing, or is `1`, `"0"`,
     * null or an array, gets its compiled-in default - which for consent is off.
     * Unknown keys in the stored array are ignored rather than honoured: a module
     * that does not exist cannot be booted, and a typo must not become a decision.
     *
     * @param array<int|string, mixed> $stored
     * @return array<string, bool>
     */
    private function normalise( array $stored ): array {
        $flags = [];
        foreach ( self::known() as $name ) {
            $value          = $stored[ $name ] ?? null;
            $flags[ $name ] = is_bool( $value ) ? $value : self::default_for( $name );
        }
        return $flags;
    }

    /**
     * The one-time decision for a site that has no stored flags.
     *
     * ---------------------------------------------------------------------------
     * THE UPGRADE THAT MUST NOT SILENTLY UN-GATE A LIVE SITE
     * ---------------------------------------------------------------------------
     * `template.bulldogs.digital` and `beaupropertystaging.com` are gating today,
     * on 0.6.2, and neither has a stored module flag - because the concept did not
     * exist when they were set up. Read "no stored flag" as "fresh install, use the
     * defaults" and both sites stop gating the moment they update: no banner, no
     * `optin` filter, `wp_has_consent()` back to returning true for everything, and
     * nothing anywhere reporting it. That is the worst possible outcome of adding
     * this feature, so absence of a flag is NOT read as "fresh".
     *
     * Two signals separate an upgrade from a new install, and neither is a guess:
     *
     *   1. `installed_version` is stamped by the activation hook from this version
     *      onwards. A site that has it introduced itself under the registry, so its
     *      flags are simply the defaults. (A fresh install ALWAYS reaches this via
     *      Modules::bootstrap() - see the ordering note there.)
     *   2. Without it, anything already in the option row was written by a build
     *      that had no registry, and a site running that build had the consent
     *      module unconditionally registered. Whatever else was true of it, it was
     *      gating - so it keeps gating.
     *
     * The consent-configuration keys are checked separately from "the row has
     * anything in it" only so the reason can be reported accurately; either is
     * enough on its own.
     *
     * Wrong in the safe direction by construction: the error this can make is
     * enabling consent on a site that did not need it, which is visible on the
     * next page load as a banner. The error it cannot make is removing a gate
     * nobody notices is gone.
     *
     * @return array<string, bool>
     */
    private function migrate(): array {
        $flags = $this->normalise( [] );

        if ( null !== $this->settings->get( self::KEY_INSTALLED_VERSION, null ) ) {
            return $flags;
        }

        $reason = $this->pre_registry_evidence();
        if ( null === $reason ) {
            return $flags;
        }

        $flags[ self::CONSENT ] = true;
        $this->settings->set( self::KEY_MIGRATED_FROM, $reason );

        return $flags;
    }

    /**
     * Why we believe this site was already running the consent module, or null.
     *
     * The string is printed by `wp bulldogs module list`, so it is written for an
     * operator checking a site after an upgrade rather than for a parser.
     */
    private function pre_registry_evidence(): ?string {
        foreach ( self::CONSENT_CONFIG_KEYS as $key ) {
            $value = $this->settings->get( $key, null );
            if ( null === $value || '' === $value || [] === $value ) {
                continue;
            }
            return 'a pre-0.7.0 install carrying consent configuration (' . $key . ')';
        }

        if ( [] !== $this->settings->keys() ) {
            return 'a pre-0.7.0 install';
        }

        return null;
    }

    /** The migration note, or null when there is none. */
    private function migrated_from(): ?string {
        $note = $this->settings->get( self::KEY_MIGRATED_FROM, null );
        return is_string( $note ) && '' !== $note ? $note : null;
    }

    /** @param array<string, bool> $flags */
    private function persist( array $flags ): void {
        $this->settings->set( self::KEY, $flags );
    }
}
