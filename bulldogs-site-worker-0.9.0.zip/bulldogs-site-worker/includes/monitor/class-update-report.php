<?php
namespace Bulldogs\SiteWorker\Monitor;

/**
 * The `updates` section of the findings response: what WordPress's own update
 * check said about every installed plugin and theme.
 *
 * ---------------------------------------------------------------------------
 * WHY THIS EXISTS
 * ---------------------------------------------------------------------------
 * WP Fleet reads plugin versions agentlessly and asks wordpress.org what is
 * current. That answers nothing for a premium plugin - Elementor Pro, JetEngine,
 * WP Rocket - because wordpress.org has never heard of it. Measured 21 Aug 2026:
 * 323 of 864 components were "unknown", 232 of them premium. WordPress itself
 * already holds the answer for those, because the vendor's own updater writes it
 * into the same transient the Plugins screen reads.
 *
 * ---------------------------------------------------------------------------
 * 🚨 THREE STATES, NEVER TWO. THIS IS THE WHOLE DESIGN.
 * ---------------------------------------------------------------------------
 * `update_plugins` has two lists and a slug's membership is the signal:
 *
 *   - in `response`  -> an updater answered and something newer exists
 *   - in `no_update` -> an updater answered and this is current
 *   - in NEITHER     -> nothing answered. Nobody checked this component.
 *
 * The third state is the one that matters. A vendor updater whose licence has
 * lapsed usually just stops answering, so the plugin appears in neither list and
 * the Plugins screen looks perfectly healthy. WP Rocket has been unlicensed since
 * Feb 2026 and is on 41 fleet sites: reading "no update flagged" as "current"
 * would turn 41 honest unknowns into 41 false green ticks. So "neither" is
 * reported as `unchecked`, with the reason, and never collapsed into `current`.
 *
 * Two more ways the transient can be answering a question about something else,
 * both also reported as `unchecked` rather than trusted:
 *
 *   - The installed version differs from the version the last check was run
 *     against (`checked`). The plugin has changed since, so the answer is about a
 *     version that is no longer there.
 *   - The component is not in `checked` at all: it was installed after the last
 *     check ran.
 *
 * ⚠️ `current` is not proof. A vendor updater on a dead licence COULD inject a
 * stale `no_update` entry rather than bailing out. WP Fleet keeps its
 * cross-estate floor (the highest version seen anywhere) as a second opinion for
 * exactly that reason; this report does not try to be the only one.
 *
 * `package` on an available update is reported because it is the closest thing
 * to a licence signal WordPress exposes: many vendor updaters announce the new
 * version but leave the download URL empty when the licence will not allow it.
 * An update you cannot install is a different job from one you can.
 */
class UpdateReport {
    public const STATE_UPDATE_AVAILABLE = 'update_available';
    public const STATE_CURRENT          = 'current';
    public const STATE_UNCHECKED        = 'unchecked';

    /** WordPress has never run an update check here, or the transient is unreadable. */
    public const REASON_NO_CHECK = 'no_update_check';
    /** In neither list. No updater answered for it - often a lapsed licence. */
    public const REASON_NO_UPDATER = 'no_updater_answered';
    /** Installed after the last check ran. */
    public const REASON_NOT_IN_CHECK = 'not_in_last_check';
    /** A different version was installed when the last check ran. */
    public const REASON_VERSION_CHANGED = 'installed_version_changed';
    /** Listed as an update, but with no version we could read. */
    public const REASON_MALFORMED = 'malformed_update_entry';

    /** Bound on the response. A site with more components than this is reported as truncated. */
    public const MAX_COMPONENTS = 500;

    /**
     * Read WordPress's own state and interpret it.
     *
     * @return array{last_checked:array{plugins:?int,themes:?int}, components:array<int,array<string,mixed>>, truncated:bool}
     */
    public function gather(): array {
        if ( ! function_exists( 'get_plugins' ) && defined( 'ABSPATH' ) && is_readable( ABSPATH . 'wp-admin/includes/plugin.php' ) ) {
            // Not loaded on a REST request. It only defines functions.
            require_once ABSPATH . 'wp-admin/includes/plugin.php';
        }

        $plugins = [];
        if ( function_exists( 'get_plugins' ) ) {
            foreach ( (array) get_plugins() as $file => $headers ) {
                if ( ! is_string( $file ) || ! is_array( $headers ) ) {
                    continue;
                }
                $plugins[ $file ] = [
                    'name'    => isset( $headers['Name'] ) && is_string( $headers['Name'] ) ? $headers['Name'] : null,
                    'version' => isset( $headers['Version'] ) && is_string( $headers['Version'] ) ? $headers['Version'] : null,
                ];
            }
        }

        $themes = [];
        if ( function_exists( 'wp_get_themes' ) ) {
            foreach ( (array) wp_get_themes() as $stylesheet => $theme ) {
                if ( ! is_string( $stylesheet ) || ! is_object( $theme ) || ! method_exists( $theme, 'get' ) ) {
                    continue;
                }
                $name    = $theme->get( 'Name' );
                $version = $theme->get( 'Version' );
                $themes[ $stylesheet ] = [
                    'name'    => is_string( $name ) && '' !== $name ? $name : null,
                    'version' => is_string( $version ) && '' !== $version ? $version : null,
                ];
            }
        }

        return $this->interpret(
            $plugins,
            function_exists( 'get_site_transient' ) ? get_site_transient( 'update_plugins' ) : false,
            $themes,
            function_exists( 'get_site_transient' ) ? get_site_transient( 'update_themes' ) : false
        );
    }

    /**
     * Pure: the installed components plus the two transients, in; the section, out.
     *
     * @param array<string, array{name:?string, version:?string}> $plugins Plugin file => headers.
     * @param mixed $plugin_transient The `update_plugins` site transient, as WordPress returns it.
     * @param array<string, array{name:?string, version:?string}> $themes Stylesheet => headers.
     * @param mixed $theme_transient The `update_themes` site transient.
     * @return array{last_checked:array{plugins:?int,themes:?int}, components:array<int,array<string,mixed>>, truncated:bool}
     */
    public function interpret( array $plugins, mixed $plugin_transient, array $themes, mixed $theme_transient ): array {
        $components = [];

        foreach ( $plugins as $file => $meta ) {
            $components[] = $this->classify( 'plugins', self::plugin_slug( (string) $file ), (string) $file, $meta, $plugin_transient );
        }
        foreach ( $themes as $stylesheet => $meta ) {
            $components[] = $this->classify( 'themes', (string) $stylesheet, (string) $stylesheet, $meta, $theme_transient );
        }

        $truncated = count( $components ) > self::MAX_COMPONENTS;

        return [
            'last_checked' => [
                'plugins' => self::last_checked( $plugin_transient ),
                'themes'  => self::last_checked( $theme_transient ),
            ],
            'components'   => array_slice( $components, 0, self::MAX_COMPONENTS ),
            'truncated'    => $truncated,
        ];
    }

    /**
     * The slug WP Fleet uses for a plugin: its directory under wp-content/plugins,
     * because that is what the agentless inventory lists. A single-file plugin in
     * the plugins root has no directory, so its file name stands in - WP Fleet does
     * not track those, and a slug that matches nothing is harmless.
     */
    public static function plugin_slug( string $file ): string {
        $dir = dirname( $file );
        if ( '.' !== $dir && '' !== $dir ) {
            return $dir;
        }
        return preg_replace( '/\.php$/', '', basename( $file ) ) ?? $file;
    }

    /**
     * @param array{name:?string, version:?string} $meta
     * @return array<string, mixed>
     */
    private function classify( string $kind, string $slug, string $key, array $meta, mixed $transient ): array {
        $version = $meta['version'] ?? null;
        $row     = [
            'kind'           => $kind,
            'slug'           => $slug,
            'name'           => $meta['name'] ?? null,
            'version'        => $version,
            'state'          => self::STATE_UNCHECKED,
            'latest_version' => null,
            'package'        => null,
            'reason'         => null,
        ];

        if ( ! is_object( $transient ) ) {
            $row['reason'] = self::REASON_NO_CHECK;
            return $row;
        }

        // What version the last check was run against. `checked` is written by
        // WordPress core itself on every check, so its absence for a key means the
        // component arrived after that check - not that it was checked and passed.
        $checked = isset( $transient->checked ) && is_array( $transient->checked ) ? $transient->checked : null;
        if ( null !== $checked ) {
            if ( ! array_key_exists( $key, $checked ) ) {
                $row['reason'] = self::REASON_NOT_IN_CHECK;
                return $row;
            }
            $checked_version = $checked[ $key ];
            if ( null !== $version && is_scalar( $checked_version ) && (string) $checked_version !== $version ) {
                $row['reason'] = self::REASON_VERSION_CHANGED;
                return $row;
            }
        }

        $response = isset( $transient->response ) && is_array( $transient->response ) ? $transient->response : [];
        $current  = isset( $transient->no_update ) && is_array( $transient->no_update ) ? $transient->no_update : [];

        if ( array_key_exists( $key, $response ) ) {
            $entry       = $response[ $key ];
            $new_version = self::field( $entry, 'new_version' );

            if ( null === $new_version ) {
                $row['reason'] = self::REASON_MALFORMED;
                return $row;
            }

            $row['latest_version'] = $new_version;

            // An updater answered, and the version it names is not newer. That is a
            // real answer - "the latest is what you have" - so it reads as current.
            if ( null !== $version && version_compare( $new_version, $version, '<=' ) ) {
                $row['state'] = self::STATE_CURRENT;
                return $row;
            }

            $package        = self::field( $entry, 'package' );
            $row['state']   = self::STATE_UPDATE_AVAILABLE;
            $row['package'] = null !== $package;
            return $row;
        }

        if ( array_key_exists( $key, $current ) ) {
            $row['state']          = self::STATE_CURRENT;
            $row['latest_version'] = self::field( $current[ $key ], 'new_version' ) ?? $version;
            return $row;
        }

        $row['reason'] = self::REASON_NO_UPDATER;
        return $row;
    }

    /** One non-empty string field from a transient entry, which is an object for plugins and an array for themes. */
    private static function field( mixed $entry, string $name ): ?string {
        $value = null;
        if ( is_object( $entry ) && isset( $entry->{$name} ) ) {
            $value = $entry->{$name};
        } elseif ( is_array( $entry ) && isset( $entry[ $name ] ) ) {
            $value = $entry[ $name ];
        }
        if ( is_int( $value ) || is_float( $value ) ) {
            $value = (string) $value;
        }
        return is_string( $value ) && '' !== trim( $value ) ? trim( $value ) : null;
    }

    private static function last_checked( mixed $transient ): ?int {
        if ( ! is_object( $transient ) || ! isset( $transient->last_checked ) || ! is_numeric( $transient->last_checked ) ) {
            return null;
        }
        $at = (int) $transient->last_checked;
        return $at > 0 ? $at : null;
    }
}
