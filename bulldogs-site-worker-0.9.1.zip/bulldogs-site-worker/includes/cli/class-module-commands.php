<?php
namespace Bulldogs\SiteWorker\CLI;

use Bulldogs\SiteWorker\Consent\BannerCategories;
use Bulldogs\SiteWorker\Consent\BannerRenderer;
use Bulldogs\SiteWorker\Consent\ConsentDependency;
use Bulldogs\SiteWorker\Consent\TagRegistry;
use Bulldogs\SiteWorker\Modules;
use Bulldogs\SiteWorker\Settings;
use WP_CLI;

/**
 * `wp bulldogs module ...` - the switches.
 *
 * ---------------------------------------------------------------------------
 * WHY THIS IS THE ROLLOUT SURFACE
 * ---------------------------------------------------------------------------
 * The plugin goes onto every site dormant and is switched on per site, later, at
 * our own pace. There is no admin UI and none is planned, so these three
 * commands are the entire mechanism for that - and the two that change something
 * are the moment to catch the mistakes that are otherwise invisible:
 *
 *   - enabling consent on a site with no cookie policy URL renders a banner with
 *     no policy link, which is itself the compliance gap the banner exists to
 *     close. Switching consent on is the last point at which anyone is looking.
 *   - enabling consent on a site with no categories to offer renders NO banner
 *     while `wp_get_consent_type` is nonetheless filtered to `optin`. Nothing on
 *     that page can ever consent: Site Kit stays denied forever and the client's
 *     analytics dies silently, looking fine the whole time.
 *
 * Both are refusals, not warnings. A warning printed by a scripted fleet rollout
 * is a line of output nobody reads.
 *
 * ---------------------------------------------------------------------------
 * POSITIONAL ARGUMENTS, NOT FLAGS
 * ---------------------------------------------------------------------------
 * Same trap as `wp bulldogs consent policy-url`: `--url` is a WP-CLI GLOBAL
 * runtime parameter, so the runner consumes it before the subcommand is
 * dispatched and it never reaches $assoc - which turned that command into a
 * silent no-op on every install. The reserved list has grown before, so the
 * module name is positional here rather than a flag with a name we are betting
 * stays free. See the long note in class-cli-commands.php.
 */
class ModuleCommands {
    /** Fields `list` will print. */
    private const LIST_FIELDS = [ 'module', 'status', 'source', 'notes' ];

    /**
     * Modules whose disabling needs saying out loud and confirming.
     *
     * Consent, because it un-gates tracking the moment it takes effect. Update,
     * because a site that cannot receive fixes has quietly left the fleet. The
     * monitor is absent deliberately: switching it off stops us seeing the site,
     * which is recoverable and changes nothing for a visitor.
     */
    private const CONFIRM_ON_DISABLE = [ Modules::CONSENT, Modules::UPDATE ];

    /**
     * List every module and whether it is switched on here.
     *
     * On a fleet sweep this is the rollout tracker: which sites are dormant,
     * which have been switched on, and - after an upgrade - which had consent
     * turned on by the migration rather than by a person.
     *
     * ## OPTIONS
     *
     * [--format=<format>]
     * : Render output in a particular format.
     * ---
     * default: table
     * options:
     *   - table
     *   - json
     *   - csv
     *   - yaml
     *   - count
     * ---
     *
     * ## EXAMPLES
     *
     *     wp bulldogs module list
     *     wp bulldogs module list --format=json
     *
     * @subcommand list
     *
     * @param array $args  Positional arguments. Unused.
     * @param array $assoc Associative arguments.
     */
    public function list_( $args, $assoc ): void {
        $format = isset( $assoc['format'] ) && is_string( $assoc['format'] ) ? $assoc['format'] : 'table';

        \WP_CLI\Utils\format_items(
            $format,
            self::rows( ( new Modules( new Settings() ) )->all() ),
            self::LIST_FIELDS
        );
    }

    /**
     * Switch a module on.
     *
     * Enabling `consent` REFUSES on a site that is not configured for it - no
     * usable cookie policy URL, or nothing for the banner to offer. Both produce
     * a site that looks switched on and is not compliant, and both are trivially
     * fixable at this moment and expensive to find later. What is missing is
     * printed, with the command that fixes it.
     *
     * ## OPTIONS
     *
     * <module>
     * : Which module. One of consent, monitor, update.
     *
     * ## EXAMPLES
     *
     *     wp bulldogs module enable consent
     *     wp bulldogs module enable monitor
     *
     * @param array $args  Positional arguments. $args[0] is the module name.
     * @param array $assoc Associative arguments.
     */
    public function enable( $args, $assoc ): void {
        $settings = new Settings();
        $modules  = new Modules( $settings );
        $module   = self::read_module( $args );

        if ( null === $module ) {
            return;
        }

        if ( $modules->is_enabled( $module ) ) {
            WP_CLI::success( sprintf( 'The %s module is already enabled here. Nothing changed.', $module ) );
            return;
        }

        if ( Modules::CONSENT === $module ) {
            $blockers = self::consent_blockers(
                BannerRenderer::normalise_policy_url( $settings->get( 'policy_url', '' ) ),
                self::banner_categories( $settings ),
                ( new ConsentDependency() )->is_available()
            );

            if ( [] !== $blockers ) {
                // Every blocker, not the first one. An operator working through a
                // site over SSH should learn everything that is missing in one
                // pass rather than one refusal at a time.
                foreach ( $blockers as $blocker ) {
                    WP_CLI::log( '  - ' . $blocker );
                }
                // The `return` matters for the same reason it does elsewhere in
                // these commands: error() halts today, but a future runner that
                // does not would fall through into the write.
                WP_CLI::error( 'this site is not configured for consent yet, so the banner would not be compliant. Fix the above, then re-run.' );
                return;
            }
        }

        $modules->set( $module, true );

        WP_CLI::success( sprintf( 'The %s module is now enabled.', $module ) );

        if ( Modules::CONSENT === $module ) {
            WP_CLI::log(
                'Purge the page cache, then verify from OUTSIDE: load the site in a clean profile, check the '
                . 'banner renders, that nothing non-essential is stored before a choice, and that accepting '
                . 'actually measures. A banner being present is not evidence anything is gated.'
            );
        }
    }

    /**
     * Switch a module off.
     *
     * ⚠️ Disabling `consent` UN-GATES TRACKING IMMEDIATELY. The module stops
     * registering entirely - no `wp_get_consent_type` filter, no banner, no
     * blocked tags - so the site behaves exactly as it would with this plugin not
     * installed. That is the intended dormant state, and it is not a small change
     * to make by accident, so it needs `--yes`.
     *
     * ## OPTIONS
     *
     * <module>
     * : Which module. One of consent, monitor, update.
     *
     * [--yes]
     * : Confirm. Required for consent and update; see the warnings printed
     * without it.
     *
     * ## EXAMPLES
     *
     *     wp bulldogs module disable consent --yes
     *     wp bulldogs module disable monitor
     *
     * @param array $args  Positional arguments. $args[0] is the module name.
     * @param array $assoc Associative arguments.
     */
    public function disable( $args, $assoc ): void {
        $settings = new Settings();
        $modules  = new Modules( $settings );
        $module   = self::read_module( $args );

        if ( null === $module ) {
            return;
        }

        if ( ! $modules->is_enabled( $module ) ) {
            WP_CLI::success( sprintf( 'The %s module is already disabled here. Nothing changed.', $module ) );
            return;
        }

        if ( in_array( $module, self::CONFIRM_ON_DISABLE, true ) && empty( $assoc['yes'] ) ) {
            foreach ( self::disable_warnings( $module, self::banner_categories( $settings ), self::tag_count( $settings ) ) as $warning ) {
                WP_CLI::log( '  - ' . $warning );
            }
            WP_CLI::error( sprintf( 'refusing to disable %s without --yes. Re-run with --yes if that is what you want.', $module ) );
            return;
        }

        $modules->set( $module, false );

        WP_CLI::success( sprintf( 'The %s module is now disabled.', $module ) );

        if ( Modules::CONSENT === $module ) {
            WP_CLI::warning(
                'Tracking on this site is now ungated. Purge the page cache - a cached copy of the gated '
                . 'page will otherwise keep serving blocked tags to visitors who now have no way to unblock them.'
            );
        }
    }

    /**
     * What stops consent being switched on here, in the operator's words.
     *
     * Pure and static so it can be tested: everything else on this class touches
     * WP_CLI or the option store and cannot be exercised without a real install.
     *
     * @param string|null $policy_url The stored cookie policy URL, ALREADY through
     *                                BannerRenderer::normalise_policy_url() - the
     *                                same rule the banner uses. Null means there is
     *                                nothing the banner would render.
     * @param string[]    $categories BannerCategories::all().
     * @return string[]
     */
    public static function consent_blockers(
        ?string $policy_url,
        array $categories,
        bool $dependency_available = false
    ): array {
        $blockers = [];

        /*
         * 🚨 DEFAULTS TO FALSE, i.e. to REFUSING. A caller that forgets this
         * argument gets a noisy refusal, never a silently permitted enable. The
         * failure direction matters more here than anywhere else in these
         * commands: enabling consent without wp-consent-api filters
         * wp_get_consent_type to "optin" while rendering no banner, so nothing
         * on the page can ever consent and the client's analytics dies silently.
         * See ConsentDependency.
         */
        if ( ! $dependency_available ) {
            $blockers[] = 'The wp-consent-api plugin is not active. The consent gate depends on it: without '
                . 'it the banner script has no dependency handle and WordPress renders nothing, while '
                . 'wp_get_consent_type is still filtered to "optin" - so consent stays denied forever and '
                . 'the site\'s analytics dies silently. Install and activate it first: '
                . 'wp plugin install wp-consent-api --activate';
        }

        if ( null === $policy_url ) {
            $blockers[] = 'No usable cookie policy URL. The banner would render with no policy link, which is '
                . 'the disclosure PECR asks for. Set one: wp bulldogs consent policy-url /cookie-policy';
        }

        if ( [] === self::clean_categories( $categories ) ) {
            $blockers[] = 'Nothing for the banner to offer - no registered tags and no Site Kit module that '
                . 'implies a category. Enabling consent here would filter wp_get_consent_type to "optin" and '
                . 'render NO banner, so nothing on the page could ever consent and any consent-aware tag would '
                . 'stay denied forever. Register the site\'s tags first (wp bulldogs consent add), or leave '
                . 'consent off - there is nothing here to gate.';
        }

        return $blockers;
    }

    /**
     * What disabling this module actually does, in the operator's words.
     *
     * Pure and static, for the same reason consent_blockers() is.
     *
     * @param string   $module     The module being disabled.
     * @param string[] $categories BannerCategories::all() - what the banner is offering today.
     * @param int      $tags       How many valid entries the tag registry holds.
     * @return string[]
     */
    public static function disable_warnings( string $module, array $categories, int $tags ): array {
        if ( Modules::UPDATE === $module ) {
            return [
                'This site stops checking for plugin updates, so it will not receive fixes - including fixes '
                . 'to the consent gating itself. Nothing will report that it has fallen behind.',
            ];
        }

        if ( Modules::VERSIONS === $module ) {
            return [
                'WP Fleet stops receiving this site\'s update-check results. Premium plugins here go back to '
                . 'reading "unchecked", so an update waiting on one of them will not be flagged.',
            ];
        }

        if ( Modules::SECURITY === $module ) {
            return [
                'WP Fleet stops receiving this site\'s Wordfence scan results. Anything Wordfence finds here - '
                . 'modified core files, malware, weak passwords - will not reach the fleet view.',
            ];
        }

        if ( Modules::CONSENT !== $module ) {
            return [];
        }

        $warnings = [];

        $clean = self::clean_categories( $categories );
        if ( [] !== $clean ) {
            $warnings[] = sprintf(
                'Tracking is UN-GATED immediately. This site currently asks about %s; it will stop asking, and '
                . 'whatever is running will run for every visitor without being offered a choice.',
                implode( ', ', $clean )
            );
        }

        $warnings[] = 'wp_get_consent_type stops being filtered, so upstream wp_has_consent() goes back to '
            . 'returning true for EVERY category - every other consent-aware plugin on this site treats '
            . 'visitors as fully consented.';

        if ( $tags > 0 ) {
            // Not a footnote. The rollout SOP moves the ungated copy of each tag
            // OUT of the theme or the header-script plugin, so the registry is the
            // only place those tags exist. The module that renders them not
            // running means they are not on the page at all.
            $warnings[] = sprintf(
                '%d registered tag(s) stop rendering ENTIRELY, not just ungated - this plugin is the only place '
                . 'they exist once the rollout has removed the ungated copy. The client stops being measured by '
                . 'them until they are put back somewhere.',
                $tags
            );
        }

        $warnings[] = 'Site Kit\'s Consent Mode defaults go back to being region-scoped, so its tag is gated '
            . 'inside the EEA by its own defaults and ungated everywhere else.';

        return $warnings;
    }

    /**
     * Module states as flat printable rows.
     *
     * Pure and static, same reasoning as above. Nothing is cast: `all()` is built
     * from a stored option, and a `wp` command fatalling mid-rollout across 29
     * sites is the failure this whole surface is written to avoid.
     *
     * @param array<string, mixed> $states Modules::all().
     * @return array<int, array{module:string, status:string, source:string, notes:string}>
     */
    public static function rows( array $states ): array {
        $rows = [];

        foreach ( $states as $name => $state ) {
            if ( ! is_array( $state ) ) {
                continue;
            }

            $enabled = isset( $state['enabled'] ) && true === $state['enabled'];
            $default = isset( $state['default'] ) && true === $state['default'];

            $notes = '';
            if ( $enabled !== $default ) {
                $notes = sprintf( 'default is %s', $default ? 'enabled' : 'disabled' );
            }

            $rows[] = [
                'module' => (string) $name,
                'status' => $enabled ? 'enabled' : 'disabled',
                'source' => isset( $state['source'] ) && is_string( $state['source'] ) ? $state['source'] : '',
                'notes'  => $notes,
            ];
        }

        return $rows;
    }

    /**
     * A module name from the positional argument, or null having already errored.
     *
     * An unknown name is an error naming the ones that exist rather than a silent
     * no-op: `wp bulldogs module enable concent` reporting success while changing
     * nothing is how a site ends up believed to be live and isn't.
     *
     * Null rather than a halt in the signature for the same reason the other
     * commands here `return` after WP_CLI::error(): error() exits today, and every
     * caller is written so that a runner which did not would still change nothing.
     */
    private static function read_module( $args ): ?string {
        $name = isset( $args[0] ) && is_string( $args[0] ) ? strtolower( trim( $args[0] ) ) : '';

        if ( ! Modules::is_known( $name ) ) {
            WP_CLI::error( sprintf(
                'unknown module "%s". Known modules: %s',
                $name,
                implode( ', ', Modules::known() )
            ) );
            return null;
        }

        return $name;
    }

    /**
     * What the banner would offer on this site.
     *
     * Asked through BannerCategories rather than the registry, for the reason that
     * class exists: a Site-Kit-only site has an EMPTY registry and still needs a
     * banner, and most of the fleet is that shape. Keying the preflight off the
     * registry would refuse to enable consent on exactly the sites that need it.
     *
     * @return string[]
     */
    private static function banner_categories( Settings $settings ): array {
        return ( new BannerCategories( new TagRegistry( $settings ) ) )->all();
    }

    /** How many entries the registry will actually emit. */
    private static function tag_count( Settings $settings ): int {
        return count( ( new TagRegistry( $settings ) )->all() );
    }

    /**
     * $categories may come from a stored option by way of TagRegistry, so anything
     * that is not a non-empty string is dropped rather than cast - the same rule
     * Scanner::clean_categories applies for the same reason.
     *
     * @param array<int|string, mixed> $categories
     * @return string[]
     */
    private static function clean_categories( array $categories ): array {
        $clean = [];
        foreach ( $categories as $category ) {
            if ( is_string( $category ) && '' !== $category && ! in_array( $category, $clean, true ) ) {
                $clean[] = $category;
            }
        }
        return $clean;
    }
}
