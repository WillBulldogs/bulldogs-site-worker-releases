<?php
namespace Bulldogs\SiteWorker\Monitor;

/**
 * Records which vendor updaters actually ran during WordPress's last update check.
 *
 * ---------------------------------------------------------------------------
 * WHY THIS EXISTS
 * ---------------------------------------------------------------------------
 * Most premium updaters (WP Rocket, Crocoblock's Jet dashboard, Revolution
 * Slider) write into the transient's `response` list when a newer version exists
 * and NEVER write `no_update`. So an up-to-date premium plugin sits in neither
 * list, exactly like one whose updater never ran. Measured 22 Sep 2026: every
 * up-to-date WP Rocket and Jet plugin on the fleet read "unchecked", licensed or
 * not, which left ~140 components permanently unknown.
 *
 * The two cases differ in one fact the transient does not keep: whether the
 * vendor's updater was hooked in when the check ran. Jet's dashboard, for one,
 * only loads in some request contexts, so a check from WP-Cron can run without
 * it. This class keeps that fact.
 *
 * It hooks `pre_set_site_transient_update_{plugins,themes}` LAST, so every
 * vendor filter has already run, and notes which KNOWN vendor updaters were
 * attached. It changes nothing: the value passes through untouched and nothing
 * is rendered or requested.
 *
 * ⚠️ AN ALLOWLIST, NOT "WHATEVER DIRECTORY THE CALLBACK LIVES IN". The first
 * version inferred the owner from the callback's file, and a read-only dry run on
 * a client site (25 Sep 2026) promptly marked JetEngine current off
 * `Jet_Engine_Modules_Updater` - a hook that updates JetEngine's add-on MODULES,
 * never JetEngine itself, whose real updater (the Jet dashboard) had not loaded.
 * Plenty of plugins hook this filter for other reasons (Rank Math sends an email
 * from it). So only updaters we have read and know to be response-only count;
 * an unlisted vendor stays `unchecked`, which is the safe direction.
 *
 * ---------------------------------------------------------------------------
 * WHAT IT CAN AND CANNOT PROVE
 * ---------------------------------------------------------------------------
 * "The vendor's updater ran and offered nothing" is what WordPress's own Plugins
 * screen shows as up to date, and it is what this lets UpdateReport say. It is
 * still an inference - an updater whose remote call failed also offers nothing -
 * so the report marks it with its own basis (`updater_silent`) and WP Fleet keeps
 * the cross-estate floor as the second opinion.
 *
 * The witness is only believed about the check it saw: it stores the check's own
 * `last_checked` stamp, and UpdateReport requires an exact match.
 */
class UpdaterWitness {
    public const OPTION = 'bulldogs_sw_updater_witness';

    /**
     * Updater callbacks known to write `response` only, never `no_update`, keyed
     * by class then method, and the plugin directory each answers for. Read from
     * the vendors' own code on LDN1, 22-25 Sep 2026.
     *
     * The Jet dashboard is resolved at witness time instead (see jet_owners()):
     * one copy ships inside each Crocoblock plugin, and whichever loads checks
     * every plugin REGISTERED with it - which is not the same as every `jet-*`.
     */
    private const KNOWN = [
        'WP_Rocket\\Engine\\Plugin\\UpdaterSubscriber' => [ 'maybe_add_rocket_update_data' => 'wp-rocket' ],
    ];

    private const JET_MANAGER = 'Jet_Dashboard\\Plugin_Manager';

    public function register(): void {
        add_filter( 'pre_set_site_transient_update_plugins', [ $this, 'witness_plugins' ], PHP_INT_MAX );
        add_filter( 'pre_set_site_transient_update_themes', [ $this, 'witness_themes' ], PHP_INT_MAX );
    }

    /** @param mixed $value */
    public function witness_plugins( $value ) {
        $this->record( 'plugins', 'pre_set_site_transient_update_plugins', $value );
        return $value;
    }

    /** @param mixed $value */
    public function witness_themes( $value ) {
        $this->record( 'themes', 'pre_set_site_transient_update_themes', $value );
        return $value;
    }

    /** @param mixed $value */
    private function record( string $kind, string $hook, $value ): void {
        try {
            if ( ! is_object( $value ) || ! isset( $value->last_checked ) || ! is_numeric( $value->last_checked ) ) {
                return;
            }
            $owners = self::owners( self::callbacks( $hook ), [ self::class, 'jet_owners' ] );

            $stored = get_option( self::OPTION );
            $stored = is_array( $stored ) ? $stored : [];
            $stored[ $kind ] = [
                'last_checked' => (int) $value->last_checked,
                'owners'       => $owners,
            ];
            update_option( self::OPTION, $stored, false );
        } catch ( \Throwable $e ) {
            // Never allowed to break an update check on a client site.
            if ( function_exists( 'error_log' ) ) {
                error_log( 'bulldogs-site-worker: updater witness failed: ' . $e->getMessage() );
            }
        }
    }

    /** @return array<int, mixed> Every callable attached to the hook right now. */
    private static function callbacks( string $hook ): array {
        global $wp_filter;
        if ( ! isset( $wp_filter[ $hook ] ) || ! is_object( $wp_filter[ $hook ] ) || ! isset( $wp_filter[ $hook ]->callbacks ) ) {
            return [];
        }
        $out = [];
        foreach ( (array) $wp_filter[ $hook ]->callbacks as $by_priority ) {
            foreach ( (array) $by_priority as $cb ) {
                if ( is_array( $cb ) && isset( $cb['function'] ) ) {
                    $out[] = $cb['function'];
                }
            }
        }
        return $out;
    }

    /**
     * The known updaters among the attached callbacks, as the directories they
     * answer for. Pure apart from $jet, which is handed the Jet dashboard's
     * manager so the suite can stand one in.
     *
     * @param array<int, mixed> $callbacks
     * @param callable(object): array<int, string> $jet
     * @return array<int, string>
     */
    public static function owners( array $callbacks, callable $jet ): array {
        $found = [];
        foreach ( $callbacks as $fn ) {
            if ( ! is_array( $fn ) || 2 !== count( $fn ) || ! is_object( $fn[0] ) || ! is_string( $fn[1] ) ) {
                continue;
            }
            $class = get_class( $fn[0] );
            if ( isset( self::KNOWN[ $class ][ $fn[1] ] ) ) {
                $found[ self::KNOWN[ $class ][ $fn[1] ] ] = true;
            } elseif ( self::JET_MANAGER === $class && 'check_update' === $fn[1] ) {
                foreach ( $jet( $fn[0] ) as $dir ) {
                    $found[ $dir ] = true;
                }
            }
        }
        $out = array_keys( $found );
        sort( $out );
        return $out;
    }

    /**
     * The plugin directories the loaded Jet dashboard checks. Empty on anything
     * unexpected, which leaves them unchecked.
     *
     * @return array<int, string>
     */
    public static function jet_owners( object $manager ): array {
        $dashboard = 'Jet_Dashboard\\Dashboard';
        if ( ! class_exists( $dashboard ) || ! method_exists( $dashboard, 'get_instance' ) ) {
            return [];
        }
        $registered = $dashboard::get_instance()->get_registered_plugins();
        $out        = [];
        foreach ( is_array( $registered ) ? $registered : [] as $file => $data ) {
            $path = is_array( $data ) && isset( $data['file'] ) && is_string( $data['file'] ) ? $data['file'] : ( is_string( $file ) ? $file : '' );
            $dir  = dirname( $path );
            if ( '' !== $dir && '.' !== $dir ) {
                $out[] = $dir;
            }
        }
        return $out;
    }

    /**
     * What was witnessed for one kind, or null.
     *
     * @return array{last_checked:int, owners:array<int,string>}|null
     */
    public static function read( string $kind ): ?array {
        if ( ! function_exists( 'get_option' ) ) {
            return null;
        }
        $stored = get_option( self::OPTION );
        if ( ! is_array( $stored ) || ! isset( $stored[ $kind ] ) || ! is_array( $stored[ $kind ] ) ) {
            return null;
        }
        $row = $stored[ $kind ];
        if ( ! isset( $row['last_checked'], $row['owners'] ) || ! is_numeric( $row['last_checked'] ) || ! is_array( $row['owners'] ) ) {
            return null;
        }
        return [
            'last_checked' => (int) $row['last_checked'],
            'owners'       => array_values( array_filter( $row['owners'], 'is_string' ) ),
        ];
    }

    /** Whether an owner list covers this slug. */
    public static function covers( array $owners, string $slug ): bool {
        return in_array( $slug, $owners, true );
    }
}
