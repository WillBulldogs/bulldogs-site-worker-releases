<?php
/**
 * Uninstall - remove everything this plugin stored.
 *
 * ---------------------------------------------------------------------------
 * ⚠️ UNINSTALLING THIS PLUGIN STOPS THE CLIENT'S ANALYTICS.
 * ---------------------------------------------------------------------------
 * This is not a side effect of deleting data - it is the design. Per the rollout
 * SOP, the ungated copy of every registered tag is REMOVED from wherever it used
 * to live (the header-script plugin, the theme, the GTM container) and the tag is
 * re-emitted by this plugin instead, gated on consent. So the registry is not a
 * record of tags that exist elsewhere; it is the only place those tags exist.
 *
 * Delete the plugin and the tags stop rendering. The site stays perfectly
 * compliant and measures nothing, which is exactly the failure state this whole
 * project was built to end - reached, this time, by tidying up.
 *
 * Deleting the option also destroys the per-site secret, so WP Fleet's registered
 * copy becomes dead. A reinstall generates a new one and needs SOP step 9 re-run.
 *
 * Before removing this plugin from a site: put the tags back somewhere ungated
 * first, or accept that the client's analytics ends here.
 *
 * ---------------------------------------------------------------------------
 * Everything lives in ONE option row.
 * ---------------------------------------------------------------------------
 * Tags, policy URL, site secret, findings and the last-scan stamp are all keys
 * inside Settings::OPTION. There is no custom table, no post type, no transient
 * and no user meta, so this file has exactly one thing to do.
 *
 * The option NAME is read from the class rather than written out again here. A
 * literal would be a second definition of the same string, and the failure mode
 * of it drifting is silent: uninstall reports success and leaves the row behind,
 * including the secret.
 *
 * WordPress does not load the plugin file when it runs uninstall.php, so the
 * class is required explicitly. class-settings.php declares a class and nothing
 * else - no WordPress calls at load time - so requiring it here is safe.
 *
 * Single-site only, deliberately. delete_option() clears the current site's row;
 * on multisite each site's row would need its own pass. Every site in scope is a
 * standalone install, and writing untested multisite iteration would be worse
 * than stating the limit.
 */

defined( 'WP_UNINSTALL_PLUGIN' ) || exit;

require_once __DIR__ . '/includes/class-settings.php';

if ( function_exists( 'delete_option' ) ) {
    delete_option( \Bulldogs\SiteWorker\Settings::OPTION );
    // What UpdaterWitness saw during the last update check. A literal, so uninstall
    // does not have to load the monitor classes.
    delete_option( 'bulldogs_sw_updater_witness' );
}
